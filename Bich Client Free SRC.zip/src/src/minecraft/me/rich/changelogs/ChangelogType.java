package me.rich.changelogs;

public enum ChangelogType {
	ADD, DELETE, IMPROVED, FIXED, PROTOTYPE, NONE, NEW,
}