package me.rich.event.events;

public enum EventType {
    PRE,
    POST,
    SEND,
    RECEIVE

}
