package me.rich.module.player;

import me.rich.module.Category;
import me.rich.module.Feature;

public class KeepSprint extends Feature {

	public KeepSprint() {
		super("KeepSprint", 0, Category.MOVEMENT);
	}
}
