package net.minecraft.advancements;

import net.minecraft.util.ResourceLocation;

public interface ICriterionInstance
{
    ResourceLocation func_192244_a();
}
