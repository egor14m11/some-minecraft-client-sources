@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.advancements.critereon;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;