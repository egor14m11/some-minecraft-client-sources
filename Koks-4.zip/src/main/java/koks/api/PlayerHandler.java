package koks.api;

public class PlayerHandler {
    public static float yaw, pitch, prevYaw, prevPitch;
    public static boolean shouldSprintReset;
}
