package koks.api.decryption;

public class Encrypt {
}
