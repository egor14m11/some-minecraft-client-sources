package koks.api.manager.notification;

public enum NotificationType {
    INFO, WARNING
}
