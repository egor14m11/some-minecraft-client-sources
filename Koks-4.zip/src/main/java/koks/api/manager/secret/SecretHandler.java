package koks.api.manager.secret;

public class SecretHandler {
    public static boolean catMode, love;
}
