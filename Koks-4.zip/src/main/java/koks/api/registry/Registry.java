package koks.api.registry;

/**
 * @author kroko
 * @created on 21.01.2021 : 09:53
 */
public interface Registry {

    void initialize();

}
