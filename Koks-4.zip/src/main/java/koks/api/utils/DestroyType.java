package koks.api.utils;

/**
 * Copyright 2020, Koks Team
 * Please don't use the code
 */
public enum DestroyType {
    CLICK,BREAK;
}
