package koks.api.via;

/**
 *@usage: for register another Protocols which are not in Via
 */
public class ProtocolRegistry {

}
