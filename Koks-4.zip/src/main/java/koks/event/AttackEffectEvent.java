package koks.event;

import koks.api.event.Event;

public class AttackEffectEvent extends Event {
}
