package koks.event;

import koks.api.event.Event;

public class InventorySwitchSyncEvent extends Event {
}
