package koks.event;

import koks.api.event.Event;
import koks.api.registry.module.Module;

public class PotionUpdateEvent extends Event {
}
