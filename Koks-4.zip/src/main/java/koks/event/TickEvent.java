package koks.event;

import koks.api.event.Event;

/**
 * Copyright 2020, Koks Team
 * Please don't use the code
 */
public class TickEvent extends Event {
}
