package koks.event;

import koks.api.event.Event;

/**
 * @author kroko
 * @created on 21.01.2021 : 10:04
 */
public class UpdateEvent extends Event {
}
