package koks.mainmenu.elements;

public abstract class Action {

    public abstract void doAction();

}
