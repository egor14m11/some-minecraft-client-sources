package koks.shader;

import koks.api.shader.Shader;

@Shader.Info(fragment = "esp")
public class ESPShader extends Shader {
}
