package xyz.monsoon;

import xyz.monsoon.gui.AccountGuiScreen;
import xyz.monsoon.util.Encryption;
import xyz.monsoon.util.HWID;

public class Main {

    public static String name = "MonsoonGrabber";
    public static String version = "v1.0a";

    public static void main(String[] args)
    {
        AccountGuiScreen.initScreen();
    }

    public static String getEncryptedAuthString(String username, String password)
    {
        return Encryption.hashMD5(Encryption.encryptAES(getAuthString(username, password), AccountGuiScreen.key));
    }

    public static String getAuthString(String username, String password)
    {
        return username + "::" + password + "::" + HWID.hwid;
    }

}
