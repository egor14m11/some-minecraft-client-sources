package xyz.monsoon.gui;

import xyz.monsoon.Main;
import xyz.monsoon.util.HWID;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AccountGuiScreen implements ActionListener {

    public static String key = "1behk23kbb2kf8o22";

    public static JPanel panel = new JPanel();
    public static JFrame frame = new JFrame();
    public static JLabel userLabel = new JLabel("MonsoonGrabber");
    public static JLabel usernameLabel = new JLabel("Username");
    public static JLabel passwordLabel = new JLabel("Password");
    public static JTextField usernameText = new JTextField(20);
    public static JTextField passwordText = new JTextField(20);
    public static JButton loginButton = new JButton("Grab");

    public static void initScreen()
    {
        frame.setSize(500, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBackground(Color.DARK_GRAY);
        frame.setVisible(true);
        frame.setResizable(false);
        frame.add(panel);

        panel.setLayout(null);
        panel.add(userLabel);
        panel.setBackground(new Color(44, 43,43));
        panel.add(usernameText);
        panel.add(passwordText);
        panel.add(usernameLabel);
        panel.add(passwordLabel);
        panel.add(loginButton);

        userLabel.setBounds(150, 20, 500, 30);
        userLabel.setForeground(Color.WHITE);
        userLabel.setFont(new Font("Roboto", Font.PLAIN, 25));

        usernameText.setBounds(160, 100,  165, 25);

        passwordText.setBounds(160, 150, 165, 25);

        usernameLabel.setBounds(205, 70, 500, 25);
        usernameLabel.setFont(new Font("Roboto", Font.PLAIN, 15));
        usernameLabel.setForeground(Color.WHITE);

        passwordLabel.setBounds(205, 125, 500, 25);
        passwordLabel.setFont(new Font("Roboto", Font.PLAIN, 15));
        passwordLabel.setForeground(Color.WHITE);

        loginButton.setBounds(160, 190, 165, 25);
        loginButton.addActionListener(new AccountGuiScreen());

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        String username = usernameText.getText();
        String password = passwordText.getText();

        copy(Main.getEncryptedAuthString(username, password));
        showMessage("Your authentication string has been copied to your clipboard.");
    }

    public static void showMessage(String msg)
    {
        JOptionPane.showMessageDialog(frame, msg);
    }

    public static String getUser(String username,  String password)
    {
        return HWID.hwid + "::" + username + "::" + password;
    }

    public static void copy(String input)
    {
        StringSelection stringSelection = new StringSelection(input);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
    }


}

