package dev.monsoon.event;

public enum EventDirection {

	INCOMING,
	OUTGOING;
	
}
