package dev.monsoon.event;

public enum EventType {

	PRE,
	POST;
	
}
