package dev.monsoon.event.listeners;

import dev.monsoon.event.Event;

public class EventUpdate extends Event<EventUpdate> {
	
}
