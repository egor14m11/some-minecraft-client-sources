package dev.monsoon.module.setting;

import dev.monsoon.module.base.Module;

public class Setting {
	
	public String name;
	public boolean focused, shouldRender;
	public Module parent;
	
}
