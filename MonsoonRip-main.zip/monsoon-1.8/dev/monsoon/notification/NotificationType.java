package dev.monsoon.notification;

public enum NotificationType {
    INFO, WARNING, ERROR, SUCCESS, FAIL;
}
