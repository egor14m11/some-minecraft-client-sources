package dev.monsoon.ui.hud;

import net.minecraft.client.gui.GuiScreen;

public class HUDConfigScreen extends GuiScreen {
	


}
