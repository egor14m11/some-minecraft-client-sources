// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook;

import net.arikia.dev.drpc.DiscordUser;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ChatComponentText;
import dev.windhook.hooks.HookManager;
import dev.windhook.overlay.TabGui1;
import dev.windhook.overlay.ToggledModules1;
import dev.windhook.module.modules.client.ClickGuiNew;
import dev.windhook.gui.astolfogui.AstolfoScreen;
import org.apache.logging.log4j.LogManager;
import dev.windhook.auth.HWIDManager;
import dev.windhook.module.modules.Client;
import dev.windhook.config.ConfigManager;
import net.arikia.dev.drpc.DiscordRPC;
import dev.windhook.utils.Files;
import dev.windhook.utils.Strings;
import java.io.File;
import dev.windhook.gui.altmanager.GuiAltManager;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.Display;
import net.minecraft.client.resources.Locale;
import dev.windhook.gui.dropdowngui.DropdownGUI;
import dev.windhook.gui.clickgui.ClickGui;
import dev.windhook.utils.Config;
import dev.windhook.font.Font;
import dev.windhook.thealtening.AltService;
import dev.windhook.account.AccountManager;
import dev.windhook.irc.IRCClient;
import dev.windhook.replay.ReplayManager;
import dev.windhook.module.ModuleManager;
import dev.windhook.command.CommandManager;
import dev.windhook.friends.FriendsManager;
import dev.windhook.event.EventManager;
import dev.windhook.utils.Blur;
import net.arikia.dev.drpc.DiscordEventHandlers;

public class BaseClient
{
    public String clientName;
    public String clientVersion;
    public String author;
    public Integer userUID;
    public String userUserName;
    public static BaseClient instance;
    public DiscordEventHandlers handlers;
    public static DiscordRP discordRP;
    public String defaultUsername;
    public Blur blur;
    public EventManager eventManager;
    public FriendsManager friendsManager;
    public CommandManager commandManager;
    public ModuleManager moduleManager;
    public ReplayManager replayManager;
    public IRCClient ircClient;
    public AccountManager accountManager;
    public AltService altService;
    public Font font;
    public Font font2;
    public Font font2Bold;
    public String packageBase;
    public Config genericConfig;
    public ClickGui clickGui;
    public DropdownGUI dropdownGUI;
    public boolean isReplay;
    public boolean isRecording;
    public Locale englishLocale;
    public ClassLoader loader;
    
    public DropdownGUI getDropdownGUI() {
        return this.dropdownGUI;
    }
    
    public void setDropdownGUI(final DropdownGUI dropdownGUI) {
        this.dropdownGUI = dropdownGUI;
    }
    
    public BaseClient() {
        this.author = "sigmaclientwastaken & Segation";
        this.defaultUsername = "WindHookUser";
        this.packageBase = "dev.windhook";
        this.clientName = "WindHook";
        this.clientVersion = "b7";
        this.author = "sigmaclientwastaken & Segation";
        this.defaultUsername = "WindHookUser";
        this.packageBase = "dev.windhook";
        this.isReplay = false;
        this.isRecording = false;
        this.loader = ClassLoader.getSystemClassLoader();
        BaseClient.instance = this;
    }
    
    public void initialize() {
        (BaseClient.instance = this).printStartup();
        this.setupShutdownHook();
        Display.setTitle(String.format("%1$s %2$s | Loading...", this.clientName, this.clientVersion));
        this.englishLocale = new Locale();
        this.ircClient = new IRCClient("chat.freenode.net", 6667, Minecraft.getMinecraft().getSession().getUsername(), "#WaveLengthBaseClient");
        new GuiAltManager();
        final String absolutePath = new File(".").getAbsolutePath();
        final String string = (absolutePath.contains("jars") ? new File(".").getAbsolutePath().substring(0, absolutePath.length() - 2) : new File(".").getAbsolutePath()) + Strings.getSplitter() + this.clientName;
        final String string2 = string + Strings.getSplitter() + "alts";
        Files.createRecursiveFolder(string2);
        this.accountManager = new AccountManager(new File(string2));
        this.clickGui = new ClickGui();
        BaseClient.discordRP.start();
        this.eventManager = new EventManager();
        this.friendsManager = new FriendsManager();
        this.replayManager = new ReplayManager();
        this.commandManager = new CommandManager(".");
        this.moduleManager = new ModuleManager();
        this.commandManager.registerCommands();
        this.altService = new AltService();
        this.switchToMojang();
        this.genericConfig = new Config(new File(string + Strings.getSplitter() + "config.cfg"));
        Minecraft.getMinecraft().setWindowIcon("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAZdJREFUOE9jZKAQMFKon2EQGCDIIMhfGdV39N9blvdXH13csfh6TyvIW7Pd9h/QE7WwvPX+0tXus0VZl14ePcHAwMDaEDB5r6aCvvmZayfmdu8qy4J5gTlOr6hm0aW+RqQwYdwT+uLN868Pb8duM7dAFo93yO1beGByIUgMHgYzXPaczdjjYgxTGKaakXf6zZEDiz2OnbZZzsfJwMDwDyQXqB9XtP7ioskMDAy/UQyQ4FBQ4OUQELj94cIFkMSe0JffXVaLc0ZoZmdzs/DzzL3c1gkSnxa88WbWWn91mEUosbDU68zN6G0m6goCCgpe8slJ0y7W1oFceSzq6y+rZdysMnzKKizs7DwPXl8DW4LiAhDHXzk5fePduQsWe506HrvNzJSBgeEvSHyK0/Z9Ey4U5xZYdyzN2exngJx20NMBY4lx30x9MWvr2O3m2jCFvLxSIpMcV5zc/2L1ikWnJlfjMUCUZ03U7tcv3jy5evrp/g0Lr/a2gBQ3uszeoamo63bmzf4dXesrvfC5gOSUPQiSMsluRtMAAK9QkhGiYFsMAAAAAElFTkSuQmCC", "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAABNZJREFUWEdjZBhgwDjA9jOMOmA0BGAhwIQlMf7DkUCxqQUp/Q/F6NpAdqCHNFwto5aMnnllaPcJ5l/sDGw/uRnYfvIwsP3kYnj/9e2dyK1GqsimSXOqyGwMvv6YgRFq3v//DP/+/wPjv///Mlgv58GI0jUpp///Yv/K8JftJwMXIx8DFyM/AzcjH4NdjwxYLUwDS5RZRrW7cnh6/HJHOailf3CEAAtIfI3f5dNKAtoGz78+vu+9Vl6NgYEBFGLYQo0Zag/jqqLDv5Jne4l8/vz5AwMDw19kB4DYrBvir/wKWKjDxsDA8JtA+cB4KvrHP0ZGJgYmRmYG48XMIEeBDcQFHHS8Y5Kc8mbFTXLnQlaDEmRLQo89231zw9SFl7pa8RnmIh8S1GS1YO2+xxvnu8mHJE47X5O34Fr3ZHx65qRvebfp/NKWTaeW9+F0gLWMq1e12Zz1Xuvk2fEZtjnw3ktuVl4Bp1WifCeivv34x/Dvm9UyHm48ejiXZR/4FjXVgZWBgQElajESza7gZ/9jdxqKv/zy8hUOA9n2hb7+ufLGlKaZlxvrd4U8fS3AISLitkRc8APDB1DcYoBU6/JuIxWLiMyFgbLYsgiK2GSnrYe+//n6ruxQWAA2w9L06urD1LIaXNZIgELpl4d8eFCTzaK1B55uWFp2IDwGm541iad/tx/I9z57/9gugg6Q51dXnO925J7TalGspSTI919+f/zot0FFDGbYqZhf/1mYWP4bLWLCKCOkOaVlJkVtehw81xireVgF94S8/FN2OMjm3MujJ5BdLMEjIbrG59arpmPJobserV4Dk1vmfeakhpChWexOS4Orr05dRNbT5r5kBxP7P+6KTXG22EIHqwMKTHr7LSScvSO2GIDyNxz0OaxfYyXlEWyxjBPkU1BpBgbqvHrqSwPO3bj3/urlsC36esh6NsVe+5+10Vf1yae7d4h2AAMDA+f+sLffHFcJgwoReOFyLvbvv9sfr1wM36RviG7Yyegff//9/8tkuYwb7jh9KWubBtfpBwMX6oHMwQpw1oabA+69W3y1u2rV7ekzQDq1RE0MF3ucOBe/xUz/yvtzl9BNq7OcNcNdITK943Ru3OY7CxaD5OcHHLpz4e2hfRMP16SR7AAPhcjIAqOuWR7rZHlBmlf6XLikwK+hY76UA2tlJMogyrM2/PZnUAL1WicvwMDAwLQx9trf5MV2fG8Y3nwm2QGg8ntvyMt/oWs0+d8xvPt8JOLTv6PPtq0sPxQRgcuw7YGPP7Ixs/E5r9HjCVT3jo0wT+8JX2TOg0s9SBxvg2S264FzDz5dP3/u5cFdFebTVvhs0xX5/PnpW1wG+iklJOUYtc7d8nDhVGs11/illyZWbrq8ZArZDlAW1NOZ5rTt4vc/395zsfDwuK2V4sBnGMhDWyPu/vvD9uP/b9bvjCFzTQhWUoSaZIxbIm//ZfnDzrjy2tTa+Vc7YZUUPAuiOYhxeuC2K2JC4lqvfj1+mLk4QBFHIwWuDa8D1qSc+c/ym42B+S8bA9NfVgamv8wMTP+ZGdxXy6KUAyDTNsXc+PeP+RfjH9afDH9YfjL8Yf3B8J/lL0Nsvzu4yCYnEYL0gCxCz8OgcgFb3Y9NLSikcDVswG4iFAUEopxy6VEHjIbAgIcAANGfxjDZ7+/RAAAAAElFTkSuQmCC");
        DiscordRPC.discordInitialize("903625392177434644", this.handlers = new DiscordEventHandlers.Builder().setReadyEventHandler(BaseClient::lambda$initialize$0).build(), true);
        this.blur = new Blur();
    }
    
    public void afterMinecraft() {
        Display.setTitle(String.format("%1$s %2$s | dsc.gg/windhook", this.clientName, this.clientVersion));
        this.font = new Font("dev.windhook.font.fonts", "jellolight", 25, 30, 33, 50, 55);
        this.font2 = new Font("dev.windhook.font.fonts", "mono", 25, 30, 33, 50, 55);
        this.registerHuds();
        this.dropdownGUI = new DropdownGUI();
        ConfigManager.setupConfigManager();
        ConfigManager.loadDefault();
        Client.launch();
        this.moduleManager.setupArray();
        this.blur.init();
        HWIDManager.hwidCheck();
        if (!Minecraft.getMinecraft().isFullScreen()) {
            Minecraft.getMinecraft().toggleFullscreen();
        }
        this.userUID = HWIDManager.getUserUID();
        this.userUserName = HWIDManager.getUserName();
        LogManager.getLogger("WindHook").info("Welcome " + this.userUserName + ", UID: " + this.userUID.toString() + "!");
        ClickGuiNew.astolfoScreen = new AstolfoScreen();
    }
    
    public void registerHuds() {
        new ToggledModules1();
        new TabGui1();
    }
    
    public String getClientName() {
        return this.clientName;
    }
    
    public String getClientVersion() {
        return this.clientVersion;
    }
    
    public String getAuthor() {
        return "sigmaclientwastaken & Segation";
    }
    
    public String getDefaultUsername() {
        return "WindHookUser";
    }
    
    public EventManager getEventManager() {
        return this.eventManager;
    }
    
    public FriendsManager getFriendsManager() {
        return this.friendsManager;
    }
    
    public CommandManager getCommandManager() {
        return this.commandManager;
    }
    
    public ModuleManager getModuleManager() {
        return this.moduleManager;
    }
    
    public IRCClient getIRCClient() {
        return this.ircClient;
    }
    
    public AccountManager getAccountManager() {
        return this.accountManager;
    }
    
    public AltService getAltService() {
        return this.altService;
    }
    
    @Deprecated
    public Font getFontRenderer() {
        return this.font;
    }
    
    public Font getFont() {
        return this.font;
    }
    
    public String getPackageBase() {
        return "dev.windhook";
    }
    
    public Config getGenericConfig() {
        return this.genericConfig;
    }
    
    public ClickGui getClickGui() {
        return this.clickGui;
    }
    
    public Locale getEnglishLocale() {
        return this.englishLocale;
    }
    
    public void setClientName(final String clientName) {
        this.clientName = clientName;
    }
    
    public void setClientVersion(final String clientVersion) {
        this.clientVersion = clientVersion;
    }
    
    public ClassLoader getLoader() {
        return this.loader;
    }
    
    public void switchToMojang() {
        this.altService.switchService(AltService.EnumAltService.MOJANG);
    }
    
    public void switchToTheAltening() {
        this.altService.switchService(AltService.EnumAltService.THEALTENING);
    }
    
    public void setupShutdownHook() {
        System.out.printf("Shutdown hook %s initialized.%n", HookManager.installShutdownHook(new Thread(this::lambda$setupShutdownHook$1)) ? "successfully" : "unsuccessfully");
    }
    
    public void printStartup() {
        LogManager.getLogger("WindHook").info(String.format("%s %s starting up.", this.clientName, this.clientVersion));
    }
    
    public static void chatMessage(final String str) {
        Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage(new ChatComponentText("§8[§j!§8] §7" + str));
    }
    
    public static BaseClient getInstance() {
        return BaseClient.instance;
    }
    
    public static DiscordRP getDiscordRP() {
        return BaseClient.discordRP;
    }
    
    public void lambda$setupShutdownHook$1() {
        DiscordRPC.discordShutdown();
        ConfigManager.saveDefault();
        LogManager.getLogger("WindHook").info(String.format("%s %s shutting down.", this.clientName, this.clientVersion));
    }
    
    public static void lambda$initialize$0(final DiscordUser discordUser) {
        LogManager.getLogger("WindHook").info("Welcome " + discordUser.username + "#" + discordUser.discriminator + "!");
    }
    
    static {
        BaseClient.discordRP = new DiscordRP();
    }
}
