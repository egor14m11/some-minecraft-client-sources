// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook;

import net.arikia.dev.drpc.DiscordRichPresence;
import net.arikia.dev.drpc.DiscordRPC;
import net.arikia.dev.drpc.DiscordUser;
import net.arikia.dev.drpc.callbacks.ReadyCallback;
import net.arikia.dev.drpc.DiscordEventHandlers;

public class DiscordRP
{
    public boolean running;
    public long created;
    
    public DiscordRP() {
        this.running = true;
        this.created = ((long)1845672668 ^ 0x6E02BADCL);
    }
    
    public void start() {
        this.created = System.currentTimeMillis();
        DiscordRPC.discordInitialize("841725650631917589", new DiscordEventHandlers.Builder().setReadyEventHandler(new ReadyCallback(this) {
            public DiscordRP this$0;
            
            @Override
            public void apply(final DiscordUser discordUser) {
                System.out.println("Welcome " + discordUser.username + "#" + discordUser.discriminator);
                this.this$0.update("Loading Windhook Client", "");
            }
        }).build(), true);
        new Thread(this, "Discord RPC Callback") {
            public DiscordRP this$0;
            
            @Override
            public void run() {
                while (DiscordRP.access$000(this.this$0)) {
                    DiscordRPC.discordRunCallbacks();
                }
            }
        }.start();
    }
    
    public void shutdown() {
        this.running = false;
        DiscordRPC.discordShutdown();
    }
    
    public void update(final String details, final String s) {
        final DiscordRichPresence.Builder builder = new DiscordRichPresence.Builder(s);
        builder.setBigImage("large", "");
        builder.setDetails(details);
        builder.setStartTimestamps(this.created);
        DiscordRPC.discordUpdatePresence(builder.build());
    }
    
    public static boolean access$000(final DiscordRP discordRP) {
        return discordRP.running;
    }
}
