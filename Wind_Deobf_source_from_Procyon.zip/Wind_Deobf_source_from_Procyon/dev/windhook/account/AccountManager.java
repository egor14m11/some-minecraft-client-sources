// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.account;

import java.util.Collection;
import java.util.Iterator;
import java.util.function.Consumer;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.Reader;
import java.io.FileReader;
import com.google.gson.JsonParser;
import com.google.gson.JsonElement;
import java.io.PrintWriter;
import com.google.gson.GsonBuilder;
import java.io.File;
import com.google.gson.Gson;
import java.util.ArrayList;

public class AccountManager
{
    public ArrayList<Account> accounts;
    public Gson gson;
    public File altsFile;
    public String alteningKey;
    public String lastAlteningAlt;
    public Account lastAlt;
    
    public AccountManager(final File file) {
        this.accounts = new ArrayList<Account>();
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        this.altsFile = new File(file.toString() + File.separator + "alts.json");
        this.load();
    }
    
    public void save() {
        if (this.altsFile == null) {
            return;
        }
        if (!this.altsFile.exists()) {
            this.altsFile.createNewFile();
        }
        final PrintWriter printWriter = new PrintWriter(this.altsFile);
        printWriter.write(this.gson.toJson((JsonElement)this.toJson()));
        printWriter.close();
    }
    
    public void load() {
        if (!this.altsFile.exists()) {
            this.save();
            return;
        }
        this.fromJson(new JsonParser().parse((Reader)new FileReader(this.altsFile)).getAsJsonObject());
    }
    
    public JsonObject toJson() {
        final JsonObject jsonObject = new JsonObject();
        final JsonArray jsonArray = new JsonArray();
        this.getAccounts().forEach((Consumer<? super Account>)AccountManager::lambda$toJson$0);
        if (this.alteningKey != null) {
            jsonObject.addProperty("altening", this.alteningKey);
        }
        if (this.lastAlteningAlt != null) {
            jsonObject.addProperty("alteningAlt", this.lastAlteningAlt);
        }
        if (this.lastAlt != null) {
            jsonObject.add("lastalt", (JsonElement)this.lastAlt.toJson());
        }
        jsonObject.add("accounts", (JsonElement)jsonArray);
        return jsonObject;
    }
    
    public void fromJson(final JsonObject jsonObject) {
        if (jsonObject.has("altening")) {
            this.alteningKey = jsonObject.get("altening").getAsString();
        }
        if (jsonObject.has("alteningAlt")) {
            this.lastAlteningAlt = jsonObject.get("alteningAlt").getAsString();
        }
        if (jsonObject.has("lastalt")) {
            final Account lastAlt = new Account();
            lastAlt.fromJson(jsonObject.get("lastalt").getAsJsonObject());
            this.lastAlt = lastAlt;
        }
        jsonObject.get("accounts").getAsJsonArray().forEach((Consumer)this::lambda$fromJson$1);
    }
    
    public void remove(final String anotherString) {
        for (final Account o : this.getAccounts()) {
            if (o.getName().equalsIgnoreCase(anotherString)) {
                this.getAccounts().remove(o);
            }
        }
    }
    
    public Account getAccountByEmail(final String anotherString) {
        for (final Account account : this.getAccounts()) {
            if (account.getEmail().equalsIgnoreCase(anotherString)) {
                return account;
            }
        }
        return null;
    }
    
    public String getLastAlteningAlt() {
        return this.lastAlteningAlt;
    }
    
    public void setLastAlteningAlt(final String lastAlteningAlt) {
        this.lastAlteningAlt = lastAlteningAlt;
    }
    
    public String getAlteningKey() {
        return this.alteningKey;
    }
    
    public void setAlteningKey(final String alteningKey) {
        this.alteningKey = alteningKey;
    }
    
    public Account getLastAlt() {
        return this.lastAlt;
    }
    
    public void setLastAlt(final Account lastAlt) {
        this.lastAlt = lastAlt;
    }
    
    public ArrayList<Account> getNotBannedAccounts() {
        final ArrayList<Account> list = new ArrayList<Account>(this.accounts);
        for (int i = 0; i < list.size(); ++i) {
            if (((Account)list.get(i)).isBanned()) {
                list.remove(i);
            }
        }
        return this.accounts;
    }
    
    public ArrayList<Account> getAccounts() {
        return this.accounts;
    }
    
    public void lambda$fromJson$1(final JsonElement jsonElement) {
        final JsonObject jsonObject = (JsonObject)jsonElement;
        final Account e = new Account();
        e.fromJson(jsonObject);
        this.getAccounts().add(e);
    }
    
    public static void lambda$toJson$0(final JsonArray jsonArray, final Account account) {
        jsonArray.add((JsonElement)account.toJson());
    }
}
