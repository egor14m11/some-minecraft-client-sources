// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.auth;

import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.awt.Component;
import javax.swing.JFrame;

public class DisplayUtils
{
    public static void Display() {
        new Frame().setVisible(false);
        throw new NoStackTraceThrowable("Verification was unsuccessful!");
    }
    
    public static class Frame extends JFrame
    {
        public Frame() {
            this.setTitle("Verification failed.");
            this.setDefaultCloseOperation(2);
            this.setLocationRelativeTo(null);
            copyToClipboard();
            JOptionPane.showMessageDialog(this, "Sorry, you are not on the HWID list.\nHWID: " + SystemUtils.getSystemInfo() + "\n(Copied to clipboard.)", "Could not verify your HWID successfully.", -1, UIManager.getIcon("OptionPane.errorIcon"));
        }
        
        public static void copyToClipboard() {
            final StringSelection stringSelection = new StringSelection(SystemUtils.getSystemInfo());
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, stringSelection);
        }
    }
}
