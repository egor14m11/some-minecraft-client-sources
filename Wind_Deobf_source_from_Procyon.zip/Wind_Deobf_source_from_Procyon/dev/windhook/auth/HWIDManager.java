// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.auth;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class HWIDManager
{
    public static String pastebinURL;
    public static String pastebinInfoURL;
    public static List<String> hwids;
    
    public static void hwidCheck() {
        HWIDManager.hwids = URLReader.readURL();
        if (!HWIDManager.hwids.contains(SystemUtils.getSystemInfo())) {
            DisplayUtils.Display();
            throw new NoStackTraceThrowable("");
        }
    }
    
    public static String getUserName() {
        HWIDManager.hwids = URLReader.readInfoURL();
        final String systemInfo = SystemUtils.getSystemInfo();
        final Iterator<String> iterator = HWIDManager.hwids.iterator();
        while (iterator.hasNext()) {
            final String[] split = iterator.next().split(":");
            if (split[0].equals(systemInfo)) {
                return split[1];
            }
        }
        return null;
    }
    
    public static Integer getUserUID() {
        HWIDManager.hwids = URLReader.readInfoURL();
        final String systemInfo = SystemUtils.getSystemInfo();
        final Iterator<String> iterator = HWIDManager.hwids.iterator();
        while (iterator.hasNext()) {
            final String[] split = iterator.next().split(":");
            if (split[0].equals(systemInfo)) {
                return Integer.parseInt(split[2]);
            }
        }
        return null;
    }
    
    static {
        HWIDManager.pastebinInfoURL = "https://pastebin.com/raw/xtpTFX1D";
        HWIDManager.pastebinURL = "https://pastebin.com/raw/a6gnmfM3";
        HWIDManager.hwids = new ArrayList<String>();
    }
}
