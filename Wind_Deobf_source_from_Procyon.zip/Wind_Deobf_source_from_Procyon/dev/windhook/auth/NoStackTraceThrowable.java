// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.auth;

public class NoStackTraceThrowable extends RuntimeException
{
    public NoStackTraceThrowable(final String message) {
        super(message);
        this.setStackTrace(new StackTraceElement[0]);
    }
    
    @Override
    public String toString() {
        return "Authentication Failed!";
    }
    
    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}
