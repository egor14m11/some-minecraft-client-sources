// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.auth;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class URLReader
{
    public static List<String> readURL() {
        final ArrayList<String> list = new ArrayList<String>();
        String line;
        while ((line = new BufferedReader(new InputStreamReader(new URL("https://pastebin.com/raw/a6gnmfM3").openStream())).readLine()) != null) {
            list.add(line);
        }
        return list;
    }
    
    public static List<String> readInfoURL() {
        final ArrayList<String> list = new ArrayList<String>();
        String line;
        while ((line = new BufferedReader(new InputStreamReader(new URL("https://pastebin.com/raw/xtpTFX1D").openStream())).readLine()) != null) {
            list.add(line);
        }
        return list;
    }
}
