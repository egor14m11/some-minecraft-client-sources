// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command;

import dev.windhook.BaseClient;
import net.minecraft.client.Minecraft;
import dev.windhook.event.EventListener;

public abstract class Command extends EventListener
{
    public String name;
    public String syntax;
    public String usage;
    public String[] aliases;
    public Minecraft mc;
    public CommandManager commandManager;
    
    public Command(final String name, final String syntax, final String usage, final String... aliases) {
        this.name = name;
        this.syntax = syntax;
        this.usage = usage;
        this.aliases = aliases;
        this.mc = Minecraft.getMinecraft();
        this.commandManager = BaseClient.instance.getCommandManager();
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getSyntax() {
        return this.getSyntax("");
    }
    
    public String getSyntax(final boolean b) {
        return this.getSyntax("", b);
    }
    
    public String getSyntax(final String s) {
        return this.getSyntax(s, true);
    }
    
    public String getSyntax(final String str, final boolean b) {
        return str + (b ? this.commandManager.getTrigger() : "") + this.syntax;
    }
    
    public String getUsage() {
        return this.usage;
    }
    
    public String[] getAliases() {
        return this.aliases;
    }
    
    public abstract String executeCommand(final String p0, final String[] p1);
}
