// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiChat;
import dev.windhook.event.events.KeyPressedEvent;
import dev.windhook.irc.IRCClient;
import dev.windhook.utils.Player;
import dev.windhook.utils.Lists;
import java.util.function.Function;
import dev.windhook.event.events.MessageSentEvent;
import java.util.function.Predicate;
import java.util.Arrays;
import dev.windhook.command.commands.DebugCommand;
import dev.windhook.command.commands.SaveCfgCommand;
import dev.windhook.command.commands.LoadCfgCommand;
import dev.windhook.command.commands.VPhaseCommand;
import dev.windhook.command.commands.ReloadComand;
import dev.windhook.command.commands.ClientCommand;
import dev.windhook.command.commands.BypassValueCommand;
import dev.windhook.command.commands.ToggleCommand;
import dev.windhook.command.commands.FontCommand;
import dev.windhook.command.commands.VClipCommand;
import dev.windhook.command.commands.XRayCommand;
import dev.windhook.command.commands.NamesCommand;
import dev.windhook.command.commands.FriendsCommand;
import dev.windhook.command.commands.BindCommand;
import dev.windhook.command.commands.SetCommand;
import dev.windhook.command.commands.IRCCommand;
import dev.windhook.command.commands.HelpCommand;
import dev.windhook.BaseClient;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import java.util.List;
import dev.windhook.event.EventListener;

public class CommandManager extends EventListener
{
    public List<Command> commands;
    public String trigger;
    public Minecraft mc;
    
    public CommandManager(final String trigger) {
        this.commands = new ArrayList<Command>();
        this.trigger = trigger;
        this.mc = Minecraft.getMinecraft();
        BaseClient.instance.getEventManager().registerListener(this);
    }
    
    public String getTrigger() {
        return this.trigger;
    }
    
    public void registerCommand(final Command command) {
        this.commands.add(command);
    }
    
    public void registerCommands() {
        this.registerCommand(new HelpCommand());
        this.registerCommand(new IRCCommand());
        this.registerCommand(new SetCommand());
        this.registerCommand(new BindCommand());
        this.registerCommand(new FriendsCommand(BaseClient.instance.getFriendsManager()));
        this.registerCommand(new NamesCommand());
        this.registerCommand(new XRayCommand());
        this.registerCommand(new VClipCommand());
        this.registerCommand(new FontCommand());
        this.registerCommand(new ToggleCommand());
        this.registerCommand(new BypassValueCommand());
        this.registerCommand(new ClientCommand());
        this.registerCommand(new ReloadComand());
        this.registerCommand(new VPhaseCommand());
        this.registerCommand(new LoadCfgCommand());
        this.registerCommand(new SaveCfgCommand());
        this.registerCommand(new DebugCommand());
    }
    
    public List<Command> getCommands() {
        return this.commands;
    }
    
    public String getHelpMessage(final String s) {
        return String.format("&cThe command &e%1$s&c does not exist.", s);
    }
    
    public Command getCommand(final String anotherString) {
        for (int i = 0; i < this.commands.size(); ++i) {
            final Command command = this.commands.get(i);
            if (command.getName().equalsIgnoreCase(anotherString) || Arrays.stream(command.getAliases()).anyMatch(anotherString::equalsIgnoreCase)) {
                return command;
            }
        }
        return null;
    }
    
    public Command getCommand(final Class<? extends Command> obj) {
        for (int i = 0; i < this.commands.size(); ++i) {
            final Command command = this.commands.get(i);
            if (command.getClass().equals(obj)) {
                return command;
            }
        }
        return null;
    }
    
    @Override
    public void onMessageSent(final MessageSentEvent messageSentEvent) {
        if (messageSentEvent.isCancelled()) {
            return;
        }
        final String[] original = Arrays.stream(messageSentEvent.getMessage().split(" (?=([^\\\"]*\\\"[^\\\"]*\\\")*[^\\\"]*$)")).map((Function<? super String, ?>)CommandManager::lambda$onMessageSent$0).toArray(CommandManager::lambda$onMessageSent$1);
        final String stringArrayToString = Lists.stringArrayToString(" ", original);
        final String stringArrayToString2 = Lists.stringArrayToString(" ", original);
        final String[] array = Arrays.copyOfRange(original, 1, original.length);
        if (!original[0].startsWith(this.trigger)) {
            if (original[0].startsWith("@")) {
                final IRCClient ircClient = BaseClient.instance.getIRCClient();
                if (ircClient != null && ircClient.isActive()) {
                    ircClient.sendMessage(ircClient.getChannel(), stringArrayToString2.substring(1));
                    Player.sendMessage(String.format("%1$s&6YOU &7(&e&o%2$s&7)&7: &e%3$s", ircClient.getPrefix(), ircClient.getUsername(), stringArrayToString2.substring(1)));
                    messageSentEvent.setCancelled(true);
                }
            }
            return;
        }
        final String substring = original[0].substring(1, original[0].length());
        messageSentEvent.setCancelled(true);
        final Command command = this.getCommand(substring);
        String s = this.getHelpMessage(original[0]);
        if (command != null) {
            s = command.executeCommand(stringArrayToString, array);
        }
        if (s != null && !s.trim().isEmpty()) {
            Player.sendMessage(s);
        }
    }
    
    @Override
    public void onKeyPressed(final KeyPressedEvent keyPressedEvent) {
        if (keyPressedEvent.getKey() == 52) {
            this.mc.displayGuiScreen(new GuiChat(this.trigger));
        }
        else if (keyPressedEvent.getKey() == 145) {
            this.mc.displayGuiScreen(new GuiChat("@"));
        }
    }
    
    public static String[] lambda$onMessageSent$1(final int n) {
        return new String[n];
    }
    
    public static String lambda$onMessageSent$0(final String s) {
        return s.replace("\"", "");
    }
}
