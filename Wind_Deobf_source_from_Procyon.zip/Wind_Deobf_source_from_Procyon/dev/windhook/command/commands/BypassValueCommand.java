// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.utils.RenderUtils;
import dev.windhook.gui.newgui.NewClickGui;
import dev.windhook.module.ModuleManager;
import dev.windhook.command.Command;

public class BypassValueCommand extends Command
{
    public BypassValueCommand() {
        super("bypassvalue", "bypassvalue", "Fixes random errors.", new String[] { "fixme" });
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        ModuleManager.clickGuiNew.newGui = new NewClickGui();
        ModuleManager.clickGuiNew.newGui.fr = RenderUtils.getFontRenderer().getFont(22);
        ModuleManager.clickGuiNew.newGui.small = RenderUtils.getFontRenderer().getFont(17);
        ModuleManager.clickGuiNew.mode.set("Old");
        return String.format("&aFixed!.", new Object[0]);
    }
}
