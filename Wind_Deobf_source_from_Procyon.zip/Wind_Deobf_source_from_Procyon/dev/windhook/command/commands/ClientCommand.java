// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.BaseClient;
import dev.windhook.command.Command;

public class ClientCommand extends Command
{
    public ClientCommand() {
        super("client", "client <version|name> <value>", "Changes the client version/name", new String[0]);
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (array.length < 2) {
            return this.getSyntax("&c");
        }
        final String lowerCase = array[0].toLowerCase();
        switch (lowerCase) {
            case "name": {
                BaseClient.instance.setClientName(array[1]);
                return String.format("&aThe client's name has been succesfully changed to &e%1$s&a.", array[1]);
            }
            case "version": {
                BaseClient.instance.setClientVersion(array[1]);
                return String.format("&aThe client's version has been succesfully changed to &e%1$s&a.", array[1]);
            }
            default: {
                return this.getSyntax("&c");
            }
        }
    }
}
