// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.BaseClient;
import dev.windhook.command.Command;

public class ClientNameCommand extends Command
{
    public ClientNameCommand() {
        super("clientname", "clientname <name>", "Changes the client name", new String[0]);
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (array.length < 1) {
            return this.getSyntax("&c");
        }
        BaseClient.instance.setClientName(array[0]);
        return String.format("&aThe client's name has been succesfully changed to &e%1$s&a.", array[0]);
    }
}
