// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.utils.Config;
import dev.windhook.utils.Strings;
import java.awt.Color;
import dev.windhook.utils.Integers;
import dev.windhook.utils.Random;
import dev.windhook.utils.Lists;
import dev.windhook.BaseClient;
import dev.windhook.command.Command;

public class ColorCommand extends Command
{
    public ColorCommand() {
        super("color", "color <color|colors|reset>", "Set the TabGUI color.", new String[0]);
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (array.length < 1) {
            return this.getSyntax("&c");
        }
        final Config genericConfig = BaseClient.instance.getGenericConfig();
        Color color = null;
        final String lowerCase = array[0].toLowerCase();
        switch (lowerCase) {
            case "colors": {
                return String.format("&eThis is the color list:\n%1$s", Lists.stringArrayToString("&f, ", "&cRED", "&1BLUE", "&3CYAN", "&2GREEN", "&dMAGENTA", "&6ORAGNE", "&eYELLOW", "&5PINK", "&k|&fRANDOM&k|"));
            }
            case "random": {
                color = Random.getRandomLightColor();
                break;
            }
            case "reset": {
                break;
            }
            default: {
                if (Integers.isInteger(array[0])) {
                    color = new Color(Integers.getInteger(array[0]));
                    break;
                }
                color = Strings.getColor(array[0]);
                break;
            }
        }
        if (color == null) {
            return String.format("&cThe color &e%1$s&c does not exist.", array[0].toUpperCase());
        }
        genericConfig.set("tabguicolor", color.getRGB());
        return String.format("&aThe TabGUI color has been succesfully changed to &e%1$s&a.", array[0].toUpperCase());
    }
}
