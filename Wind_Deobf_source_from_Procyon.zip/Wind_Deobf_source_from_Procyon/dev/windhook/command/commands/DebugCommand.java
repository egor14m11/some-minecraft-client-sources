// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.command.Command;

public class DebugCommand extends Command
{
    public DebugCommand() {
        super("debug", "debug", "Fixes random errors.", new String[0]);
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        return String.format("&aPlayerID: " + this.mc.session.getSessionID() + " | ", new Object[0]);
    }
}
