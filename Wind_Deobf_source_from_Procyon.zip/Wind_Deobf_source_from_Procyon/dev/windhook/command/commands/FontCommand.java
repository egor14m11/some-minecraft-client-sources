// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.BaseClient;
import dev.windhook.utils.Integers;
import dev.windhook.command.Command;

public class FontCommand extends Command
{
    public FontCommand() {
        super("font", "font <size>", "Set the font's size", new String[0]);
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (array.length == 0 || !Integers.isInteger(array[1])) {
            return this.getSyntax("&c");
        }
        final int integer = Integers.getInteger(array[1]);
        if (integer < 13 || integer > 45) {
            return "&cPlease, type a number within 13 and 45.";
        }
        final String lowerCase = array[0].toLowerCase();
        switch (lowerCase) {
            case "small": {
                BaseClient.instance.getFontRenderer().setFontSizeSmall(integer);
                return String.format("&aThe small font size has been set to &e%1$d&a.", integer);
            }
            case "normal": {
                BaseClient.instance.getFontRenderer().setFontSizeNormal(integer);
                return String.format("&aThe normal font size has been set to &e%1$d&a.", integer);
            }
            case "large": {
                BaseClient.instance.getFontRenderer().setFontSizeLarge(integer);
                return String.format("&aThe large font size has been set to &e%1$d&a.", integer);
            }
            case "largest": {
                BaseClient.instance.getFontRenderer().setFontSizeLargest(integer);
                return String.format("&aThe largest font size has been set to &e%1$d&a.", integer);
            }
            case "logo": {
                BaseClient.instance.getFontRenderer().setFontSizeLogo(integer);
                return String.format("&aThe logo's font size has been set to &e%1$d&a.", integer);
            }
            default: {
                return this.getSyntax("&c");
            }
        }
    }
}
