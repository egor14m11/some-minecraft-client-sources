// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import java.util.Collection;
import java.util.ArrayList;
import dev.windhook.friends.FriendsManager;
import dev.windhook.command.Command;

public class FriendsCommand extends Command
{
    public FriendsManager friendsManager;
    
    public FriendsCommand(final FriendsManager friendsManager) {
        super("friends", "friends <add|remove|list> [name]", "Manage friends", new String[] { "f", "friend" });
        this.friendsManager = friendsManager;
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (array.length < 1) {
            return this.getSyntax("&c");
        }
        final String lowerCase = array[0].toLowerCase();
        switch (lowerCase) {
            case "add": {
                final String name = this.getName(array);
                if (name == null) {
                    return this.getSyntax("&c");
                }
                if (this.friendsManager.isFriend(name)) {
                    return String.format("&e%1$s&c is already in your friends list.", name);
                }
                this.friendsManager.addFriend(name);
                return String.format("&e%1$s &ahas been added to your friends list.", name);
            }
            case "remove": {
                final String name2 = this.getName(array);
                if (name2 == null) {
                    return this.getSyntax("&c");
                }
                if (!this.friendsManager.isFriend(name2)) {
                    return String.format("&e%1$s&c is NOT in your friends list.", name2);
                }
                this.friendsManager.removeFriend(name2);
                return String.format("&e%1$s &ahas been removed from your friends list.", name2);
            }
            case "list": {
                final ArrayList<String> list = (ArrayList<String>)new ArrayList<Object>(this.friendsManager.getFriends());
                if (list.size() == 0) {
                    return "&eYou don't have any friend :(";
                }
                String string = "";
                for (int i = 0; i < list.size(); ++i) {
                    string = string + ((i == 0) ? "" : "&f, ") + "&e" + (String)list.get(i);
                }
                return String.format("&aThese are your friends: %s", string);
            }
            case "clear": {
                this.friendsManager.clear();
                return "&aYour friends list has been cleared.";
            }
            default: {
                return this.getSyntax("&c");
            }
        }
    }
    
    public String getName(final String[] array) {
        if (array.length < 2) {
            return null;
        }
        return array[1];
    }
}
