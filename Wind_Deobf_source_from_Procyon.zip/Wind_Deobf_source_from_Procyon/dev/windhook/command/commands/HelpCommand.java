// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.utils.Strings;
import java.util.Collection;
import java.util.ArrayList;
import dev.windhook.command.Command;

public class HelpCommand extends Command
{
    public HelpCommand() {
        super("help", "help [module]", "Returns all the commands or a command description.", new String[0]);
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (array.length < 1) {
            final ArrayList<Command> list = (ArrayList<Command>)new ArrayList<Object>(this.commandManager.getCommands());
            String string = "";
            for (int i = 0; i < list.size(); ++i) {
                final Command command = list.get(i);
                string += String.format("%1$s&d%2$s &7-&e %3$s", (i == 0) ? "" : "\n", command.getName(), command.getUsage());
            }
            final int maxChars = Strings.getMaxChars(string.split("\n"));
            final String format = String.format("&7%1$s&f", Strings.multiplyString(" ", maxChars / 4));
            final String format2 = String.format("&f&7&m%1$s&f", Strings.multiplyString("-", maxChars / 6));
            return format + format2 + " &5Help " + format2 + "\n" + string;
        }
        final Command command2 = this.commandManager.getCommand(array[0]);
        if (command2 == null) {
            return this.commandManager.getHelpMessage(array[0]);
        }
        return String.format("&d%1$s &7-&e %2$s", command2.getName(), command2.getSyntax(false));
    }
}
