// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.BaseClient;
import dev.windhook.irc.IRCClient;
import dev.windhook.command.Command;

public class IRCCommand extends Command
{
    public IRCClient ircClient;
    
    public IRCCommand() {
        super("irc", "irc <connect|disconnect|status>", "Connects to the IRC Server.", new String[0]);
        this.ircClient = BaseClient.instance.getIRCClient();
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (array.length < 1) {
            return this.getSyntax("&c");
        }
        final String lowerCase = array[0].toLowerCase();
        switch (lowerCase) {
            case "connect": {
                if (this.ircClient.isActive()) {
                    return String.format("%1$s&cYou are already connected to the IRC.", this.ircClient.getPrefix());
                }
                this.ircClient.start();
                this.ircClient.joinChannel(this.ircClient.getChannel());
                return String.format("%1$s&e&oConnecting to the IRC...", this.ircClient.getPrefix());
            }
            case "disconnect": {
                if (!this.ircClient.isActive()) {
                    return String.format("%1$s&cYou are not connected to the IRC.", this.ircClient.getPrefix());
                }
                this.ircClient.quit("Client disconnected.", false);
                return String.format("%1$s&a&oSuccesfully disconnected from the IRC.", this.ircClient.getPrefix());
            }
            case "status": {
                return String.format("%1$s&e&oYou are %2$sconnected&e&o.", this.ircClient.getPrefix(), this.ircClient.isActive() ? "&a&o" : "&c&onot ");
            }
            default: {
                return this.getSyntax("&c");
            }
        }
    }
}
