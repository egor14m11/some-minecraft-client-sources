// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.config.ConfigManager;
import dev.windhook.command.Command;

public class LoadCfgCommand extends Command
{
    public LoadCfgCommand() {
        super("loadcfg", "loadcfg <config>", "Loads a config.", new String[] { "cfgload" });
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (array.length != 1) {
            return this.getSyntax("&c");
        }
        ConfigManager.load(array[0]);
        return String.format("&aLoaded " + array[0] + "!", new Object[0]);
    }
}
