// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import java.util.ArrayList;
import java.util.List;
import dev.windhook.command.Command;

public class NamesCommand extends Command
{
    public List<String> exceptions;
    
    public NamesCommand() {
        super("names", "names <add|remove|list> [name]", "Manage the name protect exceptions list", new String[0]);
        this.exceptions = new ArrayList<String>();
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (array.length < 1) {
            return this.getSyntax("&c");
        }
        final String lowerCase = array[0].toLowerCase();
        switch (lowerCase) {
            case "add": {
                final String s2 = array[1];
                if (s2 == null) {
                    return this.getSyntax("&c");
                }
                if (this.exceptions.contains(s2)) {
                    return String.format("&e%1$s&c is already in the exceptions.", s2);
                }
                this.exceptions.add(s2);
                return String.format("&e%1$s &ahas been added to the exceptions.", s2);
            }
            case "remove": {
                final String s3 = array[1];
                if (s3 == null) {
                    return this.getSyntax("&c");
                }
                if (!this.exceptions.contains(s3)) {
                    return String.format("&e%1$s&c is NOT in the exceptions.", s3);
                }
                this.exceptions.remove(s3);
                return String.format("&e%1$s &ahas been removed from the exceptions.", s3);
            }
            case "list": {
                if (this.exceptions.size() == 0) {
                    return "&eYou don't have any friend :(";
                }
                String string = "";
                for (int i = 0; i < this.exceptions.size(); ++i) {
                    string = string + ((i == 0) ? "" : "&f, ") + "&e" + this.exceptions.get(i);
                }
                return String.format("&aThese are the exceptions: %s", string);
            }
            case "clear": {
                this.exceptions.clear();
                return "&aThe exceptions have been cleared.";
            }
            default: {
                return this.getSyntax("&c");
            }
        }
    }
    
    public String getName(final String[] array) {
        if (array.length < 2) {
            return null;
        }
        return array[1];
    }
    
    public List<String> getExceptions() {
        return this.exceptions;
    }
    
    public boolean isInExceptions(final String s) {
        return this.exceptions.contains(s);
    }
}
