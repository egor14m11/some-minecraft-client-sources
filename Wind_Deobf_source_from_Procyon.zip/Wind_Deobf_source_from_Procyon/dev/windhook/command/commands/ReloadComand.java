// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.BaseClient;
import dev.windhook.command.Command;

public class ReloadComand extends Command
{
    public ReloadComand() {
        super("reload", "reload", "Reloads all of the modules.", new String[0]);
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        BaseClient.getInstance().getModuleManager().registerModules();
        return String.format("Reloaded!", new Object[0]);
    }
}
