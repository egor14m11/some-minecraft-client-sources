// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.config.ConfigManager;
import java.nio.file.Paths;
import dev.windhook.command.Command;

public class SaveCfgCommand extends Command
{
    public SaveCfgCommand() {
        super("savecfg", "savecfg <config>", "Saves a config.", new String[] { "cfgsave" });
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        final boolean newFile = Paths.get("WindHookConfigs", this.name + ".json").toFile().createNewFile();
        ConfigManager.save(array[0]);
        return String.format("&aSaved " + array[0] + "! [Exists:" + newFile + "]", new Object[0]);
    }
}
