// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.command.Command;

public class SetCommand extends Command
{
    public SetCommand() {
        super("set", "set <module> <key> <value>", "Sets something for the module.", new String[0]);
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        return "idk broken command (error handling moment)";
    }
}
