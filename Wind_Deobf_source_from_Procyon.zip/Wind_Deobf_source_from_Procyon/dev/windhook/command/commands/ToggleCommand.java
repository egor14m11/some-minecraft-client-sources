// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.module.Module;
import dev.windhook.module.Category;
import dev.windhook.BaseClient;
import dev.windhook.command.Command;

public class ToggleCommand extends Command
{
    public ToggleCommand() {
        super("toggle", "toggle <module>", "Toggle a module.", new String[] { "t" });
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (array.length < 1) {
            return this.getSyntax("&c");
        }
        final Module module = BaseClient.instance.getModuleManager().getModule(array[0]);
        if (module == null) {
            return String.format("&cThe module &e%s&c does not exist.", array[0]);
        }
        if (module.getCategory().equals(Category.HIDDEN)) {
            return String.format("&cThe module &e%s&c is hidden, and can't be toggled.", module.getName());
        }
        module.toggle();
        return String.format("&aThe module &e%s&a has been toggled to &e%s&a.", module.getName(), Boolean.toString(module.isToggled()));
    }
}
