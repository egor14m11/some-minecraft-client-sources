// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.utils.Integers;
import dev.windhook.command.Command;

public class VClipCommand extends Command
{
    public VClipCommand() {
        super("vclip", "vclip <distance>", "Set the font's size", new String[] { "vc" });
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (!Integers.isInteger(array[0])) {
            return this.getSyntax("&c");
        }
        final int integer = Integers.getInteger(array[0]);
        this.mc.thePlayer.setPosition(this.mc.thePlayer.posX, this.mc.thePlayer.posY + integer, this.mc.thePlayer.posZ);
        return String.format("&aYou have VClipped &e%1$d blocks&a.", integer);
    }
}
