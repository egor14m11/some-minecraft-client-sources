// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import net.minecraft.block.material.Material;
import dev.windhook.utils.Utils;
import net.minecraft.util.BlockPos;
import dev.windhook.command.Command;

public class VPhaseCommand extends Command
{
    public VPhaseCommand() {
        super("vphase", "vphase", "Vertically clips to the closest block below you.", new String[] { "vp" });
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        if (this.mc.thePlayer.onGround) {
            for (int i = 1; i < 9; ++i) {
                final BlockPos blockPos = new BlockPos(this.mc.thePlayer.posX, this.mc.thePlayer.posY - i, this.mc.thePlayer.posZ);
                if (Utils.getBlockState(blockPos).getBlock().getMaterial() == Material.air && i < 8 && Utils.getBlockState(blockPos.down()).getBlock().getMaterial() == Material.air) {
                    this.mc.thePlayer.setPosition(blockPos.getX() + 0.0, this.mc.thePlayer.posY - (i + 1), blockPos.getZ() + 0.0);
                    break;
                }
            }
        }
        return "&aYou have VPhased!&a.";
    }
}
