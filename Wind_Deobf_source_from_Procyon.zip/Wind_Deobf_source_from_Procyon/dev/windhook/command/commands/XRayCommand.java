// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.command.commands;

import dev.windhook.command.Command;

public class XRayCommand extends Command
{
    public XRayCommand() {
        super("xray", "xray <add|remove|clear> [name|id]", "Add or remove a block from the xray list", new String[0]);
    }
    
    @Override
    public String executeCommand(final String s, final String[] array) {
        return ".";
    }
}
