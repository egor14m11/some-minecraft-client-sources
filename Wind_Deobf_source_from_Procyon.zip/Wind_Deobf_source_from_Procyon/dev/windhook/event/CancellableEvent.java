// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event;

public class CancellableEvent extends Event
{
    private boolean cancelled;
    
    public CancellableEvent() {
        this.cancelled = false;
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public boolean setCancelled(final boolean cancelled) {
        return this.cancelled = cancelled;
    }
}
