// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event;

public class Event
{
}
