// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event;

import dev.windhook.event.events.MoveEvent;
import dev.windhook.event.events.LadderClimbEvent;
import dev.windhook.event.events.SlowDownEvent;
import dev.windhook.event.events.FluidRenderEvent;
import dev.windhook.event.events.PlayerSpawnEvent;
import dev.windhook.event.events.RenderLivingLabelEvent;
import dev.windhook.event.events.BlockBrightnessRequestEvent;
import dev.windhook.event.events.BlockRenderEvent;
import dev.windhook.event.events.CollideEvent;
import dev.windhook.event.events.ServerLeaveEvent;
import dev.windhook.event.events.ServerJoinEvent;
import dev.windhook.event.events.ServerConnectingEvent;
import dev.windhook.event.events.PreRender3DEvent;
import dev.windhook.event.events.Render3DEvent;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.event.events.VelocityEvent;
import dev.windhook.event.events.PostMotionEvent;
import dev.windhook.event.events.PreMotionEvent;
import dev.windhook.event.events.MouseClickEvent;
import dev.windhook.event.events.MouseScrollEvent;
import dev.windhook.event.events.UpdateEvent;
import dev.windhook.event.events.KeyPressedEvent;
import dev.windhook.event.events.MessageReceivedEvent;
import dev.windhook.event.events.GuiRenderEvent;
import dev.windhook.event.events.MotionEvent;
import dev.windhook.event.events.MessageSentEvent;
import dev.windhook.event.events.AttackEvent;
import dev.windhook.event.events.JumpEvent;
import dev.windhook.event.events.StepEvent;
import dev.windhook.event.events.BlockBoundsEvent;
import dev.windhook.event.events.HurtcamEvent;
import dev.windhook.event.events.ClickMouseEvent;
import dev.windhook.event.events.PacketReceivedEvent;
import dev.windhook.event.events.PacketSentEvent;
import dev.windhook.event.events.PushBlockEvent;
import net.minecraft.client.Minecraft;

public class EventListener
{
    protected Minecraft mc;
    
    public EventListener() {
        this.mc = Minecraft.getMinecraft();
    }
    
    public void onPushBlock(final PushBlockEvent event) {
    }
    
    public void onPacketSent(final PacketSentEvent event) {
    }
    
    public void onPacketReceived(final PacketReceivedEvent event) {
    }
    
    public void onClickMouse(final ClickMouseEvent event) {
    }
    
    public void onHurtcam(final HurtcamEvent event) {
    }
    
    public void onBlockBounds(final BlockBoundsEvent event) {
    }
    
    public void onStep(final StepEvent event) {
    }
    
    public void onJump(final JumpEvent event) {
    }
    
    public void onAttack(final AttackEvent event) {
    }
    
    public void onMessageSent(final MessageSentEvent event) {
    }
    
    public void onMotion(final MotionEvent event) {
    }
    
    public void onGuiRender(final GuiRenderEvent event) {
    }
    
    public void onMessageReceived(final MessageReceivedEvent event) {
    }
    
    public void onKeyPressed(final KeyPressedEvent event) {
    }
    
    public void onUpdate(final UpdateEvent event) {
    }
    
    public void onMouseScroll(final MouseScrollEvent event) {
    }
    
    public void onMouseClick(final MouseClickEvent event) {
    }
    
    public void onPreMotion(final PreMotionEvent event) {
    }
    
    public void onPostMotion(final PostMotionEvent event) {
    }
    
    public void onVelocity(final VelocityEvent event) {
    }
    
    public void onRender2D(final Render2DEvent event) {
    }
    
    public void onRender3D(final Render3DEvent event) {
    }
    
    public void onPreRender3D(final PreRender3DEvent event) {
    }
    
    public void onServerConnecting(final ServerConnectingEvent event) {
    }
    
    public void onServerJoin(final ServerJoinEvent event) {
    }
    
    public void onServerLeave(final ServerLeaveEvent event) {
    }
    
    public void onCollide(final CollideEvent event) {
    }
    
    public void onBlockRender(final BlockRenderEvent event) {
    }
    
    public void onBlockBrightnessRequest(final BlockBrightnessRequestEvent event) {
    }
    
    public void onRenderLivingLabel(final RenderLivingLabelEvent event) {
    }
    
    public void onPlayerSpawn(final PlayerSpawnEvent event) {
    }
    
    public void onFluidRender(final FluidRenderEvent event) {
    }
    
    public void onSlowDown(final SlowDownEvent event) {
    }
    
    public void onLadderClimb(final LadderClimbEvent event) {
    }
    
    public void onMove(final MoveEvent event) {
    }
}
