// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event;

import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;

public class EventManager
{
    private List<EventListener> eventListeners;
    private HashMap<String, Method> listenerMethods;
    
    public EventManager() {
        this.eventListeners = new ArrayList<EventListener>();
        this.listenerMethods = new HashMap<String, Method>();
        final Method[] methods2;
        final Method[] methods = methods2 = EventListener.class.getMethods();
        for (final Method method : methods2) {
            this.listenerMethods.put(method.getName().substring(2), method);
        }
    }
    
    @Deprecated
    public void registerEvent(final EventListener eventListener) {
        this.registerListener(eventListener);
    }
    
    @Deprecated
    public void unregisterEvent(final EventListener eventListener) {
        this.unregisterListener(eventListener);
    }
    
    public void registerListener(final EventListener eventListener) {
        this.eventListeners.add(eventListener);
    }
    
    public void unregisterListener(final EventListener eventListener) {
        if (this.eventListeners.contains(eventListener)) {
            this.eventListeners.remove(eventListener);
        }
    }
    
    public void unregisterListener(final Class<? extends EventListener> clasz) {
        for (int i = 0; i < this.eventListeners.size(); ++i) {
            if (this.eventListeners.get(i).getClass().equals(clasz)) {
                this.eventListeners.remove(i);
            }
        }
    }
    
    public Event call(final Event event) {
        final List<EventListener> eventListeners = new ArrayList<EventListener>(this.eventListeners);
        String eventName = event.getClass().getSimpleName();
        eventName = eventName.substring(0, eventName.toLowerCase().lastIndexOf("event"));
        for (final EventListener listener : eventListeners) {
            if (event instanceof CancellableEvent && ((CancellableEvent)event).isCancelled()) {
                return event;
            }
            if (!this.listenerMethods.containsKey(eventName)) {
                this.listenerMethods.put(eventName, EventListener.class.getMethod("on" + eventName, event.getClass()));
            }
            final Method method = this.listenerMethods.get(eventName);
            method.invoke(listener, event);
        }
        return event;
    }
}
