// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.entity.Entity;
import dev.windhook.event.CancellableEvent;

public class AttackEvent extends CancellableEvent
{
    private final Entity entity;
    private final boolean preAttack;
    
    public AttackEvent(final Entity targetEntity, final boolean preAttack) {
        this.entity = targetEntity;
        this.preAttack = preAttack;
    }
    
    public Entity getEntity() {
        return this.entity;
    }
    
    public boolean isPreAttack() {
        return this.preAttack;
    }
    
    public boolean isPostAttack() {
        return !this.preAttack;
    }
}
