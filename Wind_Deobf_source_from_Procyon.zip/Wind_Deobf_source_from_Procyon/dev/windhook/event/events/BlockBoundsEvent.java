// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.block.Block;
import dev.windhook.event.CancellableEvent;

public class BlockBoundsEvent extends CancellableEvent
{
    private final Block block;
    private final BlockPos pos;
    private AxisAlignedBB bounds;
    
    public BlockBoundsEvent(final Block block, final BlockPos pos, final AxisAlignedBB bounds) {
        this.block = block;
        this.pos = pos;
        this.bounds = bounds;
    }
    
    public AxisAlignedBB getBounds() {
        return this.bounds;
    }
    
    public void setBounds(final AxisAlignedBB bounds) {
        this.bounds = bounds;
    }
    
    public BlockPos getPos() {
        return this.pos;
    }
    
    public Block getBlock() {
        return this.block;
    }
}
