// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.block.Block;
import dev.windhook.event.Event;

public class BlockBrightnessRequestEvent extends Event
{
    private Block block;
    private int blockBrightness;
    
    public BlockBrightnessRequestEvent(final Block block) {
        this.block = block;
        this.blockBrightness = -1;
    }
    
    public Block getBlock() {
        return this.block;
    }
    
    public int getBlockBrightness() {
        return this.blockBrightness;
    }
    
    public void setBlockBrightness(final int blockBrightness) {
        this.blockBrightness = blockBrightness;
    }
}
