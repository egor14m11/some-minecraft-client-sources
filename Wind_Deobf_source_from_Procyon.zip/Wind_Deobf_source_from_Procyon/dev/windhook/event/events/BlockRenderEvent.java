// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.block.Block;
import dev.windhook.event.CancellableEvent;

public class BlockRenderEvent extends CancellableEvent
{
    private Block block;
    private boolean forceDraw;
    
    public BlockRenderEvent(final Block block) {
        this.block = block;
        this.forceDraw = false;
    }
    
    public Block getBlock() {
        return this.block;
    }
    
    public void setForceDraw(final boolean forceDraw) {
        this.forceDraw = forceDraw;
    }
    
    public boolean shouldForceDraw() {
        return this.forceDraw;
    }
}
