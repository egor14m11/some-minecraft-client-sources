// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.block.Block;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.entity.Entity;
import dev.windhook.event.CancellableEvent;

public class CollideEvent extends CancellableEvent
{
    private Entity entity;
    private AxisAlignedBB axisAlignedBB;
    private Block block;
    
    public CollideEvent(final Entity entity, final AxisAlignedBB axisAlignedBB, final Block block) {
        this.entity = entity;
        this.axisAlignedBB = axisAlignedBB;
        this.block = block;
    }
    
    public Entity getEntity() {
        return this.entity;
    }
    
    public AxisAlignedBB getAxisAlignedBB() {
        return this.axisAlignedBB;
    }
    
    public Block getBlock() {
        return this.block;
    }
}
