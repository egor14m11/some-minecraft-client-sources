// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

public enum EventDirection
{
    INCOMING, 
    OUTGOING;
}
