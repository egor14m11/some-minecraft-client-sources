// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.potion.Potion;
import net.minecraft.client.Minecraft;
import dev.windhook.event.Event;

public class EventMotion extends Event
{
    public double x;
    public double y;
    public double z;
    boolean safeWalk;
    
    public EventMotion(final double x, final double y, final double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public double getX() {
        return this.x;
    }
    
    public void setX(final double x) {
        this.x = x;
        Minecraft.getMinecraft().thePlayer.motionX = x;
    }
    
    public void setY(final double y) {
        this.y = y;
        Minecraft.getMinecraft().thePlayer.motionY = y;
    }
    
    public double getY() {
        return this.y;
    }
    
    public double getZ() {
        return this.z;
    }
    
    public void setZ(final double z) {
        this.z = z;
        Minecraft.getMinecraft().thePlayer.motionZ = z;
    }
    
    public boolean isSafeWalk() {
        return this.safeWalk;
    }
    
    public void setSafeWalk(final boolean safeWalk) {
        this.safeWalk = safeWalk;
    }
    
    public double getLegitMotion() {
        return 0.41999998688697815;
    }
    
    public double getMovementSpeed() {
        double baseSpeed = 0.2873;
        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.moveSpeed)) {
            final int amplifier = Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (amplifier + 1);
        }
        return baseSpeed;
    }
    
    public double getMovementSpeed(final double baseSpeed) {
        double speed = baseSpeed;
        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.moveSpeed)) {
            final int amplifier = Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            return speed *= 1.0 + 0.2 * (amplifier + 1);
        }
        return speed;
    }
    
    public double getMotionY(double mY) {
        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.jump)) {
            mY += (Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1) * 0.1;
        }
        return mY;
    }
}
