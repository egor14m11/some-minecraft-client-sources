// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import dev.windhook.event.CancellableEvent;

public class FluidRenderEvent extends CancellableEvent
{
    private BlockPos blockPos;
    private IBlockState state;
    private boolean forceDraw;
    
    public FluidRenderEvent(final BlockPos blockPos, final IBlockState state) {
        this.blockPos = blockPos;
        this.state = state;
        this.forceDraw = false;
    }
    
    public BlockPos getBlockPos() {
        return this.blockPos;
    }
    
    public IBlockState getState() {
        return this.state;
    }
    
    public Block getBlock() {
        return (this.state.getBlock() == null) ? null : this.state.getBlock();
    }
    
    public void setForceDraw(final boolean forceDraw) {
        this.forceDraw = forceDraw;
    }
    
    public boolean shouldForceDraw() {
        return this.forceDraw;
    }
}
