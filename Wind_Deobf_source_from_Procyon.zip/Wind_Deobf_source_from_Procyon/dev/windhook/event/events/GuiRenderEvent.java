// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.event.Event;

public class GuiRenderEvent extends Event
{
    public float partialTicks;
    
    public GuiRenderEvent(final float partialTicks) {
        this.partialTicks = partialTicks;
    }
}
