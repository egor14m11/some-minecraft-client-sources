// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.event.Event;

public class JumpEvent extends Event
{
    private double motionY;
    private final boolean pre;
    
    public JumpEvent(final double motionY, final boolean pre) {
        this.motionY = motionY;
        this.pre = pre;
    }
    
    public double getMotionY() {
        return this.motionY;
    }
    
    public void setMotionY(final double motiony) {
        this.motionY = motiony;
    }
    
    public boolean isPre() {
        return this.pre;
    }
    
    public boolean isPost() {
        return !this.pre;
    }
}
