// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.event.CancellableEvent;

public class KeyPressedEvent extends CancellableEvent
{
    private int key;
    
    public KeyPressedEvent(final int key) {
        this.key = key;
    }
    
    public int getKey() {
        return this.key;
    }
}
