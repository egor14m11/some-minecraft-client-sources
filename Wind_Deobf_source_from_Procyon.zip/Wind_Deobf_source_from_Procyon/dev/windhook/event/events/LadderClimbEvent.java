// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.event.CancellableEvent;

public class LadderClimbEvent extends CancellableEvent
{
    private double motionY;
    
    public LadderClimbEvent(final double motionY) {
        this.motionY = motionY;
    }
    
    public double getMotionY() {
        return this.motionY;
    }
    
    public void setMotionY(final double motionY) {
        this.motionY = motionY;
    }
}
