// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.event.CancellableEvent;

public class MessageReceivedEvent extends CancellableEvent
{
    private String message;
    
    public MessageReceivedEvent(final String message, final boolean fromMinecraft) {
        this.message = message;
    }
    
    public String getMessage() {
        return this.message;
    }
    
    public String setMessage(final String message) {
        return this.message = message;
    }
}
