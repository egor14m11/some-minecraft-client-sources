// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.event.Event;

public class MotionEvent extends Event
{
    private double x;
    private double y;
    private double z;
    private float yaw;
    private float pitch;
    private boolean ground;
    private Type eventType;
    
    public Type getEventType() {
        return this.eventType;
    }
    
    public void setEventType(final Type eventType) {
        this.eventType = eventType;
    }
    
    public double getX() {
        return this.x;
    }
    
    public void setX(final double x) {
        this.x = x;
    }
    
    public double getY() {
        return this.y;
    }
    
    public void setY(final double y) {
        this.y = y;
    }
    
    public double getZ() {
        return this.z;
    }
    
    public void setZ(final double z) {
        this.z = z;
    }
    
    public float getYaw() {
        return this.yaw;
    }
    
    public void setYaw(final float yaw) {
        this.yaw = yaw;
    }
    
    public float getPitch() {
        return this.pitch;
    }
    
    public void setPitch(final float pitch) {
        this.pitch = pitch;
    }
    
    public boolean isGround() {
        return this.ground;
    }
    
    public void setGround(final boolean ground) {
        this.ground = ground;
    }
    
    public MotionEvent(final double x, final double y, final double z, final float yaw, final float pitch, final boolean ground) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.ground = ground;
    }
    
    public boolean isPre() {
        return this.eventType == Type.PRE;
    }
    
    public boolean isPost() {
        return this.eventType == Type.POST;
    }
    
    public enum Type
    {
        PRE, 
        POST;
    }
}
