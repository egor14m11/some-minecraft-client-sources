// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.utils.KeyUtils;
import dev.windhook.event.Event;

public class MouseClickEvent extends Event
{
    private int button;
    
    public MouseClickEvent(final int button) {
        this.button = button;
    }
    
    public int getButton() {
        return this.button;
    }
    
    public KeyUtils.MouseButton getMouseButton() {
        return KeyUtils.MouseButton.getFromDefaultCode(this.button);
    }
}
