// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.event.CancellableEvent;

public class MouseScrollEvent extends CancellableEvent
{
    private int button;
    
    public MouseScrollEvent(final int button) {
        this.button = button;
    }
    
    public int getDirection() {
        return this.button;
    }
}
