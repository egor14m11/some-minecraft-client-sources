// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.network.Packet;
import dev.windhook.event.CancellableEvent;

public class PacketSentEvent extends CancellableEvent
{
    private Packet<?> packet;
    
    public PacketSentEvent(final Packet<?> packet) {
        this.packet = packet;
    }
    
    public Packet<?> getPacket() {
        return this.packet;
    }
    
    public void setPacket(final Packet<?> packet) {
        this.packet = packet;
    }
}
