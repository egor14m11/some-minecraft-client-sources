// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.client.entity.EntityOtherPlayerMP;
import dev.windhook.event.CancellableEvent;

public class PlayerSpawnEvent extends CancellableEvent
{
    private EntityOtherPlayerMP entity;
    
    public PlayerSpawnEvent(final EntityOtherPlayerMP entity) {
        this.entity = entity;
    }
    
    public EntityOtherPlayerMP getEntity() {
        return this.entity;
    }
    
    public void setEntity(final EntityOtherPlayerMP entity) {
        this.entity = entity;
    }
}
