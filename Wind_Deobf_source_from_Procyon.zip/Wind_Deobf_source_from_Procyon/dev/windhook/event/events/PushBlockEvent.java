// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.event.CancellableEvent;

public class PushBlockEvent extends CancellableEvent
{
    private Type eventType;
    
    public Type getEventType() {
        return this.eventType;
    }
    
    public void setEventType(final Type eventType) {
        this.eventType = eventType;
    }
    
    public enum Type
    {
        PRE, 
        POST;
    }
}
