// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.entity.Entity;
import dev.windhook.event.CancellableEvent;

public class RenderLivingLabelEvent extends CancellableEvent
{
    private Entity entity;
    private String label;
    
    public RenderLivingLabelEvent(final Entity entity, final String label) {
        this.entity = entity;
        this.label = label;
    }
    
    public Entity getEntity() {
        return this.entity;
    }
    
    public String getLabel() {
        return this.label;
    }
    
    public void setLabel(final String label) {
        this.label = label;
    }
}
