// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.event.CancellableEvent;

public class ServerConnectingEvent extends CancellableEvent
{
    private final String address;
    private final int port;
    private String cancelReason;
    
    public ServerConnectingEvent(final String address, final int port) {
        this.address = address;
        this.port = port;
        this.cancelReason = "Connection cancelled.";
    }
    
    public String getAddress() {
        return this.address;
    }
    
    public int getPort() {
        return this.port;
    }
    
    public String getCancelReason() {
        return this.cancelReason;
    }
    
    public void setCancelReason(final String cancelReason) {
        this.cancelReason = cancelReason;
    }
}
