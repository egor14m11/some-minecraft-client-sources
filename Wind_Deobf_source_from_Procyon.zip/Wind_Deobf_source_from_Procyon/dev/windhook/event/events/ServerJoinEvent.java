// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.client.multiplayer.ServerData;
import dev.windhook.event.Event;

public class ServerJoinEvent extends Event
{
    private final ServerData serverData;
    
    public ServerJoinEvent(final ServerData serverData) {
        this.serverData = serverData;
    }
    
    public ServerData getServerData() {
        return this.serverData;
    }
}
