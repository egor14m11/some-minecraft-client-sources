// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import net.minecraft.util.IChatComponent;
import net.minecraft.client.multiplayer.ServerData;
import dev.windhook.event.Event;

public class ServerLeaveEvent extends Event
{
    private final ServerData serverData;
    private final String reason;
    private final IChatComponent message;
    
    public ServerLeaveEvent(final ServerData serverData, final String reason, final IChatComponent message) {
        this.serverData = serverData;
        this.reason = reason;
        this.message = message;
    }
    
    public ServerData getServerData() {
        return this.serverData;
    }
    
    public String getReason() {
        return this.reason;
    }
    
    public IChatComponent getMessage() {
        return this.message;
    }
}
