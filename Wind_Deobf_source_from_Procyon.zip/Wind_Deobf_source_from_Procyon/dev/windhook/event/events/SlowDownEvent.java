// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.event.events;

import dev.windhook.event.CancellableEvent;

public class SlowDownEvent extends CancellableEvent
{
    private float slowDownMultiplier;
    
    public SlowDownEvent(final float slowDownMultiplier) {
        this.slowDownMultiplier = slowDownMultiplier;
    }
    
    public float getSlowDownMultiplier() {
        return this.slowDownMultiplier;
    }
    
    public void setSlowDownMultiplier(final float slowDownMultiplier) {
        this.slowDownMultiplier = slowDownMultiplier;
    }
}
