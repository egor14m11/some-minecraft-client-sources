// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.font;

import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;
import dev.windhook.utils.RenderUtils;
import java.util.List;
import java.util.Map;

public class Font
{
    public static Map<String, List<UnicodeFontRenderer>> REGISTERED_RENDERERS;
    public String packageName;
    public String fontName;
    public int fontSizeSmall;
    public int fontSizeNormal;
    public int fontSizeLarge;
    public int fontSizeLargest;
    public int fontSizeLogo;
    
    public static Map<String, List<UnicodeFontRenderer>> getRegisteredRenderers() {
        return Font.REGISTERED_RENDERERS;
    }
    
    public Font(final String packageName, final String fontName, final int fontSizeSmall, final int fontSizeNormal, final int fontSizeLarge, final int fontSizeLargest, final int fontSizeLogo) {
        this.packageName = packageName;
        this.fontName = fontName;
        this.fontSizeSmall = fontSizeSmall;
        this.fontSizeNormal = fontSizeNormal;
        this.fontSizeLarge = fontSizeLarge;
        this.fontSizeLargest = fontSizeLargest;
        this.fontSizeLogo = fontSizeLogo;
    }
    
    public Font(final String packageName, final String fontName, final int n) {
        this.packageName = packageName;
        this.fontName = fontName;
        this.fontSizeSmall = n;
        this.fontSizeNormal = n;
        this.fontSizeLarge = n;
        this.fontSizeLargest = n;
    }
    
    public String getPackageName() {
        return this.packageName;
    }
    
    public String getFontName() {
        return this.fontName;
    }
    
    public int getFontSize() {
        switch (RenderUtils.getScaledResolution().getScaleFactor()) {
            case 1: {
                return this.fontSizeSmall;
            }
            case 2: {
                return this.fontSizeNormal;
            }
            case 3: {
                return this.fontSizeLarge;
            }
            case 4: {
                return this.fontSizeLargest;
            }
            default: {
                return this.fontSizeNormal;
            }
        }
    }
    
    public void setPackageName(final String packageName) {
        this.packageName = packageName;
    }
    
    public void setFontName(final String fontName) {
        this.fontName = fontName;
    }
    
    public void setFontSizeSmall(final int fontSizeSmall) {
        this.fontSizeSmall = fontSizeSmall;
    }
    
    public void setFontSizeNormal(final int fontSizeNormal) {
        this.fontSizeNormal = fontSizeNormal;
    }
    
    public void setFontSizeLarge(final int fontSizeLarge) {
        this.fontSizeLarge = fontSizeLarge;
    }
    
    public void setFontSizeLargest(final int fontSizeLargest) {
        this.fontSizeLargest = fontSizeLargest;
    }
    
    public void setFontSizeLogo(final int fontSizeLogo) {
        this.fontSizeLogo = fontSizeLogo;
    }
    
    public UnicodeFontRenderer getFont() {
        return this.getFont(this.packageName, this.fontName, this.getFontSize());
    }
    
    public UnicodeFontRenderer getFont(final int n) {
        return this.getFont(this.packageName, this.fontName, n);
    }
    
    public UnicodeFontRenderer getFont(final String s, final int n) {
        return this.getFont(this.packageName, s, n);
    }
    
    public UnicodeFontRenderer getFont(String s, final String str, final int n) {
        s = "." + s;
        s = s.replace(".", "/");
        for (final Map.Entry<String, List<UnicodeFontRenderer>> entry : Font.REGISTERED_RENDERERS.entrySet()) {
            if (entry.getKey().toLowerCase().equalsIgnoreCase(str.toLowerCase())) {
                for (final UnicodeFontRenderer unicodeFontRenderer : entry.getValue()) {
                    if (unicodeFontRenderer.getFont().getFont().getSize() == n) {
                        return unicodeFontRenderer;
                    }
                }
            }
        }
        final UnicodeFontRenderer unicodeFontRenderer2 = new UnicodeFontRenderer(Font.class.getResourceAsStream(String.valueOf(s) + "/" + str + (str.endsWith(".ttf") ? "" : ".ttf")), n);
        if (!Font.REGISTERED_RENDERERS.containsKey(str)) {
            Font.REGISTERED_RENDERERS.put(str, new ArrayList<UnicodeFontRenderer>());
        }
        Font.REGISTERED_RENDERERS.get(str).add(unicodeFontRenderer2);
        return unicodeFontRenderer2;
    }
    
    static {
        Font.REGISTERED_RENDERERS = new HashMap<String, List<UnicodeFontRenderer>>();
    }
}
