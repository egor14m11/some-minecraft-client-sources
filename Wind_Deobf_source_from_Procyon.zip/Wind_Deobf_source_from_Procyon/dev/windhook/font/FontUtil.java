// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.font;

import net.minecraft.util.StringUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

public class FontUtil
{
    public static FontRenderer fontRenderer;
    
    public static void setupFontUtils() {
        FontUtil.fontRenderer = Minecraft.getMinecraft().fontRendererObj;
    }
    
    public static int getStringWidth(final String s) {
        return FontUtil.fontRenderer.getStringWidth(StringUtils.stripControlCodes(s));
    }
    
    public static int getFontHeight() {
        return FontUtil.fontRenderer.FONT_HEIGHT;
    }
    
    public static void drawString(final String s, final int n, final int n2, final int n3) {
        FontUtil.fontRenderer.drawString(s, n, n2, n3);
    }
    
    public static void drawStringWithShadow(final String s, final double n, final double n2, final int n3) {
        FontUtil.fontRenderer.drawStringWithShadow(s, (float)n, (float)n2, n3);
    }
    
    public static void drawCenteredString(final String s, final int n, final int n2, final int n3) {
        drawString(s, n - FontUtil.fontRenderer.getStringWidth(s) / 2, n2, n3);
    }
    
    public static void drawCenteredStringWithShadow(final String s, final double n, final double n2, final int n3) {
        drawStringWithShadow(s, n - FontUtil.fontRenderer.getStringWidth(s) / 2, n2, n3);
    }
    
    public static void drawTotalCenteredString(final String s, final int n, final int n2, final int n3) {
        drawString(s, n - FontUtil.fontRenderer.getStringWidth(s) / 2, n2 - FontUtil.fontRenderer.FONT_HEIGHT / 2, n3);
    }
    
    public static void drawTotalCenteredStringWithShadow(final String s, final double n, final double n2, final int n3) {
        drawStringWithShadow(s, n - FontUtil.fontRenderer.getStringWidth(s) / 2, n2 - FontUtil.fontRenderer.FONT_HEIGHT / 2.0f, n3);
    }
}
