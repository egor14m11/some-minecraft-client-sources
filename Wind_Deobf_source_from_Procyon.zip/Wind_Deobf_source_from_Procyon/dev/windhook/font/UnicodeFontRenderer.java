// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.font;

import net.minecraft.util.StringUtils;
import org.lwjgl.opengl.GL11;
import java.io.InputStream;
import org.newdawn.slick.font.effects.ColorEffect;
import java.awt.Color;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.Minecraft;
import java.awt.Font;
import org.newdawn.slick.UnicodeFont;
import net.minecraft.client.gui.FontRenderer;

public class UnicodeFontRenderer extends FontRenderer
{
    public UnicodeFont font;
    
    public UnicodeFontRenderer(final Font font) {
        super(Minecraft.getMinecraft().gameSettings, new ResourceLocation("textures/font/ascii.png"), Minecraft.getMinecraft().getTextureManager(), false);
        (this.font = new UnicodeFont(font)).addAsciiGlyphs();
        this.font.getEffects().add(new ColorEffect(Color.WHITE));
        this.font.loadGlyphs();
        this.FONT_HEIGHT = this.font.getHeight("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789") / 2;
    }
    
    public UnicodeFontRenderer(final InputStream inputStream, final int n) {
        super(Minecraft.getMinecraft().gameSettings, new ResourceLocation("textures/font/ascii.png"), Minecraft.getMinecraft().getTextureManager(), false);
        (this.font = new UnicodeFont(inputStream, n)).addAsciiGlyphs();
        this.font.getEffects().add(new ColorEffect(Color.WHITE));
        this.font.loadGlyphs();
        this.FONT_HEIGHT = this.font.getHeight("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789") / 2;
    }
    
    @Override
    public int drawString(final String s, final int n, final int n2, final int n3) {
        return this.drawString(s, n, n2, n3, false);
    }
    
    public int drawString(final String s, int n, int n2, final int n3, final boolean b) {
        if (s == null) {
            return -1;
        }
        GL11.glPushMatrix();
        GL11.glScaled(0.0, 0.0, 0.0);
        final boolean glIsEnabled = GL11.glIsEnabled(3042);
        final boolean glIsEnabled2 = GL11.glIsEnabled(2896);
        final boolean glIsEnabled3 = GL11.glIsEnabled(3553);
        if (!glIsEnabled) {
            GL11.glEnable(3042);
        }
        if (glIsEnabled2) {
            GL11.glDisable(2896);
        }
        if (glIsEnabled3) {
            GL11.glDisable(3553);
        }
        GL11.glBlendFunc(770, 771);
        n *= 2;
        n2 *= 2;
        this.font.drawString((float)n, (float)n2, s, new org.newdawn.slick.Color(n3), b);
        if (glIsEnabled3) {
            GL11.glEnable(3553);
        }
        if (glIsEnabled2) {
            GL11.glEnable(2896);
        }
        if (!glIsEnabled) {
            GL11.glDisable(3042);
        }
        GL11.glPopMatrix();
        return this.getStringWidth(s);
    }
    
    public void drawStringWithShadow(final String s, final int n, final int n2, final int n3) {
        this.drawString(StringUtils.stripControlCodes(s), n + 1, n2 + 1, -16777216);
        this.drawString(s, n, n2, n3, true);
    }
    
    @Override
    public int getStringWidth(final String s) {
        return this.font.getWidth(s) / 2;
    }
    
    public int getStringHeight(final String s) {
        return this.font.getHeight(s) / 2;
    }
    
    public UnicodeFont getFont() {
        return this.font;
    }
}
