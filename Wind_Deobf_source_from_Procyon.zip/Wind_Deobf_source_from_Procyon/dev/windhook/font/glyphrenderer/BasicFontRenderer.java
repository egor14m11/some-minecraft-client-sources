// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.font.glyphrenderer;

import java.util.List;
import net.minecraft.client.resources.IResourceManagerReloadListener;

public interface BasicFontRenderer extends IResourceManagerReloadListener
{
    int getFontHeight();
    
    int drawStringWithShadow(final String p0, final float p1, final float p2, final int p3);
    
    int drawString(final String p0, final float p1, final float p2, final int p3);
    
    int drawString(final String p0, final float p1, final float p2, final int p3, final boolean p4);
    
    int drawCenteredString(final String p0, final float p1, final float p2, final int p3, final boolean p4);
    
    int getStringWidth(final String p0);
    
    int getCharWidth(final char p0);
    
    void setUnicodeFlag(final boolean p0);
    
    void setBidiFlag(final boolean p0);
    
    boolean getBidiFlag();
    
    String wrapFormattedStringToWidth(final String p0, final int p1);
    
    List listFormattedStringToWidth(final String p0, final int p1);
    
    String trimStringToWidth(final String p0, final int p1, final boolean p2);
    
    String trimStringToWidth(final String p0, final int p1);
    
    int getColorCode(final char p0);
    
    boolean isEnabled();
    
    boolean setEnabled(final boolean p0);
    
    void setFontRandomSeed(final long p0);
    
    void drawSplitString(final String p0, final int p1, final int p2, final int p3, final int p4);
    
    int splitStringWidth(final String p0, final int p1);
    
    boolean getUnicodeFlag();
    
    default String getFormatFromString(final String s) {
        String str = "";
        int index = -1;
        final int length = s.length();
        while ((index = s.indexOf(167, index + 1)) != -1) {
            if (index < length - 1) {
                final char char1 = s.charAt(index + 1);
                if (isFormatColor(char1)) {
                    str = "§" + char1;
                }
                else {
                    if (!isFormatSpecial(char1)) {
                        continue;
                    }
                    str = str + "§" + char1;
                }
            }
        }
        return str;
    }
    
    default boolean isFormatColor(final char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }
    
    default boolean isFormatSpecial(final char c) {
        return (c >= 'k' && c <= 'o') || (c >= 'K' && c <= 'O') || c == 'r' || c == 'R';
    }
}
