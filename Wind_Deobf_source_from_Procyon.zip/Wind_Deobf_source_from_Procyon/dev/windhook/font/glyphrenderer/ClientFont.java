// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.font.glyphrenderer;

import java.awt.Font;

public class ClientFont
{
    public static GlyphPageFontRenderer font(final int size, final String s, final boolean b) {
        final Font deriveFont = Font.createFont(0, ClientFont.class.getResourceAsStream("/resources/" + s + ".ttf")).deriveFont((float)size);
        final GlyphPage glyphPage = new GlyphPage(b ? deriveFont : new Font(s, 0, size), true, true);
        final char[] array = new char[256];
        for (int i = 0; i < array.length; ++i) {
            array[i] = (char)i;
        }
        glyphPage.generateGlyphPage(array);
        glyphPage.setupTexture();
        return new GlyphPageFontRenderer(glyphPage, glyphPage, glyphPage, glyphPage);
    }
    
    public static GlyphPageFontRenderer font(final int size, final FontType fontType, final boolean b) {
        final Font deriveFont = Font.createFont(0, ClientFont.class.getResourceAsStream("/resources/" + fontType.getType() + ".ttf")).deriveFont((float)size);
        final GlyphPage glyphPage = new GlyphPage(b ? deriveFont : new Font(fontType.getType(), 0, size), true, true);
        final char[] array = new char[256];
        for (int i = 0; i < array.length; ++i) {
            array[i] = (char)i;
        }
        glyphPage.generateGlyphPage(array);
        glyphPage.setupTexture();
        return new GlyphPageFontRenderer(glyphPage, glyphPage, glyphPage, glyphPage);
    }
    
    public enum FontType
    {
        COMFORTAA("Comfortaa-Regular"), 
        JETBRAINS_MONO("JetBrainsMono-Regular"), 
        ACUMIN("Acumin-RPro"), 
        ROBOTO_LIGHT("RobotoLight"), 
        ARIAL("Arial"), 
        FLUX_ICONS("Icon");
        
        public String type;
        public static FontType[] $VALUES;
        
        public FontType(final String type) {
            this.type = type;
        }
        
        public String getType() {
            return this.type;
        }
        
        static {
            FontType.$VALUES = new FontType[] { FontType.COMFORTAA, FontType.JETBRAINS_MONO, FontType.ACUMIN, FontType.ROBOTO_LIGHT, FontType.ARIAL, FontType.FLUX_ICONS };
        }
    }
}
