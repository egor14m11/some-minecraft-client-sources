// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.font.glyphrenderer;

import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.awt.Font;

public class GlyphPage
{
    public int imgSize;
    public int maxFontHeight;
    public Font font;
    public boolean antiAliasing;
    public boolean fractionalMetrics;
    public HashMap<Character, Glyph> glyphCharacterMap;
    public BufferedImage bufferedImage;
    public DynamicTexture loadedTexture;
    
    public GlyphPage(final Font font, final boolean antiAliasing, final boolean fractionalMetrics) {
        this.maxFontHeight = -1;
        this.glyphCharacterMap = new HashMap<Character, Glyph>();
        this.font = font;
        this.antiAliasing = antiAliasing;
        this.fractionalMetrics = fractionalMetrics;
    }
    
    public void generateGlyphPage(final char[] p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dstore_2       
        //     4: ldc2_w          -1.0
        //     7: dstore          4
        //     9: new             Ljava/awt/geom/AffineTransform;
        //    12: dup            
        //    13: invokespecial   java/awt/geom/AffineTransform.<init>:()V
        //    16: astore          6
        //    18: new             Ljava/awt/font/FontRenderContext;
        //    21: dup            
        //    22: aload           6
        //    24: aload_0        
        //    25: getfield        dev/windhook/font/glyphrenderer/GlyphPage.antiAliasing:Z
        //    28: aload_0        
        //    29: getfield        dev/windhook/font/glyphrenderer/GlyphPage.fractionalMetrics:Z
        //    32: invokespecial   java/awt/font/FontRenderContext.<init>:(Ljava/awt/geom/AffineTransform;ZZ)V
        //    35: astore          7
        //    37: aload_1        
        //    38: astore          8
        //    40: aload           8
        //    42: arraylength    
        //    43: istore          9
        //    45: iconst_0       
        //    46: istore          10
        //    48: iload           10
        //    50: iload           9
        //    52: if_icmpge       118
        //    55: aload           8
        //    57: iload           10
        //    59: caload         
        //    60: istore          11
        //    62: aload_0        
        //    63: getfield        dev/windhook/font/glyphrenderer/GlyphPage.font:Ljava/awt/Font;
        //    66: iload           11
        //    68: invokestatic    java/lang/Character.toString:(C)Ljava/lang/String;
        //    71: aload           7
        //    73: invokevirtual   java/awt/Font.getStringBounds:(Ljava/lang/String;Ljava/awt/font/FontRenderContext;)Ljava/awt/geom/Rectangle2D;
        //    76: astore          12
        //    78: dload_2        
        //    79: aload           12
        //    81: invokevirtual   java/awt/geom/Rectangle2D.getWidth:()D
        //    84: dcmpg          
        //    85: ifge            94
        //    88: aload           12
        //    90: invokevirtual   java/awt/geom/Rectangle2D.getWidth:()D
        //    93: dstore_2       
        //    94: dload           4
        //    96: aload           12
        //    98: invokevirtual   java/awt/geom/Rectangle2D.getHeight:()D
        //   101: dcmpg          
        //   102: ifge            112
        //   105: aload           12
        //   107: invokevirtual   java/awt/geom/Rectangle2D.getHeight:()D
        //   110: dstore          4
        //   112: iinc            10, 1
        //   115: goto            48
        //   118: dload_2        
        //   119: ldc2_w          2.0
        //   122: dadd           
        //   123: dstore_2       
        //   124: dload           4
        //   126: ldc2_w          2.0
        //   129: dadd           
        //   130: dstore          4
        //   132: aload_0        
        //   133: dload_2        
        //   134: dload_2        
        //   135: dmul           
        //   136: aload_1        
        //   137: arraylength    
        //   138: i2d            
        //   139: dmul           
        //   140: invokestatic    java/lang/Math.sqrt:(D)D
        //   143: dload_2        
        //   144: ddiv           
        //   145: invokestatic    java/lang/Math.ceil:(D)D
        //   148: dload           4
        //   150: dload           4
        //   152: dmul           
        //   153: aload_1        
        //   154: arraylength    
        //   155: i2d            
        //   156: dmul           
        //   157: invokestatic    java/lang/Math.sqrt:(D)D
        //   160: dload           4
        //   162: ddiv           
        //   163: invokestatic    java/lang/Math.ceil:(D)D
        //   166: invokestatic    java/lang/Math.max:(DD)D
        //   169: dload_2        
        //   170: dload           4
        //   172: invokestatic    java/lang/Math.max:(DD)D
        //   175: dmul           
        //   176: invokestatic    java/lang/Math.ceil:(D)D
        //   179: d2i            
        //   180: iconst_1       
        //   181: iadd           
        //   182: putfield        dev/windhook/font/glyphrenderer/GlyphPage.imgSize:I
        //   185: aload_0        
        //   186: new             Ljava/awt/image/BufferedImage;
        //   189: dup            
        //   190: aload_0        
        //   191: getfield        dev/windhook/font/glyphrenderer/GlyphPage.imgSize:I
        //   194: aload_0        
        //   195: getfield        dev/windhook/font/glyphrenderer/GlyphPage.imgSize:I
        //   198: iconst_2       
        //   199: invokespecial   java/awt/image/BufferedImage.<init>:(III)V
        //   202: putfield        dev/windhook/font/glyphrenderer/GlyphPage.bufferedImage:Ljava/awt/image/BufferedImage;
        //   205: aload_0        
        //   206: getfield        dev/windhook/font/glyphrenderer/GlyphPage.bufferedImage:Ljava/awt/image/BufferedImage;
        //   209: invokevirtual   java/awt/image/BufferedImage.getGraphics:()Ljava/awt/Graphics;
        //   212: checkcast       Ljava/awt/Graphics2D;
        //   215: astore          8
        //   217: aload           8
        //   219: aload_0        
        //   220: getfield        dev/windhook/font/glyphrenderer/GlyphPage.font:Ljava/awt/Font;
        //   223: invokevirtual   java/awt/Graphics2D.setFont:(Ljava/awt/Font;)V
        //   226: aload           8
        //   228: new             Ljava/awt/Color;
        //   231: dup            
        //   232: sipush          255
        //   235: sipush          255
        //   238: sipush          255
        //   241: iconst_0       
        //   242: invokespecial   java/awt/Color.<init>:(IIII)V
        //   245: invokevirtual   java/awt/Graphics2D.setColor:(Ljava/awt/Color;)V
        //   248: aload           8
        //   250: iconst_0       
        //   251: iconst_0       
        //   252: aload_0        
        //   253: getfield        dev/windhook/font/glyphrenderer/GlyphPage.imgSize:I
        //   256: aload_0        
        //   257: getfield        dev/windhook/font/glyphrenderer/GlyphPage.imgSize:I
        //   260: invokevirtual   java/awt/Graphics2D.fillRect:(IIII)V
        //   263: aload           8
        //   265: getstatic       java/awt/Color.white:Ljava/awt/Color;
        //   268: invokevirtual   java/awt/Graphics2D.setColor:(Ljava/awt/Color;)V
        //   271: aload           8
        //   273: getstatic       java/awt/RenderingHints.KEY_FRACTIONALMETRICS:Ljava/awt/RenderingHints$Key;
        //   276: aload_0        
        //   277: getfield        dev/windhook/font/glyphrenderer/GlyphPage.fractionalMetrics:Z
        //   280: ifeq            289
        //   283: getstatic       java/awt/RenderingHints.VALUE_FRACTIONALMETRICS_ON:Ljava/lang/Object;
        //   286: goto            292
        //   289: getstatic       java/awt/RenderingHints.VALUE_FRACTIONALMETRICS_OFF:Ljava/lang/Object;
        //   292: invokevirtual   java/awt/Graphics2D.setRenderingHint:(Ljava/awt/RenderingHints$Key;Ljava/lang/Object;)V
        //   295: aload           8
        //   297: getstatic       java/awt/RenderingHints.KEY_ANTIALIASING:Ljava/awt/RenderingHints$Key;
        //   300: aload_0        
        //   301: getfield        dev/windhook/font/glyphrenderer/GlyphPage.antiAliasing:Z
        //   304: ifeq            313
        //   307: getstatic       java/awt/RenderingHints.VALUE_ANTIALIAS_OFF:Ljava/lang/Object;
        //   310: goto            316
        //   313: getstatic       java/awt/RenderingHints.VALUE_ANTIALIAS_ON:Ljava/lang/Object;
        //   316: invokevirtual   java/awt/Graphics2D.setRenderingHint:(Ljava/awt/RenderingHints$Key;Ljava/lang/Object;)V
        //   319: aload           8
        //   321: getstatic       java/awt/RenderingHints.KEY_TEXT_ANTIALIASING:Ljava/awt/RenderingHints$Key;
        //   324: aload_0        
        //   325: getfield        dev/windhook/font/glyphrenderer/GlyphPage.antiAliasing:Z
        //   328: ifeq            337
        //   331: getstatic       java/awt/RenderingHints.VALUE_TEXT_ANTIALIAS_ON:Ljava/lang/Object;
        //   334: goto            340
        //   337: getstatic       java/awt/RenderingHints.VALUE_TEXT_ANTIALIAS_OFF:Ljava/lang/Object;
        //   340: invokevirtual   java/awt/Graphics2D.setRenderingHint:(Ljava/awt/RenderingHints$Key;Ljava/lang/Object;)V
        //   343: aload           8
        //   345: invokevirtual   java/awt/Graphics2D.getFontMetrics:()Ljava/awt/FontMetrics;
        //   348: astore          9
        //   350: iconst_0       
        //   351: istore          10
        //   353: iconst_0       
        //   354: istore          11
        //   356: iconst_1       
        //   357: istore          12
        //   359: aload_1        
        //   360: astore          13
        //   362: aload           13
        //   364: arraylength    
        //   365: istore          14
        //   367: iconst_0       
        //   368: istore          15
        //   370: iload           15
        //   372: iload           14
        //   374: if_icmpge       585
        //   377: aload           13
        //   379: iload           15
        //   381: caload         
        //   382: istore          16
        //   384: new             Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;
        //   387: dup            
        //   388: invokespecial   dev/windhook/font/glyphrenderer/GlyphPage$Glyph.<init>:()V
        //   391: astore          17
        //   393: aload           9
        //   395: iload           16
        //   397: invokestatic    java/lang/Character.toString:(C)Ljava/lang/String;
        //   400: aload           8
        //   402: invokevirtual   java/awt/FontMetrics.getStringBounds:(Ljava/lang/String;Ljava/awt/Graphics;)Ljava/awt/geom/Rectangle2D;
        //   405: astore          18
        //   407: aload           17
        //   409: aload           18
        //   411: invokevirtual   java/awt/geom/Rectangle2D.getBounds:()Ljava/awt/Rectangle;
        //   414: getfield        java/awt/Rectangle.width:I
        //   417: bipush          8
        //   419: iadd           
        //   420: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$002:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;I)I
        //   423: pop            
        //   424: aload           17
        //   426: aload           18
        //   428: invokevirtual   java/awt/geom/Rectangle2D.getBounds:()Ljava/awt/Rectangle;
        //   431: getfield        java/awt/Rectangle.height:I
        //   434: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$102:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;I)I
        //   437: pop            
        //   438: iload           12
        //   440: aload           17
        //   442: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$100:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;)I
        //   445: iadd           
        //   446: aload_0        
        //   447: getfield        dev/windhook/font/glyphrenderer/GlyphPage.imgSize:I
        //   450: iload           11
        //   452: aload           17
        //   454: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$000:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;)I
        //   457: iadd           
        //   458: aload_0        
        //   459: getfield        dev/windhook/font/glyphrenderer/GlyphPage.imgSize:I
        //   462: if_icmplt       478
        //   465: iconst_0       
        //   466: istore          11
        //   468: iload           12
        //   470: iload           10
        //   472: iadd           
        //   473: istore          12
        //   475: iconst_0       
        //   476: istore          10
        //   478: aload           17
        //   480: iload           11
        //   482: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$202:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;I)I
        //   485: pop            
        //   486: aload           17
        //   488: iload           12
        //   490: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$302:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;I)I
        //   493: pop            
        //   494: aload           17
        //   496: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$100:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;)I
        //   499: aload_0        
        //   500: getfield        dev/windhook/font/glyphrenderer/GlyphPage.maxFontHeight:I
        //   503: if_icmple       515
        //   506: aload_0        
        //   507: aload           17
        //   509: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$100:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;)I
        //   512: putfield        dev/windhook/font/glyphrenderer/GlyphPage.maxFontHeight:I
        //   515: aload           17
        //   517: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$100:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;)I
        //   520: iload           10
        //   522: if_icmple       532
        //   525: aload           17
        //   527: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$100:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;)I
        //   530: istore          10
        //   532: aload           8
        //   534: iload           16
        //   536: invokestatic    java/lang/Character.toString:(C)Ljava/lang/String;
        //   539: iload           11
        //   541: iconst_2       
        //   542: iadd           
        //   543: iload           12
        //   545: aload           9
        //   547: invokevirtual   java/awt/FontMetrics.getAscent:()I
        //   550: iadd           
        //   551: invokevirtual   java/awt/Graphics2D.drawString:(Ljava/lang/String;II)V
        //   554: iload           11
        //   556: aload           17
        //   558: invokestatic    dev/windhook/font/glyphrenderer/GlyphPage$Glyph.access$000:(Ldev/windhook/font/glyphrenderer/GlyphPage$Glyph;)I
        //   561: iadd           
        //   562: istore          11
        //   564: aload_0        
        //   565: getfield        dev/windhook/font/glyphrenderer/GlyphPage.glyphCharacterMap:Ljava/util/HashMap;
        //   568: iload           16
        //   570: invokestatic    java/lang/Character.valueOf:(C)Ljava/lang/Character;
        //   573: aload           17
        //   575: invokevirtual   java/util/HashMap.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   578: pop            
        //   579: iinc            15, 1
        //   582: goto            370
        //   585: return         
        //    StackMap: 5B 6F 33 FB
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0370 (coming from #0582).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void setupTexture() {
        this.loadedTexture = new DynamicTexture(this.bufferedImage);
    }
    
    public void bindTexture() {
        GlStateManager.bindTexture(this.loadedTexture.getGlTextureId());
    }
    
    public void unbindTexture() {
        GlStateManager.bindTexture(0);
    }
    
    public float drawChar(final char c, final float n, final float n2) {
        final Glyph glyph = this.glyphCharacterMap.get(c);
        if (glyph == null) {
            return 0.0f;
        }
        final float n3 = Glyph.access$200(glyph) / (float)this.imgSize;
        final float n4 = Glyph.access$300(glyph) / (float)this.imgSize;
        final float n5 = Glyph.access$000(glyph) / (float)this.imgSize;
        final float n6 = Glyph.access$100(glyph) / (float)this.imgSize;
        final float n7 = (float)Glyph.access$000(glyph);
        final float n8 = (float)Glyph.access$100(glyph);
        GL11.glBegin(4);
        GL11.glTexCoord2f(n3 + n5, n4);
        GL11.glVertex2f(n + n7, n2);
        GL11.glTexCoord2f(n3, n4);
        GL11.glVertex2f(n, n2);
        GL11.glTexCoord2f(n3, n4 + n6);
        GL11.glVertex2f(n, n2 + n8);
        GL11.glTexCoord2f(n3, n4 + n6);
        GL11.glVertex2f(n, n2 + n8);
        GL11.glTexCoord2f(n3 + n5, n4 + n6);
        GL11.glVertex2f(n + n7, n2 + n8);
        GL11.glTexCoord2f(n3 + n5, n4);
        GL11.glVertex2f(n + n7, n2);
        GL11.glEnd();
        return n7 - 8.0f;
    }
    
    public float getWidth(final char c) {
        return (float)Glyph.access$000(this.glyphCharacterMap.get(c));
    }
    
    public int getMaxFontHeight() {
        return this.maxFontHeight;
    }
    
    public boolean isAntiAliasingEnabled() {
        return this.antiAliasing;
    }
    
    public boolean isFractionalMetricsEnabled() {
        return this.fractionalMetrics;
    }
    
    static class Glyph
    {
        public int x;
        public int y;
        public int width;
        public int height;
        
        public Glyph(final int x, final int y, final int width, final int height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
        
        public Glyph() {
        }
        
        public int getX() {
            return this.x;
        }
        
        public int getY() {
            return this.y;
        }
        
        public int getWidth() {
            return this.width;
        }
        
        public int getHeight() {
            return this.height;
        }
        
        public static int access$002(final Glyph glyph, final int width) {
            return glyph.width = width;
        }
        
        public static int access$102(final Glyph glyph, final int height) {
            return glyph.height = height;
        }
        
        public static int access$100(final Glyph glyph) {
            return glyph.height;
        }
        
        public static int access$000(final Glyph glyph) {
            return glyph.width;
        }
        
        public static int access$202(final Glyph glyph, final int x) {
            return glyph.x = x;
        }
        
        public static int access$302(final Glyph glyph, final int y) {
            return glyph.y = y;
        }
        
        public static int access$200(final Glyph glyph) {
            return glyph.x;
        }
        
        public static int access$300(final Glyph glyph) {
            return glyph.y;
        }
    }
}
