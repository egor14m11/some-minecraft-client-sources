// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.font.glyphrenderer;

import java.util.Iterator;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.Tessellator;
import java.util.Locale;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager;
import java.awt.Font;
import java.util.Random;

public class GlyphPageFontRenderer implements BasicFontRenderer
{
    public Random fontRandom;
    public float posX;
    public float posY;
    public int[] colorCode;
    public float red;
    public float blue;
    public float green;
    public float alpha;
    public int textColor;
    public boolean randomStyle;
    public boolean boldStyle;
    public boolean italicStyle;
    public boolean underlineStyle;
    public boolean strikethroughStyle;
    public GlyphPage regularGlyphPage;
    public GlyphPage boldGlyphPage;
    public GlyphPage italicGlyphPage;
    public GlyphPage boldItalicGlyphPage;
    
    public GlyphPageFontRenderer(final GlyphPage regularGlyphPage, final GlyphPage boldGlyphPage, final GlyphPage italicGlyphPage, final GlyphPage boldItalicGlyphPage) {
        this.fontRandom = new Random();
        this.colorCode = new int[32];
        this.regularGlyphPage = regularGlyphPage;
        this.boldGlyphPage = boldGlyphPage;
        this.italicGlyphPage = italicGlyphPage;
        this.boldItalicGlyphPage = boldItalicGlyphPage;
        for (int i = 0; i < 32; ++i) {
            final int n = (i >> 3 & 0x1) * 85;
            int n2 = (i >> 2 & 0x1) * 170 + n;
            int n3 = (i >> 1 & 0x1) * 170 + n;
            int n4 = (i & 0x1) * 170 + n;
            if (i == 6) {
                n2 += 85;
            }
            if (i >= 16) {
                n2 /= 4;
                n3 /= 4;
                n4 /= 4;
            }
            this.colorCode[i] = ((n2 & 0xFF) << 16 | (n3 & 0xFF) << 8 | (n4 & 0xFF));
        }
    }
    
    public static GlyphPageFontRenderer create(final String s, final int n, final boolean b, final boolean b2, final boolean b3) {
        final char[] array = new char[256];
        for (int i = 0; i < array.length; ++i) {
            array[i] = (char)i;
        }
        final GlyphPage glyphPage = new GlyphPage(new Font(s, 0, n), true, true);
        glyphPage.generateGlyphPage(array);
        glyphPage.setupTexture();
        GlyphPage glyphPage2 = glyphPage;
        GlyphPage glyphPage3 = glyphPage;
        GlyphPage glyphPage4 = glyphPage;
        if (b) {
            glyphPage2 = new GlyphPage(new Font(s, 1, n), true, true);
            glyphPage2.generateGlyphPage(array);
            glyphPage2.setupTexture();
        }
        if (b2) {
            glyphPage3 = new GlyphPage(new Font(s, 2, n), true, true);
            glyphPage3.generateGlyphPage(array);
            glyphPage3.setupTexture();
        }
        if (b3) {
            glyphPage4 = new GlyphPage(new Font(s, 3, n), true, true);
            glyphPage4.generateGlyphPage(array);
            glyphPage4.setupTexture();
        }
        return new GlyphPageFontRenderer(glyphPage, glyphPage2, glyphPage3, glyphPage4);
    }
    
    @Override
    public int drawString(final String s, final float n, final float n2, final int n3, final boolean b) {
        GlStateManager.enableAlpha();
        this.resetStyles();
        int n4;
        if (b) {
            n4 = Math.max(this.renderString(s, n + 1.0f, n2 + 1.0f, n3, true), this.renderString(s, n, n2, n3, false));
        }
        else {
            n4 = this.renderString(s, n, n2, n3, false);
        }
        return n4;
    }
    
    @Override
    public int drawStringWithShadow(final String s, final float n, final float n2, final int n3) {
        return this.drawString(s, n, n2, n3, true);
    }
    
    @Override
    public int drawString(final String s, final float n, final float n2, final int n3) {
        return this.drawString(s, n, n2, n3, false);
    }
    
    @Override
    public int drawCenteredString(final String s, final float n, final float n2, final int n3, final boolean b) {
        return this.drawString(s, n - this.getStringWidth(s) / 2, n2, n3, b);
    }
    
    public int renderString(final String s, final float n, final float n2, int n3, final boolean b) {
        if (s == null) {
            return 0;
        }
        if ((n3 & 0xFC000000) == 0x0) {
            n3 |= 0xFF000000;
        }
        if (b) {
            n3 = ((n3 & 0xFCFCFC) >> 2 | (n3 & 0xFF000000));
        }
        this.red = (n3 >> 16 & 0xFF) / 255.0f;
        this.blue = (n3 >> 8 & 0xFF) / 255.0f;
        this.green = (n3 & 0xFF) / 255.0f;
        this.alpha = (n3 >> 24 & 0xFF) / 255.0f;
        GlStateManager.color(this.red, this.blue, this.green, this.alpha);
        this.posX = n * 2.0f;
        this.posY = n2 * 2.0f;
        this.renderStringAtPos(s, b);
        return (int)(this.posX / 2.0f);
    }
    
    public void renderStringAtPos(final String s, final boolean b) {
        GlyphPage glyphPage = this.getCurrentGlyphPage();
        GL11.glPushMatrix();
        GL11.glScaled(0.0, 0.0, 0.0);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(770, 771);
        GlStateManager.enableTexture2D();
        glyphPage.bindTexture();
        GL11.glTexParameteri(3553, 10240, 9729);
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            if (char1 == '§' && i + 1 < s.length()) {
                int index = "0123456789abcdefklmnor".indexOf(s.toLowerCase(Locale.ENGLISH).charAt(i + 1));
                if (index < 16) {
                    this.randomStyle = false;
                    this.boldStyle = false;
                    this.strikethroughStyle = false;
                    this.underlineStyle = false;
                    this.italicStyle = false;
                    if (index < 0) {
                        index = 15;
                    }
                    if (b) {
                        index += 16;
                    }
                    final int textColor = this.colorCode[index];
                    this.textColor = textColor;
                    GlStateManager.color((textColor >> 16) / 255.0f, (textColor >> 8 & 0xFF) / 255.0f, (textColor & 0xFF) / 255.0f, this.alpha);
                }
                else if (index == 16) {
                    this.randomStyle = true;
                }
                else if (index == 17) {
                    this.boldStyle = true;
                }
                else if (index == 18) {
                    this.strikethroughStyle = true;
                }
                else if (index == 19) {
                    this.underlineStyle = true;
                }
                else if (index == 20) {
                    this.italicStyle = true;
                }
                else {
                    this.randomStyle = false;
                    this.boldStyle = false;
                    this.strikethroughStyle = false;
                    this.underlineStyle = false;
                    this.italicStyle = false;
                    GlStateManager.color(this.red, this.blue, this.green, this.alpha);
                }
                ++i;
            }
            else {
                glyphPage = this.getCurrentGlyphPage();
                glyphPage.bindTexture();
                this.doDraw(glyphPage.drawChar(char1, this.posX, this.posY), glyphPage);
            }
        }
        glyphPage.unbindTexture();
        GL11.glPopMatrix();
    }
    
    public void doDraw(final float n, final GlyphPage glyphPage) {
        if (this.strikethroughStyle) {
            final Tessellator instance = Tessellator.getInstance();
            final WorldRenderer worldRenderer = instance.getWorldRenderer();
            GlStateManager.disableTexture2D();
            worldRenderer.begin(7, DefaultVertexFormats.POSITION);
            worldRenderer.pos(this.posX, this.posY + glyphPage.getMaxFontHeight() / 2, 0.0).endVertex();
            worldRenderer.pos(this.posX + n, this.posY + glyphPage.getMaxFontHeight() / 2, 0.0).endVertex();
            worldRenderer.pos(this.posX + n, this.posY + glyphPage.getMaxFontHeight() / 2 - 1.0f, 0.0).endVertex();
            worldRenderer.pos(this.posX, this.posY + glyphPage.getMaxFontHeight() / 2 - 1.0f, 0.0).endVertex();
            instance.draw();
            GlStateManager.enableTexture2D();
        }
        if (this.underlineStyle) {
            final Tessellator instance2 = Tessellator.getInstance();
            final WorldRenderer worldRenderer2 = instance2.getWorldRenderer();
            GlStateManager.disableTexture2D();
            worldRenderer2.begin(7, DefaultVertexFormats.POSITION);
            final int n2 = this.underlineStyle ? -1 : 0;
            worldRenderer2.pos(this.posX + n2, this.posY + glyphPage.getMaxFontHeight(), 0.0).endVertex();
            worldRenderer2.pos(this.posX + n, this.posY + glyphPage.getMaxFontHeight(), 0.0).endVertex();
            worldRenderer2.pos(this.posX + n, this.posY + glyphPage.getMaxFontHeight() - 1.0f, 0.0).endVertex();
            worldRenderer2.pos(this.posX + n2, this.posY + glyphPage.getMaxFontHeight() - 1.0f, 0.0).endVertex();
            instance2.draw();
            GlStateManager.enableTexture2D();
        }
        this.posX += n;
    }
    
    public GlyphPage getCurrentGlyphPage() {
        if (this.boldStyle && this.italicStyle) {
            return this.boldItalicGlyphPage;
        }
        if (this.boldStyle) {
            return this.boldGlyphPage;
        }
        if (this.italicStyle) {
            return this.italicGlyphPage;
        }
        return this.regularGlyphPage;
    }
    
    public void resetStyles() {
        this.randomStyle = false;
        this.boldStyle = false;
        this.italicStyle = false;
        this.underlineStyle = false;
        this.strikethroughStyle = false;
    }
    
    @Override
    public int getFontHeight() {
        return this.regularGlyphPage.getMaxFontHeight() / 2;
    }
    
    @Override
    public int getStringWidth(String replace) {
        if (replace == null) {
            return 0;
        }
        int n = 0;
        final String s = "0123456789abcdefklmnor";
        for (int i = 0; i < s.length(); ++i) {
            replace = replace.replace("\ufffd" + s.charAt(i), "");
        }
        final int length = replace.length();
        int n2 = 0;
        for (int j = 0; j < length; ++j) {
            final char char1 = replace.charAt(j);
            if (char1 == '\ufffd') {
                n2 = 1;
            }
            else if (n2 != 0 && char1 >= '0' && char1 <= 'r') {
                final int index = "0123456789abcdefklmnor".indexOf(char1);
                if (index < 16) {
                    this.boldStyle = false;
                    this.italicStyle = false;
                }
                else if (index == 17) {
                    this.boldStyle = true;
                }
                else if (index == 20) {
                    this.italicStyle = true;
                }
                else if (index == 21) {
                    this.boldStyle = false;
                    this.italicStyle = false;
                }
                ++j;
                n2 = 0;
            }
            else {
                if (n2 != 0) {
                    --j;
                }
                n += (int)(this.getCurrentGlyphPage().getWidth(replace.charAt(j)) - 8.0f);
            }
        }
        return n / 2;
    }
    
    @Override
    public String trimStringToWidth(final String s, final int n) {
        return this.trimStringToWidth(s, n, false);
    }
    
    @Override
    public String trimStringToWidth(final String s, final int n, final boolean b) {
        final StringBuilder sb = new StringBuilder();
        int n2 = 0;
        final int n3 = b ? (s.length() - 1) : 0;
        final int n4 = b ? -1 : 1;
        int n5 = 0;
        for (int n6 = n3; n6 >= 0 && n6 < s.length() && n6 < n; n6 += n4) {
            char c = s.charAt(n6);
            if (c == '\ufffd') {
                n2 = 1;
            }
            else if (n2 != 0 && c >= '0' && c <= 'r') {
                final int index = "0123456789abcdefklmnor".indexOf(c);
                if (index < 16) {
                    this.boldStyle = false;
                    this.italicStyle = false;
                }
                else if (index == 17) {
                    this.boldStyle = true;
                }
                else if (index == 20) {
                    this.italicStyle = true;
                }
                else if (index == 21) {
                    this.boldStyle = false;
                    this.italicStyle = false;
                }
                ++n6;
                n2 = 0;
            }
            else {
                if (n2 != 0) {
                    --n6;
                }
                c = s.charAt(n6);
                n5 += (int)((this.getCurrentGlyphPage().getWidth(c) - 8.0f) / 2.0f);
            }
            if (n6 > n5) {
                break;
            }
            if (b) {
                sb.insert(0, c);
            }
            else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
    
    @Override
    public int getCharWidth(final char c) {
        return this.getStringWidth("" + c);
    }
    
    @Override
    public void onResourceManagerReload(final IResourceManager resourceManager) {
    }
    
    @Override
    public void setUnicodeFlag(final boolean b) {
    }
    
    @Override
    public void setBidiFlag(final boolean b) {
    }
    
    @Override
    public boolean getBidiFlag() {
        return false;
    }
    
    @Override
    public String wrapFormattedStringToWidth(final String s, final int n) {
        final int sizeStringToWidth = this.sizeStringToWidth(s, n);
        if (s.length() <= sizeStringToWidth) {
            return s;
        }
        final String substring = s.substring(0, sizeStringToWidth);
        final char char1 = s.charAt(sizeStringToWidth);
        new StringBuilder().append(getFormatFromString(substring)).append(s.substring(sizeStringToWidth + ((char1 == ' ' || char1 == '\n') ? 1 : 0))).toString();
        return substring;
    }
    
    public static String getFormatFromString(final String s) {
        String str = "";
        int index = -1;
        final int length = s.length();
        while ((index = s.indexOf(167, index + 1)) != -1) {
            if (index < length - 1) {
                final char char1 = s.charAt(index + 1);
                if (isFormatColor(char1)) {
                    str = "§" + char1;
                }
                else {
                    if (!isFormatSpecial(char1)) {
                        continue;
                    }
                    str = str + "§" + char1;
                }
            }
        }
        return str;
    }
    
    public int sizeStringToWidth(final String s, final int n) {
        final int length = s.length();
        float n2 = 0.0f;
        int i = 0;
        int n3 = -1;
        int n4 = 0;
        while (i < length) {
            final char char1 = s.charAt(i);
            Label_0167: {
                switch (char1) {
                    case 10: {
                        --i;
                        break Label_0167;
                    }
                    case 32: {
                        n3 = i;
                        break;
                    }
                    case 167: {
                        if (i >= length - 1) {
                            break Label_0167;
                        }
                        ++i;
                        final char char2 = s.charAt(i);
                        if (char2 == 'l' || char2 == 'L') {
                            n4 = 1;
                            break Label_0167;
                        }
                        if (char2 == 'r' || char2 == 'R' || isFormatColor(char2)) {
                            n4 = 0;
                        }
                        break Label_0167;
                    }
                }
                n2 += this.getCharWidthFloat(char1);
                if (n4 != 0) {
                    ++n2;
                }
            }
            if (char1 == '\n') {
                n3 = ++i;
                break;
            }
            if (n2 > n) {
                break;
            }
            ++i;
        }
        return (i != length && n3 != -1 && n3 < i) ? n3 : i;
    }
    
    public static boolean isFormatColor(final char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }
    
    public static boolean isFormatSpecial(final char c) {
        return (c >= 'k' && c <= 'o') || (c >= 'K' && c <= 'O') || c == 'r' || c == 'R';
    }
    
    @Override
    public List listFormattedStringToWidth(final String s, final int n) {
        return Arrays.asList(this.wrapFormattedStringToWidth(s, n).split("\n"));
    }
    
    @Override
    public int getColorCode(final char ch) {
        final int index = "0123456789abcdef".indexOf(ch);
        if (index >= 0 && index < this.colorCode.length) {
            return this.colorCode[index];
        }
        return 16777215;
    }
    
    @Override
    public boolean isEnabled() {
        return true;
    }
    
    @Override
    public boolean setEnabled(final boolean b) {
        return true;
    }
    
    @Override
    public void setFontRandomSeed(final long seed) {
        this.fontRandom.setSeed(seed);
    }
    
    @Override
    public void drawSplitString(String trimStringNewline, final int n, final int n2, final int n3, final int textColor) {
        this.resetStyles();
        this.textColor = textColor;
        trimStringNewline = this.trimStringNewline(trimStringNewline);
        this.renderSplitString(trimStringNewline, n, n2, n3, false);
    }
    
    @Override
    public int splitStringWidth(final String s, final int n) {
        return this.getFontHeight() * this.listFormattedStringToWidth(s, n).size();
    }
    
    @Override
    public boolean getUnicodeFlag() {
        return false;
    }
    
    public float getCharWidthFloat(final char c) {
        return (float)this.getCharWidth(c);
    }
    
    public int renderStringAligned(final String s, final int n, final int n2, final int n3, final int n4, final boolean b) {
        return this.renderString(s, (float)n, (float)n2, n4, b);
    }
    
    public void renderSplitString(final String s, final int n, int n2, final int n3, final boolean b) {
        final Iterator<String> iterator = this.listFormattedStringToWidth(s, n3).iterator();
        while (iterator.hasNext()) {
            this.renderStringAligned(iterator.next(), n, n2, n3, this.textColor, b);
            n2 += this.getFontHeight();
        }
    }
    
    public String trimStringNewline(String substring) {
        while (substring != null && substring.endsWith("\n")) {
            substring = substring.substring(0, substring.length() - 1);
        }
        return substring;
    }
}
