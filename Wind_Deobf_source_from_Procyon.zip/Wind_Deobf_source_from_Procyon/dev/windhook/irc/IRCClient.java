// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.irc;

import dev.windhook.utils.Player;

public class IRCClient extends dev.windhook.utils.IRCClient
{
    public String channel;
    public String prefix;
    
    public IRCClient(final String s, final int n, final String s2, final String channel) {
        super(s, n, s2);
        this.channel = channel;
        this.prefix = "&dIRC&7> ";
    }
    
    public String getChannel() {
        return this.channel;
    }
    
    public String getPrefix() {
        return this.prefix;
    }
    
    @Override
    public void listener(final String s) {
        if (!this.isActive()) {
            return;
        }
        if (!s.contains("!") || !s.contains(":")) {
            return;
        }
        Player.sendMessage(String.format("%1$s&b%2$s&7: &e%3$s", this.prefix, s.substring(1, s.indexOf("!")), s.substring(s.lastIndexOf(":") + 1, s.length())), false);
    }
    
    @Override
    public void onConnect() {
    }
    
    @Override
    public void exception(final Exception ex) {
    }
}
