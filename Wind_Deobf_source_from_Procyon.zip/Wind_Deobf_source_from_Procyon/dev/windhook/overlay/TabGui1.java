// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.overlay;

import dev.windhook.utils.Colors;
import dev.windhook.utils.RenderUtils;
import java.awt.Color;
import java.util.Collection;
import dev.windhook.utils.Strings;
import java.util.ArrayList;
import dev.windhook.event.events.MouseClickEvent;
import dev.windhook.event.events.MouseScrollEvent;
import dev.windhook.event.events.KeyPressedEvent;
import net.minecraft.client.gui.GuiScreen;
import dev.windhook.gui.clickgui.GuiBind;
import dev.windhook.gui.clickgui.ClickGui;
import dev.windhook.module.modules.client.TabGui;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.module.ModuleSettings;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import dev.windhook.module.Category;
import java.util.List;
import dev.windhook.module.Module;
import dev.windhook.module.modules.semi_hidden.AdvancedTabGui;
import dev.windhook.BaseClient;
import dev.windhook.module.ModuleManager;
import dev.windhook.utils.animation.basic.Translate;
import dev.windhook.event.EventListener;

public class TabGui1 extends EventListener
{
    public int currentCategory;
    public int currentModule;
    public int currentSetting;
    public Translate translator;
    public String[] moduleSettingsExceptions;
    public int indentation;
    public int maxItemWidth;
    public ModuleManager moduleManager;
    
    public TabGui1() {
        this.translator = new Translate(0.0f, 0.0f);
        BaseClient.instance.getEventManager().registerListener(this);
        this.moduleManager = BaseClient.instance.getModuleManager();
        this.moduleSettingsExceptions = new String[] { "toggled", "key" };
    }
    
    public int getMode() {
        return BaseClient.instance.getModuleManager().getModule(AdvancedTabGui.class).isToggled() ? 1 : 0;
    }
    
    public List<Module> getModules() {
        return this.moduleManager.getModules(Category.values()[this.currentCategory]);
    }
    
    public Module getCurrentModule() {
        final int size = this.getModules().size();
        if (size <= this.currentModule) {
            this.currentModule = size;
        }
        return this.getModules().get(this.currentModule);
    }
    
    public List<String> getCurrentSettingsList() {
        return null;
    }
    
    public List<String> getFilteredSettingsList() {
        final List<? super Object> list = this.getCurrentSettingsList().stream().distinct().collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList());
        for (int i = 0; i < this.moduleSettingsExceptions.length; ++i) {
            for (int j = 0; j < list.size(); ++j) {
                final String s = list.get(j);
                if (this.moduleSettingsExceptions[i].equalsIgnoreCase(s.substring(0, s.indexOf(":")))) {
                    list.remove(j);
                }
            }
        }
        return (List<String>)list;
    }
    
    public String getCurrentSettings() {
        return this.getCurrentSettingsList().get(this.currentSetting);
    }
    
    public String getCurrentSettingsFiltered() {
        return this.getFilteredSettingsList().get(this.currentSetting);
    }
    
    public ModuleSettings getCurrentModuleSettings() {
        return null;
    }
    
    @Override
    public void onRender2D(final Render2DEvent render2DEvent) {
        if (!BaseClient.instance.getModuleManager().getModule(TabGui.class).isToggled()) {
            return;
        }
        final GuiScreen currentScreen = this.mc.currentScreen;
        if (currentScreen != null && (currentScreen instanceof ClickGui || currentScreen instanceof GuiBind)) {
            return;
        }
        switch (this.indentation) {
            default: {
                this.renderCategories(render2DEvent);
                break;
            }
            case 1: {
                this.renderModules(render2DEvent);
                break;
            }
            case 2:
            case 3: {
                this.renderSettings(render2DEvent);
                break;
            }
        }
    }
    
    public void menuScroll(final int p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: invokevirtual   dev/windhook/BaseClient.getModuleManager:()Ldev/windhook/module/ModuleManager;
        //     6: ldc             Ldev/windhook/module/modules/client/TabGui;.class
        //     8: invokevirtual   dev/windhook/module/ModuleManager.getModule:(Ljava/lang/Class;)Ldev/windhook/module/Module;
        //    11: invokevirtual   dev/windhook/module/Module.isToggled:()Z
        //    14: ifne            18
        //    17: return         
        //    18: aload_0        
        //    19: getfield        dev/windhook/overlay/TabGui1.indentation:I
        //    22: iconst_3       
        //    23: if_icmpne       246
        //    26: aload_0        
        //    27: invokespecial   dev/windhook/overlay/TabGui1.getCurrentSettingsFiltered:()Ljava/lang/String;
        //    30: ldc             ": "
        //    32: invokevirtual   java/lang/String.split:(Ljava/lang/String;)[Ljava/lang/String;
        //    35: astore_2       
        //    36: aload_2        
        //    37: iconst_0       
        //    38: aaload         
        //    39: astore_3       
        //    40: aload_2        
        //    41: iconst_1       
        //    42: aaload         
        //    43: astore          4
        //    45: aload           4
        //    47: invokestatic    dev/windhook/utils/Integers.isInteger:(Ljava/lang/String;)Z
        //    50: ifeq            77
        //    53: aload           4
        //    55: invokestatic    dev/windhook/utils/Integers.getInteger:(Ljava/lang/String;)I
        //    58: istore          5
        //    60: iload           5
        //    62: iload_1        
        //    63: ifne            70
        //    66: iconst_m1      
        //    67: goto            66
        //    70: iconst_1       
        //    71: iadd           
        //    72: istore          5
        //    74: goto            240
        //    77: aload           4
        //    79: invokestatic    dev/windhook/utils/Integers.isDouble:(Ljava/lang/String;)Z
        //    82: ifeq            213
        //    85: aload           4
        //    87: invokestatic    java/lang/Double.parseDouble:(Ljava/lang/String;)D
        //    90: dstore          5
        //    92: aload_0        
        //    93: getfield        dev/windhook/overlay/TabGui1.mc:Lnet/minecraft/client/Minecraft;
        //    96: getfield        net/minecraft/client/Minecraft.gameSettings:Lnet/minecraft/client/settings/GameSettings;
        //    99: getfield        net/minecraft/client/settings/GameSettings.keyBindSneak:Lnet/minecraft/client/settings/KeyBinding;
        //   102: invokevirtual   net/minecraft/client/settings/KeyBinding.isKeyDown:()Z
        //   105: ifeq            112
        //   108: dconst_1       
        //   109: goto            113
        //   112: dconst_0       
        //   113: dstore          7
        //   115: dload           5
        //   117: iload_1        
        //   118: ifne            127
        //   121: dload           7
        //   123: dneg           
        //   124: goto            129
        //   127: dload           7
        //   129: dadd           
        //   130: dstore          5
        //   132: new             Ljava/text/DecimalFormat;
        //   135: dup            
        //   136: ldc             "#.#"
        //   138: invokespecial   java/text/DecimalFormat.<init>:(Ljava/lang/String;)V
        //   141: dload           5
        //   143: invokevirtual   java/text/DecimalFormat.format:(D)Ljava/lang/String;
        //   146: ldc             ","
        //   148: ldc             "."
        //   150: invokevirtual   java/lang/String.replace:(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
        //   153: invokestatic    java/lang/Double.valueOf:(Ljava/lang/String;)Ljava/lang/Double;
        //   156: invokevirtual   java/lang/Double.doubleValue:()D
        //   159: dstore          5
        //   161: dload           5
        //   163: dconst_0       
        //   164: dcmpg          
        //   165: ifge            171
        //   168: dconst_0       
        //   169: dstore          5
        //   171: dload           5
        //   173: invokestatic    java/lang/Double.toString:(D)Ljava/lang/String;
        //   176: ldc             "."
        //   178: invokevirtual   java/lang/String.contains:(Ljava/lang/CharSequence;)Z
        //   181: ifne            210
        //   184: new             Ljava/lang/StringBuilder;
        //   187: dup            
        //   188: invokespecial   java/lang/StringBuilder.<init>:()V
        //   191: dload           5
        //   193: invokevirtual   java/lang/StringBuilder.append:(D)Ljava/lang/StringBuilder;
        //   196: ldc_w           ".0"
        //   199: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   202: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   205: invokestatic    java/lang/Double.parseDouble:(Ljava/lang/String;)D
        //   208: dstore          5
        //   210: goto            240
        //   213: aload           4
        //   215: invokestatic    dev/windhook/utils/Strings.isBoolean:(Ljava/lang/String;)Z
        //   218: ifeq            240
        //   221: aload           4
        //   223: invokestatic    dev/windhook/utils/Strings.getBooleanValue:(Ljava/lang/String;)Z
        //   226: istore          5
        //   228: iload           5
        //   230: ifne            237
        //   233: iconst_1       
        //   234: goto            238
        //   237: iconst_0       
        //   238: istore          5
        //   240: aload_0        
        //   241: iconst_0       
        //   242: putfield        dev/windhook/overlay/TabGui1.maxItemWidth:I
        //   245: return         
        //   246: aload_0        
        //   247: getfield        dev/windhook/overlay/TabGui1.indentation:I
        //   250: tableswitch {
        //                0: 280
        //                1: 339
        //                2: 408
        //                3: 408
        //          default: 280
        //        }
        //   280: aload_0        
        //   281: iload_1        
        //   282: ifne            311
        //   285: aload_0        
        //   286: getfield        dev/windhook/overlay/TabGui1.currentCategory:I
        //   289: invokestatic    dev/windhook/module/Category.values:()[Ldev/windhook/module/Category;
        //   292: arraylength    
        //   293: iconst_3       
        //   294: isub           
        //   295: if_icmpne       302
        //   298: iconst_0       
        //   299: goto            333
        //   302: aload_0        
        //   303: getfield        dev/windhook/overlay/TabGui1.currentCategory:I
        //   306: iconst_1       
        //   307: iadd           
        //   308: goto            333
        //   311: aload_0        
        //   312: getfield        dev/windhook/overlay/TabGui1.currentCategory:I
        //   315: ifne            327
        //   318: invokestatic    dev/windhook/module/Category.values:()[Ldev/windhook/module/Category;
        //   321: arraylength    
        //   322: iconst_3       
        //   323: isub           
        //   324: goto            333
        //   327: aload_0        
        //   328: getfield        dev/windhook/overlay/TabGui1.currentCategory:I
        //   331: iconst_1       
        //   332: isub           
        //   333: putfield        dev/windhook/overlay/TabGui1.currentCategory:I
        //   336: goto            474
        //   339: aload_0        
        //   340: iload_1        
        //   341: ifne            375
        //   344: aload_0        
        //   345: getfield        dev/windhook/overlay/TabGui1.currentModule:I
        //   348: aload_0        
        //   349: invokespecial   dev/windhook/overlay/TabGui1.getModules:()Ljava/util/List;
        //   352: invokeinterface java/util/List.size:()I
        //   357: iconst_1       
        //   358: isub           
        //   359: if_icmpne       366
        //   362: iconst_0       
        //   363: goto            402
        //   366: aload_0        
        //   367: getfield        dev/windhook/overlay/TabGui1.currentModule:I
        //   370: iconst_1       
        //   371: iadd           
        //   372: goto            402
        //   375: aload_0        
        //   376: getfield        dev/windhook/overlay/TabGui1.currentModule:I
        //   379: ifne            396
        //   382: aload_0        
        //   383: invokespecial   dev/windhook/overlay/TabGui1.getModules:()Ljava/util/List;
        //   386: invokeinterface java/util/List.size:()I
        //   391: iconst_1       
        //   392: isub           
        //   393: goto            402
        //   396: aload_0        
        //   397: getfield        dev/windhook/overlay/TabGui1.currentModule:I
        //   400: iconst_1       
        //   401: isub           
        //   402: putfield        dev/windhook/overlay/TabGui1.currentModule:I
        //   405: goto            474
        //   408: aload_0        
        //   409: iload_1        
        //   410: ifne            444
        //   413: aload_0        
        //   414: getfield        dev/windhook/overlay/TabGui1.currentSetting:I
        //   417: aload_0        
        //   418: invokespecial   dev/windhook/overlay/TabGui1.getFilteredSettingsList:()Ljava/util/List;
        //   421: invokeinterface java/util/List.size:()I
        //   426: iconst_1       
        //   427: isub           
        //   428: if_icmpne       435
        //   431: iconst_0       
        //   432: goto            471
        //   435: aload_0        
        //   436: getfield        dev/windhook/overlay/TabGui1.currentSetting:I
        //   439: iconst_1       
        //   440: iadd           
        //   441: goto            471
        //   444: aload_0        
        //   445: getfield        dev/windhook/overlay/TabGui1.currentSetting:I
        //   448: ifne            465
        //   451: aload_0        
        //   452: invokespecial   dev/windhook/overlay/TabGui1.getFilteredSettingsList:()Ljava/util/List;
        //   455: invokeinterface java/util/List.size:()I
        //   460: iconst_1       
        //   461: isub           
        //   462: goto            471
        //   465: aload_0        
        //   466: getfield        dev/windhook/overlay/TabGui1.currentSetting:I
        //   469: iconst_1       
        //   470: isub           
        //   471: putfield        dev/windhook/overlay/TabGui1.currentSetting:I
        //   474: return         
        //    StackMap: 5B 6F 33 FB
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0066 (coming from #0067).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void menuInteract(final int n) {
        if (!BaseClient.instance.getModuleManager().getModule(TabGui.class).isToggled()) {
            return;
        }
        if (this.indentation == 3) {
            this.indentation -= 2;
            this.menuInteract(1);
            return;
        }
        boolean b = (this.indentation != 0 || this.getModules().size() != 0) && (this.indentation != 1 || this.getCurrentSettingsList().size() != 0);
        if (this.indentation == 0 && this.getModules().size() == 0) {
            b = false;
        }
        if (this.indentation == 1) {
            if (this.getFilteredSettingsList().size() == 0) {
                b = false;
            }
            else {
                final List<String> filteredSettingsList = this.getFilteredSettingsList();
                b = false;
                final int n2 = 0;
                if (n2 < filteredSettingsList.size()) {
                    final String s = filteredSettingsList.get(n2);
                    b = true;
                }
            }
        }
        final int n3 = (n == 0) ? ((this.indentation == 0) ? 0 : ((this.indentation == 3) ? 0 : -1)) : (b ? 1 : 0);
        this.indentation += n3;
        if (this.indentation < 2) {
            this.currentSetting = 0;
        }
        if (this.indentation < 1) {
            this.currentModule = 0;
        }
        this.maxItemWidth = ((n3 == 0) ? this.maxItemWidth : 0);
    }
    
    @Override
    public void onKeyPressed(final KeyPressedEvent keyPressedEvent) {
        if (keyPressedEvent.getKey() == 210) {
            this.menuInteract(0);
        }
        if (keyPressedEvent.getKey() == 28 && this.indentation == 1) {
            this.getCurrentModule().toggle();
            return;
        }
        if (this.getMode() != 0) {
            return;
        }
        switch (keyPressedEvent.getKey()) {
            case 200: {
                this.menuScroll(1);
                break;
            }
            case 208: {
                this.menuScroll(0);
                break;
            }
            case 14:
            case 203: {
                this.menuInteract(0);
                break;
            }
            case 205: {
                this.menuInteract(1);
                break;
            }
            default: {}
        }
    }
    
    @Override
    public void onMouseScroll(final MouseScrollEvent mouseScrollEvent) {
        if (this.getMode() != 1) {
            return;
        }
        mouseScrollEvent.setCancelled(true);
        switch (mouseScrollEvent.getDirection()) {
            case 120: {
                this.menuScroll(1);
                break;
            }
            case 240: {
                this.menuScroll(1);
                this.menuScroll(1);
            }
            case -120: {
                this.menuScroll(0);
                break;
            }
            case -240: {
                this.menuScroll(0);
                this.menuScroll(0);
                break;
            }
            default: {}
        }
    }
    
    @Override
    public void onMouseClick(final MouseClickEvent mouseClickEvent) {
        if (this.getMode() != 1) {
            return;
        }
        switch (mouseClickEvent.getButton()) {
            case 1: {
                this.menuInteract(0);
            }
            case 0: {
                this.menuInteract(1);
            }
            case 4: {
                if (this.indentation != 1) {
                    return;
                }
                this.getCurrentModule().toggle();
                break;
            }
        }
    }
    
    public void renderCategories(final Render2DEvent render2DEvent) {
        final ArrayList<String> list = new ArrayList<String>();
        final Category[] values = Category.values();
        for (int i = 0; i < values.length; ++i) {
            final Category category = values[i];
            if (!category.equals(Category.HIDDEN)) {
                if (!category.equals(Category.SEMI_HIDDEN)) {
                    list.add(Strings.capitalizeOnlyFirstLetter(category.name()));
                }
            }
        }
        this.renderMenu(list, this.currentCategory);
    }
    
    public void renderModules(final Render2DEvent render2DEvent) {
        final ArrayList<Module> list = (ArrayList<Module>)new ArrayList<Object>(this.getModules());
        final ArrayList<String> list2 = new ArrayList<String>();
        for (int i = 0; i < list.size(); ++i) {
            final Module module = list.get(i);
            list2.add((module.isToggled() ? "&a" : "") + Strings.capitalizeFirstLetter(module.getName()));
        }
        this.renderMenu(list2, this.currentModule);
    }
    
    public void renderSettings(final Render2DEvent render2DEvent) {
        this.renderMenu(this.getFilteredSettingsList(), this.currentSetting);
    }
    
    public void renderMenu(final List<String> list, final int n) {
        BaseClient.instance.getModuleManager().getModule(TabGui.class);
        final boolean enabled = ModuleManager.tabGui.rainbow.isEnabled();
        final boolean enabled2 = ModuleManager.tabGui.gradient.isEnabled();
        final int n2 = (int)ModuleManager.tabGui.speed.getValue();
        final int n3 = (int)ModuleManager.tabGui.offset.getValue();
        final int n4 = BaseClient.instance.getFontRenderer().getFontSize() / 2 + 4;
        final int fontSizeLogo = BaseClient.instance.getFontRenderer().fontSizeLogo;
        RenderUtils.drawGradientRect(5, n4 * 2 - 5 + fontSizeLogo, (this.maxItemWidth + 15) * 2, n4 * (list.size() + 2) - 5 + fontSizeLogo, new Color(0, 0, 0, 100).getRGB(), enabled2 ? new Color(100, 100, 100, 200).getRGB() : new Color(0, 0, 0, 100).getRGB());
        for (int i = 0; i < list.size(); ++i) {
            String string = list.get(i);
            final int stringWidthCFR = Strings.getStringWidthCFR(string);
            if (stringWidthCFR > this.maxItemWidth) {
                this.maxItemWidth = stringWidthCFR;
            }
            if (i == n) {
                final int n5 = enabled ? Colors.getRGBWave((float)n2, 1.0f, 0.0f, i * n3 * 2) : dev.windhook.module.Color.getColor(string).getRGB();
                this.translator.interpolate((float)(n4 * (i + 2) - 5 + fontSizeLogo), (float)(n4 * (i + 3) - 5 + fontSizeLogo), 10.0);
                RenderUtils.drawGradientRect(5, (int)this.translator.getX(), (this.maxItemWidth + 15 + 5) * 2 - 7, (int)this.translator.getY(), enabled ? n5 : dev.windhook.module.Color.getColor(string).getRGB(), enabled2 ? new Color(0, 0, 0).getRGB() : (enabled ? n5 : dev.windhook.module.Color.getColor(string).getRGB()));
                if (this.indentation == 3) {
                    string = "&a" + string;
                }
            }
            RenderUtils.drawString(string, 10, n4 * (i + 2) - 3 + fontSizeLogo, -1);
        }
        if (this.indentation != 1 || this.getCurrentModule() == null) {
            return;
        }
        final String description = this.getCurrentModule().getDescription();
        RenderUtils.drawGradientRect(5, 1 + n4 * (list.size() + 3) - n4 + fontSizeLogo, Strings.getStringWidthCFR(description) + 12, n4 * (list.size() + 3) + fontSizeLogo, new Color(0, 0, 0, 100).getRGB(), enabled2 ? new Color(0, 0, 0, 100).getRGB() : new Color(100, 100, 100, 200).getRGB());
        RenderUtils.drawString(description, 8, n4 * (list.size() + 2) + fontSizeLogo, -1);
    }
}
