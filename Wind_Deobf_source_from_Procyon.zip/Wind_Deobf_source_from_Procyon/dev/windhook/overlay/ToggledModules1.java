// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.overlay;

import dev.windhook.module.settings.ModeSetting;
import dev.windhook.module.settings.Setting;
import java.util.Iterator;
import net.minecraft.client.gui.FontRenderer;
import java.util.List;
import net.minecraft.client.gui.Gui;
import java.util.function.ToIntFunction;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import dev.windhook.utils.RenderUtils;
import java.awt.Color;
import dev.windhook.module.Category;
import dev.windhook.utils.Integers;
import dev.windhook.utils.Colors;
import dev.windhook.utils.Strings;
import java.util.Comparator;
import dev.windhook.module.ModuleManager;
import dev.windhook.module.Module;
import dev.windhook.module.modules.client.ArrayList;
import dev.windhook.event.events.Render2DEvent;
import dev.windhook.BaseClient;
import dev.windhook.font.UnicodeFontRenderer;
import dev.windhook.event.EventListener;

public class ToggledModules1 extends EventListener
{
    public double newLineCurrent;
    public UnicodeFontRenderer newFr;
    
    public ToggledModules1() {
        this.newLineCurrent = 0.0;
        this.newFr = BaseClient.instance.font2.getFont(21);
        BaseClient.instance.getEventManager().registerListener(this);
    }
    
    @Override
    public void onRender2D(final Render2DEvent render2DEvent) {
        if (BaseClient.instance.getModuleManager().getModule(ArrayList.class).isToggled()) {
            final List<Module> toggledModules = BaseClient.instance.getModuleManager().getToggledModules();
            final String mode = ModuleManager.arrayList.mode.getMode();
            switch (mode) {
                case "Old": {
                    toggledModules.sort(ToggledModules1::lambda$onRender2D$0);
                    int n2 = 1;
                    final int n3 = 3;
                    final int n4 = -2;
                    final int n5 = BaseClient.instance.getFont().getFontSize() + n3 - 15;
                    for (int i = 0; i < toggledModules.size(); ++i) {
                        final Module module = toggledModules.get(i);
                        final String capitalizeFirstLetter = Strings.capitalizeFirstLetter(module.getNameWithAddon());
                        final int stringWidthCFR = Strings.getStringWidthCFR(capitalizeFirstLetter);
                        final int n6 = (int)ModuleManager.arrayList.tab_size.getValue();
                        final int n7 = ModuleManager.arrayList.rainbow.isEnabled() ? Colors.getRGBWave((float)ModuleManager.arrayList.speed.getValue(), 1.0f, 0.0f, Math.round(i * n2 * ModuleManager.arrayList.offset.getValue())) : module.getColor().getRGB();
                        final int n8 = ModuleManager.arrayList.rainbow.isEnabled() ? (ModuleManager.arrayList.match_module_color.isEnabled() ? n7 : Colors.getRGBWave((float)ModuleManager.arrayList.speed.getValue(), 1.0f, 0.0f, Integers.flipPositive((int)Math.round(i * n2 * ModuleManager.arrayList.offset.getValue())))) : module.getColor().getRGB();
                        final boolean enabled = ModuleManager.arrayList.gradient.isEnabled();
                        final int a = (ModuleManager.arrayList.opacity.getValue() > 255.0) ? 255 : ((int)ModuleManager.arrayList.opacity.getValue());
                        if (!module.getCategory().equals(Category.HIDDEN)) {
                            if (module.isShownInModuleArrayList()) {
                                RenderUtils.drawGradientRect(render2DEvent.getWidth() - stringWidthCFR + n4 - 5, n2 + 1, render2DEvent.getWidth(), n2 + n5 - 1, new Color(0, 0, 0, a).getRGB(), enabled ? new Color(100, 100, 100, (a > 255) ? 255 : a).getRGB() : new Color(0, 0, 0, (a > 255) ? 255 : a).getRGB());
                                RenderUtils.drawRect(render2DEvent.getWidth() - stringWidthCFR + n4 - 5, n2 + 1, render2DEvent.getWidth() - stringWidthCFR - n6, n2 + n5 - 1, n8);
                                RenderUtils.drawString(capitalizeFirstLetter, render2DEvent.getWidth() - stringWidthCFR + n4, n2 + 1, n7, BaseClient.instance.getFontRenderer().fontSizeNormal, true);
                                n2 += n5 - 2;
                            }
                        }
                    }
                    break;
                }
                case "Broken": {
                    GlStateManager.pushMatrix();
                    GlStateManager.scale(1.5, 1.5, 1.0);
                    final FontRenderer fontRendererObj = this.mc.fontRendererObj;
                    final float n9 = (float)(fontRendererObj.FONT_HEIGHT + 1);
                    final ScaledResolution scaledResolution = new ScaledResolution(this.mc);
                    final List<Module> toggledModules2 = BaseClient.instance.getModuleManager().getToggledModules();
                    toggledModules2.sort(this::lambda$onRender2D$1);
                    int n10 = 0;
                    for (final Module module2 : toggledModules2) {
                        if (!module2.isShownInModuleArrayList()) {
                            continue;
                        }
                        final boolean b = this.getAddon(module2) != null;
                        this.getAddon(module2);
                        fontRendererObj.drawStringWithShadow(this.getFullName(module2), scaledResolution.getScaledWidth() / 1.0f - fontRendererObj.getStringWidth(this.getFullName(module2)) - 3.0f, (float)((int)(n9 * n10) + 2), Colors.getRGBWave(30.0f, 0.0f, 1.0f, n10 * ((long)1407094977 ^ 0x53DE90DFL)));
                        ++n10;
                    }
                    GlStateManager.popMatrix();
                    break;
                }
                case "New": {
                    final List<Module> toggledModules3 = BaseClient.instance.getModuleManager().getToggledModules3();
                    toggledModules3.sort(Comparator.comparingInt(this::lambda$onRender2D$2).reversed());
                    final ScaledResolution scaledResolution2 = new ScaledResolution(this.mc);
                    GlStateManager.pushMatrix();
                    GlStateManager.enableAlpha();
                    GlStateManager.enableBlend();
                    this.newLineCurrent = this.animate(this.getTarget(), this.newLineCurrent, 0.0);
                    Gui.drawRect(scaledResolution2.getScaledWidth() - 4.5, 6.0, scaledResolution2.getScaledWidth() - 3.5, this.newLineCurrent, new Color(223, 43, 255).getRGB());
                    Gui.drawRect(scaledResolution2.getScaledWidth() - 5, 6.5, scaledResolution2.getScaledWidth() - 3, this.newLineCurrent - 0.0, new Color(223, 43, 255).getRGB());
                    Gui.drawRect(scaledResolution2.getScaledWidth() - 4.4, 6.0, scaledResolution2.getScaledWidth() - 3.5, this.newLineCurrent, new Color(223, 43, 255).getRGB());
                    final int n11 = this.newFr.getStringHeight("ApILwWAD|2131REWRNyj") + 2;
                    int n12 = 0;
                    for (final Module module3 : toggledModules3) {
                        if (module3.isToggled()) {
                            module3.nalFade = Math.min(255, module3.nalFade + 25);
                        }
                        else {
                            module3.nalFade = Math.max(0, module3.nalFade - 25);
                        }
                        if (module3.getAddon() == null) {
                            this.newFr.drawString(module3.getName(), scaledResolution2.getScaledWidth() - this.newFr.getStringWidth(module3.getName()) - 8, 9 + n12 * n11, new Color(223, 43, 255, module3.nalFade).brighter().getRGB(), true);
                        }
                        else {
                            this.newFr.drawString(module3.getAddon(), scaledResolution2.getScaledWidth() - this.newFr.getStringWidth(module3.getAddon()) - 8, 9 + n12 * n11, new Color(194, 194, 194, module3.nalFade).brighter().getRGB(), true);
                            this.newFr.drawString(module3.getName(), scaledResolution2.getScaledWidth() - this.newFr.getStringWidth(module3.getName() + " |" + module3.getAddon()) - 8, 9 + n12 * n11, new Color(223, 43, 255, module3.nalFade).brighter().getRGB(), true);
                        }
                        ++n12;
                    }
                    GlStateManager.popMatrix();
                    break;
                }
            }
        }
    }
    
    public String getAddon(final Module module) {
        for (final Setting setting : module.settings) {
            if (setting.name.equalsIgnoreCase("Mode")) {
                ((ModeSetting)setting).getMode();
            }
        }
        return null;
    }
    
    public String getFullName(final Module module) {
        return (this.getAddon(module) != null) ? (module.getName() + " " + this.getAddon(module)) : module.getName();
    }
    
    public double getTarget() {
        return 12 + BaseClient.instance.getModuleManager().getToggledModules2().size() * (this.newFr.getStringHeight("ApILwWAD|2131REWRNyj") + 2);
    }
    
    public double animate(final double n, double n2, double n3) {
        final boolean b = n > n2;
        if (n3 < 0.0) {
            n3 = 0.0;
        }
        else if (n3 > 1.0) {
            n3 = 1.0;
        }
        double n4 = (Math.max(n, n2) - Math.min(n, n2)) * n3;
        if (n4 < 0.0) {
            n4 = 0.0;
        }
        if (b) {
            n2 += n4;
        }
        else {
            n2 -= n4;
        }
        return n2;
    }
    
    public int lambda$onRender2D$2(final Object o) {
        return this.newFr.getStringWidth((((Module)o).getAddon() == null) ? ((Module)o).getName() : (((Module)o).getName() + " |" + ((Module)o).getAddon()));
    }
    
    public int lambda$onRender2D$1(final Module module, final Module module2) {
        return Strings.getStringWidthCFR(Strings.capitalizeFirstLetter(this.getFullName(module2))) - Strings.getStringWidthCFR(Strings.capitalizeFirstLetter(this.getFullName(module)));
    }
    
    public static int lambda$onRender2D$0(final Module module, final Module module2) {
        return Strings.getStringWidthCFR(Strings.capitalizeFirstLetter(module2.getNameWithAddon())) - Strings.getStringWidthCFR(Strings.capitalizeFirstLetter(module.getNameWithAddon()));
    }
}
