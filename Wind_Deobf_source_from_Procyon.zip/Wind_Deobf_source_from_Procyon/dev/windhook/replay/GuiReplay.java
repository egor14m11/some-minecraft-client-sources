// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.replay;

import java.io.IOException;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.network.PacketBuffer;
import io.netty.buffer.Unpooled;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.client.Minecraft;
import dev.windhook.BaseClient;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;

public class GuiReplay extends GuiScreen
{
    @Override
    public void drawScreen(final int n, final int n2, final float n3) {
        Gui.drawRect(0, 0, this.width, this.height, -16777216);
        super.drawScreen(n, n2, n3);
    }
    
    @Override
    public void actionPerformed(final GuiButton guiButton) throws IOException {
        if (guiButton.id == 0) {
            BaseClient.instance.replayManager.init();
            Minecraft.getMinecraft().displayGuiScreen(new GuiDownloadTerrain(Minecraft.getMinecraft().getNetHandler()));
            Minecraft.getMinecraft().getNetHandler().addToSendQueue(new C17PacketCustomPayload("MC|Brand", new PacketBuffer(Unpooled.buffer()).writeString(ClientBrandRetriever.getClientModName())));
            BaseClient.instance.isReplay = true;
        }
        super.actionPerformed(guiButton);
    }
    
    @Override
    public void initGui() {
        this.buttonList.add(new GuiButton(0, 0, 0, "Replay"));
        super.initGui();
    }
}
