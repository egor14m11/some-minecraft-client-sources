// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.replay;

public class Point
{
    public double posX;
    public double posY;
    public double posZ;
    public float rotationYaw;
    public float rotationPitch;
    public long timeElapsed;
    
    public Point(final double posX, final double posY, final double posZ, final float rotationYaw, final float rotationPitch, final long timeElapsed) {
        this.posX = posX;
        this.posY = posY;
        this.posZ = posZ;
        this.rotationYaw = rotationYaw;
        this.rotationPitch = rotationPitch;
        this.timeElapsed = timeElapsed;
    }
    
    public double getPosX() {
        return this.posX;
    }
    
    public void setPosX(final double posX) {
        this.posX = posX;
    }
    
    public double getPosY() {
        return this.posY;
    }
    
    public void setPosY(final double posY) {
        this.posY = posY;
    }
    
    public double getPosZ() {
        return this.posZ;
    }
    
    public void setPosZ(final double posZ) {
        this.posZ = posZ;
    }
    
    public float getRotationYaw() {
        return this.rotationYaw;
    }
    
    public void setRotationYaw(final float rotationYaw) {
        this.rotationYaw = rotationYaw;
    }
    
    public float getRotationPitch() {
        return this.rotationPitch;
    }
    
    public void setRotationPitch(final float rotationPitch) {
        this.rotationPitch = rotationPitch;
    }
}
