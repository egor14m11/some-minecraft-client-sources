// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.replay;

import dev.windhook.BaseClient;
import net.minecraft.client.entity.EntityPlayerSP;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;

public class Replay
{
    public boolean stopped;
    public WorldClient world;
    public Minecraft mc;
    public ArrayList<Point> points;
    public long timeElapsed;
    
    public Replay(final WorldClient world) {
        this.stopped = false;
        this.mc = Minecraft.getMinecraft();
        this.points = new ArrayList<Point>();
        this.timeElapsed = ((long)459418277 ^ 0x1B622AA5L);
        this.stopped = false;
        this.timeElapsed = ((long)1956751912 ^ 0x74A1AA28L);
        this.world = world;
    }
    
    public void recordSession(final WorldClient worldClient, final EntityPlayerSP entityPlayerSP) {
        if (worldClient == null) {
            this.save();
            this.stopped = true;
            BaseClient.instance.isRecording = false;
            return;
        }
        if (this.stopped) {
            return;
        }
        this.timeElapsed += ((long)(-387524848) ^ 0xFFFFFFFFE8E6D711L);
        if (ReplayManager.isMoving() || entityPlayerSP.rotationYaw - entityPlayerSP.lastReportedYaw != 0.0f || entityPlayerSP.rotationPitch - entityPlayerSP.lastReportedPitch != 0.0f) {
            this.points.add(new Point(entityPlayerSP.posX, entityPlayerSP.posY, entityPlayerSP.posZ, entityPlayerSP.rotationYaw, entityPlayerSP.rotationPitch, this.timeElapsed));
        }
    }
    
    public void save() {
    }
}
