// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.replay;

import java.util.ArrayList;
import net.minecraft.entity.EntityLivingBase;

public class ReplayLivingBase
{
    public EntityLivingBase base;
    public ArrayList<Point> points;
    
    public ReplayLivingBase(final EntityLivingBase base, final ArrayList<Point> points) {
        this.base = base;
        this.points = points;
    }
    
    public EntityLivingBase getBase() {
        return this.base;
    }
    
    public void setBase(final EntityLivingBase base) {
        this.base = base;
    }
    
    public ArrayList<Point> getPoints() {
        return this.points;
    }
    
    public void setPoints(final ArrayList<Point> points) {
        this.points = points;
    }
}
