// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.replay;

import java.util.Iterator;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;

public class ReplayManager
{
    public static Minecraft mc;
    public long elapsed;
    public ArrayList<Replay> replays;
    
    public ReplayManager() {
        this.elapsed = ((long)(-1178425599) ^ 0xFFFFFFFFB9C2A701L);
        this.replays = new ArrayList<Replay>();
    }
    
    public void playReplay() {
        final Replay replay = this.replays.get(0);
        final Minecraft minecraft = Minecraft.getMinecraft();
        this.elapsed += ((long)(-1549240896) ^ 0xFFFFFFFFA3A875C1L);
        for (final Point point : replay.points) {
            if (point.timeElapsed == this.elapsed) {
                minecraft.thePlayer.setPosition(point.posX, point.posY, point.posZ);
                minecraft.thePlayer.rotationYaw = point.rotationYaw;
                minecraft.thePlayer.rotationPitch = point.rotationYaw;
            }
        }
    }
    
    public void init() {
        Minecraft.getMinecraft().loadWorld(this.replays.get(0).world);
    }
    
    public static boolean isMoving() {
        return ReplayManager.mc.thePlayer != null && (ReplayManager.mc.thePlayer.movementInput.moveForward != 0.0f || ReplayManager.mc.thePlayer.movementInput.moveStrafe != 0.0f);
    }
    
    static {
        ReplayManager.mc = Minecraft.getMinecraft();
    }
}
