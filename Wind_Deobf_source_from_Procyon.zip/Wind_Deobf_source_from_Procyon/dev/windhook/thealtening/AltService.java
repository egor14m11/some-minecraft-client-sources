// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.thealtening;

import java.util.function.BiConsumer;
import java.net.URL;
import java.util.HashMap;

public class AltService
{
    public ReflectionUtility userAuthentication;
    public ReflectionUtility minecraftSession;
    public EnumAltService currentService;
    
    public AltService() {
        this.userAuthentication = new ReflectionUtility("com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication");
        this.minecraftSession = new ReflectionUtility("com.mojang.authlib.yggdrasil.YggdrasilMinecraftSessionService");
    }
    
    public void switchService(final EnumAltService currentService) throws NoSuchFieldException, IllegalAccessException {
        if (this.currentService == currentService) {
            return;
        }
        this.reflectionFields(currentService.hostname);
        this.currentService = currentService;
    }
    
    public void reflectionFields(final String str) throws NoSuchFieldException, IllegalAccessException {
        final HashMap<String, URL> hashMap = new HashMap<String, URL>();
        final String str2 = str.contains("thealtening") ? "http" : "https";
        hashMap.put("ROUTE_AUTHENTICATE", this.constantURL(str2 + "://authserver." + str + ".com/authenticate"));
        hashMap.put("ROUTE_INVALIDATE", this.constantURL(str2 + "://authserver" + str + "com/invalidate"));
        hashMap.put("ROUTE_REFRESH", this.constantURL(str2 + "://authserver." + str + ".com/refresh"));
        hashMap.put("ROUTE_VALIDATE", this.constantURL(str2 + "://authserver." + str + ".com/validate"));
        hashMap.put("ROUTE_SIGNOUT", this.constantURL(str2 + "://authserver." + str + ".com/signout"));
        hashMap.forEach(this::lambda$reflectionFields$0);
        this.userAuthentication.setStaticField("BASE_URL", str2 + "://authserver." + str + ".com/");
        this.minecraftSession.setStaticField("BASE_URL", str2 + "://sessionserver." + str + ".com/session/minecraft/");
        this.minecraftSession.setStaticField("JOIN_URL", this.constantURL(str2 + "://sessionserver." + str + ".com/session/minecraft/join"));
        this.minecraftSession.setStaticField("CHECK_URL", this.constantURL(str2 + "://sessionserver." + str + ".com/session/minecraft/hasJoined"));
        this.minecraftSession.setStaticField("WHITELISTED_DOMAINS", new String[] { ".minecraft.net", ".mojang.com", ".thealtening.com" });
    }
    
    public URL constantURL(final String spec) {
        return new URL(spec);
    }
    
    public EnumAltService getCurrentService() {
        if (this.currentService == null) {
            this.currentService = EnumAltService.MOJANG;
        }
        return this.currentService;
    }
    
    public void lambda$reflectionFields$0(final String s, final URL url) {
        this.userAuthentication.setStaticField(s, url);
    }
    
    public enum EnumAltService
    {
        MOJANG("mojang"), 
        THEALTENING("thealtening");
        
        public String hostname;
        public static EnumAltService[] $VALUES;
        
        public EnumAltService(final String hostname) {
            this.hostname = hostname;
        }
        
        static {
            EnumAltService.$VALUES = new EnumAltService[] { EnumAltService.MOJANG, EnumAltService.THEALTENING };
        }
    }
}
