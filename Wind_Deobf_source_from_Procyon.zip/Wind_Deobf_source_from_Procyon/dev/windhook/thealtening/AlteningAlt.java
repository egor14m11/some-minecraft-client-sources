// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.thealtening;

import com.google.gson.annotations.SerializedName;

public class AlteningAlt
{
    @SerializedName("token")
    public String token;
    @SerializedName("username")
    public String username;
    @SerializedName("expires")
    public String expiryDate;
    @SerializedName("limit")
    public boolean isLimitReached;
    @SerializedName("skin")
    public String skinHash;
    
    public String getToken() {
        return this.token;
    }
    
    public String getUsername() {
        return this.username;
    }
    
    public String getExpiryDate() {
        return this.expiryDate;
    }
    
    public boolean isLimitReached() {
        return this.isLimitReached;
    }
    
    public String getSkinHash() {
        return this.skinHash;
    }
}
