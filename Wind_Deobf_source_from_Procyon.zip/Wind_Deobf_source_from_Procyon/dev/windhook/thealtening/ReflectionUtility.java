// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.thealtening;

import java.lang.reflect.Field;

public class ReflectionUtility
{
    public Class<?> clazz;
    
    public ReflectionUtility(final String className) {
        this.clazz = Class.forName(className);
    }
    
    public void setStaticField(final String name, final Object value) throws NoSuchFieldException, IllegalAccessException {
        final Field declaredField = this.clazz.getDeclaredField(name);
        declaredField.setAccessible(true);
        final Field declaredField2 = Field.class.getDeclaredField("modifiers");
        declaredField2.setAccessible(true);
        declaredField2.setInt(declaredField, declaredField.getModifiers() & 0xFFFFFFEF);
        declaredField.set(null, value);
    }
}
