// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.thealtening;

import javax.net.ssl.SSLSession;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import java.security.SecureRandom;
import javax.net.ssl.SSLContext;
import java.security.cert.X509Certificate;
import javax.net.ssl.X509TrustManager;
import javax.net.ssl.TrustManager;

public class SSLVerification
{
    public boolean verified;
    
    public SSLVerification() {
        this.verified = false;
    }
    
    public void verify() {
        if (!this.verified) {
            this.bypassSSL();
            this.whitelistTheAltening();
            this.verified = true;
        }
    }
    
    public void bypassSSL() {
        final TrustManager[] tm = { new X509TrustManager(this) {
                public SSLVerification this$0;
                
                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                
                @Override
                public void checkClientTrusted(final X509Certificate[] array, final String s) {
                }
                
                @Override
                public void checkServerTrusted(final X509Certificate[] array, final String s) {
                }
            } };
        final SSLContext instance = SSLContext.getInstance("SSL");
        instance.init(null, tm, new SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(instance.getSocketFactory());
    }
    
    public void whitelistTheAltening() {
        HttpsURLConnection.setDefaultHostnameVerifier(SSLVerification::lambda$whitelistTheAltening$0);
    }
    
    public static boolean lambda$whitelistTheAltening$0(final String s, final SSLSession sslSession) {
        return s.equals("authserver.thealtening.com") || s.equals("sessionserver.thealtening.com");
    }
}
