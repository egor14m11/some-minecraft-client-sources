// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.thealtening;

import java.io.IOException;
import java.net.URL;
import com.google.gson.GsonBuilder;
import com.google.gson.Gson;

public class TheAltening
{
    public String apiKey;
    public String website;
    public Gson gson;
    
    public TheAltening(final String apiKey) {
        this.website = "http://api.thealtening.com/v1/";
        this.website = "http://api.thealtening.com/v1/";
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        this.apiKey = apiKey;
    }
    
    public User getUser() throws IOException {
        this.getClass();
        return (User)this.gson.fromJson(new String(Utilities.getInstance().readAllBytes(new URL(this.attach("http://api.thealtening.com/v1/license")).openConnection().getInputStream())), (Class)User.class);
    }
    
    public AlteningAlt generateAccount(final User user) throws IOException {
        this.getClass();
        final String s = new String(Utilities.getInstance().readAllBytes(new URL(this.attach("http://api.thealtening.com/v1/generate")).openConnection().getInputStream()));
        if (user.isPremium()) {
            return (AlteningAlt)this.gson.fromJson(s, (Class)AlteningAlt.class);
        }
        return null;
    }
    
    public boolean favoriteAccount(final AlteningAlt alteningAlt) throws IOException {
        this.getClass();
        return new String(Utilities.getInstance().readAllBytes(new URL(this.attachAccount("http://api.thealtening.com/v1/favorite", alteningAlt)).openConnection().getInputStream())).isEmpty();
    }
    
    public boolean privateAccount(final AlteningAlt alteningAlt) throws IOException {
        this.getClass();
        return new String(Utilities.getInstance().readAllBytes(new URL(this.attachAccount("http://api.thealtening.com/v1/private", alteningAlt)).openConnection().getInputStream())).isEmpty();
    }
    
    public String attach(final String str) {
        return str + "?token=" + this.apiKey;
    }
    
    public String attachAccount(final String str, final AlteningAlt alteningAlt) {
        return str + "?token=" + this.apiKey + "&acctoken=" + alteningAlt.getToken();
    }
}
