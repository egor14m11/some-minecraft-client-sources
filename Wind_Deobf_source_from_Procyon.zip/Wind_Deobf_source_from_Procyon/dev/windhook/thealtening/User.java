// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.thealtening;

import com.google.gson.annotations.SerializedName;

public class User
{
    @SerializedName("username")
    public String username;
    @SerializedName("premium")
    public boolean premium;
    @SerializedName("premium_name")
    public String premiumName;
    @SerializedName("expires")
    public String expiryDate;
    
    public String getUsername() {
        return this.username;
    }
    
    public boolean isPremium() {
        return this.premium;
    }
    
    public String getPremiumName() {
        return this.premiumName;
    }
    
    public String getExpiryDate() {
        return this.expiryDate;
    }
}
