// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.thealtening;

public class UserSkin
{
    public AlteningAlt account;
    
    public UserSkin(final AlteningAlt account) {
        this.account = account;
    }
    
    public AlteningAlt getAccount() {
        return this.account;
    }
}
