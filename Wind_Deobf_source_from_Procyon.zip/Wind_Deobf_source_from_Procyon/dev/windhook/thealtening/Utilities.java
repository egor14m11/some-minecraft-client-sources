// 
// Decompiled by Procyon v0.5.36
// 

package dev.windhook.thealtening;

import java.io.IOException;
import java.util.Arrays;
import java.io.InputStream;

public class Utilities
{
    public static Utilities INSTANCE;
    public static int DEFAULT_BUFFER_SIZE;
    public static int MAX_BUFFER_SIZE;
    
    public byte[] readAllBytes(final InputStream inputStream) throws IOException {
        byte[] copy = new byte[8192];
        int length = copy.length;
        int n = 0;
        while (true) {
            final int read;
            if ((read = inputStream.read(copy, n, length - n)) > 0) {
                n += read;
            }
            else {
                if (read < 0) {
                    return (length == n) ? copy : Arrays.copyOf(copy, n);
                }
                if (length <= 2147483639 - length) {
                    length <<= 1;
                }
                else {
                    if (length == 2147483639) {
                        throw new OutOfMemoryError("Required array size too large");
                    }
                    length = 2147483639;
                }
                copy = Arrays.copyOf(copy, length);
            }
        }
    }
    
    public static Utilities getInstance() {
        return Utilities.INSTANCE;
    }
    
    static {
        Utilities.MAX_BUFFER_SIZE = 2147483639;
        Utilities.DEFAULT_BUFFER_SIZE = 8192;
        Utilities.INSTANCE = new Utilities();
    }
}
