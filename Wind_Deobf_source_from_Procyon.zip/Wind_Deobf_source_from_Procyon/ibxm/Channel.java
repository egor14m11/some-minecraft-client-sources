// 
// Decompiled by Procyon v0.5.36
// 

package ibxm;

public class Channel
{
    public int pattern_loop_row;
    public Module module;
    public Instrument instrument;
    public Sample sample;
    public int[] global_volume;
    public int[] current_note;
    public boolean linear_periods;
    public boolean fast_volume_slides;
    public boolean key_on;
    public boolean silent;
    public int sample_idx;
    public int sample_frac;
    public int step;
    public int left_gain;
    public int right_gain;
    public int volume;
    public int panning;
    public int fine_tune;
    public int period;
    public int porta_period;
    public int key_add;
    public int tremolo_speed;
    public int tremolo_depth;
    public int tremolo_tick;
    public int tremolo_wave;
    public int tremolo_add;
    public int vibrato_speed;
    public int vibrato_depth;
    public int vibrato_tick;
    public int vibrato_wave;
    public int vibrato_add;
    public int volume_slide_param;
    public int portamento_param;
    public int retrig_param;
    public int volume_envelope_tick;
    public int panning_envelope_tick;
    public int effect_tick;
    public int trigger_tick;
    public int fade_out_volume;
    public int random_seed;
    public int log_2_sampling_rate;
    public int log_2_c2_rate;
    public static int LOG_2_29024;
    public static int LOG_2_1712;
    public static int[] sine_table;
    
    public Channel(final Module module, final int n, final int[] global_volume) {
        this.module = module;
        this.global_volume = global_volume;
        this.linear_periods = this.module.linear_periods;
        this.fast_volume_slides = this.module.fast_volume_slides;
        this.current_note = new int[5];
        this.log_2_sampling_rate = LogTable.log_2(n);
    }
    
    public void reset() {
        this.tremolo_speed = 0;
        this.tremolo_depth = 0;
        this.tremolo_wave = 0;
        this.vibrato_speed = 0;
        this.vibrato_depth = 0;
        this.vibrato_wave = 0;
        this.volume_slide_param = 0;
        this.portamento_param = 0;
        this.retrig_param = 0;
        this.random_seed = 11256099;
        this.instrument = this.module.get_instrument(0);
        this.row(48, 256, 0, 0, 0);
    }
    
    public void resample(final int[] array, final int n, final int n2, final int n3) {
        if (!this.silent) {
            switch (n3) {
                default: {
                    this.sample.resample_nearest(this.sample_idx, this.sample_frac, this.step, this.left_gain, this.right_gain, array, n, n2);
                    break;
                }
                case 1: {
                    this.sample.resample_linear(this.sample_idx, this.sample_frac, this.step, this.left_gain, this.right_gain, array, n, n2);
                    break;
                }
                case 2: {
                    this.sample.resample_sinc(this.sample_idx, this.sample_frac, this.step, this.left_gain, this.right_gain, array, n, n2);
                    break;
                }
            }
        }
    }
    
    public void update_sample_idx(final int n) {
        this.sample_frac += this.step * n;
        this.sample_idx += this.sample_frac >> 15;
        this.sample_frac &= 0x7FFF;
    }
    
    public void set_volume(int volume) {
        if (volume < 0) {
            volume = 0;
        }
        if (volume > 64) {
            volume = 64;
        }
        this.volume = volume;
    }
    
    public void set_panning(int panning) {
        if (panning < 0) {
            panning = 0;
        }
        if (panning > 255) {
            panning = 255;
        }
        this.panning = panning;
    }
    
    public void row(final int n, final int n2, final int n3, int n4, int n5) {
        n4 &= 0xFF;
        if (n4 >= 48) {
            n4 = 0;
        }
        if (n4 == 0 && n5 != 0) {
            n4 = 64;
        }
        if (n4 == 14) {
            n4 = 48 + ((n5 & 0xF0) >> 4);
            n5 &= 0xF;
        }
        if (n4 == 33) {
            n4 = 64 + ((n5 & 0xF0) >> 4);
            n5 &= 0xF;
        }
        this.current_note[0] = n;
        this.current_note[1] = n2;
        this.current_note[2] = n3;
        this.current_note[3] = n4;
        this.current_note[4] = n5;
        this.effect_tick = 0;
        ++this.trigger_tick;
        this.update_envelopes();
        this.key_add = 0;
        this.vibrato_add = 0;
        this.tremolo_add = 0;
        if (n4 != 61 || n5 <= 0) {
            this.trigger(n, n2, n3, n4);
            switch (n3 & 0xF0) {
                case 0: {
                    break;
                }
                case 96: {
                    break;
                }
                case 112: {
                    break;
                }
                case 128: {
                    this.set_volume(this.volume - (n3 & 0xF));
                    break;
                }
                case 144: {
                    this.set_volume(this.volume + (n3 & 0xF));
                    break;
                }
                case 160: {
                    this.set_vibrato_speed(n3 & 0xF);
                    break;
                }
                case 176: {
                    this.set_vibrato_depth(n3 & 0xF);
                    this.vibrato();
                    break;
                }
                case 192: {
                    this.set_panning((n3 & 0xF) << 4);
                    break;
                }
                case 208: {
                    break;
                }
                case 224: {
                    break;
                }
                case 240: {
                    this.set_portamento_param(n3 & 0xF);
                    break;
                }
                default: {
                    this.set_volume(n3 - 16);
                    break;
                }
            }
        }
        if (this.instrument.vibrato_depth > 0) {
            this.auto_vibrato();
        }
        switch (n4) {
            case 1: {
                this.set_portamento_param(n5);
                this.portamento_up();
                break;
            }
            case 2: {
                this.set_portamento_param(n5);
                this.portamento_down();
                break;
            }
            case 3: {
                this.set_portamento_param(n5);
                break;
            }
            case 4: {
                this.set_vibrato_speed((n5 & 0xF0) >> 4);
                this.set_vibrato_depth(n5 & 0xF);
                this.vibrato();
                break;
            }
            case 5: {
                this.set_volume_slide_param(n5);
                this.volume_slide();
                break;
            }
            case 6: {
                this.set_volume_slide_param(n5);
                this.vibrato();
                this.volume_slide();
                break;
            }
            case 7: {
                this.set_tremolo_speed((n5 & 0xF0) >> 4);
                this.set_tremolo_depth(n5 & 0xF);
                this.tremolo();
                break;
            }
            case 8: {
                this.set_panning(n5);
                break;
            }
            case 9: {
                this.set_sample_index(n5 << 8);
                break;
            }
            case 10: {
                this.set_volume_slide_param(n5);
                this.volume_slide();
            }
            case 12: {
                this.set_volume(n5);
            }
            case 13: {}
            case 14: {}
            case 16: {
                this.set_global_volume(n5);
                break;
            }
            case 17: {
                this.set_volume_slide_param(n5);
                break;
            }
            case 20: {
                if (n5 == 0) {
                    this.key_on = false;
                    break;
                }
                break;
            }
            case 21: {
                this.set_envelope_tick(n5);
                break;
            }
            case 25: {
                this.set_volume_slide_param(n5);
                break;
            }
            case 27: {
                this.set_retrig_param(n5);
                this.retrig_volume_slide();
                break;
            }
            case 29: {
                this.set_retrig_param(n5);
                this.tremor();
                break;
            }
            case 36: {
                this.set_vibrato_speed((n5 & 0xF0) >> 4);
                this.set_vibrato_depth(n5 & 0xF);
                this.fine_vibrato();
            }
            case 37: {}
            case 49: {
                this.set_portamento_param(0xF0 | n5);
                this.portamento_up();
                break;
            }
            case 50: {
                this.set_portamento_param(0xF0 | n5);
                this.portamento_down();
            }
            case 52: {
                this.set_vibrato_wave(n5);
            }
            case 53: {}
            case 55: {
                this.set_tremolo_wave(n5);
            }
            case 57: {
                this.set_retrig_param(n5);
                break;
            }
            case 58: {
                this.set_volume_slide_param(n5 << 4 | 0xF);
                this.volume_slide();
                break;
            }
            case 59: {
                this.set_volume_slide_param(0xF0 | n5);
                this.volume_slide();
                break;
            }
            case 60: {
                if (n5 == 0) {
                    this.set_volume(0);
                    break;
                }
                break;
            }
            case 61: {}
            case 62: {}
            case 63: {}
            case 65: {
                this.set_portamento_param(0xE0 | n5);
                this.portamento_up();
                break;
            }
            case 66: {
                this.set_portamento_param(0xE0 | n5);
                this.portamento_down();
                break;
            }
        }
        this.calculate_amplitude();
        this.calculate_frequency();
    }
    
    public void tick() {
        final int n = this.current_note[2];
        final int n2 = this.current_note[3];
        final int n3 = this.current_note[4];
        ++this.effect_tick;
        Label_0734: {
            if (n2 == 61 && n3 == this.effect_tick) {
                this.row(this.current_note[0], this.current_note[1], n, 0, 0);
            }
            else {
                ++this.trigger_tick;
                ++this.vibrato_tick;
                ++this.tremolo_tick;
                this.update_envelopes();
                this.key_add = 0;
                this.vibrato_add = 0;
                this.tremolo_add = 0;
                if (this.instrument.vibrato_depth > 0) {
                    this.auto_vibrato();
                }
                switch (n & 0xF0) {
                    case 96: {
                        this.set_volume(this.volume - (n & 0xF));
                        break;
                    }
                    case 112: {
                        this.set_volume(this.volume + (n & 0xF));
                        break;
                    }
                    case 176: {
                        this.vibrato();
                        break;
                    }
                    case 208: {
                        this.set_panning(this.panning - (n & 0xF));
                        break;
                    }
                    case 224: {
                        this.set_panning(this.panning + (n & 0xF));
                        break;
                    }
                    case 240: {
                        this.tone_portamento();
                        break;
                    }
                }
                switch (n2) {
                    case 1: {
                        this.portamento_up();
                        break;
                    }
                    case 2: {
                        this.portamento_down();
                        break;
                    }
                    case 3: {
                        this.tone_portamento();
                        break;
                    }
                    case 4: {
                        this.vibrato();
                        break;
                    }
                    case 5: {
                        this.tone_portamento();
                        this.volume_slide();
                        break;
                    }
                    case 6: {
                        this.vibrato();
                        this.volume_slide();
                        break;
                    }
                    case 7: {
                        this.tremolo();
                        break;
                    }
                    case 10: {
                        this.volume_slide();
                        break;
                    }
                    case 17: {
                        this.global_volume_slide();
                        break;
                    }
                    case 20: {
                        if (this.effect_tick == n3) {
                            this.key_on = false;
                            break;
                        }
                        break;
                    }
                    case 25: {
                        this.panning_slide();
                        break;
                    }
                    case 27: {
                        this.retrig_volume_slide();
                        break;
                    }
                    case 29: {
                        this.tremor();
                        break;
                    }
                    case 36: {
                        this.fine_vibrato();
                        break;
                    }
                    case 57: {
                        this.retrig_volume_slide();
                        break;
                    }
                    case 60: {
                        if (this.effect_tick == n3) {
                            this.set_volume(0);
                            break;
                        }
                        break;
                    }
                    case 64: {
                        switch (this.effect_tick % 3) {
                            case 1: {
                                this.key_add = (n3 & 0xF0) >> 4;
                                break Label_0734;
                            }
                            case 2: {
                                this.key_add = (n3 & 0xF);
                                break Label_0734;
                            }
                        }
                        break;
                    }
                }
            }
        }
        this.calculate_amplitude();
        this.calculate_frequency();
    }
    
    public void set_vibrato_speed(final int vibrato_speed) {
        if (vibrato_speed > 0) {
            this.vibrato_speed = vibrato_speed;
        }
    }
    
    public void set_vibrato_depth(final int vibrato_depth) {
        if (vibrato_depth > 0) {
            this.vibrato_depth = vibrato_depth;
        }
    }
    
    public void set_vibrato_wave(int vibrato_wave) {
        if (vibrato_wave < 0 || vibrato_wave > 7) {
            vibrato_wave = 0;
        }
        this.vibrato_wave = vibrato_wave;
    }
    
    public void set_tremolo_speed(final int tremolo_speed) {
        if (tremolo_speed > 0) {
            this.tremolo_speed = tremolo_speed;
        }
    }
    
    public void set_tremolo_depth(final int tremolo_depth) {
        if (tremolo_depth > 0) {
            this.tremolo_depth = tremolo_depth;
        }
    }
    
    public void set_tremolo_wave(int tremolo_wave) {
        if (tremolo_wave < 0 || tremolo_wave > 7) {
            tremolo_wave = 0;
        }
        this.tremolo_wave = tremolo_wave;
    }
    
    public void vibrato() {
        this.vibrato_add += this.waveform(this.vibrato_tick * this.vibrato_speed, this.vibrato_wave) * this.vibrato_depth >> 5;
    }
    
    public void fine_vibrato() {
        this.vibrato_add += this.waveform(this.vibrato_tick * this.vibrato_speed, this.vibrato_wave) * this.vibrato_depth >> 7;
    }
    
    public void tremolo() {
        this.tremolo_add += this.waveform(this.tremolo_tick * this.tremolo_speed, this.tremolo_wave) * this.tremolo_depth >> 6;
    }
    
    public void set_portamento_param(final int portamento_param) {
        if (portamento_param != 0) {
            this.portamento_param = portamento_param;
        }
    }
    
    public void tone_portamento() {
        if (this.porta_period < this.period) {
            int porta_period = this.period - (this.portamento_param << 2);
            if (porta_period < this.porta_period) {
                porta_period = this.porta_period;
            }
            this.set_period(porta_period);
        }
        if (this.porta_period > this.period) {
            int porta_period2 = this.period + (this.portamento_param << 2);
            if (porta_period2 > this.porta_period) {
                porta_period2 = this.porta_period;
            }
            this.set_period(porta_period2);
        }
    }
    
    public void portamento_up() {
        if ((this.portamento_param & 0xF0) == 0xE0) {
            if (this.effect_tick == 0) {
                this.set_period(this.period - (this.portamento_param & 0xF));
            }
        }
        else if ((this.portamento_param & 0xF0) == 0xF0) {
            if (this.effect_tick == 0) {
                this.set_period(this.period - ((this.portamento_param & 0xF) << 2));
            }
        }
        else if (this.effect_tick > 0) {
            this.set_period(this.period - (this.portamento_param << 2));
        }
    }
    
    public void portamento_down() {
        if ((this.portamento_param & 0xF0) == 0xE0) {
            if (this.effect_tick == 0) {
                this.set_period(this.period + (this.portamento_param & 0xF));
            }
        }
        else if ((this.portamento_param & 0xF0) == 0xF0) {
            if (this.effect_tick == 0) {
                this.set_period(this.period + ((this.portamento_param & 0xF) << 2));
            }
        }
        else if (this.effect_tick > 0) {
            this.set_period(this.period + (this.portamento_param << 2));
        }
    }
    
    public void set_period(int period) {
        if (period < 32) {
            period = 32;
        }
        if (period > 32768) {
            period = 32768;
        }
        this.period = period;
    }
    
    public void set_global_volume(int n) {
        if (n < 0) {
            n = 0;
        }
        if (n > 64) {
            n = 64;
        }
        this.global_volume[0] = n;
    }
    
    public void set_volume_slide_param(final int volume_slide_param) {
        if (volume_slide_param != 0) {
            this.volume_slide_param = volume_slide_param;
        }
    }
    
    public void global_volume_slide() {
        this.set_global_volume(this.global_volume[0] + ((this.volume_slide_param & 0xF0) >> 4) - (this.volume_slide_param & 0xF));
    }
    
    public void volume_slide() {
        final int n = (this.volume_slide_param & 0xF0) >> 4;
        final int n2 = this.volume_slide_param & 0xF;
        if (n2 == 15 && n > 0) {
            if (this.effect_tick == 0) {
                this.set_volume(this.volume + n);
            }
        }
        else if (n == 15 && n2 > 0) {
            if (this.effect_tick == 0) {
                this.set_volume(this.volume - n2);
            }
        }
        else if (this.effect_tick > 0 || this.fast_volume_slides) {
            this.set_volume(this.volume + n - n2);
        }
    }
    
    public void panning_slide() {
        this.set_panning(this.panning - ((this.volume_slide_param & 0xF0) >> 4) + (this.volume_slide_param & 0xF));
    }
    
    public void set_retrig_param(final int retrig_param) {
        if (retrig_param != 0) {
            this.retrig_param = retrig_param;
        }
    }
    
    public void tremor() {
        final int n = ((this.retrig_param & 0xF0) >> 4) + 1;
        if (this.trigger_tick % (n + (this.retrig_param & 0xF) + 1) >= n) {
            this.tremolo_add = -64;
        }
    }
    
    public void retrig_volume_slide() {
        final int n = (this.retrig_param & 0xF0) >> 4;
        final int n2 = this.retrig_param & 0xF;
        if (n2 > 0 && this.trigger_tick % n2 == 0) {
            this.set_sample_index(0);
            switch (n) {
                case 1: {
                    this.set_volume(this.volume - 1);
                    break;
                }
                case 2: {
                    this.set_volume(this.volume - 2);
                    break;
                }
                case 3: {
                    this.set_volume(this.volume - 4);
                    break;
                }
                case 4: {
                    this.set_volume(this.volume - 8);
                    break;
                }
                case 5: {
                    this.set_volume(this.volume - 16);
                    break;
                }
                case 6: {
                    this.set_volume(this.volume - this.volume / 3);
                    break;
                }
                case 7: {
                    this.set_volume(this.volume / 2);
                    break;
                }
                case 9: {
                    this.set_volume(this.volume + 1);
                    break;
                }
                case 10: {
                    this.set_volume(this.volume + 2);
                    break;
                }
                case 11: {
                    this.set_volume(this.volume + 4);
                    break;
                }
                case 12: {
                    this.set_volume(this.volume + 8);
                    break;
                }
                case 13: {
                    this.set_volume(this.volume + 16);
                    break;
                }
                case 14: {
                    this.set_volume(this.volume + this.volume / 2);
                    break;
                }
                case 15: {
                    this.set_volume(this.volume * 2);
                    break;
                }
            }
        }
    }
    
    public void set_sample_index(int sample_idx) {
        if (sample_idx < 0) {
            sample_idx = 0;
        }
        this.sample_idx = sample_idx;
        this.sample_frac = 0;
    }
    
    public void set_envelope_tick(final int n) {
        this.volume_envelope_tick = n;
        this.panning_envelope_tick = n;
    }
    
    public void trigger(final int n, final int n2, final int n3, final int n4) {
        if (n2 > 0) {
            this.instrument = this.module.get_instrument(n2);
            this.sample = this.instrument.get_sample_from_key(n);
            this.set_volume(this.sample.volume);
            if (this.sample.set_panning) {
                this.set_panning(this.sample.panning);
            }
            this.log_2_c2_rate = LogTable.log_2(this.sample.c2_rate);
            this.set_envelope_tick(0);
            this.fade_out_volume = 32768;
            this.key_on = true;
        }
        if (n > 0) {
            if (n < 97) {
                this.porta_period = this.key_to_period(n);
                if (n4 != 3 && n4 != 5 && (n3 & 0xF0) != 0xF0) {
                    this.trigger_tick = 0;
                    if (this.vibrato_wave < 4) {
                        this.vibrato_tick = 0;
                    }
                    if (this.tremolo_wave < 4) {
                        this.tremolo_tick = 0;
                    }
                    this.set_period(this.porta_period);
                    this.set_sample_index(0);
                }
            }
            else {
                this.key_on = false;
            }
        }
    }
    
    public void update_envelopes() {
        if (this.instrument.volume_envelope_active) {
            if (!this.key_on) {
                this.fade_out_volume -= (this.instrument.volume_fade_out & 0xFFFF);
                if (this.fade_out_volume < 0) {
                    this.fade_out_volume = 0;
                }
            }
            this.volume_envelope_tick = this.instrument.get_volume_envelope().next_tick(this.volume_envelope_tick, this.key_on);
        }
        if (this.instrument.panning_envelope_active) {
            this.panning_envelope_tick = this.instrument.get_panning_envelope().next_tick(this.panning_envelope_tick, this.key_on);
        }
    }
    
    public void auto_vibrato() {
        final int n = this.instrument.vibrato_sweep & 0xFF;
        int n2 = this.instrument.vibrato_depth & 0xF;
        final int n3 = this.instrument.vibrato_rate & 0x3F;
        if (this.trigger_tick < n) {
            n2 = n2 * this.trigger_tick / n;
        }
        this.vibrato_add += this.waveform(this.trigger_tick * n3, 0) * n2 >> 9;
    }
    
    public int waveform(final int n, final int n2) {
        int n3 = 0;
        switch (n2 & 0x3) {
            case 0: {
                if ((n & 0x20) == 0x0) {
                    n3 = Channel.sine_table[n & 0x1F];
                    break;
                }
                n3 = -Channel.sine_table[n & 0x1F];
                break;
            }
            case 1: {
                if ((n & 0x20) == 0x0) {
                    n3 = (n & 0x1F) << 3;
                    break;
                }
                n3 = ((n & 0x1F) << 3) - 255;
                break;
            }
            case 2: {
                if ((n & 0x20) == 0x0) {
                    n3 = 255;
                    break;
                }
                n3 = -255;
                break;
            }
            case 3: {
                n3 = (this.random_seed >> 15) - 255;
                this.random_seed = (this.random_seed * 65 + 17 & 0xFFFFFF);
                break;
            }
        }
        return n3;
    }
    
    public int key_to_period(int n) {
        n += this.sample.relative_note;
        int n2;
        if (this.linear_periods) {
            n2 = 7744 - n * 64;
        }
        else {
            n2 = LogTable.raise_2(Channel.LOG_2_29024 - (n << 15) / 12) >> 15;
        }
        return n2;
    }
    
    public void calculate_amplitude() {
        int calculate_ampl = 0;
        if (this.instrument.volume_envelope_active) {
            calculate_ampl = this.instrument.get_volume_envelope().calculate_ampl(this.volume_envelope_tick);
        }
        else if (this.key_on) {
            calculate_ampl = 64;
        }
        int n = this.volume + this.tremolo_add;
        if (n < 0) {
            n = 0;
        }
        if (n > 64) {
            n = 64;
        }
        final int n2 = ((((n << 9) * calculate_ampl >> 6) * this.fade_out_volume >> 15) * this.global_volume[0] >> 6) * this.module.channel_gain >> 15;
        this.silent = this.sample.has_finished(this.sample_idx);
        if (n2 <= 0) {
            this.silent = true;
        }
        else {
            int calculate_ampl2 = 32;
            if (this.instrument.panning_envelope_active) {
                calculate_ampl2 = this.instrument.get_panning_envelope().calculate_ampl(this.panning_envelope_tick);
            }
            final int n3 = (this.panning & 0xFF) << 7;
            int n4 = 32768 - n3;
            if (n4 > n3) {
                n4 = n3;
            }
            final int n5 = n3 + (n4 * (calculate_ampl2 - 32) >> 5);
            this.left_gain = n2 * (32768 - n5) >> 15;
            this.right_gain = n2 * n5 >> 15;
        }
    }
    
    public void calculate_frequency() {
        int n = this.period + this.vibrato_add;
        if (n < 32) {
            n = 32;
        }
        if (n > 32768) {
            n = 32768;
        }
        int n2;
        if (this.linear_periods) {
            n2 = this.log_2_c2_rate + (4608 - n << 15) / 768;
        }
        else {
            n2 = this.log_2_c2_rate + Channel.LOG_2_1712 - LogTable.log_2(n);
        }
        this.step = LogTable.raise_2(n2 + ((this.key_add << 7) + this.sample.fine_tune << 15) / 1536 - this.log_2_sampling_rate);
    }
    
    static {
        Channel.LOG_2_29024 = LogTable.log_2(29024);
        Channel.LOG_2_1712 = LogTable.log_2(1712);
        Channel.sine_table = new int[] { 0, 24, 49, 74, 97, 120, 141, 161, 180, 197, 212, 224, 235, 244, 250, 253, 255, 253, 250, 244, 235, 224, 212, 197, 180, 161, 141, 120, 97, 74, 49, 24 };
    }
}
