// 
// Decompiled by Procyon v0.5.36
// 

package ibxm;

public class Envelope
{
    public boolean sustain;
    public boolean looped;
    public int sustain_tick;
    public int loop_start_tick;
    public int loop_end_tick;
    public int[] ticks;
    public int[] ampls;
    
    public Envelope() {
        this.set_num_points(1);
    }
    
    public void set_num_points(int n) {
        if (n <= 0) {
            n = 1;
        }
        this.ticks = new int[n];
        this.ampls = new int[n];
        this.set_point(0, 0, 0);
    }
    
    public void set_point(int i, int j, final int n) {
        if (i >= 0 && i < this.ticks.length) {
            if (i == 0) {
                j = 0;
            }
            if (i > 0) {
                if (j < this.ticks[i - 1]) {
                    j += 256;
                }
                if (j <= this.ticks[i - 1]) {
                    System.out.println("Envelope: Point not valid (" + j + " <= " + this.ticks[i - 1] + ")");
                    j = this.ticks[i - 1] + 1;
                }
            }
            this.ticks[i] = j;
            this.ampls[i] = n;
            ++i;
            while (i < this.ticks.length) {
                this.ticks[i] = this.ticks[i - 1] + 1;
                this.ampls[i] = 0;
                ++i;
            }
        }
    }
    
    public void set_sustain_point(int n) {
        if (n < 0) {
            n = 0;
        }
        if (n >= this.ticks.length) {
            n = this.ticks.length - 1;
        }
        this.sustain_tick = this.ticks[n];
    }
    
    public void set_loop_points(int n, int n2) {
        if (n < 0) {
            n = 0;
        }
        if (n >= this.ticks.length) {
            n = this.ticks.length - 1;
        }
        if (n2 < n || n2 >= this.ticks.length) {
            n2 = n;
        }
        this.loop_start_tick = this.ticks[n];
        this.loop_end_tick = this.ticks[n2];
    }
    
    public int next_tick(int n, final boolean b) {
        ++n;
        if (this.looped && n >= this.loop_end_tick) {
            n = this.loop_start_tick;
        }
        if (this.sustain && b && n >= this.sustain_tick) {
            n = this.sustain_tick;
        }
        return n;
    }
    
    public int calculate_ampl(final int n) {
        int n2 = this.ampls[this.ticks.length - 1];
        if (n < this.ticks[this.ticks.length - 1]) {
            int n3 = 0;
            for (int i = 1; i < this.ticks.length; ++i) {
                if (this.ticks[i] <= n) {
                    n3 = i;
                }
            }
            n2 = ((this.ampls[n3 + 1] - this.ampls[n3] << 15) / (this.ticks[n3 + 1] - this.ticks[n3]) * (n - this.ticks[n3]) >> 15) + this.ampls[n3];
        }
        return n2;
    }
    
    public void dump() {
        for (int i = 0; i < this.ticks.length; ++i) {
            System.out.println(this.ticks[i] + ", " + this.ampls[i]);
        }
        for (int j = 0; j < 222; ++j) {
            System.out.print(this.calculate_ampl(j) + ", ");
        }
    }
}
