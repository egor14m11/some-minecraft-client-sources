// 
// Decompiled by Procyon v0.5.36
// 

package ibxm;

import java.io.IOException;
import java.io.DataInput;

public class FastTracker2
{
    public static boolean is_xm(final byte[] array) {
        return ascii_text(array, 0, 17).equals("Extended Module: ");
    }
    
    public static Module load_xm(final byte[] array, final DataInput dataInput) throws IOException {
        if (!is_xm(array)) {
            throw new IllegalArgumentException("Not an XM file!");
        }
        final int unsigned_short_le = unsigned_short_le(array, 58);
        if (unsigned_short_le != 260) {
            throw new IllegalArgumentException("Sorry, XM version " + unsigned_short_le + " is not supported!");
        }
        final Module module = new Module();
        module.song_title = ascii_text(array, 17, 20);
        final byte[] array2 = new byte[4];
        dataInput.readFully(array2);
        final int int_le = int_le(array2, 0);
        final byte[] array3 = new byte[int_le];
        dataInput.readFully(array3, 4, int_le - 4);
        final int unsigned_short_le2 = unsigned_short_le(array3, 4);
        module.restart_sequence_index = unsigned_short_le(array3, 6);
        final int unsigned_short_le3 = unsigned_short_le(array3, 8);
        final int unsigned_short_le4 = unsigned_short_le(array3, 10);
        final int unsigned_short_le5 = unsigned_short_le(array3, 12);
        module.linear_periods = ((unsigned_short_le(array3, 14) & 0x1) == 0x1);
        module.global_volume = 64;
        module.channel_gain = 12288;
        module.default_speed = unsigned_short_le(array3, 16);
        module.default_tempo = unsigned_short_le(array3, 18);
        module.set_num_channels(unsigned_short_le3);
        for (int i = 0; i < unsigned_short_le3; ++i) {
            module.set_initial_panning(i, 128);
        }
        module.set_sequence_length(unsigned_short_le2);
        for (int j = 0; j < unsigned_short_le2; ++j) {
            module.set_sequence(j, array3[20 + j] & 0xFF);
        }
        module.set_num_patterns(unsigned_short_le4);
        for (int k = 0; k < unsigned_short_le4; ++k) {
            module.set_pattern(k, read_xm_pattern(dataInput, unsigned_short_le3));
        }
        module.set_num_instruments(unsigned_short_le5);
        for (int l = 1; l <= unsigned_short_le5; ++l) {
            module.set_instrument(l, read_xm_instrument(dataInput));
        }
        return module;
    }
    
    public static Pattern read_xm_pattern(final DataInput dataInput, final int n) throws IOException {
        final byte[] array = new byte[4];
        dataInput.readFully(array);
        final int int_le = int_le(array, 0);
        final byte[] array2 = new byte[int_le];
        dataInput.readFully(array2, 4, int_le - 4);
        final byte i = array2[4];
        if (i != 0) {
            throw new IllegalArgumentException("Pattern packing type " + i + " is not supported!");
        }
        final Pattern pattern = new Pattern();
        pattern.num_rows = unsigned_short_le(array2, 5);
        final byte[] array3 = new byte[unsigned_short_le(array2, 7)];
        dataInput.readFully(array3);
        pattern.set_pattern_data(array3);
        return pattern;
    }
    
    public static Instrument read_xm_instrument(final DataInput dataInput) throws IOException {
        final byte[] array = new byte[4];
        dataInput.readFully(array);
        final int int_le = int_le(array, 0);
        final byte[] array2 = new byte[int_le];
        dataInput.readFully(array2, 4, int_le - 4);
        final Instrument instrument = new Instrument();
        instrument.name = ascii_text(array2, 4, 22);
        final int unsigned_short_le = unsigned_short_le(array2, 27);
        if (unsigned_short_le > 0) {
            instrument.set_num_samples(unsigned_short_le);
            for (int i = 0; i < 96; ++i) {
                instrument.set_key_to_sample(i + 1, array2[33 + i] & 0xFF);
            }
            final Envelope envelope = new Envelope();
            final int n = array2[225] & 0xFF;
            envelope.set_num_points(n);
            for (int j = 0; j < n; ++j) {
                envelope.set_point(j, unsigned_short_le(array2, 129 + j * 4), unsigned_short_le(array2, 131 + j * 4));
            }
            envelope.set_sustain_point(array2[227] & 0xFF);
            envelope.set_loop_points(array2[228] & 0xFF, array2[229] & 0xFF);
            final int n2 = array2[233] & 0xFF;
            instrument.volume_envelope_active = ((n2 & 0x1) == 0x1);
            envelope.sustain = ((n2 & 0x2) == 0x2);
            envelope.looped = ((n2 & 0x4) == 0x4);
            instrument.set_volume_envelope(envelope);
            final Envelope envelope2 = new Envelope();
            final int n3 = array2[226] & 0xFF;
            envelope2.set_num_points(n3);
            for (int k = 0; k < n3; ++k) {
                envelope2.set_point(k, unsigned_short_le(array2, 177 + k * 4), unsigned_short_le(array2, 179 + k * 4));
            }
            envelope2.set_sustain_point(array2[230] & 0xFF);
            envelope2.set_loop_points(array2[231] & 0xFF, array2[232] & 0xFF);
            final int n4 = array2[234] & 0xFF;
            instrument.panning_envelope_active = ((n4 & 0x1) == 0x1);
            envelope2.sustain = ((n4 & 0x2) == 0x2);
            envelope2.looped = ((n4 & 0x4) == 0x4);
            instrument.set_panning_envelope(envelope2);
            instrument.vibrato_type = (array2[235] & 0xFF);
            instrument.vibrato_sweep = (array2[236] & 0xFF);
            instrument.vibrato_depth = (array2[237] & 0xFF);
            instrument.vibrato_rate = (array2[238] & 0xFF);
            instrument.volume_fade_out = unsigned_short_le(array2, 239);
            final byte[] array3 = new byte[unsigned_short_le * 40];
            dataInput.readFully(array3);
            for (int l = 0; l < unsigned_short_le; ++l) {
                instrument.set_sample(l, read_xm_sample(array3, l, dataInput));
            }
        }
        return instrument;
    }
    
    public static Sample read_xm_sample(final byte[] array, final int n, final DataInput dataInput) throws IOException {
        final int n2 = n * 40;
        final Sample sample = new Sample();
        final int int_le = int_le(array, n2);
        final int int_le2 = int_le(array, n2 + 4);
        int int_le3 = int_le(array, n2 + 8);
        sample.volume = (array[n2 + 12] & 0xFF);
        sample.fine_tune = array[n2 + 13];
        sample.set_panning = true;
        final int n3 = array[n2 + 14] & 0xFF;
        if ((n3 & 0x3) == 0x0) {
            int_le3 = 0;
        }
        final boolean b = (n3 & 0x2) == 0x2;
        final boolean b2 = (n3 & 0x10) == 0x10;
        sample.panning = (array[n2 + 15] & 0xFF);
        sample.relative_note = array[n2 + 16];
        sample.name = ascii_text(array, n2 + 18, 22);
        final byte[] array2 = new byte[int_le];
        dataInput.readFully(array2);
        int i = 0;
        int n4 = 0;
        int n5 = 0;
        if (b2) {
            final short[] array3 = new short[int_le >> 1];
            while (i < array2.length) {
                n5 += ((array2[i] & 0xFF) | (array2[i + 1] & 0xFF) << 8);
                array3[n4] = (short)n5;
                i += 2;
                ++n4;
            }
            sample.set_sample_data(array3, int_le2 >> 1, int_le3 >> 1, b);
        }
        else {
            final short[] array4 = new short[int_le];
            while (i < array2.length) {
                n5 += (array2[i] & 0xFF);
                array4[n4] = (short)(n5 << 8);
                ++i;
                ++n4;
            }
            sample.set_sample_data(array4, int_le2, int_le3, b);
        }
        return sample;
    }
    
    public static int unsigned_short_le(final byte[] array, final int n) {
        return (array[n] & 0xFF) | (array[n + 1] & 0xFF) << 8;
    }
    
    public static int int_le(final byte[] array, final int n) {
        return (array[n] & 0xFF) | (array[n + 1] & 0xFF) << 8 | (array[n + 2] & 0xFF) << 16 | (array[n + 3] & 0x7F) << 24;
    }
    
    public static String ascii_text(final byte[] array, final int n, final int length) {
        final byte[] bytes = new byte[length];
        for (int i = 0; i < length; ++i) {
            int n2 = array[n + i];
            if (n2 < 32) {
                n2 = 32;
            }
            bytes[i] = (byte)n2;
        }
        return new String(bytes, 0, length, "ISO-8859-1");
    }
}
