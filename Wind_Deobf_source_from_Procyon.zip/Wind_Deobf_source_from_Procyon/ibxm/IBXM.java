// 
// Decompiled by Procyon v0.5.36
// 

package ibxm;

import java.nio.ByteOrder;

public class IBXM
{
    public static String VERSION;
    public static int FP_SHIFT;
    public static int FP_ONE;
    public static int FP_MASK;
    public int sampling_rate;
    public int resampling_quality;
    public int volume_ramp_length;
    public int tick_length_samples;
    public int current_tick_samples;
    public int[] mixing_buffer;
    public int[] volume_ramp_buffer;
    public Module module;
    public Channel[] channels;
    public int[] global_volume;
    public int[] note;
    public int current_sequence_index;
    public int next_sequence_index;
    public int current_row;
    public int next_row;
    public int tick_counter;
    public int ticks_per_row;
    public int pattern_loop_count;
    public int pattern_loop_channel;
    
    public IBXM(int sampling_rate) {
        System.out.println("ibxm alpha 45 (c)2006 mumart@gmail.com");
        if (sampling_rate < 8000) {
            sampling_rate = 8000;
        }
        this.sampling_rate = sampling_rate;
        this.volume_ramp_length = this.sampling_rate >> 10;
        this.volume_ramp_buffer = new int[this.volume_ramp_length * 2];
        this.mixing_buffer = new int[this.sampling_rate / 6];
        this.global_volume = new int[1];
        this.note = new int[5];
        this.set_module(new Module());
        this.set_resampling_quality(1);
    }
    
    public void set_module(final Module module) {
        this.module = module;
        this.channels = new Channel[this.module.get_num_channels()];
        for (int i = 0; i < this.channels.length; ++i) {
            this.channels[i] = new Channel(this.module, this.sampling_rate, this.global_volume);
        }
        this.set_sequence_index(0, 0);
    }
    
    public void set_resampling_quality(final int resampling_quality) {
        this.resampling_quality = resampling_quality;
    }
    
    public int calculate_song_duration() {
        this.set_sequence_index(0, 0);
        this.next_tick();
        int tick_length_samples = this.tick_length_samples;
        while (!this.next_tick()) {
            tick_length_samples += this.tick_length_samples;
        }
        this.set_sequence_index(0, 0);
        return tick_length_samples;
    }
    
    public void set_sequence_index(final int next_sequence_index, final int next_row) {
        this.global_volume[0] = 64;
        for (int i = 0; i < this.channels.length; ++i) {
            this.channels[i].reset();
            this.channels[i].set_panning(this.module.get_initial_panning(i));
        }
        this.set_global_volume(this.module.global_volume);
        this.set_speed(6);
        this.set_speed(this.module.default_speed);
        this.set_tempo(125);
        this.set_tempo(this.module.default_tempo);
        this.pattern_loop_count = -1;
        this.next_sequence_index = next_sequence_index;
        this.next_row = next_row;
        this.tick_counter = 0;
        this.current_tick_samples = this.tick_length_samples;
    }
    
    public void seek(int i) {
        this.set_sequence_index(0, 0);
        this.next_tick();
        while (i > this.tick_length_samples) {
            i -= this.tick_length_samples;
            this.next_tick();
        }
        this.next_tick();
        this.current_tick_samples = i;
    }
    
    public void get_audio(final byte[] array, int i) {
        final boolean equals = ByteOrder.nativeOrder().equals(ByteOrder.BIG_ENDIAN);
        int n = 0;
        while (i > 0) {
            int n2 = this.tick_length_samples - this.current_tick_samples;
            if (n2 > i) {
                n2 = i;
            }
            int j;
            for (j = this.current_tick_samples << 1; j <= j + (n2 << 1) - 1; ++j) {
                int n3 = this.mixing_buffer[j];
                if (n3 > 32767) {
                    n3 = 32767;
                }
                if (n3 < -32768) {
                    n3 = -32768;
                }
                if (equals) {
                    array[n] = (byte)(n3 >> 8);
                    array[n + 1] = (byte)(n3 & 0xFF);
                }
                else {
                    array[n] = (byte)(n3 & 0xFF);
                    array[n + 1] = (byte)(n3 >> 8);
                }
                n += 2;
            }
            this.current_tick_samples = j >> 1;
            i -= n2;
            if (i > 0) {
                this.next_tick();
                this.mix_tick();
                this.current_tick_samples = 0;
            }
        }
    }
    
    public void mix_tick() {
        for (int i = 0; i < this.tick_length_samples + this.volume_ramp_length << 1; ++i) {
            this.mixing_buffer[i] = 0;
        }
        for (int j = 0; j < this.channels.length; ++j) {
            this.channels[j].resample(this.mixing_buffer, 0, this.tick_length_samples + this.volume_ramp_length, this.resampling_quality);
        }
        this.volume_ramp();
    }
    
    public boolean next_tick() {
        for (int i = 0; i < this.channels.length; ++i) {
            this.channels[i].update_sample_idx(this.tick_length_samples);
        }
        --this.tick_counter;
        boolean next_row;
        if (this.tick_counter <= 0) {
            this.tick_counter = this.ticks_per_row;
            next_row = this.next_row();
        }
        else {
            for (int j = 0; j < this.channels.length; ++j) {
                this.channels[j].tick();
            }
            next_row = false;
        }
        return next_row;
    }
    
    public boolean next_row() {
        boolean b = false;
        if (this.next_sequence_index < 0) {
            this.next_sequence_index = 0;
            this.next_row = 0;
        }
        if (this.next_sequence_index >= this.module.get_sequence_length()) {
            b = true;
            this.next_sequence_index = this.module.restart_sequence_index;
            if (this.next_sequence_index < 0) {
                this.next_sequence_index = 0;
            }
            if (this.next_sequence_index >= this.module.get_sequence_length()) {
                this.next_sequence_index = 0;
            }
            this.next_row = 0;
        }
        if (this.next_sequence_index < this.current_sequence_index) {
            b = true;
        }
        if (this.next_sequence_index == this.current_sequence_index && this.next_row <= this.current_row && this.pattern_loop_count < 0) {
            b = true;
        }
        this.current_sequence_index = this.next_sequence_index;
        final Pattern get_pattern_from_sequence = this.module.get_pattern_from_sequence(this.current_sequence_index);
        if (this.next_row < 0 || this.next_row >= get_pattern_from_sequence.num_rows) {
            this.next_row = 0;
        }
        this.current_row = this.next_row;
        this.next_row = this.current_row + 1;
        if (this.next_row >= get_pattern_from_sequence.num_rows) {
            this.next_sequence_index = this.current_sequence_index + 1;
            this.next_row = 0;
        }
        for (int i = 0; i < this.channels.length; ++i) {
            get_pattern_from_sequence.get_note(this.note, this.current_row * this.channels.length + i);
            final int n = this.note[3];
            final int next_sequence_index = this.note[4];
            this.channels[i].row(this.note[0], this.note[1], this.note[2], n, next_sequence_index);
            switch (n) {
                case 11: {
                    if (this.pattern_loop_count < 0) {
                        this.next_sequence_index = next_sequence_index;
                        this.next_row = 0;
                        break;
                    }
                    break;
                }
                case 13: {
                    if (this.pattern_loop_count < 0) {
                        this.next_sequence_index = this.current_sequence_index + 1;
                        this.next_row = (next_sequence_index >> 4) * 10 + (next_sequence_index & 0xF);
                        break;
                    }
                    break;
                }
                case 14: {
                    switch (next_sequence_index & 0xF0) {
                        case 96: {
                            if ((next_sequence_index & 0xF) == 0x0) {
                                this.channels[i].pattern_loop_row = this.current_row;
                            }
                            if (this.channels[i].pattern_loop_row >= this.current_row) {
                                break;
                            }
                            if (this.pattern_loop_count < 0) {
                                this.pattern_loop_count = (next_sequence_index & 0xF);
                                this.pattern_loop_channel = i;
                            }
                            if (this.pattern_loop_channel == i) {
                                if (this.pattern_loop_count == 0) {
                                    this.channels[i].pattern_loop_row = this.current_row + 1;
                                }
                                else {
                                    this.next_row = this.channels[i].pattern_loop_row;
                                    this.next_sequence_index = this.current_sequence_index;
                                }
                                --this.pattern_loop_count;
                                break;
                            }
                            break;
                        }
                        case 224: {
                            this.tick_counter += this.ticks_per_row * (next_sequence_index & 0xF);
                            break;
                        }
                    }
                    break;
                }
                case 15: {
                    if (next_sequence_index < 32) {
                        this.set_speed(next_sequence_index);
                        this.tick_counter = this.ticks_per_row;
                        break;
                    }
                    this.set_tempo(next_sequence_index);
                    break;
                }
                case 37: {
                    this.set_speed(next_sequence_index);
                    this.tick_counter = this.ticks_per_row;
                    break;
                }
            }
        }
        return b;
    }
    
    public void set_global_volume(int n) {
        if (n < 0) {
            n = 0;
        }
        if (n > 64) {
            n = 64;
        }
        this.global_volume[0] = n;
    }
    
    public void set_speed(final int ticks_per_row) {
        if (ticks_per_row > 0 && ticks_per_row < 256) {
            this.ticks_per_row = ticks_per_row;
        }
    }
    
    public void set_tempo(final int n) {
        if (n > 31 && n < 256) {
            this.tick_length_samples = this.sampling_rate * 5 / (n * 2);
        }
    }
    
    public void volume_ramp() {
        final int n = 32768 / this.volume_ramp_length;
        int n2 = 0;
        int i = 0;
        final int n3 = 2 * this.tick_length_samples;
        while (i <= this.volume_ramp_length * 2 - 1) {
            this.mixing_buffer[i] = (this.volume_ramp_buffer[i] * (32768 - n2) >> 15) + (this.mixing_buffer[i] * n2 >> 15);
            this.volume_ramp_buffer[i] = this.mixing_buffer[n3 + i];
            this.mixing_buffer[i + 1] = (this.volume_ramp_buffer[i + 1] * (32768 - n2) >> 15) + (this.mixing_buffer[i + 1] * n2 >> 15);
            this.volume_ramp_buffer[i + 1] = this.mixing_buffer[n3 + i + 1];
            n2 += n;
            i += 2;
        }
    }
    
    static {
        IBXM.FP_MASK = 32767;
        IBXM.FP_ONE = 32768;
        IBXM.FP_SHIFT = 15;
        IBXM.VERSION = "ibxm alpha 45 (c)2006 mumart@gmail.com";
    }
}
