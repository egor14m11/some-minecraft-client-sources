// 
// Decompiled by Procyon v0.5.36
// 

package ibxm;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.AL;
import org.lwjgl.BufferUtils;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;

public class OpenALMODPlayer
{
    public static int sectionSize;
    public IntBuffer bufferNames;
    public IBXM ibxm;
    public int songDuration;
    public byte[] data;
    public ByteBuffer bufferData;
    public IntBuffer unqueued;
    public int source;
    public boolean soundWorks;
    public Module module;
    public boolean loop;
    public boolean done;
    public int remainingBufferCount;
    
    public OpenALMODPlayer() {
        this.data = new byte[163840];
        this.bufferData = BufferUtils.createByteBuffer(163840);
        this.unqueued = BufferUtils.createIntBuffer(1);
        this.soundWorks = true;
        this.done = true;
    }
    
    public void init() {
        AL.create();
        this.soundWorks = true;
        if (this.soundWorks) {
            final IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
            AL10.alGenSources(intBuffer);
            if (AL10.alGetError() != 0) {
                System.err.println("Failed to create sources");
                this.soundWorks = false;
            }
            else {
                this.source = intBuffer.get(0);
            }
        }
    }
    
    public void play(final InputStream inputStream, final boolean b, final boolean b2) throws IOException {
        this.play(this.source, inputStream, b, b2);
    }
    
    public void play(final int source, final InputStream inputStream, final boolean loop, final boolean b) throws IOException {
        if (!this.soundWorks) {
            return;
        }
        this.done = false;
        this.loop = loop;
        this.source = source;
        this.play(this.module = loadModule(inputStream), source, loop, b);
    }
    
    public void play(final Module module, final int source, final boolean loop, final boolean b) {
        this.source = source;
        this.loop = loop;
        this.module = module;
        this.done = false;
        (this.ibxm = new IBXM(48000)).set_module(module);
        this.songDuration = this.ibxm.calculate_song_duration();
        if (this.bufferNames != null) {
            AL10.alSourceStop(source);
            this.bufferNames.flip();
            AL10.alDeleteBuffers(this.bufferNames);
        }
        AL10.alGenBuffers(this.bufferNames = BufferUtils.createIntBuffer(2));
        this.remainingBufferCount = 2;
        for (int i = 0; i < 2; ++i) {
            this.stream(this.bufferNames.get(i));
        }
        AL10.alSourceQueueBuffers(source, this.bufferNames);
        AL10.alSourcef(source, 4099, 1.0f);
        AL10.alSourcef(source, 4106, 1.0f);
        if (b) {
            AL10.alSourcePlay(source);
        }
    }
    
    public void setup(final float n, final float n2) {
        AL10.alSourcef(this.source, 4099, n);
        AL10.alSourcef(this.source, 4106, n2);
    }
    
    public boolean done() {
        return this.done;
    }
    
    public static Module loadModule(final InputStream in) throws IOException {
        final DataInputStream dataInputStream = new DataInputStream(in);
        final byte[] b = new byte[60];
        dataInputStream.readFully(b);
        Module module;
        if (FastTracker2.is_xm(b)) {
            module = FastTracker2.load_xm(b, dataInputStream);
        }
        else {
            final byte[] b2 = new byte[96];
            System.arraycopy(b, 0, b2, 0, 60);
            dataInputStream.readFully(b2, 60, 36);
            if (ScreamTracker3.is_s3m(b2)) {
                module = ScreamTracker3.load_s3m(b2, dataInputStream);
            }
            else {
                final byte[] b3 = new byte[1084];
                System.arraycopy(b2, 0, b3, 0, 96);
                dataInputStream.readFully(b3, 96, 988);
                module = ProTracker.load_mod(b3, dataInputStream);
            }
        }
        dataInputStream.close();
        return module;
    }
    
    public void update() {
        if (this.done) {
            return;
        }
        for (int i = AL10.alGetSourcei(this.source, 4118); i > 0; --i) {
            this.unqueued.clear();
            AL10.alSourceUnqueueBuffers(this.source, this.unqueued);
            if (this.stream(this.unqueued.get(0))) {
                AL10.alSourceQueueBuffers(this.source, this.unqueued);
            }
            else {
                --this.remainingBufferCount;
                if (this.remainingBufferCount == 0) {
                    this.done = true;
                }
            }
        }
        if (AL10.alGetSourcei(this.source, 4112) != 4114) {
            AL10.alSourcePlay(this.source);
        }
    }
    
    public boolean stream(final int n) {
        int songDuration = 40960;
        boolean b = false;
        boolean b2 = true;
        if (songDuration > this.songDuration) {
            songDuration = this.songDuration;
            b = true;
        }
        this.ibxm.get_audio(this.data, songDuration);
        this.bufferData.clear();
        this.bufferData.put(this.data);
        this.bufferData.limit(songDuration * 4);
        if (b) {
            if (this.loop) {
                this.ibxm.seek(0);
                this.ibxm.set_module(this.module);
                this.songDuration = this.ibxm.calculate_song_duration();
            }
            else {
                b2 = false;
                this.songDuration -= songDuration;
            }
        }
        else {
            this.songDuration -= songDuration;
        }
        this.bufferData.flip();
        AL10.alBufferData(n, 4355, this.bufferData, 48000);
        return b2;
    }
    
    static {
        OpenALMODPlayer.sectionSize = 40960;
    }
}
