// 
// Decompiled by Procyon v0.5.36
// 

package ibxm;

public class Pattern
{
    public int num_rows;
    public int data_offset;
    public int note_index;
    public byte[] pattern_data;
    
    public Pattern() {
        this.num_rows = 1;
        this.set_pattern_data(new byte[0]);
    }
    
    public void set_pattern_data(final byte[] pattern_data) {
        if (pattern_data != null) {
            this.pattern_data = pattern_data;
        }
        this.data_offset = 0;
        this.note_index = 0;
    }
    
    public void get_note(final int[] array, final int n) {
        if (n < this.note_index) {
            this.note_index = 0;
            this.data_offset = 0;
        }
        while (this.note_index <= n) {
            this.data_offset = this.next_note(this.data_offset, array);
            ++this.note_index;
        }
    }
    
    public int next_note(int length, final int[] array) {
        if (length < 0) {
            length = this.pattern_data.length;
        }
        int n = 128;
        if (length < this.pattern_data.length) {
            n = (this.pattern_data[length] & 0xFF);
        }
        if ((n & 0x80) == 0x80) {
            ++length;
        }
        else {
            n = 31;
        }
        for (int i = 0; i < 5; ++i) {
            array[i] = 0;
            if ((n & 0x1) == 0x1 && length < this.pattern_data.length) {
                array[i] = (this.pattern_data[length] & 0xFF);
                ++length;
            }
            n >>= 1;
        }
        return length;
    }
}
