// 
// Decompiled by Procyon v0.5.36
// 

package ibxm;

import java.io.IOException;
import java.io.DataInput;

public class ProTracker
{
    public static boolean is_mod(final byte[] array) {
        boolean b = false;
        if (calculate_num_channels(array) > 0) {
            b = true;
        }
        return b;
    }
    
    public static Module load_mod(final byte[] array, final DataInput dataInput) throws IOException {
        final int calculate_num_channels = calculate_num_channels(array);
        if (calculate_num_channels < 1) {
            throw new IllegalArgumentException("ProTracker: Unrecognised module format!");
        }
        final Module module = new Module();
        module.song_title = ascii_text(array, 0, 20);
        module.global_volume = 64;
        module.channel_gain = 12288;
        module.default_speed = 6;
        module.default_tempo = 125;
        module.set_num_channels(calculate_num_channels);
        for (int i = 0; i < calculate_num_channels; ++i) {
            int n = 64;
            if ((i & 0x3) == 0x1 || (i & 0x3) == 0x2) {
                n = 192;
            }
            module.set_initial_panning(i, n);
        }
        final int n2 = array[950] & 0x7F;
        int restart_sequence_index = array[951] & 0x7F;
        if (restart_sequence_index >= n2) {
            restart_sequence_index = 0;
        }
        module.restart_sequence_index = restart_sequence_index;
        module.set_sequence_length(n2);
        for (int j = 0; j < n2; ++j) {
            module.set_sequence(j, array[952 + j] & 0x7F);
        }
        final int calculate_num_patterns = calculate_num_patterns(array);
        module.set_num_patterns(calculate_num_patterns);
        for (int k = 0; k < calculate_num_patterns; ++k) {
            module.set_pattern(k, read_mod_pattern(dataInput, calculate_num_channels));
        }
        module.set_num_instruments(31);
        for (int l = 1; l <= 31; ++l) {
            module.set_instrument(l, read_mod_instrument(array, l, dataInput));
        }
        return module;
    }
    
    public static int calculate_num_patterns(final byte[] array) {
        int n = 0;
        for (int i = 0; i < 128; ++i) {
            final int n2 = array[952 + i] & 0x7F;
            if (n2 >= n) {
                n = n2 + 1;
            }
        }
        return n;
    }
    
    public static int calculate_num_channels(final byte[] array) {
        int n = 0;
        switch (array[1082] << 8 | array[1083]) {
            case 19233:
            case 19246:
            case 21550:
            case 21556: {
                n = 4;
                break;
            }
            case 18510: {
                n = array[1080] - 48;
                break;
            }
            case 17224: {
                n = (array[1080] - 48) * 10 + (array[1081] - 48);
                break;
            }
            default: {
                n = 0;
                break;
            }
        }
        return n;
    }
    
    public static Pattern read_mod_pattern(final DataInput dataInput, final int n) throws IOException {
        final Pattern pattern = new Pattern();
        pattern.num_rows = 64;
        final byte[] array = new byte[64 * n * 4];
        final byte[] array2 = new byte[64 * n * 5];
        dataInput.readFully(array);
        for (int i = 0, n2 = 0; i < array.length; i += 4, n2 += 5) {
            array2[n2] = to_key((array[i] & 0xF) << 8 | (array[i + 1] & 0xFF));
            array2[n2 + 1] = (byte)((array[i] & 0x10) | (array[i + 2] & 0xF0) >> 4);
            int n3 = array[i + 2] & 0xF;
            int n4 = array[i + 3] & 0xFF;
            if (n3 == 8 && n == 4) {
                n3 = 0;
                n4 = 0;
            }
            if (n3 == 10 && n4 == 0) {
                n3 = 0;
            }
            if (n3 == 5 && n4 == 0) {
                n3 = 3;
            }
            if (n3 == 6 && n4 == 0) {
                n3 = 4;
            }
            array2[n2 + 3] = (byte)n3;
            array2[n2 + 4] = (byte)n4;
        }
        pattern.set_pattern_data(array2);
        return pattern;
    }
    
    public static Instrument read_mod_instrument(final byte[] array, final int n, final DataInput dataInput) throws IOException {
        final int n2 = (n - 1) * 30 + 20;
        final Instrument instrument = new Instrument();
        instrument.name = ascii_text(array, n2, 22);
        final Sample sample = new Sample();
        sample.c2_rate = 8287;
        final int n3 = unsigned_short_be(array, n2 + 22) << 1;
        sample.fine_tune = (array[n2 + 24] & 0xF) << 4;
        if (sample.fine_tune > 127) {
            final Sample sample2 = sample;
            sample2.fine_tune -= 256;
        }
        sample.volume = (array[n2 + 25] & 0x7F);
        final int n4 = unsigned_short_be(array, n2 + 26) << 1;
        int n5 = unsigned_short_be(array, n2 + 28) << 1;
        if (n5 < 4) {
            n5 = 0;
        }
        final byte[] array2 = new byte[n3];
        final short[] array3 = new short[n3];
        dataInput.readFully(array2);
        for (int i = 0; i < array2.length; ++i) {
            array3[i] = (short)(array2[i] << 8);
        }
        sample.set_sample_data(array3, n4, n5, false);
        instrument.set_num_samples(1);
        instrument.set_sample(0, sample);
        return instrument;
    }
    
    public static byte to_key(final int n) {
        int n2;
        if (n < 32) {
            n2 = 0;
        }
        else {
            final int n3 = LogTable.log_2(7256) - LogTable.log_2(n);
            if (n3 < 0) {
                n2 = 0;
            }
            else {
                final int n4 = n3 * 12 >> 14;
                n2 = (n4 >> 1) + (n4 & 0x1);
            }
        }
        return (byte)n2;
    }
    
    public static int unsigned_short_be(final byte[] array, final int n) {
        return (array[n] & 0xFF) << 8 | (array[n + 1] & 0xFF);
    }
    
    public static String ascii_text(final byte[] array, final int n, final int length) {
        final byte[] bytes = new byte[length];
        for (int i = 0; i < length; ++i) {
            int n2 = array[n + i];
            if (n2 < 32) {
                n2 = 32;
            }
            bytes[i] = (byte)n2;
        }
        return new String(bytes, 0, length, "ISO-8859-1");
    }
}
