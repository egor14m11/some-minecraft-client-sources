// 
// Decompiled by Procyon v0.5.36
// 

package ibxm;

public class Sample
{
    public String name;
    public boolean set_panning;
    public int volume;
    public int panning;
    public int c2_rate;
    public int relative_note;
    public int fine_tune;
    public int loop_start;
    public int loop_length;
    public short[] sample_data;
    public static int POINT_SHIFT;
    public static int POINTS;
    public static int OVERLAP;
    public static int INTERP_SHIFT;
    public static int INTERP_BITMASK;
    public static short[] sinc_table;
    
    public Sample() {
        this.name = "";
        this.c2_rate = 8363;
        this.set_sample_data(new short[0], 0, 0, false);
    }
    
    public void set_sample_data(final short[] array, int loop_start, int loop_length, final boolean b) {
        if (loop_start < 0) {
            loop_start = 0;
        }
        if (loop_start >= array.length) {
            loop_start = array.length - 1;
        }
        if (loop_start + loop_length > array.length) {
            loop_length = array.length - loop_start;
        }
        if (loop_length <= 1) {
            System.arraycopy(array, 0, this.sample_data = new short[8 + array.length + 24], 8, array.length);
            for (int i = 0; i < 8; ++i) {
                this.sample_data[8 + array.length + i] = (short)(this.sample_data[8 + array.length - 1] * (8 - i) / 8);
            }
            loop_start = 8 + array.length + 8;
            loop_length = 1;
        }
        else {
            if (b) {
                System.arraycopy(array, 0, this.sample_data = new short[8 + loop_start + loop_length * 2 + 16], 8, loop_start + loop_length);
                for (int j = 0; j < loop_length; ++j) {
                    this.sample_data[8 + loop_start + loop_length + j] = array[loop_start + loop_length - j - 1];
                }
                loop_start += 8;
                loop_length *= 2;
            }
            else {
                System.arraycopy(array, 0, this.sample_data = new short[8 + loop_start + loop_length + 16], 8, loop_start + loop_length);
                loop_start += 8;
            }
            for (int k = 0; k < 16; ++k) {
                this.sample_data[loop_start + loop_length + k] = this.sample_data[loop_start + k];
            }
        }
        this.loop_start = loop_start;
        this.loop_length = loop_length;
    }
    
    public void resample_nearest(int n, int n2, final int n3, final int n4, final int n5, final int[] array, final int n6, final int n7) {
        n += 8;
        final int n8 = this.loop_start + this.loop_length - 1;
        for (int i = n6 << 1; i <= n6 + n7 - 1 << 1; i += 2, n2 += n3, n += n2 >> 15, n2 &= 0x7FFF) {
            if (n > n8) {
                if (this.loop_length <= 1) {
                    break;
                }
                n = this.loop_start + (n - this.loop_start) % this.loop_length;
            }
            final int n9 = i;
            array[n9] += this.sample_data[n] * n4 >> 15;
            final int n10 = i + 1;
            array[n10] += this.sample_data[n] * n5 >> 15;
        }
    }
    
    public void resample_linear(int n, int n2, final int n3, final int n4, final int n5, final int[] array, final int n6, final int n7) {
        n += 8;
        final int n8 = this.loop_start + this.loop_length - 1;
        for (int i = n6 << 1; i <= n6 + n7 - 1 << 1; i += 2, n2 += n3, n += n2 >> 15, n2 &= 0x7FFF) {
            if (n > n8) {
                if (this.loop_length <= 1) {
                    break;
                }
                n = this.loop_start + (n - this.loop_start) % this.loop_length;
            }
            final short n9 = this.sample_data[n];
            final int n10 = n9 + ((this.sample_data[n + 1] - n9) * n2 >> 15);
            final int n11 = i;
            array[n11] += n10 * n4 >> 15;
            final int n12 = i + 1;
            array[n12] += n10 * n5 >> 15;
        }
    }
    
    public void resample_sinc(int n, int n2, final int n3, final int n4, final int n5, final int[] array, final int n6, final int n7) {
        final int n8 = this.loop_start + this.loop_length - 1;
        for (int i = n6 << 1; i <= n6 + n7 - 1 << 1; i += 2, n2 += n3, n += n2 >> 15, n2 &= 0x7FFF) {
            if (n > n8) {
                if (this.loop_length <= 1) {
                    break;
                }
                n = this.loop_start + (n - this.loop_start) % this.loop_length;
            }
            final int n9 = n2 >> 11 << 4;
            final int n10 = (Sample.sinc_table[n9 + 0] * this.sample_data[n + 0] >> 15) + (Sample.sinc_table[n9 + 1] * this.sample_data[n + 1] >> 15) + (Sample.sinc_table[n9 + 2] * this.sample_data[n + 2] >> 15) + (Sample.sinc_table[n9 + 3] * this.sample_data[n + 3] >> 15) + (Sample.sinc_table[n9 + 4] * this.sample_data[n + 4] >> 15) + (Sample.sinc_table[n9 + 5] * this.sample_data[n + 5] >> 15) + (Sample.sinc_table[n9 + 6] * this.sample_data[n + 6] >> 15) + (Sample.sinc_table[n9 + 7] * this.sample_data[n + 7] >> 15) + (Sample.sinc_table[n9 + 8] * this.sample_data[n + 8] >> 15) + (Sample.sinc_table[n9 + 9] * this.sample_data[n + 9] >> 15) + (Sample.sinc_table[n9 + 10] * this.sample_data[n + 10] >> 15) + (Sample.sinc_table[n9 + 11] * this.sample_data[n + 11] >> 15) + (Sample.sinc_table[n9 + 12] * this.sample_data[n + 12] >> 15) + (Sample.sinc_table[n9 + 13] * this.sample_data[n + 13] >> 15) + (Sample.sinc_table[n9 + 14] * this.sample_data[n + 14] >> 15) + (Sample.sinc_table[n9 + 15] * this.sample_data[n + 15] >> 15);
            final int n11 = n10 + (((Sample.sinc_table[n9 + 16] * this.sample_data[n + 0] >> 15) + (Sample.sinc_table[n9 + 17] * this.sample_data[n + 1] >> 15) + (Sample.sinc_table[n9 + 18] * this.sample_data[n + 2] >> 15) + (Sample.sinc_table[n9 + 19] * this.sample_data[n + 3] >> 15) + (Sample.sinc_table[n9 + 20] * this.sample_data[n + 4] >> 15) + (Sample.sinc_table[n9 + 21] * this.sample_data[n + 5] >> 15) + (Sample.sinc_table[n9 + 22] * this.sample_data[n + 6] >> 15) + (Sample.sinc_table[n9 + 23] * this.sample_data[n + 7] >> 15) + (Sample.sinc_table[n9 + 24] * this.sample_data[n + 8] >> 15) + (Sample.sinc_table[n9 + 25] * this.sample_data[n + 9] >> 15) + (Sample.sinc_table[n9 + 26] * this.sample_data[n + 10] >> 15) + (Sample.sinc_table[n9 + 27] * this.sample_data[n + 11] >> 15) + (Sample.sinc_table[n9 + 28] * this.sample_data[n + 12] >> 15) + (Sample.sinc_table[n9 + 29] * this.sample_data[n + 13] >> 15) + (Sample.sinc_table[n9 + 30] * this.sample_data[n + 14] >> 15) + (Sample.sinc_table[n9 + 31] * this.sample_data[n + 15] >> 15) - n10) * (n2 & 0x7FF) >> 11);
            final int n12 = i;
            array[n12] += n11 * n4 >> 15;
            final int n13 = i + 1;
            array[n13] += n11 * n5 >> 15;
        }
    }
    
    public boolean has_finished(final int n) {
        boolean b = false;
        if (this.loop_length <= 1 && n > this.loop_start) {
            b = true;
        }
        return b;
    }
    
    static {
        Sample.INTERP_BITMASK = 2047;
        Sample.INTERP_SHIFT = 11;
        Sample.OVERLAP = 8;
        Sample.POINTS = 16;
        Sample.POINT_SHIFT = 4;
        Sample.sinc_table = new short[] { 0, -7, 27, -71, 142, -227, 299, 32439, 299, -227, 142, -71, 27, -7, 0, 0, 0, 0, -5, 36, -142, 450, -1439, 32224, 2302, -974, 455, -190, 64, -15, 2, 0, 0, 6, -33, 128, -391, 1042, -2894, 31584, 4540, -1765, 786, -318, 105, -25, 3, 0, 0, 10, -55, 204, -597, 1533, -4056, 30535, 6977, -2573, 1121, -449, 148, -36, 5, 0, -1, 13, -71, 261, -757, 1916, -4922, 29105, 9568, -3366, 1448, -578, 191, -47, 7, 0, -1, 15, -81, 300, -870, 2185, -5498, 27328, 12263, -4109, 1749, -698, 232, -58, 9, 0, -1, 15, -86, 322, -936, 2343, -5800, 25249, 15006, -4765, 2011, -802, 269, -68, 10, 0, -1, 15, -87, 328, -957, 2394, -5849, 22920, 17738, -5298, 2215, -885, 299, -77, 12, 0, 0, 14, -83, 319, -938, 2347, -5671, 20396, 20396, -5671, 2347, -938, 319, -83, 14, 0, 0, 12, -77, 299, -885, 2215, -5298, 17738, 22920, -5849, 2394, -957, 328, -87, 15, -1, 0, 10, -68, 269, -802, 2011, -4765, 15006, 25249, -5800, 2343, -936, 322, -86, 15, -1, 0, 9, -58, 232, -698, 1749, -4109, 12263, 27328, -5498, 2185, -870, 300, -81, 15, -1, 0, 7, -47, 191, -578, 1448, -3366, 9568, 29105, -4922, 1916, -757, 261, -71, 13, -1, 0, 5, -36, 148, -449, 1121, -2573, 6977, 30535, -4056, 1533, -597, 204, -55, 10, 0, 0, 3, -25, 105, -318, 786, -1765, 4540, 31584, -2894, 1042, -391, 128, -33, 6, 0, 0, 2, -15, 64, -190, 455, -974, 2302, 32224, -1439, 450, -142, 36, -5, 0, 0, 0, 0, -7, 27, -71, 142, -227, 299, 32439, 299, -227, 142, -71, 27, -7, 0 };
    }
}
