// 
// Decompiled by Procyon v0.5.36
// 

package ibxm;

import java.io.IOException;
import java.io.DataInput;

public class ScreamTracker3
{
    public static int[] effect_map;
    public static int[] effect_s_map;
    
    public static boolean is_s3m(final byte[] array) {
        return ascii_text(array, 44, 4).equals("SCRM");
    }
    
    public static Module load_s3m(final byte[] array, final DataInput dataInput) throws IOException {
        final byte[] read_s3m_file = read_s3m_file(array, dataInput);
        final Module module = new Module();
        module.song_title = ascii_text(read_s3m_file, 0, 28);
        final int get_num_pattern_orders = get_num_pattern_orders(read_s3m_file);
        final int get_num_instruments = get_num_instruments(read_s3m_file);
        final int get_num_patterns = get_num_patterns(read_s3m_file);
        final int unsigned_short_le = unsigned_short_le(read_s3m_file, 38);
        final int unsigned_short_le2 = unsigned_short_le(read_s3m_file, 40);
        if ((unsigned_short_le & 0x40) == 0x40 || unsigned_short_le2 == 4864) {
            module.fast_volume_slides = true;
        }
        boolean b = false;
        if (unsigned_short_le(read_s3m_file, 42) == 1) {
            b = true;
        }
        module.global_volume = (read_s3m_file[48] & 0xFF);
        module.default_speed = (read_s3m_file[49] & 0xFF);
        module.default_tempo = (read_s3m_file[50] & 0xFF);
        module.channel_gain = (read_s3m_file[51] & 0x7F) << 15 >> 7;
        final boolean b2 = (read_s3m_file[51] & 0x80) == 0x80;
        final boolean b3 = (read_s3m_file[53] & 0xFF) == 0xFC;
        final int[] array2 = new int[32];
        int n = 0;
        for (int i = 0; i < 32; ++i) {
            final int n2 = read_s3m_file[64 + i] & 0xFF;
            array2[i] = -1;
            if (n2 < 16) {
                array2[i] = n;
                ++n;
            }
        }
        module.set_num_channels(n);
        final int n3 = 96 + get_num_pattern_orders + get_num_instruments * 2 + get_num_patterns * 2;
        for (int j = 0; j < 32; ++j) {
            final int n4 = read_s3m_file[64 + j] & 0xFF;
            if (array2[j] >= 0) {
                int n5 = 128;
                if (b2) {
                    if (n4 < 8) {
                        n5 = 64;
                    }
                    else {
                        n5 = 192;
                    }
                }
                if (b3) {
                    final int n6 = read_s3m_file[n3 + j] & 0xFF;
                    if ((n6 & 0x20) == 0x20) {
                        n5 = (n6 & 0xF) << 4;
                    }
                }
                module.set_initial_panning(array2[j], n5);
            }
        }
        final int[] read_s3m_sequence = read_s3m_sequence(read_s3m_file);
        module.set_sequence_length(read_s3m_sequence.length);
        for (int k = 0; k < read_s3m_sequence.length; ++k) {
            module.set_sequence(k, read_s3m_sequence[k]);
        }
        module.set_num_instruments(get_num_instruments);
        for (int l = 0; l < get_num_instruments; ++l) {
            module.set_instrument(l + 1, read_s3m_instrument(read_s3m_file, l, b));
        }
        module.set_num_patterns(get_num_patterns);
        for (int n7 = 0; n7 < get_num_patterns; ++n7) {
            module.set_pattern(n7, read_s3m_pattern(read_s3m_file, n7, array2));
        }
        return module;
    }
    
    public static int[] read_s3m_sequence(final byte[] array) {
        final int get_num_pattern_orders = get_num_pattern_orders(array);
        int n = 0;
        for (int i = 0; i < get_num_pattern_orders; ++i) {
            final int n2 = array[96 + i] & 0xFF;
            if (n2 == 255) {
                break;
            }
            if (n2 < 254) {
                ++n;
            }
        }
        final int[] array2 = new int[n];
        int n3 = 0;
        for (int j = 0; j < get_num_pattern_orders; ++j) {
            final int n4 = array[96 + j] & 0xFF;
            if (n4 == 255) {
                break;
            }
            if (n4 < 254) {
                array2[n3] = n4;
                ++n3;
            }
        }
        return array2;
    }
    
    public static Instrument read_s3m_instrument(final byte[] array, final int n, final boolean b) {
        final int get_instrument_offset = get_instrument_offset(array, n);
        final Instrument instrument = new Instrument();
        instrument.name = ascii_text(array, get_instrument_offset + 48, 28);
        final Sample sample = new Sample();
        if (array[get_instrument_offset] == 1) {
            final int get_sample_data_length = get_sample_data_length(array, get_instrument_offset);
            final int unsigned_short_le = unsigned_short_le(array, get_instrument_offset + 20);
            int n2 = unsigned_short_le(array, get_instrument_offset + 24) - unsigned_short_le;
            sample.volume = (array[get_instrument_offset + 28] & 0xFF);
            if (array[get_instrument_offset + 30] != 0) {
                throw new IllegalArgumentException("ScreamTracker3: Packed samples not supported!");
            }
            if ((array[get_instrument_offset + 31] & 0x1) == 0x0) {
                n2 = 0;
            }
            sample.c2_rate = unsigned_short_le(array, get_instrument_offset + 32);
            final short[] array2 = new short[get_sample_data_length];
            final int get_sample_data_offset = get_sample_data_offset(array, get_instrument_offset);
            if (b) {
                for (int i = 0; i < get_sample_data_length; ++i) {
                    array2[i] = (short)(array[get_sample_data_offset + i] << 8 << 8);
                }
            }
            else {
                for (int j = 0; j < get_sample_data_length; ++j) {
                    array2[j] = (short)((array[get_sample_data_offset + j] & 0xFF) - 128 << 8);
                }
            }
            sample.set_sample_data(array2, unsigned_short_le, n2, false);
        }
        instrument.set_num_samples(1);
        instrument.set_sample(0, sample);
        return instrument;
    }
    
    public static Pattern read_s3m_pattern(final byte[] array, final int n, final int[] array2) {
        int n2 = 0;
        for (int i = 0; i < 32; ++i) {
            if (array2[i] >= n2) {
                n2 = i + 1;
            }
        }
        final byte[] array3 = new byte[n2 * 64 * 5];
        int j = 0;
        int n3 = get_pattern_offset(array, n) + 2;
        while (j < 64) {
            final int n4 = array[n3] & 0xFF;
            ++n3;
            if (n4 > 0) {
                final int n5 = array2[n4 & 0x1F];
                final int n6 = (n2 * j + n5) * 5;
                if ((n4 & 0x20) == 0x20) {
                    if (n5 >= 0) {
                        final int n7 = array[n3] & 0xFF;
                        int k;
                        if (n7 == 255) {
                            k = 0;
                        }
                        else if (n7 == 254) {
                            k = 97;
                        }
                        else {
                            for (k = ((n7 & 0xF0) >> 4) * 12 + (n7 & 0xF) + 1; k > 96; k -= 12) {}
                        }
                        array3[n6] = (byte)k;
                        array3[n6 + 1] = array[n3 + 1];
                    }
                    n3 += 2;
                }
                if ((n4 & 0x40) == 0x40) {
                    if (n5 >= 0) {
                        array3[n6 + 2] = (byte)((array[n3] & 0xFF) + 16);
                    }
                    ++n3;
                }
                if ((n4 & 0x80) != 0x80) {
                    continue;
                }
                if (n5 >= 0) {
                    final int n8 = array[n3] & 0xFF;
                    int n9 = array[n3 + 1] & 0xFF;
                    int n10 = ScreamTracker3.effect_map[n8 & 0x1F];
                    if (n10 == 255) {
                        n10 = 0;
                        n9 = 0;
                    }
                    if (n10 == 14) {
                        final int n11 = ScreamTracker3.effect_s_map[(n9 & 0xF0) >> 4];
                        n9 &= 0xF;
                        switch (n11) {
                            case 8: {
                                n10 = 8;
                                n9 <<= 4;
                                break;
                            }
                            case 9: {
                                n10 = 8;
                                if (n9 > 7) {
                                    n9 -= 8;
                                    break;
                                }
                                n9 += 8;
                                break;
                            }
                            case 255: {
                                n10 = 0;
                                n9 = 0;
                                break;
                            }
                            default: {
                                n9 = ((n11 & 0xF) << 4 | (n9 & 0xF));
                                n10 = 14;
                                break;
                            }
                        }
                    }
                    array3[n6 + 3] = (byte)n10;
                    array3[n6 + 4] = (byte)n9;
                }
                n3 += 2;
            }
            else {
                ++j;
            }
        }
        final Pattern pattern = new Pattern();
        pattern.num_rows = 64;
        pattern.set_pattern_data(array3);
        return pattern;
    }
    
    public static byte[] read_s3m_file(final byte[] array, final DataInput dataInput) throws IOException {
        if (!is_s3m(array)) {
            throw new IllegalArgumentException("ScreamTracker3: Not an S3M file!");
        }
        final int length = array.length;
        final int get_num_pattern_orders = get_num_pattern_orders(array);
        final int get_num_instruments = get_num_instruments(array);
        final int get_num_patterns = get_num_patterns(array);
        int n = length + get_num_pattern_orders + get_num_instruments * 2 + get_num_patterns * 2;
        final byte[] read_more = read_more(array, n, dataInput);
        for (int i = 0; i < get_num_instruments; ++i) {
            int get_instrument_offset = get_instrument_offset(read_more, i);
            get_instrument_offset += 80;
            if (get_instrument_offset > n) {
                n = get_instrument_offset;
            }
        }
        for (int j = 0; j < get_num_patterns; ++j) {
            int get_pattern_offset = get_pattern_offset(read_more, j);
            get_pattern_offset += 2;
            if (get_pattern_offset > n) {
                n = get_pattern_offset;
            }
        }
        final byte[] read_more2 = read_more(read_more, n, dataInput);
        for (int k = 0; k < get_num_instruments; ++k) {
            final int get_instrument_offset2 = get_instrument_offset(read_more2, k);
            final int n2 = get_sample_data_offset(read_more2, get_instrument_offset2) + get_sample_data_length(read_more2, get_instrument_offset2);
            if (n2 > n) {
                n = n2;
            }
        }
        for (int l = 0; l < get_num_patterns; ++l) {
            final int get_pattern_offset2 = get_pattern_offset(read_more2, l);
            int n3 = get_pattern_offset2 + get_pattern_length(read_more2, get_pattern_offset2);
            n3 += 2;
            if (n3 > n) {
                n = n3;
            }
        }
        return read_more(read_more2, n, dataInput);
    }
    
    public static int get_num_pattern_orders(final byte[] array) {
        return unsigned_short_le(array, 32);
    }
    
    public static int get_num_instruments(final byte[] array) {
        return unsigned_short_le(array, 34);
    }
    
    public static int get_num_patterns(final byte[] array) {
        return unsigned_short_le(array, 36);
    }
    
    public static int get_instrument_offset(final byte[] array, final int n) {
        return unsigned_short_le(array, 96 + get_num_pattern_orders(array) + n * 2) << 4;
    }
    
    public static int get_sample_data_offset(final byte[] array, final int n) {
        int n2 = 0;
        if (array[n] == 1) {
            n2 = ((array[n + 13] & 0xFF) << 20 | unsigned_short_le(array, n + 14) << 4);
        }
        return n2;
    }
    
    public static int get_sample_data_length(final byte[] array, final int n) {
        int unsigned_short_le = 0;
        if (array[n] == 1) {
            unsigned_short_le = unsigned_short_le(array, n + 16);
        }
        return unsigned_short_le;
    }
    
    public static int get_pattern_offset(final byte[] array, final int n) {
        return unsigned_short_le(array, 96 + get_num_pattern_orders(array) + get_num_instruments(array) * 2 + n * 2) << 4;
    }
    
    public static int get_pattern_length(final byte[] array, final int n) {
        return unsigned_short_le(array, n);
    }
    
    public static byte[] read_more(final byte[] array, final int n, final DataInput dataInput) throws IOException {
        byte[] array2 = array;
        if (n > array.length) {
            array2 = new byte[n];
            System.arraycopy(array, 0, array2, 0, array.length);
            dataInput.readFully(array2, array.length, array2.length - array.length);
        }
        return array2;
    }
    
    public static int unsigned_short_le(final byte[] array, final int n) {
        return (array[n] & 0xFF) | (array[n + 1] & 0xFF) << 8;
    }
    
    public static String ascii_text(final byte[] array, final int n, final int length) {
        final byte[] bytes = new byte[length];
        for (int i = 0; i < length; ++i) {
            int n2 = array[n + i];
            if (n2 < 32) {
                n2 = 32;
            }
            bytes[i] = (byte)n2;
        }
        return new String(bytes, 0, length, "ISO-8859-1");
    }
    
    static {
        ScreamTracker3.effect_map = new int[] { 255, 37, 11, 13, 10, 2, 1, 3, 4, 29, 0, 6, 5, 255, 255, 9, 255, 27, 7, 14, 15, 36, 16, 255, 255, 255, 255, 255, 255, 255, 255, 255 };
        ScreamTracker3.effect_s_map = new int[] { 0, 3, 5, 4, 7, 255, 255, 255, 8, 255, 9, 6, 12, 13, 14, 15 };
    }
}
