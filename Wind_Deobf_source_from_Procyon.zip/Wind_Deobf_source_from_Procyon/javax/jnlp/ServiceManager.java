// 
// Decompiled by Procyon v0.5.36
// 

package javax.jnlp;

import java.util.HashMap;
import java.util.Map;

public class ServiceManager
{
    public static ServiceManagerStub stub;
    public static Map lookupTable;
    
    public static Object lookup(final String s) throws UnavailableServiceException {
        if (ServiceManager.stub == null) {
            throw new UnavailableServiceException("service stub not set.");
        }
        // monitorenter(lookupTable = ServiceManager.lookupTable)
        Object o = ServiceManager.lookupTable.get(s);
        if (o == null) {
            o = ServiceManager.stub.lookup(s);
            if (o != null) {
                ServiceManager.lookupTable.put(s, o);
            }
        }
        if (o == null) {
            throw new UnavailableServiceException("service not available (stub returned null).");
        }
        // monitorexit(lookupTable)
        return o;
    }
    
    public static String[] getServiceNames() {
        if (ServiceManager.stub == null) {
            return new String[0];
        }
        return ServiceManager.stub.getServiceNames();
    }
    
    public static void setServiceManagerStub(final ServiceManagerStub stub) {
        if (ServiceManager.stub == null) {
            ServiceManager.stub = stub;
        }
    }
    
    static {
        ServiceManager.stub = null;
        ServiceManager.lookupTable = new HashMap();
    }
}
