// 
// Decompiled by Procyon v0.5.36
// 

package javax.jnlp;

public interface ServiceManagerStub
{
    Object lookup(final String p0) throws UnavailableServiceException;
    
    String[] getServiceNames();
}
