// 
// Decompiled by Procyon v0.5.36
// 

package javax.jnlp;

public class UnavailableServiceException extends Exception
{
    public UnavailableServiceException() {
    }
    
    public UnavailableServiceException(final String message) {
        super(message);
    }
}
