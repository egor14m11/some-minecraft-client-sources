// 
// Decompiled by Procyon v0.5.36
// 

package javax.net;

import java.net.InetAddress;
import java.io.IOException;
import java.net.ServerSocket;

public class DefaultServerSocketFactory extends ServerSocketFactory
{
    @Override
    public ServerSocket createServerSocket(final int port) throws IOException {
        return new ServerSocket(port);
    }
    
    @Override
    public ServerSocket createServerSocket(final int port, final int backlog) throws IOException {
        return new ServerSocket(port, backlog);
    }
    
    @Override
    public ServerSocket createServerSocket(final int port, final int backlog, final InetAddress bindAddr) throws IOException {
        return new ServerSocket(port, backlog, bindAddr);
    }
}
