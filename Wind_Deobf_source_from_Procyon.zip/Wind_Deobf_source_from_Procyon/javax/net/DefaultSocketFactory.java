// 
// Decompiled by Procyon v0.5.36
// 

package javax.net;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.io.IOException;
import java.net.Socket;

public class DefaultSocketFactory extends SocketFactory
{
    @Override
    public Socket createSocket(final String host, final int port) throws IOException, UnknownHostException {
        return new Socket(host, port);
    }
    
    @Override
    public Socket createSocket(final String host, final int port, final InetAddress localAddr, final int localPort) throws IOException, UnknownHostException {
        return new Socket(host, port, localAddr, localPort);
    }
    
    @Override
    public Socket createSocket(final InetAddress address, final int port) throws IOException {
        return new Socket(address, port);
    }
    
    @Override
    public Socket createSocket(final InetAddress address, final int port, final InetAddress localAddr, final int localPort) throws IOException {
        return new Socket(address, port, localAddr, localPort);
    }
}
