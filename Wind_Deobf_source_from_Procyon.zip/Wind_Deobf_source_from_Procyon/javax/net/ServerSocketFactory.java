// 
// Decompiled by Procyon v0.5.36
// 

package javax.net;

import java.net.InetAddress;
import java.io.IOException;
import java.net.ServerSocket;

public abstract class ServerSocketFactory
{
    public static ServerSocketFactory theFactory;
    public static Class class$javax$net$ServerSocketFactory;
    
    public static Class class$(final String className) {
        return Class.forName(className);
    }
    
    public abstract ServerSocket createServerSocket(final int p0) throws IOException;
    
    public abstract ServerSocket createServerSocket(final int p0, final int p1) throws IOException;
    
    public abstract ServerSocket createServerSocket(final int p0, final int p1, final InetAddress p2) throws IOException;
    
    public static ServerSocketFactory getDefault() throws Throwable {
        if (ServerSocketFactory.theFactory == null) {
            // monitorenter(clazz = ServerSocketFactory.class$javax$net$ServerSocketFactory != null ? ServerSocketFactory.class$javax$net$ServerSocketFactory : ServerSocketFactory.class$javax$net$ServerSocketFactory = class$("javax.net.ServerSocketFactory"))
            // monitorexit(clazz)
            ServerSocketFactory.theFactory = new DefaultServerSocketFactory();
        }
        return ServerSocketFactory.theFactory;
    }
}
