// 
// Decompiled by Procyon v0.5.36
// 

package javax.net;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.io.IOException;
import java.net.Socket;

public abstract class SocketFactory
{
    public static SocketFactory theFactory;
    public static Class class$javax$net$SocketFactory;
    
    public static Class class$(final String className) {
        return Class.forName(className);
    }
    
    public abstract Socket createSocket(final String p0, final int p1) throws IOException, UnknownHostException;
    
    public abstract Socket createSocket(final String p0, final int p1, final InetAddress p2, final int p3) throws IOException, UnknownHostException;
    
    public abstract Socket createSocket(final InetAddress p0, final int p1) throws IOException;
    
    public abstract Socket createSocket(final InetAddress p0, final int p1, final InetAddress p2, final int p3) throws IOException;
    
    public static SocketFactory getDefault() throws Throwable {
        if (SocketFactory.theFactory == null) {
            // monitorenter(clazz = SocketFactory.class$javax$net$SocketFactory != null ? SocketFactory.class$javax$net$SocketFactory : SocketFactory.class$javax$net$SocketFactory = class$("javax.net.SocketFactory"))
            // monitorexit(clazz)
            SocketFactory.theFactory = new DefaultSocketFactory();
        }
        return SocketFactory.theFactory;
    }
}
