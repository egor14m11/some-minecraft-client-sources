// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import java.net.InetAddress;
import java.io.IOException;
import java.net.SocketException;
import java.net.ServerSocket;

public class DefaultSSLServerSocketFactory extends SSLServerSocketFactory
{
    @Override
    public ServerSocket createServerSocket(final int n) throws IOException {
        throw new SocketException("no SSL Server Sockets");
    }
    
    @Override
    public ServerSocket createServerSocket(final int n, final int n2) throws IOException {
        throw new SocketException("no SSL Server Sockets");
    }
    
    @Override
    public ServerSocket createServerSocket(final int n, final int n2, final InetAddress inetAddress) throws IOException {
        throw new SocketException("no SSL Server Sockets");
    }
    
    @Override
    public String[] getDefaultCipherSuites() {
        return new String[0];
    }
    
    @Override
    public String[] getSupportedCipherSuites() {
        return new String[0];
    }
}
