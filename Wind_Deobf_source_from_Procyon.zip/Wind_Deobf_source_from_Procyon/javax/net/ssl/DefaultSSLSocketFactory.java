// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import java.net.InetAddress;
import java.io.IOException;
import java.net.SocketException;
import java.net.Socket;

public class DefaultSSLSocketFactory extends SSLSocketFactory
{
    @Override
    public Socket createSocket(final String s, final int n) throws IOException {
        throw new SocketException("SSL implementation not available");
    }
    
    @Override
    public Socket createSocket(final String s, final int n, final InetAddress inetAddress, final int n2) throws IOException {
        throw new SocketException("SSL implementation not available");
    }
    
    @Override
    public Socket createSocket(final InetAddress inetAddress, final int n) throws IOException {
        throw new SocketException("SSL implementation not available");
    }
    
    @Override
    public Socket createSocket(final InetAddress inetAddress, final int n, final InetAddress inetAddress2, final int n2) throws IOException {
        throw new SocketException("SSL implementation not available");
    }
    
    @Override
    public Socket createSocket(final Socket socket, final String s, final int n, final boolean b) throws IOException {
        throw new SocketException("SSL implementation not available");
    }
    
    @Override
    public String[] getDefaultCipherSuites() {
        return new String[0];
    }
    
    @Override
    public String[] getSupportedCipherSuites() {
        return new String[0];
    }
}
