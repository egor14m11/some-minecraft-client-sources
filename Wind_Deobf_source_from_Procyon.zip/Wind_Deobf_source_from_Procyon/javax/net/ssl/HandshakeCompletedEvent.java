// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import javax.security.cert.X509Certificate;
import java.util.EventObject;

public class HandshakeCompletedEvent extends EventObject
{
    public transient SSLSession a;
    
    public HandshakeCompletedEvent(final SSLSocket source, final SSLSession a) {
        super(source);
        this.a = a;
    }
    
    public String getCipherSuite() {
        return this.a.getCipherSuite();
    }
    
    public X509Certificate[] getPeerCertificateChain() throws SSLPeerUnverifiedException {
        return this.a.getPeerCertificateChain();
    }
    
    public SSLSession getSession() {
        return this.a;
    }
    
    public SSLSocket getSocket() {
        return (SSLSocket)this.getSource();
    }
}
