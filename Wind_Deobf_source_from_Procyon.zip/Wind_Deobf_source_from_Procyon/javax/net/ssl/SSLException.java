// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import java.io.IOException;

public class SSLException extends IOException
{
    public SSLException(final String message) {
        super(message);
    }
}
