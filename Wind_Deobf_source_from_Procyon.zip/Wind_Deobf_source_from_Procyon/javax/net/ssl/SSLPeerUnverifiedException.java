// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

public class SSLPeerUnverifiedException extends SSLException
{
    public SSLPeerUnverifiedException(final String s) {
        super(s);
    }
}
