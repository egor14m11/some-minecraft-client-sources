// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import java.net.InetAddress;
import java.io.IOException;
import java.net.ServerSocket;

public abstract class SSLServerSocket extends ServerSocket
{
    public SSLServerSocket(final int port) throws IOException {
        super(port);
    }
    
    public SSLServerSocket(final int port, final int backlog) throws IOException {
        super(port, backlog);
    }
    
    public SSLServerSocket(final int port, final int backlog, final InetAddress bindAddr) throws IOException {
        super(port, backlog, bindAddr);
    }
    
    public abstract boolean getEnableSessionCreation();
    
    public abstract String[] getEnabledCipherSuites();
    
    public abstract boolean getNeedClientAuth();
    
    public abstract String[] getSupportedCipherSuites();
    
    public abstract boolean getUseClientMode();
    
    public abstract void setEnableSessionCreation(final boolean p0);
    
    public abstract void setEnabledCipherSuites(final String[] p0);
    
    public abstract void setNeedClientAuth(final boolean p0);
    
    public abstract void setUseClientMode(final boolean p0);
}
