// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import java.security.AccessController;
import java.security.Security;
import java.security.PrivilegedAction;
import javax.net.ServerSocketFactory;

public abstract class SSLServerSocketFactory extends ServerSocketFactory
{
    public static SSLServerSocketFactory a;
    public static Class b;
    
    public static Class class$(final String className) {
        return Class.forName(className);
    }
    
    public static synchronized ServerSocketFactory getDefault() {
        if (SSLServerSocketFactory.a == null) {
            final Class<?> forName = Class.forName(a());
            if (forName != ((SSLServerSocketFactory.b != null) ? SSLServerSocketFactory.b : (SSLServerSocketFactory.b = class$("com.sun.net.ssl.internal.ssl.SSLServerSocketFactoryImpl")))) {
                SSLServerSocketFactory.a = new DefaultSSLServerSocketFactory();
            }
            else {
                SSLServerSocketFactory.a = (SSLServerSocketFactory)forName.newInstance();
            }
        }
        return SSLServerSocketFactory.a;
    }
    
    public abstract String[] getDefaultCipherSuites();
    
    public static String a() {
        String s = AccessController.doPrivileged((PrivilegedAction<String>)new PrivilegedAction() {
            @Override
            public Object run() {
                return Security.getProperty("ssl.ServerSocketFactory.provider");
            }
        });
        if (s == null) {
            s = "com.sun.net.ssl.internal.ssl.SSLServerSocketFactoryImpl";
        }
        return s;
    }
    
    public abstract String[] getSupportedCipherSuites();
}
