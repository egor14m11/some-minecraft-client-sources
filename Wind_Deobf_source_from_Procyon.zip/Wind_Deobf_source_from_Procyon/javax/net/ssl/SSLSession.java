// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import javax.security.cert.X509Certificate;

public interface SSLSession
{
    String getCipherSuite();
    
    long getCreationTime();
    
    byte[] getId();
    
    long getLastAccessedTime();
    
    X509Certificate[] getPeerCertificateChain() throws SSLPeerUnverifiedException;
    
    String getPeerHost();
    
    SSLSessionContext getSessionContext();
    
    Object getValue(final String p0);
    
    String[] getValueNames();
    
    void invalidate();
    
    void putValue(final String p0, final Object p1);
    
    void removeValue(final String p0);
}
