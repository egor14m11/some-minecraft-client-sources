// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import java.util.EventObject;

public class SSLSessionBindingEvent extends EventObject
{
    public String a;
    
    public SSLSessionBindingEvent(final SSLSession source, final String a) {
        super(source);
        this.a = a;
    }
    
    public String getName() {
        return this.a;
    }
    
    public SSLSession getSession() {
        return (SSLSession)this.getSource();
    }
}
