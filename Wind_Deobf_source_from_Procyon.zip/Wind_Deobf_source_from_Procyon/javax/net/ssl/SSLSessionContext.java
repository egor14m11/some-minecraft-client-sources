// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import java.util.Enumeration;

public interface SSLSessionContext
{
    Enumeration getIds();
    
    SSLSession getSession(final byte[] p0);
}
