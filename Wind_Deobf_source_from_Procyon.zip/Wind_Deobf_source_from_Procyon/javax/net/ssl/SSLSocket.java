// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.io.IOException;
import java.net.Socket;

public abstract class SSLSocket extends Socket
{
    public SSLSocket() {
    }
    
    public SSLSocket(final String host, final int port) throws IOException, UnknownHostException {
        super(host, port);
    }
    
    public SSLSocket(final String host, final int port, final InetAddress localAddr, final int localPort) throws IOException, UnknownHostException {
        super(host, port, localAddr, localPort);
    }
    
    public SSLSocket(final InetAddress address, final int port) throws IOException, UnknownHostException {
        super(address, port);
    }
    
    public SSLSocket(final InetAddress address, final int port, final InetAddress localAddr, final int localPort) throws IOException, UnknownHostException {
        super(address, port, localAddr, localPort);
    }
    
    public abstract void addHandshakeCompletedListener(final HandshakeCompletedListener p0);
    
    public abstract boolean getEnableSessionCreation();
    
    public abstract String[] getEnabledCipherSuites();
    
    public abstract boolean getNeedClientAuth();
    
    public abstract SSLSession getSession();
    
    public abstract String[] getSupportedCipherSuites();
    
    public abstract boolean getUseClientMode();
    
    public abstract void removeHandshakeCompletedListener(final HandshakeCompletedListener p0);
    
    public abstract void setEnableSessionCreation(final boolean p0);
    
    public abstract void setEnabledCipherSuites(final String[] p0);
    
    public abstract void setNeedClientAuth(final boolean p0);
    
    public abstract void setUseClientMode(final boolean p0);
    
    public abstract void startHandshake() throws IOException;
}
