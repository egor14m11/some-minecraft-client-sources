// 
// Decompiled by Procyon v0.5.36
// 

package javax.net.ssl;

import java.security.AccessController;
import java.security.Security;
import java.security.PrivilegedAction;
import java.io.IOException;
import java.net.Socket;
import javax.net.SocketFactory;

public abstract class SSLSocketFactory extends SocketFactory
{
    public static SSLSocketFactory a;
    public static Class b;
    
    public static Class class$(final String className) {
        return Class.forName(className);
    }
    
    public abstract Socket createSocket(final Socket p0, final String p1, final int p2, final boolean p3) throws IOException;
    
    public static synchronized SocketFactory getDefault() {
        if (SSLSocketFactory.a == null) {
            final Class<?> forName = Class.forName(a());
            if (forName != ((SSLSocketFactory.b != null) ? SSLSocketFactory.b : (SSLSocketFactory.b = class$("com.sun.net.ssl.internal.ssl.SSLSocketFactoryImpl")))) {
                SSLSocketFactory.a = new DefaultSSLSocketFactory();
            }
            else {
                SSLSocketFactory.a = (SSLSocketFactory)forName.newInstance();
            }
        }
        return SSLSocketFactory.a;
    }
    
    public abstract String[] getDefaultCipherSuites();
    
    public static String a() {
        String s = AccessController.doPrivileged((PrivilegedAction<String>)new PrivilegedAction() {
            @Override
            public Object run() {
                return Security.getProperty("ssl.SocketFactory.provider");
            }
        });
        if (s == null) {
            s = "com.sun.net.ssl.internal.ssl.SSLSocketFactoryImpl";
        }
        return s;
    }
    
    public abstract String[] getSupportedCipherSuites();
}
