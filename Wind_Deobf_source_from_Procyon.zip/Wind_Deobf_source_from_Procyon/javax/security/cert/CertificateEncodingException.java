// 
// Decompiled by Procyon v0.5.36
// 

package javax.security.cert;

public class CertificateEncodingException extends CertificateException
{
    public CertificateEncodingException() {
    }
    
    public CertificateEncodingException(final String s) {
        super(s);
    }
}
