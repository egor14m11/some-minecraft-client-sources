// 
// Decompiled by Procyon v0.5.36
// 

package javax.security.cert;

public class CertificateExpiredException extends CertificateException
{
    public CertificateExpiredException() {
    }
    
    public CertificateExpiredException(final String s) {
        super(s);
    }
}
