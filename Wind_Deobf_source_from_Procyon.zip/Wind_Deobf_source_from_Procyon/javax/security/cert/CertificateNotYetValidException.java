// 
// Decompiled by Procyon v0.5.36
// 

package javax.security.cert;

public class CertificateNotYetValidException extends CertificateException
{
    public CertificateNotYetValidException() {
    }
    
    public CertificateNotYetValidException(final String s) {
        super(s);
    }
}
