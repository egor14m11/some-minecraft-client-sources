// 
// Decompiled by Procyon v0.5.36
// 

package javax.security.cert;

public class CertificateParsingException extends CertificateException
{
    public CertificateParsingException() {
    }
    
    public CertificateParsingException(final String s) {
        super(s);
    }
}
