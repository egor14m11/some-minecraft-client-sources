// 
// Decompiled by Procyon v0.5.36
// 

package javax.security.cert;

import java.security.Security;
import java.math.BigInteger;
import java.security.Principal;
import java.io.InputStream;
import java.util.Date;

public abstract class X509Certificate extends Certificate
{
    public static String X509_PROVIDER;
    public static String X509Provider;
    public static Class class$java$io$InputStream;
    
    public abstract void checkValidity() throws CertificateExpiredException, CertificateNotYetValidException;
    
    public abstract void checkValidity(final Date p0) throws CertificateExpiredException, CertificateNotYetValidException;
    
    public static Class class$(final String className) {
        return Class.forName(className);
    }
    
    public static X509Certificate getInst(final Object o) throws CertificateException {
        String x509Provider = X509Certificate.X509Provider;
        if (x509Provider == null) {
            x509Provider = "com.sun.security.cert.internal.x509.X509V1CertImpl";
        }
        Class[] parameterTypes;
        if (o instanceof InputStream) {
            parameterTypes = new Class[] { (X509Certificate.class$java$io$InputStream != null) ? X509Certificate.class$java$io$InputStream : (X509Certificate.class$java$io$InputStream = class$("java.io.InputStream")) };
        }
        else {
            if (!(o instanceof byte[])) {
                throw new CertificateException("Unsupported argument type");
            }
            parameterTypes = new Class[] { o.getClass() };
        }
        return (X509Certificate)Class.forName(x509Provider).getConstructor((Class<?>[])parameterTypes).newInstance(o);
    }
    
    public static X509Certificate getInstance(final InputStream inputStream) throws CertificateException {
        return getInst(inputStream);
    }
    
    public static X509Certificate getInstance(final byte[] array) throws CertificateException {
        return getInst(array);
    }
    
    public abstract Principal getIssuerDN();
    
    public abstract Date getNotAfter();
    
    public abstract Date getNotBefore();
    
    public abstract BigInteger getSerialNumber();
    
    public abstract String getSigAlgName();
    
    public abstract String getSigAlgOID();
    
    public abstract byte[] getSigAlgParams();
    
    public abstract Principal getSubjectDN();
    
    public abstract int getVersion();
    
    static {
        X509Certificate.X509_PROVIDER = "cert.provider.x509v1";
        X509Certificate.X509Provider = null;
        X509Certificate.X509Provider = Security.getProperty("cert.provider.x509v1");
    }
}
