// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

public class MismatchedSizeException extends RuntimeException
{
    public MismatchedSizeException() {
    }
    
    public MismatchedSizeException(final String message) {
        super(message);
    }
}
