// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

import java.io.Serializable;

public class Point3d extends Tuple3d implements Serializable
{
    public static long serialVersionUID;
    
    public Point3d(final double n, final double n2, final double n3) {
        super(n, n2, n3);
    }
    
    public Point3d(final double[] array) {
        super(array);
    }
    
    public Point3d(final Point3d point3d) {
        super(point3d);
    }
    
    public Point3d(final Point3f point3f) {
        super(point3f);
    }
    
    public Point3d(final Tuple3f tuple3f) {
        super(tuple3f);
    }
    
    public Point3d(final Tuple3d tuple3d) {
        super(tuple3d);
    }
    
    public Point3d() {
    }
    
    public double distanceSquared(final Point3d point3d) {
        final double n = this.x - point3d.x;
        final double n2 = this.y - point3d.y;
        final double n3 = this.z - point3d.z;
        return n * n + n2 * n2 + n3 * n3;
    }
    
    public double distance(final Point3d point3d) {
        final double n = this.x - point3d.x;
        final double n2 = this.y - point3d.y;
        final double n3 = this.z - point3d.z;
        return Math.sqrt(n * n + n2 * n2 + n3 * n3);
    }
    
    public double distanceL1(final Point3d point3d) {
        return Math.abs(this.x - point3d.x) + Math.abs(this.y - point3d.y) + Math.abs(this.z - point3d.z);
    }
    
    public double distanceLinf(final Point3d point3d) {
        return Math.max(Math.max(Math.abs(this.x - point3d.x), Math.abs(this.y - point3d.y)), Math.abs(this.z - point3d.z));
    }
    
    public void project(final Point4d point4d) {
        final double n = 1.0 / point4d.w;
        this.x = point4d.x * n;
        this.y = point4d.y * n;
        this.z = point4d.z * n;
    }
    
    static {
        Point3d.serialVersionUID = ((long)1251575087 ^ 0x4F5AA35ACE2D8BC0L);
    }
}
