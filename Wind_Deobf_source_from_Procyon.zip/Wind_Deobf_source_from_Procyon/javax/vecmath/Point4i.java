// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

import java.io.Serializable;

public class Point4i extends Tuple4i implements Serializable
{
    public static long serialVersionUID;
    
    public Point4i(final int n, final int n2, final int n3, final int n4) {
        super(n, n2, n3, n4);
    }
    
    public Point4i(final int[] array) {
        super(array);
    }
    
    public Point4i(final Tuple4i tuple4i) {
        super(tuple4i);
    }
    
    public Point4i() {
    }
    
    static {
        Point4i.serialVersionUID = ((long)1109762478 ^ 0x89B2033F8C06B51L);
    }
}
