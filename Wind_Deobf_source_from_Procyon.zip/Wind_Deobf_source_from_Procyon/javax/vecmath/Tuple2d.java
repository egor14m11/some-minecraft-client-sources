// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

import java.io.Serializable;

public abstract class Tuple2d implements Serializable, Cloneable
{
    public static long serialVersionUID;
    public double x;
    public double y;
    
    public Tuple2d(final double x, final double y) {
        this.x = x;
        this.y = y;
    }
    
    public Tuple2d(final double[] array) {
        this.x = array[0];
        this.y = array[1];
    }
    
    public Tuple2d(final Tuple2d tuple2d) {
        this.x = tuple2d.x;
        this.y = tuple2d.y;
    }
    
    public Tuple2d(final Tuple2f tuple2f) {
        this.x = tuple2f.x;
        this.y = tuple2f.y;
    }
    
    public Tuple2d() {
        this.x = 0.0;
        this.y = 0.0;
    }
    
    public void set(final double x, final double y) {
        this.x = x;
        this.y = y;
    }
    
    public void set(final double[] array) {
        this.x = array[0];
        this.y = array[1];
    }
    
    public void set(final Tuple2d tuple2d) {
        this.x = tuple2d.x;
        this.y = tuple2d.y;
    }
    
    public void set(final Tuple2f tuple2f) {
        this.x = tuple2f.x;
        this.y = tuple2f.y;
    }
    
    public void get(final double[] array) {
        array[0] = this.x;
        array[1] = this.y;
    }
    
    public void add(final Tuple2d tuple2d, final Tuple2d tuple2d2) {
        this.x = tuple2d.x + tuple2d2.x;
        this.y = tuple2d.y + tuple2d2.y;
    }
    
    public void add(final Tuple2d tuple2d) {
        this.x += tuple2d.x;
        this.y += tuple2d.y;
    }
    
    public void sub(final Tuple2d tuple2d, final Tuple2d tuple2d2) {
        this.x = tuple2d.x - tuple2d2.x;
        this.y = tuple2d.y - tuple2d2.y;
    }
    
    public void sub(final Tuple2d tuple2d) {
        this.x -= tuple2d.x;
        this.y -= tuple2d.y;
    }
    
    public void negate(final Tuple2d tuple2d) {
        this.x = -tuple2d.x;
        this.y = -tuple2d.y;
    }
    
    public void negate() {
        this.x = -this.x;
        this.y = -this.y;
    }
    
    public void scale(final double n, final Tuple2d tuple2d) {
        this.x = n * tuple2d.x;
        this.y = n * tuple2d.y;
    }
    
    public void scale(final double n) {
        this.x *= n;
        this.y *= n;
    }
    
    public void scaleAdd(final double n, final Tuple2d tuple2d, final Tuple2d tuple2d2) {
        this.x = n * tuple2d.x + tuple2d2.x;
        this.y = n * tuple2d.y + tuple2d2.y;
    }
    
    public void scaleAdd(final double n, final Tuple2d tuple2d) {
        this.x = n * this.x + tuple2d.x;
        this.y = n * this.y + tuple2d.y;
    }
    
    @Override
    public int hashCode() {
        return VecMathUtil.hashFinish(VecMathUtil.hashDoubleBits(VecMathUtil.hashDoubleBits((long)303066886 ^ 0x12106F07L, this.x), this.y));
    }
    
    public boolean equals(final Tuple2d tuple2d) {
        return this.x == tuple2d.x && this.y == tuple2d.y;
    }
    
    @Override
    public boolean equals(final Object o) {
        final Tuple2d tuple2d = (Tuple2d)o;
        return this.x == tuple2d.x && this.y == tuple2d.y;
    }
    
    public boolean epsilonEquals(final Tuple2d tuple2d, final double n) {
        final double v = this.x - tuple2d.x;
        if (Double.isNaN(v)) {
            return false;
        }
        if (((v < 0.0) ? (-v) : v) > n) {
            return false;
        }
        final double v2 = this.y - tuple2d.y;
        return !Double.isNaN(v2) && ((v2 < 0.0) ? (-v2) : v2) <= n;
    }
    
    @Override
    public String toString() {
        return "(" + this.x + ", " + this.y + ")";
    }
    
    public void clamp(final double n, final double n2, final Tuple2d tuple2d) {
        if (tuple2d.x > n2) {
            this.x = n2;
        }
        else if (tuple2d.x < n) {
            this.x = n;
        }
        else {
            this.x = tuple2d.x;
        }
        if (tuple2d.y > n2) {
            this.y = n2;
        }
        else if (tuple2d.y < n) {
            this.y = n;
        }
        else {
            this.y = tuple2d.y;
        }
    }
    
    public void clampMin(final double n, final Tuple2d tuple2d) {
        if (tuple2d.x < n) {
            this.x = n;
        }
        else {
            this.x = tuple2d.x;
        }
        if (tuple2d.y < n) {
            this.y = n;
        }
        else {
            this.y = tuple2d.y;
        }
    }
    
    public void clampMax(final double n, final Tuple2d tuple2d) {
        if (tuple2d.x > n) {
            this.x = n;
        }
        else {
            this.x = tuple2d.x;
        }
        if (tuple2d.y > n) {
            this.y = n;
        }
        else {
            this.y = tuple2d.y;
        }
    }
    
    public void absolute(final Tuple2d tuple2d) {
        this.x = Math.abs(tuple2d.x);
        this.y = Math.abs(tuple2d.y);
    }
    
    public void clamp(final double n, final double n2) {
        if (this.x > n2) {
            this.x = n2;
        }
        else if (this.x < n) {
            this.x = n;
        }
        if (this.y > n2) {
            this.y = n2;
        }
        else if (this.y < n) {
            this.y = n;
        }
    }
    
    public void clampMin(final double n) {
        if (this.x < n) {
            this.x = n;
        }
        if (this.y < n) {
            this.y = n;
        }
    }
    
    public void clampMax(final double n) {
        if (this.x > n) {
            this.x = n;
        }
        if (this.y > n) {
            this.y = n;
        }
    }
    
    public void absolute() {
        this.x = Math.abs(this.x);
        this.y = Math.abs(this.y);
    }
    
    public void interpolate(final Tuple2d tuple2d, final Tuple2d tuple2d2, final double n) {
        this.x = (1.0 - n) * tuple2d.x + n * tuple2d2.x;
        this.y = (1.0 - n) * tuple2d.y + n * tuple2d2.y;
    }
    
    public void interpolate(final Tuple2d tuple2d, final double n) {
        this.x = (1.0 - n) * this.x + n * tuple2d.x;
        this.y = (1.0 - n) * this.y + n * tuple2d.y;
    }
    
    public Object clone() {
        return super.clone();
    }
    
    public double getX() {
        return this.x;
    }
    
    public void setX(final double x) {
        this.x = x;
    }
    
    public double getY() {
        return this.y;
    }
    
    public void setY(final double y) {
        this.y = y;
    }
    
    static {
        Tuple2d.serialVersionUID = ((long)(-166734538) ^ 0xA9E0B3E6CF1052B8L);
    }
}
