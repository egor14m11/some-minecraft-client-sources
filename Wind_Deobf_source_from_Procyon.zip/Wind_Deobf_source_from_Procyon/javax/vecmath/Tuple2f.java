// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

import java.io.Serializable;

public abstract class Tuple2f implements Serializable, Cloneable
{
    public static long serialVersionUID;
    public float x;
    public float y;
    
    public Tuple2f(final float x, final float y) {
        this.x = x;
        this.y = y;
    }
    
    public Tuple2f(final float[] array) {
        this.x = array[0];
        this.y = array[1];
    }
    
    public Tuple2f(final Tuple2f tuple2f) {
        this.x = tuple2f.x;
        this.y = tuple2f.y;
    }
    
    public Tuple2f(final Tuple2d tuple2d) {
        this.x = (float)tuple2d.x;
        this.y = (float)tuple2d.y;
    }
    
    public Tuple2f() {
        this.x = 0.0f;
        this.y = 0.0f;
    }
    
    public void set(final float x, final float y) {
        this.x = x;
        this.y = y;
    }
    
    public void set(final float[] array) {
        this.x = array[0];
        this.y = array[1];
    }
    
    public void set(final Tuple2f tuple2f) {
        this.x = tuple2f.x;
        this.y = tuple2f.y;
    }
    
    public void set(final Tuple2d tuple2d) {
        this.x = (float)tuple2d.x;
        this.y = (float)tuple2d.y;
    }
    
    public void get(final float[] array) {
        array[0] = this.x;
        array[1] = this.y;
    }
    
    public void add(final Tuple2f tuple2f, final Tuple2f tuple2f2) {
        this.x = tuple2f.x + tuple2f2.x;
        this.y = tuple2f.y + tuple2f2.y;
    }
    
    public void add(final Tuple2f tuple2f) {
        this.x += tuple2f.x;
        this.y += tuple2f.y;
    }
    
    public void sub(final Tuple2f tuple2f, final Tuple2f tuple2f2) {
        this.x = tuple2f.x - tuple2f2.x;
        this.y = tuple2f.y - tuple2f2.y;
    }
    
    public void sub(final Tuple2f tuple2f) {
        this.x -= tuple2f.x;
        this.y -= tuple2f.y;
    }
    
    public void negate(final Tuple2f tuple2f) {
        this.x = -tuple2f.x;
        this.y = -tuple2f.y;
    }
    
    public void negate() {
        this.x = -this.x;
        this.y = -this.y;
    }
    
    public void scale(final float n, final Tuple2f tuple2f) {
        this.x = n * tuple2f.x;
        this.y = n * tuple2f.y;
    }
    
    public void scale(final float n) {
        this.x *= n;
        this.y *= n;
    }
    
    public void scaleAdd(final float n, final Tuple2f tuple2f, final Tuple2f tuple2f2) {
        this.x = n * tuple2f.x + tuple2f2.x;
        this.y = n * tuple2f.y + tuple2f2.y;
    }
    
    public void scaleAdd(final float n, final Tuple2f tuple2f) {
        this.x = n * this.x + tuple2f.x;
        this.y = n * this.y + tuple2f.y;
    }
    
    @Override
    public int hashCode() {
        return VecMathUtil.hashFinish(VecMathUtil.hashFloatBits(VecMathUtil.hashFloatBits((long)(-1741506980) ^ 0xFFFFFFFF9832B65DL, this.x), this.y));
    }
    
    public boolean equals(final Tuple2f tuple2f) {
        return this.x == tuple2f.x && this.y == tuple2f.y;
    }
    
    @Override
    public boolean equals(final Object o) {
        final Tuple2f tuple2f = (Tuple2f)o;
        return this.x == tuple2f.x && this.y == tuple2f.y;
    }
    
    public boolean epsilonEquals(final Tuple2f tuple2f, final float n) {
        final float v = this.x - tuple2f.x;
        if (Float.isNaN(v)) {
            return false;
        }
        if (((v < 0.0f) ? (-v) : v) > n) {
            return false;
        }
        final float v2 = this.y - tuple2f.y;
        return !Float.isNaN(v2) && ((v2 < 0.0f) ? (-v2) : v2) <= n;
    }
    
    @Override
    public String toString() {
        return "(" + this.x + ", " + this.y + ")";
    }
    
    public void clamp(final float n, final float n2, final Tuple2f tuple2f) {
        if (tuple2f.x > n2) {
            this.x = n2;
        }
        else if (tuple2f.x < n) {
            this.x = n;
        }
        else {
            this.x = tuple2f.x;
        }
        if (tuple2f.y > n2) {
            this.y = n2;
        }
        else if (tuple2f.y < n) {
            this.y = n;
        }
        else {
            this.y = tuple2f.y;
        }
    }
    
    public void clampMin(final float n, final Tuple2f tuple2f) {
        if (tuple2f.x < n) {
            this.x = n;
        }
        else {
            this.x = tuple2f.x;
        }
        if (tuple2f.y < n) {
            this.y = n;
        }
        else {
            this.y = tuple2f.y;
        }
    }
    
    public void clampMax(final float n, final Tuple2f tuple2f) {
        if (tuple2f.x > n) {
            this.x = n;
        }
        else {
            this.x = tuple2f.x;
        }
        if (tuple2f.y > n) {
            this.y = n;
        }
        else {
            this.y = tuple2f.y;
        }
    }
    
    public void absolute(final Tuple2f tuple2f) {
        this.x = Math.abs(tuple2f.x);
        this.y = Math.abs(tuple2f.y);
    }
    
    public void clamp(final float n, final float n2) {
        if (this.x > n2) {
            this.x = n2;
        }
        else if (this.x < n) {
            this.x = n;
        }
        if (this.y > n2) {
            this.y = n2;
        }
        else if (this.y < n) {
            this.y = n;
        }
    }
    
    public void clampMin(final float n) {
        if (this.x < n) {
            this.x = n;
        }
        if (this.y < n) {
            this.y = n;
        }
    }
    
    public void clampMax(final float n) {
        if (this.x > n) {
            this.x = n;
        }
        if (this.y > n) {
            this.y = n;
        }
    }
    
    public void absolute() {
        this.x = Math.abs(this.x);
        this.y = Math.abs(this.y);
    }
    
    public void interpolate(final Tuple2f tuple2f, final Tuple2f tuple2f2, final float n) {
        this.x = (1.0f - n) * tuple2f.x + n * tuple2f2.x;
        this.y = (1.0f - n) * tuple2f.y + n * tuple2f2.y;
    }
    
    public void interpolate(final Tuple2f tuple2f, final float n) {
        this.x = (1.0f - n) * this.x + n * tuple2f.x;
        this.y = (1.0f - n) * this.y + n * tuple2f.y;
    }
    
    public Object clone() {
        return super.clone();
    }
    
    public float getX() {
        return this.x;
    }
    
    public void setX(final float x) {
        this.x = x;
    }
    
    public float getY() {
        return this.y;
    }
    
    public void setY(final float y) {
        this.y = y;
    }
    
    static {
        Tuple2f.serialVersionUID = ((long)2074163961 ^ 0x7D0E24D277CFD83DL);
    }
}
