// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

import java.io.Serializable;

public abstract class Tuple2i implements Serializable, Cloneable
{
    public static long serialVersionUID;
    public int x;
    public int y;
    
    public Tuple2i(final int x, final int y) {
        this.x = x;
        this.y = y;
    }
    
    public Tuple2i(final int[] array) {
        this.x = array[0];
        this.y = array[1];
    }
    
    public Tuple2i(final Tuple2i tuple2i) {
        this.x = tuple2i.x;
        this.y = tuple2i.y;
    }
    
    public Tuple2i() {
        this.x = 0;
        this.y = 0;
    }
    
    public void set(final int x, final int y) {
        this.x = x;
        this.y = y;
    }
    
    public void set(final int[] array) {
        this.x = array[0];
        this.y = array[1];
    }
    
    public void set(final Tuple2i tuple2i) {
        this.x = tuple2i.x;
        this.y = tuple2i.y;
    }
    
    public void get(final int[] array) {
        array[0] = this.x;
        array[1] = this.y;
    }
    
    public void get(final Tuple2i tuple2i) {
        tuple2i.x = this.x;
        tuple2i.y = this.y;
    }
    
    public void add(final Tuple2i tuple2i, final Tuple2i tuple2i2) {
        this.x = tuple2i.x + tuple2i2.x;
        this.y = tuple2i.y + tuple2i2.y;
    }
    
    public void add(final Tuple2i tuple2i) {
        this.x += tuple2i.x;
        this.y += tuple2i.y;
    }
    
    public void sub(final Tuple2i tuple2i, final Tuple2i tuple2i2) {
        this.x = tuple2i.x - tuple2i2.x;
        this.y = tuple2i.y - tuple2i2.y;
    }
    
    public void sub(final Tuple2i tuple2i) {
        this.x -= tuple2i.x;
        this.y -= tuple2i.y;
    }
    
    public void negate(final Tuple2i tuple2i) {
        this.x = -tuple2i.x;
        this.y = -tuple2i.y;
    }
    
    public void negate() {
        this.x = -this.x;
        this.y = -this.y;
    }
    
    public void scale(final int n, final Tuple2i tuple2i) {
        this.x = n * tuple2i.x;
        this.y = n * tuple2i.y;
    }
    
    public void scale(final int n) {
        this.x *= n;
        this.y *= n;
    }
    
    public void scaleAdd(final int n, final Tuple2i tuple2i, final Tuple2i tuple2i2) {
        this.x = n * tuple2i.x + tuple2i2.x;
        this.y = n * tuple2i.y + tuple2i2.y;
    }
    
    public void scaleAdd(final int n, final Tuple2i tuple2i) {
        this.x = n * this.x + tuple2i.x;
        this.y = n * this.y + tuple2i.y;
    }
    
    @Override
    public String toString() {
        return "(" + this.x + ", " + this.y + ")";
    }
    
    @Override
    public boolean equals(final Object o) {
        final Tuple2i tuple2i = (Tuple2i)o;
        return this.x == tuple2i.x && this.y == tuple2i.y;
    }
    
    @Override
    public int hashCode() {
        final long n = ((long)452480440 ^ 0x1AF84DA7L) * (((long)(-1284043912) ^ 0xFFFFFFFFB3770B67L) * ((long)(-1890581919) ^ 0xFFFFFFFF8F500260L) + this.x) + this.y;
        return (int)(n ^ n >> 32);
    }
    
    public void clamp(final int n, final int n2, final Tuple2i tuple2i) {
        if (tuple2i.x > n2) {
            this.x = n2;
        }
        else if (tuple2i.x < n) {
            this.x = n;
        }
        else {
            this.x = tuple2i.x;
        }
        if (tuple2i.y > n2) {
            this.y = n2;
        }
        else if (tuple2i.y < n) {
            this.y = n;
        }
        else {
            this.y = tuple2i.y;
        }
    }
    
    public void clampMin(final int n, final Tuple2i tuple2i) {
        if (tuple2i.x < n) {
            this.x = n;
        }
        else {
            this.x = tuple2i.x;
        }
        if (tuple2i.y < n) {
            this.y = n;
        }
        else {
            this.y = tuple2i.y;
        }
    }
    
    public void clampMax(final int n, final Tuple2i tuple2i) {
        if (tuple2i.x > n) {
            this.x = n;
        }
        else {
            this.x = tuple2i.x;
        }
        if (tuple2i.y > n) {
            this.y = n;
        }
        else {
            this.y = tuple2i.y;
        }
    }
    
    public void absolute(final Tuple2i tuple2i) {
        this.x = Math.abs(tuple2i.x);
        this.y = Math.abs(tuple2i.y);
    }
    
    public void clamp(final int n, final int n2) {
        if (this.x > n2) {
            this.x = n2;
        }
        else if (this.x < n) {
            this.x = n;
        }
        if (this.y > n2) {
            this.y = n2;
        }
        else if (this.y < n) {
            this.y = n;
        }
    }
    
    public void clampMin(final int n) {
        if (this.x < n) {
            this.x = n;
        }
        if (this.y < n) {
            this.y = n;
        }
    }
    
    public void clampMax(final int n) {
        if (this.x > n) {
            this.x = n;
        }
        if (this.y > n) {
            this.y = n;
        }
    }
    
    public void absolute() {
        this.x = Math.abs(this.x);
        this.y = Math.abs(this.y);
    }
    
    public Object clone() {
        return super.clone();
    }
    
    public int getX() {
        return this.x;
    }
    
    public void setX(final int x) {
        this.x = x;
    }
    
    public int getY() {
        return this.y;
    }
    
    public void setY(final int y) {
        this.y = y;
    }
    
    static {
        Tuple2i.serialVersionUID = ((long)1973662894 ^ 0xCEA79C3053F58274L);
    }
}
