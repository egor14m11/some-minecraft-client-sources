// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

import java.io.Serializable;

public abstract class Tuple3f implements Serializable, Cloneable
{
    public static long serialVersionUID;
    public float x;
    public float y;
    public float z;
    
    public Tuple3f(final float x, final float y, final float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public Tuple3f(final float[] array) {
        this.x = array[0];
        this.y = array[1];
        this.z = array[2];
    }
    
    public Tuple3f(final Tuple3f tuple3f) {
        this.x = tuple3f.x;
        this.y = tuple3f.y;
        this.z = tuple3f.z;
    }
    
    public Tuple3f(final Tuple3d tuple3d) {
        this.x = (float)tuple3d.x;
        this.y = (float)tuple3d.y;
        this.z = (float)tuple3d.z;
    }
    
    public Tuple3f() {
        this.x = 0.0f;
        this.y = 0.0f;
        this.z = 0.0f;
    }
    
    @Override
    public String toString() {
        return "(" + this.x + ", " + this.y + ", " + this.z + ")";
    }
    
    public void set(final float x, final float y, final float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public void set(final float[] array) {
        this.x = array[0];
        this.y = array[1];
        this.z = array[2];
    }
    
    public void set(final Tuple3f tuple3f) {
        this.x = tuple3f.x;
        this.y = tuple3f.y;
        this.z = tuple3f.z;
    }
    
    public void set(final Tuple3d tuple3d) {
        this.x = (float)tuple3d.x;
        this.y = (float)tuple3d.y;
        this.z = (float)tuple3d.z;
    }
    
    public void get(final float[] array) {
        array[0] = this.x;
        array[1] = this.y;
        array[2] = this.z;
    }
    
    public void get(final Tuple3f tuple3f) {
        tuple3f.x = this.x;
        tuple3f.y = this.y;
        tuple3f.z = this.z;
    }
    
    public void add(final Tuple3f tuple3f, final Tuple3f tuple3f2) {
        this.x = tuple3f.x + tuple3f2.x;
        this.y = tuple3f.y + tuple3f2.y;
        this.z = tuple3f.z + tuple3f2.z;
    }
    
    public void add(final Tuple3f tuple3f) {
        this.x += tuple3f.x;
        this.y += tuple3f.y;
        this.z += tuple3f.z;
    }
    
    public void sub(final Tuple3f tuple3f, final Tuple3f tuple3f2) {
        this.x = tuple3f.x - tuple3f2.x;
        this.y = tuple3f.y - tuple3f2.y;
        this.z = tuple3f.z - tuple3f2.z;
    }
    
    public void sub(final Tuple3f tuple3f) {
        this.x -= tuple3f.x;
        this.y -= tuple3f.y;
        this.z -= tuple3f.z;
    }
    
    public void negate(final Tuple3f tuple3f) {
        this.x = -tuple3f.x;
        this.y = -tuple3f.y;
        this.z = -tuple3f.z;
    }
    
    public void negate() {
        this.x = -this.x;
        this.y = -this.y;
        this.z = -this.z;
    }
    
    public void scale(final float n, final Tuple3f tuple3f) {
        this.x = n * tuple3f.x;
        this.y = n * tuple3f.y;
        this.z = n * tuple3f.z;
    }
    
    public void scale(final float n) {
        this.x *= n;
        this.y *= n;
        this.z *= n;
    }
    
    public void scaleAdd(final float n, final Tuple3f tuple3f, final Tuple3f tuple3f2) {
        this.x = n * tuple3f.x + tuple3f2.x;
        this.y = n * tuple3f.y + tuple3f2.y;
        this.z = n * tuple3f.z + tuple3f2.z;
    }
    
    public void scaleAdd(final float n, final Tuple3f tuple3f) {
        this.x = n * this.x + tuple3f.x;
        this.y = n * this.y + tuple3f.y;
        this.z = n * this.z + tuple3f.z;
    }
    
    public boolean equals(final Tuple3f tuple3f) {
        return this.x == tuple3f.x && this.y == tuple3f.y && this.z == tuple3f.z;
    }
    
    @Override
    public boolean equals(final Object o) {
        final Tuple3f tuple3f = (Tuple3f)o;
        return this.x == tuple3f.x && this.y == tuple3f.y && this.z == tuple3f.z;
    }
    
    public boolean epsilonEquals(final Tuple3f tuple3f, final float n) {
        final float v = this.x - tuple3f.x;
        if (Float.isNaN(v)) {
            return false;
        }
        if (((v < 0.0f) ? (-v) : v) > n) {
            return false;
        }
        final float v2 = this.y - tuple3f.y;
        if (Float.isNaN(v2)) {
            return false;
        }
        if (((v2 < 0.0f) ? (-v2) : v2) > n) {
            return false;
        }
        final float v3 = this.z - tuple3f.z;
        return !Float.isNaN(v3) && ((v3 < 0.0f) ? (-v3) : v3) <= n;
    }
    
    @Override
    public int hashCode() {
        return VecMathUtil.hashFinish(VecMathUtil.hashFloatBits(VecMathUtil.hashFloatBits(VecMathUtil.hashFloatBits((long)5654599 ^ 0x564846L, this.x), this.y), this.z));
    }
    
    public void clamp(final float z, final float z2, final Tuple3f tuple3f) {
        if (tuple3f.x > z2) {
            this.x = z2;
        }
        else if (tuple3f.x < z) {
            this.x = z;
        }
        else {
            this.x = tuple3f.x;
        }
        if (tuple3f.y > z2) {
            this.y = z2;
        }
        else if (tuple3f.y < z) {
            this.y = z;
        }
        else {
            this.y = tuple3f.y;
        }
        if (tuple3f.z > z2) {
            this.z = z2;
        }
        else if (tuple3f.z < z) {
            this.z = z;
        }
        else {
            this.z = tuple3f.z;
        }
    }
    
    public void clampMin(final float z, final Tuple3f tuple3f) {
        if (tuple3f.x < z) {
            this.x = z;
        }
        else {
            this.x = tuple3f.x;
        }
        if (tuple3f.y < z) {
            this.y = z;
        }
        else {
            this.y = tuple3f.y;
        }
        if (tuple3f.z < z) {
            this.z = z;
        }
        else {
            this.z = tuple3f.z;
        }
    }
    
    public void clampMax(final float z, final Tuple3f tuple3f) {
        if (tuple3f.x > z) {
            this.x = z;
        }
        else {
            this.x = tuple3f.x;
        }
        if (tuple3f.y > z) {
            this.y = z;
        }
        else {
            this.y = tuple3f.y;
        }
        if (tuple3f.z > z) {
            this.z = z;
        }
        else {
            this.z = tuple3f.z;
        }
    }
    
    public void absolute(final Tuple3f tuple3f) {
        this.x = Math.abs(tuple3f.x);
        this.y = Math.abs(tuple3f.y);
        this.z = Math.abs(tuple3f.z);
    }
    
    public void clamp(final float z, final float z2) {
        if (this.x > z2) {
            this.x = z2;
        }
        else if (this.x < z) {
            this.x = z;
        }
        if (this.y > z2) {
            this.y = z2;
        }
        else if (this.y < z) {
            this.y = z;
        }
        if (this.z > z2) {
            this.z = z2;
        }
        else if (this.z < z) {
            this.z = z;
        }
    }
    
    public void clampMin(final float z) {
        if (this.x < z) {
            this.x = z;
        }
        if (this.y < z) {
            this.y = z;
        }
        if (this.z < z) {
            this.z = z;
        }
    }
    
    public void clampMax(final float z) {
        if (this.x > z) {
            this.x = z;
        }
        if (this.y > z) {
            this.y = z;
        }
        if (this.z > z) {
            this.z = z;
        }
    }
    
    public void absolute() {
        this.x = Math.abs(this.x);
        this.y = Math.abs(this.y);
        this.z = Math.abs(this.z);
    }
    
    public void interpolate(final Tuple3f tuple3f, final Tuple3f tuple3f2, final float n) {
        this.x = (1.0f - n) * tuple3f.x + n * tuple3f2.x;
        this.y = (1.0f - n) * tuple3f.y + n * tuple3f2.y;
        this.z = (1.0f - n) * tuple3f.z + n * tuple3f2.z;
    }
    
    public void interpolate(final Tuple3f tuple3f, final float n) {
        this.x = (1.0f - n) * this.x + n * tuple3f.x;
        this.y = (1.0f - n) * this.y + n * tuple3f.y;
        this.z = (1.0f - n) * this.z + n * tuple3f.z;
    }
    
    public Object clone() {
        return super.clone();
    }
    
    public float getX() {
        return this.x;
    }
    
    public void setX(final float x) {
        this.x = x;
    }
    
    public float getY() {
        return this.y;
    }
    
    public void setY(final float y) {
        this.y = y;
    }
    
    public float getZ() {
        return this.z;
    }
    
    public void setZ(final float z) {
        this.z = z;
    }
    
    static {
        Tuple3f.serialVersionUID = ((long)(-1450362477) ^ 0xBA55F702D41FB433L);
    }
}
