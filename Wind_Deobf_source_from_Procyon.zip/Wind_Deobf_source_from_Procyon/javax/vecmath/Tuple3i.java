// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

import java.io.Serializable;

public abstract class Tuple3i implements Serializable, Cloneable
{
    public static long serialVersionUID;
    public int x;
    public int y;
    public int z;
    
    public Tuple3i(final int x, final int y, final int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public Tuple3i(final int[] array) {
        this.x = array[0];
        this.y = array[1];
        this.z = array[2];
    }
    
    public Tuple3i(final Tuple3i tuple3i) {
        this.x = tuple3i.x;
        this.y = tuple3i.y;
        this.z = tuple3i.z;
    }
    
    public Tuple3i() {
        this.x = 0;
        this.y = 0;
        this.z = 0;
    }
    
    public void set(final int x, final int y, final int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public void set(final int[] array) {
        this.x = array[0];
        this.y = array[1];
        this.z = array[2];
    }
    
    public void set(final Tuple3i tuple3i) {
        this.x = tuple3i.x;
        this.y = tuple3i.y;
        this.z = tuple3i.z;
    }
    
    public void get(final int[] array) {
        array[0] = this.x;
        array[1] = this.y;
        array[2] = this.z;
    }
    
    public void get(final Tuple3i tuple3i) {
        tuple3i.x = this.x;
        tuple3i.y = this.y;
        tuple3i.z = this.z;
    }
    
    public void add(final Tuple3i tuple3i, final Tuple3i tuple3i2) {
        this.x = tuple3i.x + tuple3i2.x;
        this.y = tuple3i.y + tuple3i2.y;
        this.z = tuple3i.z + tuple3i2.z;
    }
    
    public void add(final Tuple3i tuple3i) {
        this.x += tuple3i.x;
        this.y += tuple3i.y;
        this.z += tuple3i.z;
    }
    
    public void sub(final Tuple3i tuple3i, final Tuple3i tuple3i2) {
        this.x = tuple3i.x - tuple3i2.x;
        this.y = tuple3i.y - tuple3i2.y;
        this.z = tuple3i.z - tuple3i2.z;
    }
    
    public void sub(final Tuple3i tuple3i) {
        this.x -= tuple3i.x;
        this.y -= tuple3i.y;
        this.z -= tuple3i.z;
    }
    
    public void negate(final Tuple3i tuple3i) {
        this.x = -tuple3i.x;
        this.y = -tuple3i.y;
        this.z = -tuple3i.z;
    }
    
    public void negate() {
        this.x = -this.x;
        this.y = -this.y;
        this.z = -this.z;
    }
    
    public void scale(final int n, final Tuple3i tuple3i) {
        this.x = n * tuple3i.x;
        this.y = n * tuple3i.y;
        this.z = n * tuple3i.z;
    }
    
    public void scale(final int n) {
        this.x *= n;
        this.y *= n;
        this.z *= n;
    }
    
    public void scaleAdd(final int n, final Tuple3i tuple3i, final Tuple3i tuple3i2) {
        this.x = n * tuple3i.x + tuple3i2.x;
        this.y = n * tuple3i.y + tuple3i2.y;
        this.z = n * tuple3i.z + tuple3i2.z;
    }
    
    public void scaleAdd(final int n, final Tuple3i tuple3i) {
        this.x = n * this.x + tuple3i.x;
        this.y = n * this.y + tuple3i.y;
        this.z = n * this.z + tuple3i.z;
    }
    
    @Override
    public String toString() {
        return "(" + this.x + ", " + this.y + ", " + this.z + ")";
    }
    
    @Override
    public boolean equals(final Object o) {
        final Tuple3i tuple3i = (Tuple3i)o;
        return this.x == tuple3i.x && this.y == tuple3i.y && this.z == tuple3i.z;
    }
    
    @Override
    public int hashCode() {
        final long n = ((long)(-1697507010) ^ 0xFFFFFFFF9AD21921L) * (((long)(-1001382200) ^ 0xFFFFFFFFC4501ED7L) * (((long)582689944 ^ 0x22BB2487L) * ((long)1858222974 ^ 0x6EC23B7FL) + this.x) + this.y) + this.z;
        return (int)(n ^ n >> 32);
    }
    
    public void clamp(final int z, final int z2, final Tuple3i tuple3i) {
        if (tuple3i.x > z2) {
            this.x = z2;
        }
        else if (tuple3i.x < z) {
            this.x = z;
        }
        else {
            this.x = tuple3i.x;
        }
        if (tuple3i.y > z2) {
            this.y = z2;
        }
        else if (tuple3i.y < z) {
            this.y = z;
        }
        else {
            this.y = tuple3i.y;
        }
        if (tuple3i.z > z2) {
            this.z = z2;
        }
        else if (tuple3i.z < z) {
            this.z = z;
        }
        else {
            this.z = tuple3i.z;
        }
    }
    
    public void clampMin(final int z, final Tuple3i tuple3i) {
        if (tuple3i.x < z) {
            this.x = z;
        }
        else {
            this.x = tuple3i.x;
        }
        if (tuple3i.y < z) {
            this.y = z;
        }
        else {
            this.y = tuple3i.y;
        }
        if (tuple3i.z < z) {
            this.z = z;
        }
        else {
            this.z = tuple3i.z;
        }
    }
    
    public void clampMax(final int z, final Tuple3i tuple3i) {
        if (tuple3i.x > z) {
            this.x = z;
        }
        else {
            this.x = tuple3i.x;
        }
        if (tuple3i.y > z) {
            this.y = z;
        }
        else {
            this.y = tuple3i.y;
        }
        if (tuple3i.z > z) {
            this.z = z;
        }
        else {
            this.z = tuple3i.z;
        }
    }
    
    public void absolute(final Tuple3i tuple3i) {
        this.x = Math.abs(tuple3i.x);
        this.y = Math.abs(tuple3i.y);
        this.z = Math.abs(tuple3i.z);
    }
    
    public void clamp(final int z, final int z2) {
        if (this.x > z2) {
            this.x = z2;
        }
        else if (this.x < z) {
            this.x = z;
        }
        if (this.y > z2) {
            this.y = z2;
        }
        else if (this.y < z) {
            this.y = z;
        }
        if (this.z > z2) {
            this.z = z2;
        }
        else if (this.z < z) {
            this.z = z;
        }
    }
    
    public void clampMin(final int z) {
        if (this.x < z) {
            this.x = z;
        }
        if (this.y < z) {
            this.y = z;
        }
        if (this.z < z) {
            this.z = z;
        }
    }
    
    public void clampMax(final int z) {
        if (this.x > z) {
            this.x = z;
        }
        if (this.y > z) {
            this.y = z;
        }
        if (this.z > z) {
            this.z = z;
        }
    }
    
    public void absolute() {
        this.x = Math.abs(this.x);
        this.y = Math.abs(this.y);
        this.z = Math.abs(this.z);
    }
    
    public Object clone() {
        return super.clone();
    }
    
    public int getX() {
        return this.x;
    }
    
    public void setX(final int x) {
        this.x = x;
    }
    
    public int getY() {
        return this.y;
    }
    
    public void setY(final int y) {
        this.y = y;
    }
    
    public int getZ() {
        return this.z;
    }
    
    public void setZ(final int z) {
        this.z = z;
    }
    
    static {
        Tuple3i.serialVersionUID = ((long)865401717 ^ 0xF5D4C867983E662DL);
    }
}
