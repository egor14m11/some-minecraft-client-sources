// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

import java.io.Serializable;

public abstract class Tuple4d implements Serializable, Cloneable
{
    public static long serialVersionUID;
    public double x;
    public double y;
    public double z;
    public double w;
    
    public Tuple4d(final double x, final double y, final double z, final double w) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }
    
    public Tuple4d(final double[] array) {
        this.x = array[0];
        this.y = array[1];
        this.z = array[2];
        this.w = array[3];
    }
    
    public Tuple4d(final Tuple4d tuple4d) {
        this.x = tuple4d.x;
        this.y = tuple4d.y;
        this.z = tuple4d.z;
        this.w = tuple4d.w;
    }
    
    public Tuple4d(final Tuple4f tuple4f) {
        this.x = tuple4f.x;
        this.y = tuple4f.y;
        this.z = tuple4f.z;
        this.w = tuple4f.w;
    }
    
    public Tuple4d() {
        this.x = 0.0;
        this.y = 0.0;
        this.z = 0.0;
        this.w = 0.0;
    }
    
    public void set(final double x, final double y, final double z, final double w) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }
    
    public void set(final double[] array) {
        this.x = array[0];
        this.y = array[1];
        this.z = array[2];
        this.w = array[3];
    }
    
    public void set(final Tuple4d tuple4d) {
        this.x = tuple4d.x;
        this.y = tuple4d.y;
        this.z = tuple4d.z;
        this.w = tuple4d.w;
    }
    
    public void set(final Tuple4f tuple4f) {
        this.x = tuple4f.x;
        this.y = tuple4f.y;
        this.z = tuple4f.z;
        this.w = tuple4f.w;
    }
    
    public void get(final double[] array) {
        array[0] = this.x;
        array[1] = this.y;
        array[2] = this.z;
        array[3] = this.w;
    }
    
    public void get(final Tuple4d tuple4d) {
        tuple4d.x = this.x;
        tuple4d.y = this.y;
        tuple4d.z = this.z;
        tuple4d.w = this.w;
    }
    
    public void add(final Tuple4d tuple4d, final Tuple4d tuple4d2) {
        this.x = tuple4d.x + tuple4d2.x;
        this.y = tuple4d.y + tuple4d2.y;
        this.z = tuple4d.z + tuple4d2.z;
        this.w = tuple4d.w + tuple4d2.w;
    }
    
    public void add(final Tuple4d tuple4d) {
        this.x += tuple4d.x;
        this.y += tuple4d.y;
        this.z += tuple4d.z;
        this.w += tuple4d.w;
    }
    
    public void sub(final Tuple4d tuple4d, final Tuple4d tuple4d2) {
        this.x = tuple4d.x - tuple4d2.x;
        this.y = tuple4d.y - tuple4d2.y;
        this.z = tuple4d.z - tuple4d2.z;
        this.w = tuple4d.w - tuple4d2.w;
    }
    
    public void sub(final Tuple4d tuple4d) {
        this.x -= tuple4d.x;
        this.y -= tuple4d.y;
        this.z -= tuple4d.z;
        this.w -= tuple4d.w;
    }
    
    public void negate(final Tuple4d tuple4d) {
        this.x = -tuple4d.x;
        this.y = -tuple4d.y;
        this.z = -tuple4d.z;
        this.w = -tuple4d.w;
    }
    
    public void negate() {
        this.x = -this.x;
        this.y = -this.y;
        this.z = -this.z;
        this.w = -this.w;
    }
    
    public void scale(final double n, final Tuple4d tuple4d) {
        this.x = n * tuple4d.x;
        this.y = n * tuple4d.y;
        this.z = n * tuple4d.z;
        this.w = n * tuple4d.w;
    }
    
    public void scale(final double n) {
        this.x *= n;
        this.y *= n;
        this.z *= n;
        this.w *= n;
    }
    
    public void scaleAdd(final double n, final Tuple4d tuple4d, final Tuple4d tuple4d2) {
        this.x = n * tuple4d.x + tuple4d2.x;
        this.y = n * tuple4d.y + tuple4d2.y;
        this.z = n * tuple4d.z + tuple4d2.z;
        this.w = n * tuple4d.w + tuple4d2.w;
    }
    
    @Deprecated
    public void scaleAdd(final float n, final Tuple4d tuple4d) {
        this.scaleAdd((double)n, tuple4d);
    }
    
    public void scaleAdd(final double n, final Tuple4d tuple4d) {
        this.x = n * this.x + tuple4d.x;
        this.y = n * this.y + tuple4d.y;
        this.z = n * this.z + tuple4d.z;
        this.w = n * this.w + tuple4d.w;
    }
    
    @Override
    public String toString() {
        return "(" + this.x + ", " + this.y + ", " + this.z + ", " + this.w + ")";
    }
    
    public boolean equals(final Tuple4d tuple4d) {
        return this.x == tuple4d.x && this.y == tuple4d.y && this.z == tuple4d.z && this.w == tuple4d.w;
    }
    
    @Override
    public boolean equals(final Object o) {
        final Tuple4d tuple4d = (Tuple4d)o;
        return this.x == tuple4d.x && this.y == tuple4d.y && this.z == tuple4d.z && this.w == tuple4d.w;
    }
    
    public boolean epsilonEquals(final Tuple4d tuple4d, final double n) {
        final double v = this.x - tuple4d.x;
        if (Double.isNaN(v)) {
            return false;
        }
        if (((v < 0.0) ? (-v) : v) > n) {
            return false;
        }
        final double v2 = this.y - tuple4d.y;
        if (Double.isNaN(v2)) {
            return false;
        }
        if (((v2 < 0.0) ? (-v2) : v2) > n) {
            return false;
        }
        final double v3 = this.z - tuple4d.z;
        if (Double.isNaN(v3)) {
            return false;
        }
        if (((v3 < 0.0) ? (-v3) : v3) > n) {
            return false;
        }
        final double v4 = this.w - tuple4d.w;
        return !Double.isNaN(v4) && ((v4 < 0.0) ? (-v4) : v4) <= n;
    }
    
    @Override
    public int hashCode() {
        return VecMathUtil.hashFinish(VecMathUtil.hashDoubleBits(VecMathUtil.hashDoubleBits(VecMathUtil.hashDoubleBits(VecMathUtil.hashDoubleBits((long)1910042053 ^ 0x71D8EDC4L, this.x), this.y), this.z), this.w));
    }
    
    @Deprecated
    public void clamp(final float n, final float n2, final Tuple4d tuple4d) {
        this.clamp(n, (double)n2, tuple4d);
    }
    
    public void clamp(final double n, final double n2, final Tuple4d tuple4d) {
        if (tuple4d.x > n2) {
            this.x = n2;
        }
        else if (tuple4d.x < n) {
            this.x = n;
        }
        else {
            this.x = tuple4d.x;
        }
        if (tuple4d.y > n2) {
            this.y = n2;
        }
        else if (tuple4d.y < n) {
            this.y = n;
        }
        else {
            this.y = tuple4d.y;
        }
        if (tuple4d.z > n2) {
            this.z = n2;
        }
        else if (tuple4d.z < n) {
            this.z = n;
        }
        else {
            this.z = tuple4d.z;
        }
        if (tuple4d.w > n2) {
            this.w = n2;
        }
        else if (tuple4d.w < n) {
            this.w = n;
        }
        else {
            this.w = tuple4d.w;
        }
    }
    
    @Deprecated
    public void clampMin(final float n, final Tuple4d tuple4d) {
        this.clampMin((double)n, tuple4d);
    }
    
    public void clampMin(final double n, final Tuple4d tuple4d) {
        if (tuple4d.x < n) {
            this.x = n;
        }
        else {
            this.x = tuple4d.x;
        }
        if (tuple4d.y < n) {
            this.y = n;
        }
        else {
            this.y = tuple4d.y;
        }
        if (tuple4d.z < n) {
            this.z = n;
        }
        else {
            this.z = tuple4d.z;
        }
        if (tuple4d.w < n) {
            this.w = n;
        }
        else {
            this.w = tuple4d.w;
        }
    }
    
    @Deprecated
    public void clampMax(final float n, final Tuple4d tuple4d) {
        this.clampMax((double)n, tuple4d);
    }
    
    public void clampMax(final double n, final Tuple4d tuple4d) {
        if (tuple4d.x > n) {
            this.x = n;
        }
        else {
            this.x = tuple4d.x;
        }
        if (tuple4d.y > n) {
            this.y = n;
        }
        else {
            this.y = tuple4d.y;
        }
        if (tuple4d.z > n) {
            this.z = n;
        }
        else {
            this.z = tuple4d.z;
        }
        if (tuple4d.w > n) {
            this.w = n;
        }
        else {
            this.w = tuple4d.z;
        }
    }
    
    public void absolute(final Tuple4d tuple4d) {
        this.x = Math.abs(tuple4d.x);
        this.y = Math.abs(tuple4d.y);
        this.z = Math.abs(tuple4d.z);
        this.w = Math.abs(tuple4d.w);
    }
    
    @Deprecated
    public void clamp(final float n, final float n2) {
        this.clamp(n, (double)n2);
    }
    
    public void clamp(final double n, final double n2) {
        if (this.x > n2) {
            this.x = n2;
        }
        else if (this.x < n) {
            this.x = n;
        }
        if (this.y > n2) {
            this.y = n2;
        }
        else if (this.y < n) {
            this.y = n;
        }
        if (this.z > n2) {
            this.z = n2;
        }
        else if (this.z < n) {
            this.z = n;
        }
        if (this.w > n2) {
            this.w = n2;
        }
        else if (this.w < n) {
            this.w = n;
        }
    }
    
    @Deprecated
    public void clampMin(final float n) {
        this.clampMin((double)n);
    }
    
    public void clampMin(final double n) {
        if (this.x < n) {
            this.x = n;
        }
        if (this.y < n) {
            this.y = n;
        }
        if (this.z < n) {
            this.z = n;
        }
        if (this.w < n) {
            this.w = n;
        }
    }
    
    @Deprecated
    public void clampMax(final float n) {
        this.clampMax((double)n);
    }
    
    public void clampMax(final double n) {
        if (this.x > n) {
            this.x = n;
        }
        if (this.y > n) {
            this.y = n;
        }
        if (this.z > n) {
            this.z = n;
        }
        if (this.w > n) {
            this.w = n;
        }
    }
    
    public void absolute() {
        this.x = Math.abs(this.x);
        this.y = Math.abs(this.y);
        this.z = Math.abs(this.z);
        this.w = Math.abs(this.w);
    }
    
    @Deprecated
    public void interpolate(final Tuple4d tuple4d, final Tuple4d tuple4d2, final float n) {
        this.interpolate(tuple4d, tuple4d2, (double)n);
    }
    
    public void interpolate(final Tuple4d tuple4d, final Tuple4d tuple4d2, final double n) {
        this.x = (1.0 - n) * tuple4d.x + n * tuple4d2.x;
        this.y = (1.0 - n) * tuple4d.y + n * tuple4d2.y;
        this.z = (1.0 - n) * tuple4d.z + n * tuple4d2.z;
        this.w = (1.0 - n) * tuple4d.w + n * tuple4d2.w;
    }
    
    @Deprecated
    public void interpolate(final Tuple4d tuple4d, final float n) {
        this.interpolate(tuple4d, (double)n);
    }
    
    public void interpolate(final Tuple4d tuple4d, final double n) {
        this.x = (1.0 - n) * this.x + n * tuple4d.x;
        this.y = (1.0 - n) * this.y + n * tuple4d.y;
        this.z = (1.0 - n) * this.z + n * tuple4d.z;
        this.w = (1.0 - n) * this.w + n * tuple4d.w;
    }
    
    public Object clone() {
        return super.clone();
    }
    
    public double getX() {
        return this.x;
    }
    
    public void setX(final double x) {
        this.x = x;
    }
    
    public double getY() {
        return this.y;
    }
    
    public void setY(final double y) {
        this.y = y;
    }
    
    public double getZ() {
        return this.z;
    }
    
    public void setZ(final double z) {
        this.z = z;
    }
    
    public double getW() {
        return this.w;
    }
    
    public void setW(final double w) {
        this.w = w;
    }
    
    static {
        Tuple4d.serialVersionUID = ((long)1961346219 ^ 0xBE1853C7E78C841FL);
    }
}
