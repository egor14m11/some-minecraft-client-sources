// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

import java.io.Serializable;

public abstract class Tuple4f implements Serializable, Cloneable
{
    public static long serialVersionUID;
    public float x;
    public float y;
    public float z;
    public float w;
    
    public Tuple4f(final float x, final float y, final float z, final float w) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }
    
    public Tuple4f(final float[] array) {
        this.x = array[0];
        this.y = array[1];
        this.z = array[2];
        this.w = array[3];
    }
    
    public Tuple4f(final Tuple4f tuple4f) {
        this.x = tuple4f.x;
        this.y = tuple4f.y;
        this.z = tuple4f.z;
        this.w = tuple4f.w;
    }
    
    public Tuple4f(final Tuple4d tuple4d) {
        this.x = (float)tuple4d.x;
        this.y = (float)tuple4d.y;
        this.z = (float)tuple4d.z;
        this.w = (float)tuple4d.w;
    }
    
    public Tuple4f() {
        this.x = 0.0f;
        this.y = 0.0f;
        this.z = 0.0f;
        this.w = 0.0f;
    }
    
    public void set(final float x, final float y, final float z, final float w) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }
    
    public void set(final float[] array) {
        this.x = array[0];
        this.y = array[1];
        this.z = array[2];
        this.w = array[3];
    }
    
    public void set(final Tuple4f tuple4f) {
        this.x = tuple4f.x;
        this.y = tuple4f.y;
        this.z = tuple4f.z;
        this.w = tuple4f.w;
    }
    
    public void set(final Tuple4d tuple4d) {
        this.x = (float)tuple4d.x;
        this.y = (float)tuple4d.y;
        this.z = (float)tuple4d.z;
        this.w = (float)tuple4d.w;
    }
    
    public void get(final float[] array) {
        array[0] = this.x;
        array[1] = this.y;
        array[2] = this.z;
        array[3] = this.w;
    }
    
    public void get(final Tuple4f tuple4f) {
        tuple4f.x = this.x;
        tuple4f.y = this.y;
        tuple4f.z = this.z;
        tuple4f.w = this.w;
    }
    
    public void add(final Tuple4f tuple4f, final Tuple4f tuple4f2) {
        this.x = tuple4f.x + tuple4f2.x;
        this.y = tuple4f.y + tuple4f2.y;
        this.z = tuple4f.z + tuple4f2.z;
        this.w = tuple4f.w + tuple4f2.w;
    }
    
    public void add(final Tuple4f tuple4f) {
        this.x += tuple4f.x;
        this.y += tuple4f.y;
        this.z += tuple4f.z;
        this.w += tuple4f.w;
    }
    
    public void sub(final Tuple4f tuple4f, final Tuple4f tuple4f2) {
        this.x = tuple4f.x - tuple4f2.x;
        this.y = tuple4f.y - tuple4f2.y;
        this.z = tuple4f.z - tuple4f2.z;
        this.w = tuple4f.w - tuple4f2.w;
    }
    
    public void sub(final Tuple4f tuple4f) {
        this.x -= tuple4f.x;
        this.y -= tuple4f.y;
        this.z -= tuple4f.z;
        this.w -= tuple4f.w;
    }
    
    public void negate(final Tuple4f tuple4f) {
        this.x = -tuple4f.x;
        this.y = -tuple4f.y;
        this.z = -tuple4f.z;
        this.w = -tuple4f.w;
    }
    
    public void negate() {
        this.x = -this.x;
        this.y = -this.y;
        this.z = -this.z;
        this.w = -this.w;
    }
    
    public void scale(final float n, final Tuple4f tuple4f) {
        this.x = n * tuple4f.x;
        this.y = n * tuple4f.y;
        this.z = n * tuple4f.z;
        this.w = n * tuple4f.w;
    }
    
    public void scale(final float n) {
        this.x *= n;
        this.y *= n;
        this.z *= n;
        this.w *= n;
    }
    
    public void scaleAdd(final float n, final Tuple4f tuple4f, final Tuple4f tuple4f2) {
        this.x = n * tuple4f.x + tuple4f2.x;
        this.y = n * tuple4f.y + tuple4f2.y;
        this.z = n * tuple4f.z + tuple4f2.z;
        this.w = n * tuple4f.w + tuple4f2.w;
    }
    
    public void scaleAdd(final float n, final Tuple4f tuple4f) {
        this.x = n * this.x + tuple4f.x;
        this.y = n * this.y + tuple4f.y;
        this.z = n * this.z + tuple4f.z;
        this.w = n * this.w + tuple4f.w;
    }
    
    @Override
    public String toString() {
        return "(" + this.x + ", " + this.y + ", " + this.z + ", " + this.w + ")";
    }
    
    public boolean equals(final Tuple4f tuple4f) {
        return this.x == tuple4f.x && this.y == tuple4f.y && this.z == tuple4f.z && this.w == tuple4f.w;
    }
    
    @Override
    public boolean equals(final Object o) {
        final Tuple4f tuple4f = (Tuple4f)o;
        return this.x == tuple4f.x && this.y == tuple4f.y && this.z == tuple4f.z && this.w == tuple4f.w;
    }
    
    public boolean epsilonEquals(final Tuple4f tuple4f, final float n) {
        final float v = this.x - tuple4f.x;
        if (Float.isNaN(v)) {
            return false;
        }
        if (((v < 0.0f) ? (-v) : v) > n) {
            return false;
        }
        final float v2 = this.y - tuple4f.y;
        if (Float.isNaN(v2)) {
            return false;
        }
        if (((v2 < 0.0f) ? (-v2) : v2) > n) {
            return false;
        }
        final float v3 = this.z - tuple4f.z;
        if (Float.isNaN(v3)) {
            return false;
        }
        if (((v3 < 0.0f) ? (-v3) : v3) > n) {
            return false;
        }
        final float v4 = this.w - tuple4f.w;
        return !Float.isNaN(v4) && ((v4 < 0.0f) ? (-v4) : v4) <= n;
    }
    
    @Override
    public int hashCode() {
        return VecMathUtil.hashFinish(VecMathUtil.hashFloatBits(VecMathUtil.hashFloatBits(VecMathUtil.hashFloatBits(VecMathUtil.hashFloatBits((long)1385242081 ^ 0x52911DE0L, this.x), this.y), this.z), this.w));
    }
    
    public void clamp(final float n, final float n2, final Tuple4f tuple4f) {
        if (tuple4f.x > n2) {
            this.x = n2;
        }
        else if (tuple4f.x < n) {
            this.x = n;
        }
        else {
            this.x = tuple4f.x;
        }
        if (tuple4f.y > n2) {
            this.y = n2;
        }
        else if (tuple4f.y < n) {
            this.y = n;
        }
        else {
            this.y = tuple4f.y;
        }
        if (tuple4f.z > n2) {
            this.z = n2;
        }
        else if (tuple4f.z < n) {
            this.z = n;
        }
        else {
            this.z = tuple4f.z;
        }
        if (tuple4f.w > n2) {
            this.w = n2;
        }
        else if (tuple4f.w < n) {
            this.w = n;
        }
        else {
            this.w = tuple4f.w;
        }
    }
    
    public void clampMin(final float n, final Tuple4f tuple4f) {
        if (tuple4f.x < n) {
            this.x = n;
        }
        else {
            this.x = tuple4f.x;
        }
        if (tuple4f.y < n) {
            this.y = n;
        }
        else {
            this.y = tuple4f.y;
        }
        if (tuple4f.z < n) {
            this.z = n;
        }
        else {
            this.z = tuple4f.z;
        }
        if (tuple4f.w < n) {
            this.w = n;
        }
        else {
            this.w = tuple4f.w;
        }
    }
    
    public void clampMax(final float n, final Tuple4f tuple4f) {
        if (tuple4f.x > n) {
            this.x = n;
        }
        else {
            this.x = tuple4f.x;
        }
        if (tuple4f.y > n) {
            this.y = n;
        }
        else {
            this.y = tuple4f.y;
        }
        if (tuple4f.z > n) {
            this.z = n;
        }
        else {
            this.z = tuple4f.z;
        }
        if (tuple4f.w > n) {
            this.w = n;
        }
        else {
            this.w = tuple4f.z;
        }
    }
    
    public void absolute(final Tuple4f tuple4f) {
        this.x = Math.abs(tuple4f.x);
        this.y = Math.abs(tuple4f.y);
        this.z = Math.abs(tuple4f.z);
        this.w = Math.abs(tuple4f.w);
    }
    
    public void clamp(final float n, final float n2) {
        if (this.x > n2) {
            this.x = n2;
        }
        else if (this.x < n) {
            this.x = n;
        }
        if (this.y > n2) {
            this.y = n2;
        }
        else if (this.y < n) {
            this.y = n;
        }
        if (this.z > n2) {
            this.z = n2;
        }
        else if (this.z < n) {
            this.z = n;
        }
        if (this.w > n2) {
            this.w = n2;
        }
        else if (this.w < n) {
            this.w = n;
        }
    }
    
    public void clampMin(final float n) {
        if (this.x < n) {
            this.x = n;
        }
        if (this.y < n) {
            this.y = n;
        }
        if (this.z < n) {
            this.z = n;
        }
        if (this.w < n) {
            this.w = n;
        }
    }
    
    public void clampMax(final float n) {
        if (this.x > n) {
            this.x = n;
        }
        if (this.y > n) {
            this.y = n;
        }
        if (this.z > n) {
            this.z = n;
        }
        if (this.w > n) {
            this.w = n;
        }
    }
    
    public void absolute() {
        this.x = Math.abs(this.x);
        this.y = Math.abs(this.y);
        this.z = Math.abs(this.z);
        this.w = Math.abs(this.w);
    }
    
    public void interpolate(final Tuple4f tuple4f, final Tuple4f tuple4f2, final float n) {
        this.x = (1.0f - n) * tuple4f.x + n * tuple4f2.x;
        this.y = (1.0f - n) * tuple4f.y + n * tuple4f2.y;
        this.z = (1.0f - n) * tuple4f.z + n * tuple4f2.z;
        this.w = (1.0f - n) * tuple4f.w + n * tuple4f2.w;
    }
    
    public void interpolate(final Tuple4f tuple4f, final float n) {
        this.x = (1.0f - n) * this.x + n * tuple4f.x;
        this.y = (1.0f - n) * this.y + n * tuple4f.y;
        this.z = (1.0f - n) * this.z + n * tuple4f.z;
        this.w = (1.0f - n) * this.w + n * tuple4f.w;
    }
    
    public Object clone() {
        return super.clone();
    }
    
    public float getX() {
        return this.x;
    }
    
    public void setX(final float x) {
        this.x = x;
    }
    
    public float getY() {
        return this.y;
    }
    
    public void setY(final float y) {
        this.y = y;
    }
    
    public float getZ() {
        return this.z;
    }
    
    public void setZ(final float z) {
        this.z = z;
    }
    
    public float getW() {
        return this.w;
    }
    
    public void setW(final float w) {
        this.w = w;
    }
    
    static {
        Tuple4f.serialVersionUID = ((long)2061294933 ^ 0x62183735BF195696L);
    }
}
