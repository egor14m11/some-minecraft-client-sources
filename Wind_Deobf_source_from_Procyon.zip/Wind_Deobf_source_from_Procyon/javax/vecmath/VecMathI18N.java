// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

import java.util.ResourceBundle;

public class VecMathI18N
{
    public static String getString(final String key) {
        return ResourceBundle.getBundle("javax.vecmath.ExceptionStrings").getString(key);
    }
}
