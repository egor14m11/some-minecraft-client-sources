// 
// Decompiled by Procyon v0.5.36
// 

package javax.vecmath;

public class VecMathUtil
{
    public static long hashLongBits(long n, final long n2) {
        n *= ((long)1879105270 ^ 0x7000DEE9L);
        return n + n2;
    }
    
    public static long hashFloatBits(long n, final float value) {
        n *= ((long)1563556831 ^ 0x5D31FBC0L);
        if (value == 0.0f) {
            return n;
        }
        return n + Float.floatToIntBits(value);
    }
    
    public static long hashDoubleBits(long n, final double value) {
        n *= ((long)1819675484 ^ 0x6C760B43L);
        if (value == 0.0) {
            return n;
        }
        return n + Double.doubleToLongBits(value);
    }
    
    public static int hashFinish(final long n) {
        return (int)(n ^ n >> 32);
    }
}
