// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.newdawn.slick.opengl.renderer.Renderer;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import org.newdawn.slick.util.ResourceLoader;
import java.util.Map;
import java.util.LinkedHashMap;
import org.newdawn.slick.opengl.renderer.SGL;

public class AngelCodeFont implements Font
{
    public static SGL GL;
    public static int DISPLAY_LIST_CACHE_SIZE;
    public static int MAX_CHAR;
    public boolean displayListCaching;
    public Image fontImage;
    public CharDef[] chars;
    public int lineHeight;
    public int baseDisplayListID;
    public int eldestDisplayListID;
    public DisplayList eldestDisplayList;
    public LinkedHashMap displayLists;
    
    public AngelCodeFont(final String s, final Image fontImage) throws SlickException {
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public AngelCodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                AngelCodeFont.access$002(this.this$0, entry.getValue());
                AngelCodeFont.access$102(this.this$0, AngelCodeFont.access$000(this.this$0).id);
                return false;
            }
        };
        this.fontImage = fontImage;
        this.parseFnt(ResourceLoader.getResourceAsStream(s));
    }
    
    public AngelCodeFont(final String s, final String s2) throws SlickException {
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public AngelCodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                AngelCodeFont.access$002(this.this$0, entry.getValue());
                AngelCodeFont.access$102(this.this$0, AngelCodeFont.access$000(this.this$0).id);
                return false;
            }
        };
        this.fontImage = new Image(s2);
        this.parseFnt(ResourceLoader.getResourceAsStream(s));
    }
    
    public AngelCodeFont(final String s, final Image fontImage, final boolean displayListCaching) throws SlickException {
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public AngelCodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                AngelCodeFont.access$002(this.this$0, entry.getValue());
                AngelCodeFont.access$102(this.this$0, AngelCodeFont.access$000(this.this$0).id);
                return false;
            }
        };
        this.fontImage = fontImage;
        this.displayListCaching = displayListCaching;
        this.parseFnt(ResourceLoader.getResourceAsStream(s));
    }
    
    public AngelCodeFont(final String s, final String s2, final boolean displayListCaching) throws SlickException {
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public AngelCodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                AngelCodeFont.access$002(this.this$0, entry.getValue());
                AngelCodeFont.access$102(this.this$0, AngelCodeFont.access$000(this.this$0).id);
                return false;
            }
        };
        this.fontImage = new Image(s2);
        this.displayListCaching = displayListCaching;
        this.parseFnt(ResourceLoader.getResourceAsStream(s));
    }
    
    public AngelCodeFont(final String s, final InputStream inputStream, final InputStream inputStream2) throws SlickException {
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public AngelCodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                AngelCodeFont.access$002(this.this$0, entry.getValue());
                AngelCodeFont.access$102(this.this$0, AngelCodeFont.access$000(this.this$0).id);
                return false;
            }
        };
        this.fontImage = new Image(inputStream2, s, false);
        this.parseFnt(inputStream);
    }
    
    public AngelCodeFont(final String s, final InputStream inputStream, final InputStream inputStream2, final boolean displayListCaching) throws SlickException {
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public AngelCodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                AngelCodeFont.access$002(this.this$0, entry.getValue());
                AngelCodeFont.access$102(this.this$0, AngelCodeFont.access$000(this.this$0).id);
                return false;
            }
        };
        this.fontImage = new Image(inputStream2, s, false);
        this.displayListCaching = displayListCaching;
        this.parseFnt(inputStream);
    }
    
    public void parseFnt(final InputStream in) throws SlickException {
        if (this.displayListCaching) {
            this.baseDisplayListID = AngelCodeFont.GL.glGenLists(200);
            if (this.baseDisplayListID == 0) {
                this.displayListCaching = false;
            }
        }
        final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
        bufferedReader.readLine();
        bufferedReader.readLine();
        bufferedReader.readLine();
        final HashMap<Object, Object> hashMap = new HashMap<Object, Object>(64);
        final ArrayList<CharDef> list = new ArrayList<CharDef>(255);
        int max = 0;
        int i = 0;
        while (i == 0) {
            final String line = bufferedReader.readLine();
            if (line == null) {
                i = 1;
            }
            else {
                if (!line.startsWith("chars c")) {
                    if (line.startsWith("char")) {
                        final CharDef char1 = this.parseChar(line);
                        if (char1 != null) {
                            max = Math.max(max, char1.id);
                            list.add(char1);
                        }
                    }
                }
                if (line.startsWith("kernings c")) {
                    continue;
                }
                if (!line.startsWith("kerning")) {
                    continue;
                }
                final StringTokenizer stringTokenizer = new StringTokenizer(line, " =");
                stringTokenizer.nextToken();
                stringTokenizer.nextToken();
                final short short1 = Short.parseShort(stringTokenizer.nextToken());
                stringTokenizer.nextToken();
                final int int1 = Integer.parseInt(stringTokenizer.nextToken());
                stringTokenizer.nextToken();
                final int int2 = Integer.parseInt(stringTokenizer.nextToken());
                List<?> list2 = hashMap.get(new Short(short1));
                if (list2 == null) {
                    list2 = new ArrayList<Object>();
                    hashMap.put(new Short(short1), list2);
                }
                list2.add(new Short((short)(int2 << 8 | int1)));
            }
        }
        this.chars = new CharDef[max + 1];
        for (final CharDef charDef : list) {
            this.chars[charDef.id] = charDef;
        }
        for (final Map.Entry<Short, List<Short>> entry : hashMap.entrySet()) {
            final short shortValue = entry.getKey();
            final List<Short> list3 = entry.getValue();
            final short[] kerning = new short[list3.size()];
            int n = 0;
            final Iterator<Short> iterator3 = list3.iterator();
            while (iterator3.hasNext()) {
                kerning[n] = iterator3.next();
                ++n;
            }
            this.chars[shortValue].kerning = kerning;
        }
    }
    
    public CharDef parseChar(final String str) throws SlickException {
        final CharDef charDef = new CharDef(null);
        final StringTokenizer stringTokenizer = new StringTokenizer(str, " =");
        stringTokenizer.nextToken();
        stringTokenizer.nextToken();
        charDef.id = Short.parseShort(stringTokenizer.nextToken());
        if (charDef.id < 0) {
            return null;
        }
        if (charDef.id > 255) {
            throw new SlickException("Invalid character '" + charDef.id + "': AngelCodeFont does not support characters above " + 255);
        }
        stringTokenizer.nextToken();
        charDef.x = Short.parseShort(stringTokenizer.nextToken());
        stringTokenizer.nextToken();
        charDef.y = Short.parseShort(stringTokenizer.nextToken());
        stringTokenizer.nextToken();
        charDef.width = Short.parseShort(stringTokenizer.nextToken());
        stringTokenizer.nextToken();
        charDef.height = Short.parseShort(stringTokenizer.nextToken());
        stringTokenizer.nextToken();
        charDef.xoffset = Short.parseShort(stringTokenizer.nextToken());
        stringTokenizer.nextToken();
        charDef.yoffset = Short.parseShort(stringTokenizer.nextToken());
        stringTokenizer.nextToken();
        charDef.xadvance = Short.parseShort(stringTokenizer.nextToken());
        charDef.init();
        if (charDef.id != 32) {
            this.lineHeight = Math.max(charDef.height + charDef.yoffset, this.lineHeight);
        }
        return charDef;
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s) {
        this.drawString(n, n2, s, Color.white);
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s, final Color color) {
        this.drawString(n, n2, s, color, 0, s.length() - 1);
    }
    
    @Override
    public void drawString(final float n, final float n2, final String key, final Color color, final int n3, final int n4) {
        this.fontImage.bind();
        color.bind();
        AngelCodeFont.GL.glTranslatef(n, n2, 0.0f);
        if (this.displayListCaching && n3 == 0 && n4 == key.length() - 1) {
            final DisplayList list = this.displayLists.get(key);
            if (list != null) {
                AngelCodeFont.GL.glCallList(list.id);
            }
            else {
                final DisplayList value = new DisplayList(null);
                value.text = key;
                final int size = this.displayLists.size();
                if (size < 200) {
                    value.id = this.baseDisplayListID + size;
                }
                else {
                    value.id = this.eldestDisplayListID;
                    this.displayLists.remove(this.eldestDisplayList.text);
                }
                this.displayLists.put(key, value);
                AngelCodeFont.GL.glNewList(value.id, 4865);
                this.render(key, n3, n4);
                AngelCodeFont.GL.glEndList();
            }
        }
        else {
            this.render(key, n3, n4);
        }
        AngelCodeFont.GL.glTranslatef(-n, -n2, 0.0f);
    }
    
    public void render(final String s, final int n, final int n2) {
        AngelCodeFont.GL.glBegin(7);
        int n3 = 0;
        int n4 = 0;
        CharDef charDef = null;
        final char[] charArray = s.toCharArray();
        for (int i = 0; i < charArray.length; ++i) {
            final char c = charArray[i];
            if (c == '\n') {
                n3 = 0;
                n4 += this.getLineHeight();
            }
            else if (c < this.chars.length) {
                final CharDef charDef2 = this.chars[c];
                if (charDef2 != null) {
                    if (charDef != null) {
                        n3 += charDef.getKerning(c);
                    }
                    charDef = charDef2;
                    if (i >= n && i <= n2) {
                        charDef2.draw((float)n3, (float)n4);
                    }
                    n3 += charDef2.xadvance;
                }
            }
        }
        AngelCodeFont.GL.glEnd();
    }
    
    public int getYOffset(final String key) {
        DisplayList list = null;
        if (this.displayListCaching) {
            list = this.displayLists.get(key);
            if (list != null && list.yOffset != null) {
                return list.yOffset;
            }
        }
        int n = key.indexOf(10);
        if (n == -1) {
            n = key.length();
        }
        int min = 10000;
        for (int i = 0; i < n; ++i) {
            final CharDef charDef = this.chars[key.charAt(i)];
            if (charDef != null) {
                min = Math.min(charDef.yoffset, min);
            }
        }
        if (list != null) {
            list.yOffset = new Short((short)min);
        }
        return min;
    }
    
    @Override
    public int getHeight(final String key) {
        DisplayList list = null;
        if (this.displayListCaching) {
            list = this.displayLists.get(key);
            if (list != null && list.height != null) {
                return list.height;
            }
        }
        int n = 0;
        int max = 0;
        for (int i = 0; i < key.length(); ++i) {
            final char char1 = key.charAt(i);
            if (char1 == '\n') {
                ++n;
                max = 0;
            }
            else if (char1 != ' ') {
                final CharDef charDef = this.chars[char1];
                if (charDef != null) {
                    max = Math.max(charDef.height + charDef.yoffset, max);
                }
            }
        }
        final int n2 = max + n * this.getLineHeight();
        if (list != null) {
            list.height = new Short((short)n2);
        }
        return n2;
    }
    
    @Override
    public int getWidth(final String key) {
        DisplayList list = null;
        if (this.displayListCaching) {
            list = this.displayLists.get(key);
            if (list != null && list.width != null) {
                return list.width;
            }
        }
        int max = 0;
        int b = 0;
        CharDef charDef = null;
        for (int i = 0, length = key.length(); i < length; ++i) {
            final char char1 = key.charAt(i);
            if (char1 == '\n') {
                b = 0;
            }
            else if (char1 < this.chars.length) {
                final CharDef charDef2 = this.chars[char1];
                if (charDef2 != null) {
                    if (charDef != null) {
                        b += charDef.getKerning(char1);
                    }
                    charDef = charDef2;
                    if (i < length - 1) {
                        b += charDef2.xadvance;
                    }
                    else {
                        b += charDef2.width;
                    }
                    max = Math.max(max, b);
                }
            }
        }
        if (list != null) {
            list.width = new Short((short)max);
        }
        return max;
    }
    
    @Override
    public int getLineHeight() {
        return this.lineHeight;
    }
    
    public static DisplayList access$002(final AngelCodeFont angelCodeFont, final DisplayList eldestDisplayList) {
        return angelCodeFont.eldestDisplayList = eldestDisplayList;
    }
    
    public static int access$102(final AngelCodeFont angelCodeFont, final int eldestDisplayListID) {
        return angelCodeFont.eldestDisplayListID = eldestDisplayListID;
    }
    
    public static DisplayList access$000(final AngelCodeFont angelCodeFont) {
        return angelCodeFont.eldestDisplayList;
    }
    
    public static Image access$400(final AngelCodeFont angelCodeFont) {
        return angelCodeFont.fontImage;
    }
    
    static {
        AngelCodeFont.MAX_CHAR = 255;
        AngelCodeFont.DISPLAY_LIST_CACHE_SIZE = 200;
        AngelCodeFont.GL = Renderer.get();
    }
    
    private class CharDef
    {
        public short id;
        public short x;
        public short y;
        public short width;
        public short height;
        public short xoffset;
        public short yoffset;
        public short xadvance;
        public Image image;
        public short dlIndex;
        public short[] kerning;
        public AngelCodeFont this$0;
        
        public CharDef(final AngelCodeFont this$0) {
            this.this$0 = this$0;
        }
        
        public void init() {
            this.image = AngelCodeFont.access$400(this.this$0).getSubImage(this.x, this.y, this.width, this.height);
        }
        
        @Override
        public String toString() {
            return "[CharDef id=" + this.id + " x=" + this.x + " y=" + this.y + "]";
        }
        
        public void draw(final float n, final float n2) {
            this.image.drawEmbedded(n + this.xoffset, n2 + this.yoffset, this.width, this.height);
        }
        
        public int getKerning(final int n) {
            if (this.kerning == null) {
                return 0;
            }
            int i = 0;
            int n2 = this.kerning.length - 1;
            while (i <= n2) {
                final int n3 = i + n2 >>> 1;
                final short n4 = this.kerning[n3];
                final int n5 = n4 & 0xFF;
                if (n5 < n) {
                    i = n3 + 1;
                }
                else {
                    if (n5 <= n) {
                        return n4 >> 8;
                    }
                    n2 = n3 - 1;
                }
            }
            return 0;
        }
        
        public CharDef(final AngelCodeFont angelCodeFont, final AngelCodeFont$1 linkedHashMap) {
            this(angelCodeFont);
        }
    }
    
    private static class DisplayList
    {
        public int id;
        public Short yOffset;
        public Short width;
        public Short height;
        public String text;
        
        public DisplayList() {
        }
        
        public DisplayList(final AngelCodeFont$1 linkedHashMap) {
            this();
        }
    }
}
