// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.lwjgl.Sys;
import org.newdawn.slick.util.Log;
import java.util.ArrayList;

public class Animation implements Renderable
{
    public ArrayList frames;
    public int currentFrame;
    public long nextChange;
    public boolean stopped;
    public long timeLeft;
    public float speed;
    public int stopAt;
    public long lastUpdate;
    public boolean firstUpdate;
    public boolean autoUpdate;
    public int direction;
    public boolean pingPong;
    public boolean loop;
    public SpriteSheet spriteSheet;
    
    public Animation() {
        this(true);
    }
    
    public Animation(final Image[] array, final int n) {
        this(array, n, true);
    }
    
    public Animation(final Image[] array, final int[] array2) {
        this(array, array2, true);
    }
    
    public Animation(final boolean autoUpdate) {
        this.frames = new ArrayList();
        this.currentFrame = -1;
        this.nextChange = ((long)1732042906 ^ 0x673CE09AL);
        this.stopped = false;
        this.speed = 1.0f;
        this.stopAt = -2;
        this.firstUpdate = true;
        this.autoUpdate = true;
        this.direction = 1;
        this.loop = true;
        this.spriteSheet = null;
        this.currentFrame = 0;
        this.autoUpdate = autoUpdate;
    }
    
    public Animation(final Image[] array, final int n, final boolean autoUpdate) {
        this.frames = new ArrayList();
        this.currentFrame = -1;
        this.nextChange = ((long)(-1410750539) ^ 0xFFFFFFFFABE9A7B5L);
        this.stopped = false;
        this.speed = 1.0f;
        this.stopAt = -2;
        this.firstUpdate = true;
        this.autoUpdate = true;
        this.direction = 1;
        this.loop = true;
        this.spriteSheet = null;
        for (int i = 0; i < array.length; ++i) {
            this.addFrame(array[i], n);
        }
        this.currentFrame = 0;
        this.autoUpdate = autoUpdate;
    }
    
    public Animation(final Image[] array, final int[] array2, final boolean autoUpdate) {
        this.frames = new ArrayList();
        this.currentFrame = -1;
        this.nextChange = ((long)1904302803 ^ 0x71815AD3L);
        this.stopped = false;
        this.speed = 1.0f;
        this.stopAt = -2;
        this.firstUpdate = true;
        this.autoUpdate = true;
        this.direction = 1;
        this.loop = true;
        this.spriteSheet = null;
        this.autoUpdate = autoUpdate;
        if (array.length != array2.length) {
            throw new RuntimeException("There must be one duration per frame");
        }
        for (int i = 0; i < array.length; ++i) {
            this.addFrame(array[i], array2[i]);
        }
        this.currentFrame = 0;
    }
    
    public Animation(final SpriteSheet spriteSheet, final int n) {
        this(spriteSheet, 0, 0, spriteSheet.getHorizontalCount() - 1, spriteSheet.getVerticalCount() - 1, true, n, true);
    }
    
    public Animation(final SpriteSheet spriteSheet, final int n, final int n2, final int n3, final int n4, final boolean b, final int n5, final boolean autoUpdate) {
        this.frames = new ArrayList();
        this.currentFrame = -1;
        this.nextChange = ((long)108649355 ^ 0x679DB8BL);
        this.stopped = false;
        this.speed = 1.0f;
        this.stopAt = -2;
        this.firstUpdate = true;
        this.autoUpdate = true;
        this.direction = 1;
        this.loop = true;
        this.spriteSheet = null;
        this.autoUpdate = autoUpdate;
        if (!b) {
            for (int i = n; i <= n3; ++i) {
                for (int j = n2; j <= n4; ++j) {
                    this.addFrame(spriteSheet.getSprite(i, j), n5);
                }
            }
        }
        else {
            for (int k = n2; k <= n4; ++k) {
                for (int l = n; l <= n3; ++l) {
                    this.addFrame(spriteSheet.getSprite(l, k), n5);
                }
            }
        }
    }
    
    public Animation(final SpriteSheet spriteSheet, final int[] array, final int[] array2) {
        this.frames = new ArrayList();
        this.currentFrame = -1;
        this.nextChange = ((long)1799585784 ^ 0x6B437FF8L);
        this.stopped = false;
        this.speed = 1.0f;
        this.stopAt = -2;
        this.firstUpdate = true;
        this.autoUpdate = true;
        this.direction = 1;
        this.loop = true;
        this.spriteSheet = null;
        this.spriteSheet = spriteSheet;
        for (int i = 0; i < array.length / 2; ++i) {
            this.addFrame(array2[i], array[i * 2], array[i * 2 + 1]);
        }
    }
    
    public void addFrame(final int n, final int n2, final int n3) {
        if (n == 0) {
            Log.error("Invalid duration: " + n);
            throw new RuntimeException("Invalid duration: " + n);
        }
        if (this.frames.isEmpty()) {
            this.nextChange = (int)(n / this.speed);
        }
        this.frames.add(new Frame(n, n2, n3));
        this.currentFrame = 0;
    }
    
    public void setAutoUpdate(final boolean autoUpdate) {
        this.autoUpdate = autoUpdate;
    }
    
    public void setPingPong(final boolean pingPong) {
        this.pingPong = pingPong;
    }
    
    public boolean isStopped() {
        return this.stopped;
    }
    
    public void setSpeed(final float speed) {
        if (speed > 0.0f) {
            this.nextChange = (long)(this.nextChange * this.speed / speed);
            this.speed = speed;
        }
    }
    
    public float getSpeed() {
        return this.speed;
    }
    
    public void stop() {
        if (this.frames.size() == 0) {
            return;
        }
        this.timeLeft = this.nextChange;
        this.stopped = true;
    }
    
    public void start() {
        if (!this.stopped) {
            return;
        }
        if (this.frames.size() == 0) {
            return;
        }
        this.stopped = false;
        this.nextChange = this.timeLeft;
    }
    
    public void restart() {
        if (this.frames.size() == 0) {
            return;
        }
        this.stopped = false;
        this.currentFrame = 0;
        this.nextChange = (int)(this.frames.get(0).duration / this.speed);
        this.firstUpdate = true;
        this.lastUpdate = ((long)1530404370 ^ 0x5B381E12L);
    }
    
    public void addFrame(final Image image, final int n) {
        if (n == 0) {
            Log.error("Invalid duration: " + n);
            throw new RuntimeException("Invalid duration: " + n);
        }
        if (this.frames.isEmpty()) {
            this.nextChange = (int)(n / this.speed);
        }
        this.frames.add(new Frame(image, n));
        this.currentFrame = 0;
    }
    
    public void draw() {
        this.draw(0.0f, 0.0f);
    }
    
    @Override
    public void draw(final float n, final float n2) {
        this.draw(n, n2, (float)this.getWidth(), (float)this.getHeight());
    }
    
    public void draw(final float n, final float n2, final Color color) {
        this.draw(n, n2, (float)this.getWidth(), (float)this.getHeight(), color);
    }
    
    public void draw(final float n, final float n2, final float n3, final float n4) {
        this.draw(n, n2, n3, n4, Color.white);
    }
    
    public void draw(final float n, final float n2, final float n3, final float n4, final Color color) {
        if (this.frames.size() == 0) {
            return;
        }
        if (this.autoUpdate) {
            final long time = this.getTime();
            long n5 = time - this.lastUpdate;
            if (this.firstUpdate) {
                n5 = ((long)(-1459361805) ^ 0xFFFFFFFFA903E7F3L);
                this.firstUpdate = false;
            }
            this.lastUpdate = time;
            this.nextFrame(n5);
        }
        this.frames.get(this.currentFrame).image.draw(n, n2, n3, n4, color);
    }
    
    public void renderInUse(final int n, final int n2) {
        if (this.frames.size() == 0) {
            return;
        }
        if (this.autoUpdate) {
            final long time = this.getTime();
            long n3 = time - this.lastUpdate;
            if (this.firstUpdate) {
                n3 = ((long)(-254395974) ^ 0xFFFFFFFFF0D639BAL);
                this.firstUpdate = false;
            }
            this.lastUpdate = time;
            this.nextFrame(n3);
        }
        final Frame frame = this.frames.get(this.currentFrame);
        this.spriteSheet.renderInUse(n, n2, frame.x, frame.y);
    }
    
    public int getWidth() {
        return this.frames.get(this.currentFrame).image.getWidth();
    }
    
    public int getHeight() {
        return this.frames.get(this.currentFrame).image.getHeight();
    }
    
    public void drawFlash(final float n, final float n2, final float n3, final float n4) {
        this.drawFlash(n, n2, n3, n4, Color.white);
    }
    
    public void drawFlash(final float n, final float n2, final float n3, final float n4, final Color color) {
        if (this.frames.size() == 0) {
            return;
        }
        if (this.autoUpdate) {
            final long time = this.getTime();
            long n5 = time - this.lastUpdate;
            if (this.firstUpdate) {
                n5 = ((long)(-1668285598) ^ 0xFFFFFFFF9C8FFB62L);
                this.firstUpdate = false;
            }
            this.lastUpdate = time;
            this.nextFrame(n5);
        }
        this.frames.get(this.currentFrame).image.drawFlash(n, n2, n3, n4, color);
    }
    
    @Deprecated
    public void updateNoDraw() {
        if (this.autoUpdate) {
            final long time = this.getTime();
            long n = time - this.lastUpdate;
            if (this.firstUpdate) {
                n = ((long)(-1261412514) ^ 0xFFFFFFFFB4D05F5EL);
                this.firstUpdate = false;
            }
            this.lastUpdate = time;
            this.nextFrame(n);
        }
    }
    
    public void update(final long n) {
        this.nextFrame(n);
    }
    
    public int getFrame() {
        return this.currentFrame;
    }
    
    public void setCurrentFrame(final int currentFrame) {
        this.currentFrame = currentFrame;
    }
    
    public Image getImage(final int index) {
        return this.frames.get(index).image;
    }
    
    public int getFrameCount() {
        return this.frames.size();
    }
    
    public Image getCurrentFrame() {
        return this.frames.get(this.currentFrame).image;
    }
    
    public void nextFrame(final long n) {
        if (this.stopped) {
            return;
        }
        if (this.frames.size() == 0) {
            return;
        }
        this.nextChange -= n;
        while (this.nextChange < ((long)(-655224653) ^ 0xFFFFFFFFD8F210B3L) && !this.stopped) {
            if (this.currentFrame == this.stopAt) {
                this.stopped = true;
                break;
            }
            if (this.currentFrame == this.frames.size() - 1 && !this.loop && !this.pingPong) {
                this.stopped = true;
                break;
            }
            this.currentFrame = (this.currentFrame + this.direction) % this.frames.size();
            if (this.pingPong) {
                if (this.currentFrame <= 0) {
                    this.currentFrame = 0;
                    this.direction = 1;
                    if (!this.loop) {
                        this.stopped = true;
                        break;
                    }
                }
                else if (this.currentFrame >= this.frames.size() - 1) {
                    this.currentFrame = this.frames.size() - 1;
                    this.direction = -1;
                }
            }
            this.nextChange += (int)(this.frames.get(this.currentFrame).duration / this.speed);
        }
    }
    
    public void setLooping(final boolean loop) {
        this.loop = loop;
    }
    
    public long getTime() {
        return Sys.getTime() * ((long)1814610718 ^ 0x6C28C0F6L) / Sys.getTimerResolution();
    }
    
    public void stopAt(final int stopAt) {
        this.stopAt = stopAt;
    }
    
    public int getDuration(final int index) {
        return this.frames.get(index).duration;
    }
    
    public void setDuration(final int index, final int duration) {
        this.frames.get(index).duration = duration;
    }
    
    public int[] getDurations() {
        final int[] array = new int[this.frames.size()];
        for (int i = 0; i < this.frames.size(); ++i) {
            array[i] = this.getDuration(i);
        }
        return array;
    }
    
    @Override
    public String toString() {
        String s = "[Animation (" + this.frames.size() + ") ";
        for (int i = 0; i < this.frames.size(); ++i) {
            s = s + ((Frame)this.frames.get(i)).duration + ",";
        }
        return s + "]";
    }
    
    public Animation copy() {
        final Animation animation = new Animation();
        animation.spriteSheet = this.spriteSheet;
        animation.frames = this.frames;
        animation.autoUpdate = this.autoUpdate;
        animation.direction = this.direction;
        animation.loop = this.loop;
        animation.pingPong = this.pingPong;
        animation.speed = this.speed;
        return animation;
    }
    
    public static SpriteSheet access$000(final Animation animation) {
        return animation.spriteSheet;
    }
    
    private class Frame
    {
        public Image image;
        public int duration;
        public int x;
        public int y;
        public Animation this$0;
        
        public Frame(final Animation this$0, final Image image, final int duration) {
            this.this$0 = this$0;
            this.x = -1;
            this.y = -1;
            this.image = image;
            this.duration = duration;
        }
        
        public Frame(final Animation this$0, final int duration, final int x, final int y) {
            this.this$0 = this$0;
            this.x = -1;
            this.y = -1;
            this.image = Animation.access$000(this$0).getSubImage(x, y);
            this.duration = duration;
            this.x = x;
            this.y = y;
        }
    }
}
