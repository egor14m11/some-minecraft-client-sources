// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import java.io.IOException;
import java.io.OutputStream;
import org.newdawn.slick.opengl.LoadableImageData;
import org.newdawn.slick.util.ResourceLoader;
import org.newdawn.slick.opengl.ImageIOImageData;
import org.newdawn.slick.opengl.TGAImageData;
import org.lwjgl.openal.AL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import org.newdawn.slick.util.Log;
import org.lwjgl.Sys;
import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.PixelFormat;
import org.newdawn.slick.openal.SoundStore;
import java.nio.ByteBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.input.Cursor;
import org.newdawn.slick.opengl.ImageData;
import org.lwjgl.input.Mouse;
import org.newdawn.slick.opengl.CursorLoader;
import org.newdawn.slick.opengl.InternalTextureLoader;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;

public class AppGameContainer extends GameContainer
{
    public DisplayMode originalDisplayMode;
    public DisplayMode targetDisplayMode;
    public boolean updateOnlyOnVisible;
    public boolean alphaSupport;
    
    public AppGameContainer(final Game game) throws SlickException {
        this(game, 640, 480, false);
    }
    
    public AppGameContainer(final Game game, final int n, final int n2, final boolean b) throws SlickException {
        super(game);
        this.updateOnlyOnVisible = true;
        this.alphaSupport = false;
        this.originalDisplayMode = Display.getDisplayMode();
        this.setDisplayMode(n, n2, b);
    }
    
    public boolean supportsAlphaInBackBuffer() {
        return this.alphaSupport;
    }
    
    public void setTitle(final String title) {
        Display.setTitle(title);
    }
    
    public void setDisplayMode(final int n, final int n2, final boolean b) throws SlickException {
        if (this.width == n && this.height == n2 && this.isFullscreen() == b) {
            return;
        }
        this.targetDisplayMode = null;
        if (b) {
            final DisplayMode[] availableDisplayModes = Display.getAvailableDisplayModes();
            int frequency = 0;
            for (int i = 0; i < availableDisplayModes.length; ++i) {
                final DisplayMode displayMode = availableDisplayModes[i];
                if (displayMode.getWidth() == n && displayMode.getHeight() == n2) {
                    if ((this.targetDisplayMode == null || displayMode.getFrequency() >= frequency) && (this.targetDisplayMode == null || displayMode.getBitsPerPixel() > this.targetDisplayMode.getBitsPerPixel())) {
                        this.targetDisplayMode = displayMode;
                        frequency = this.targetDisplayMode.getFrequency();
                    }
                    if (displayMode.getBitsPerPixel() == this.originalDisplayMode.getBitsPerPixel() && displayMode.getFrequency() == this.originalDisplayMode.getFrequency()) {
                        this.targetDisplayMode = displayMode;
                        break;
                    }
                }
            }
        }
        else {
            this.targetDisplayMode = new DisplayMode(n, n2);
        }
        if (this.targetDisplayMode == null) {
            throw new SlickException("Failed to find value mode: " + n + "x" + n2 + " fs=" + b);
        }
        this.width = n;
        this.height = n2;
        Display.setDisplayMode(this.targetDisplayMode);
        Display.setFullscreen(b);
        if (Display.isCreated()) {
            this.initGL();
            this.enterOrtho();
        }
        if (this.targetDisplayMode.getBitsPerPixel() == 16) {
            InternalTextureLoader.get().set16BitMode();
        }
        this.getDelta();
    }
    
    @Override
    public boolean isFullscreen() {
        return Display.isFullscreen();
    }
    
    @Override
    public void setFullscreen(final boolean fullscreen) throws SlickException {
        if (this.isFullscreen() == fullscreen) {
            return;
        }
        if (!fullscreen) {
            Display.setFullscreen(fullscreen);
        }
        else {
            this.setDisplayMode(this.width, this.height, fullscreen);
        }
        this.getDelta();
    }
    
    @Override
    public void setMouseCursor(final String s, final int n, final int n2) throws SlickException {
        Mouse.setNativeCursor(CursorLoader.get().getCursor(s, n, n2));
    }
    
    @Override
    public void setMouseCursor(final ImageData imageData, final int n, final int n2) throws SlickException {
        Mouse.setNativeCursor(CursorLoader.get().getCursor(imageData, n, n2));
    }
    
    @Override
    public void setMouseCursor(final Cursor nativeCursor, final int n, final int n2) throws SlickException {
        Mouse.setNativeCursor(nativeCursor);
    }
    
    public int get2Fold(final int n) {
        int i;
        for (i = 2; i < n; i *= 2) {}
        return i;
    }
    
    @Override
    public void setMouseCursor(final Image image, final int n, final int n2) throws SlickException {
        final Image image2 = new Image(this.get2Fold(image.getWidth()), this.get2Fold(image.getHeight()));
        final Graphics graphics = image2.getGraphics();
        final ByteBuffer byteBuffer = BufferUtils.createByteBuffer(image2.getWidth() * image2.getHeight() * 4);
        graphics.drawImage(image.getFlippedCopy(false, true), 0.0f, 0.0f);
        graphics.flush();
        graphics.getArea(0, 0, image2.getWidth(), image2.getHeight(), byteBuffer);
        Mouse.setNativeCursor(CursorLoader.get().getCursor(byteBuffer, n, n2, image2.getWidth(), image.getHeight()));
    }
    
    @Override
    public void reinit() throws SlickException {
        InternalTextureLoader.get().clear();
        SoundStore.get().clear();
        this.initSystem();
        this.enterOrtho();
        this.game.init(this);
    }
    
    public void tryCreateDisplay(final PixelFormat pixelFormat) throws LWJGLException {
        if (AppGameContainer.SHARED_DRAWABLE == null) {
            Display.create(pixelFormat);
        }
        else {
            Display.create(pixelFormat, AppGameContainer.SHARED_DRAWABLE);
        }
    }
    
    public void start() throws SlickException {
        this.setup();
        this.getDelta();
        while (this.running()) {
            this.gameLoop();
        }
        this.destroy();
        if (this.forceExit) {
            System.exit(0);
        }
    }
    
    public void setup() throws SlickException {
        if (this.targetDisplayMode == null) {
            this.setDisplayMode(640, 480, false);
        }
        Display.setTitle(this.game.getTitle());
        Log.info("LWJGL Version: " + Sys.getVersion());
        Log.info("OriginalDisplayMode: " + this.originalDisplayMode);
        Log.info("TargetDisplayMode: " + this.targetDisplayMode);
        AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction(this) {
            public AppGameContainer this$0;
            
            @Override
            public Object run() {
                AppGameContainer.access$000(this.this$0, new PixelFormat(8, 8, GameContainer.stencil ? 8 : 0, this.this$0.samples));
                this.this$0.supportsMultiSample = true;
                return null;
            }
        });
        if (!Display.isCreated()) {
            throw new SlickException("Failed to initialise the LWJGL display");
        }
        this.initSystem();
        this.enterOrtho();
        this.getInput().initControllers();
        this.game.init(this);
    }
    
    public void gameLoop() throws SlickException {
        final int delta = this.getDelta();
        if (!Display.isVisible() && this.updateOnlyOnVisible) {
            Thread.sleep((long)940704542 ^ 0x3812037AL);
        }
        else {
            this.updateAndRender(delta);
        }
        this.updateFPS();
        Display.update();
        if (Display.isCloseRequested() && this.game.closeRequested()) {
            this.running = false;
        }
    }
    
    @Override
    public void setUpdateOnlyWhenVisible(final boolean updateOnlyOnVisible) {
        this.updateOnlyOnVisible = updateOnlyOnVisible;
    }
    
    @Override
    public boolean isUpdatingOnlyWhenVisible() {
        return this.updateOnlyOnVisible;
    }
    
    @Override
    public void setIcon(final String s) throws SlickException {
        this.setIcons(new String[] { s });
    }
    
    @Override
    public void setMouseGrabbed(final boolean grabbed) {
        Mouse.setGrabbed(grabbed);
    }
    
    @Override
    public boolean isMouseGrabbed() {
        return Mouse.isGrabbed();
    }
    
    @Override
    public boolean hasFocus() {
        return Display.isActive();
    }
    
    @Override
    public int getScreenHeight() {
        return this.originalDisplayMode.getHeight();
    }
    
    @Override
    public int getScreenWidth() {
        return this.originalDisplayMode.getWidth();
    }
    
    public void destroy() {
        Display.destroy();
        AL.destroy();
    }
    
    @Override
    public void setIcons(final String[] array) throws SlickException {
        final ByteBuffer[] icon = new ByteBuffer[array.length];
        for (int i = 0; i < array.length; ++i) {
            boolean b = true;
            LoadableImageData loadableImageData;
            if (array[i].endsWith(".tga")) {
                loadableImageData = new TGAImageData();
            }
            else {
                b = false;
                loadableImageData = new ImageIOImageData();
            }
            icon[i] = loadableImageData.loadImage(ResourceLoader.getResourceAsStream(array[i]), b, false, null);
        }
        Display.setIcon(icon);
    }
    
    @Override
    public void setDefaultMouseCursor() {
        Mouse.setNativeCursor((Cursor)null);
    }
    
    public static void access$000(final AppGameContainer appGameContainer, final PixelFormat pixelFormat) throws LWJGLException {
        appGameContainer.tryCreateDisplay(pixelFormat);
    }
    
    static {
        AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction() {
            @Override
            public Object run() {
                Display.getDisplayMode();
                return null;
            }
        });
    }
    
    private class NullOutputStream extends OutputStream
    {
        public AppGameContainer this$0;
        
        public NullOutputStream(final AppGameContainer this$0) {
            this.this$0 = this$0;
        }
        
        @Override
        public void write(final int n) throws IOException {
        }
    }
}
