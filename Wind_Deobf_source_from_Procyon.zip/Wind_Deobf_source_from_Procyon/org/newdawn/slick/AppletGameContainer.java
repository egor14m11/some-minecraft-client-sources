// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import java.awt.GridLayout;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.awt.Label;
import java.awt.Font;
import java.awt.Color;
import java.awt.TextArea;
import java.awt.Panel;
import org.lwjgl.opengl.GL11;
import org.lwjgl.input.Cursor;
import org.newdawn.slick.opengl.ImageData;
import java.nio.ByteBuffer;
import org.lwjgl.BufferUtils;
import org.newdawn.slick.opengl.CursorLoader;
import org.lwjgl.input.Mouse;
import org.newdawn.slick.openal.SoundStore;
import org.newdawn.slick.opengl.InternalTextureLoader;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.PixelFormat;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import org.newdawn.slick.util.Log;
import java.awt.Component;
import java.awt.Canvas;
import java.applet.Applet;

public class AppletGameContainer extends Applet
{
    public ContainerPanel canvas;
    public Container container;
    public Canvas displayParent;
    public Thread gameThread;
    public boolean alphaSupport;
    
    public AppletGameContainer() {
        this.alphaSupport = true;
    }
    
    @Override
    public void destroy() {
        if (this.displayParent != null) {
            this.remove(this.displayParent);
        }
        super.destroy();
        Log.info("Clear up");
    }
    
    public void destroyLWJGL() {
        this.container.stopApplet();
        this.gameThread.join();
    }
    
    @Override
    public void start() {
    }
    
    public void startLWJGL() {
        if (this.gameThread != null) {
            return;
        }
        (this.gameThread = new Thread(this) {
            public AppletGameContainer this$0;
            
            @Override
            public void run() {
                this.this$0.canvas.start();
            }
        }).start();
    }
    
    @Override
    public void stop() {
    }
    
    @Override
    public void init() {
        this.removeAll();
        this.setLayout(new BorderLayout());
        this.setIgnoreRepaint(true);
        this.container = new Container((Game)Class.forName(this.getParameter("game")).newInstance());
        this.canvas = new ContainerPanel(this.container);
        (this.displayParent = new Canvas(this) {
            public AppletGameContainer this$0;
            
            @Override
            public void addNotify() {
                super.addNotify();
                this.this$0.startLWJGL();
            }
            
            @Override
            public void removeNotify() {
                AppletGameContainer.access$000(this.this$0);
                super.removeNotify();
            }
        }).setSize(this.getWidth(), this.getHeight());
        this.add(this.displayParent);
        this.displayParent.setFocusable(true);
        this.displayParent.requestFocus();
        this.displayParent.setIgnoreRepaint(true);
        this.setVisible(true);
    }
    
    public GameContainer getContainer() {
        return this.container;
    }
    
    public static void access$000(final AppletGameContainer appletGameContainer) {
        appletGameContainer.destroyLWJGL();
    }
    
    public class ContainerPanel
    {
        public Container container;
        public AppletGameContainer this$0;
        
        public ContainerPanel(final AppletGameContainer this$0, final Container container) {
            this.this$0 = this$0;
            this.container = container;
        }
        
        public void createDisplay() throws Exception {
            Display.create(new PixelFormat(8, 8, GameContainer.stencil ? 8 : 0));
            this.this$0.alphaSupport = true;
        }
        
        public void start() throws Exception {
            Display.setParent(this.this$0.displayParent);
            Display.setVSyncEnabled(true);
            this.createDisplay();
            this.initGL();
            this.this$0.displayParent.requestFocus();
            this.container.runloop();
        }
        
        public void initGL() {
            InternalTextureLoader.get().clear();
            SoundStore.get().clear();
            this.container.initApplet();
        }
    }
    
    public class Container extends GameContainer
    {
        public AppletGameContainer this$0;
        
        public Container(final AppletGameContainer this$0, final Game game) {
            this.this$0 = this$0;
            super(game);
            this.width = this$0.getWidth();
            this.height = this$0.getHeight();
        }
        
        public void initApplet() throws SlickException {
            this.initSystem();
            this.enterOrtho();
            this.getInput().initControllers();
            this.game.init(this);
            this.getDelta();
        }
        
        public boolean isRunning() {
            return this.running;
        }
        
        public void stopApplet() {
            this.running = false;
        }
        
        @Override
        public int getScreenHeight() {
            return 0;
        }
        
        @Override
        public int getScreenWidth() {
            return 0;
        }
        
        public boolean supportsAlphaInBackBuffer() {
            return this.this$0.alphaSupport;
        }
        
        @Override
        public boolean hasFocus() {
            return true;
        }
        
        public Applet getApplet() {
            return this.this$0;
        }
        
        @Override
        public void setIcon(final String s) throws SlickException {
        }
        
        @Override
        public void setMouseGrabbed(final boolean grabbed) {
            Mouse.setGrabbed(grabbed);
        }
        
        @Override
        public boolean isMouseGrabbed() {
            return Mouse.isGrabbed();
        }
        
        @Override
        public void setMouseCursor(final String s, final int n, final int n2) throws SlickException {
            Mouse.setNativeCursor(CursorLoader.get().getCursor(s, n, n2));
        }
        
        public int get2Fold(final int n) {
            int i;
            for (i = 2; i < n; i *= 2) {}
            return i;
        }
        
        @Override
        public void setMouseCursor(final Image image, final int n, final int n2) throws SlickException {
            final Image image2 = new Image(this.get2Fold(image.getWidth()), this.get2Fold(image.getHeight()));
            final Graphics graphics = image2.getGraphics();
            final ByteBuffer byteBuffer = BufferUtils.createByteBuffer(image2.getWidth() * image2.getHeight() * 4);
            graphics.drawImage(image.getFlippedCopy(false, true), 0.0f, 0.0f);
            graphics.flush();
            graphics.getArea(0, 0, image2.getWidth(), image2.getHeight(), byteBuffer);
            Mouse.setNativeCursor(CursorLoader.get().getCursor(byteBuffer, n, n2, image2.getWidth(), image2.getHeight()));
        }
        
        @Override
        public void setIcons(final String[] array) throws SlickException {
        }
        
        @Override
        public void setMouseCursor(final ImageData imageData, final int n, final int n2) throws SlickException {
            Mouse.setNativeCursor(CursorLoader.get().getCursor(imageData, n, n2));
        }
        
        @Override
        public void setMouseCursor(final Cursor nativeCursor, final int n, final int n2) throws SlickException {
            Mouse.setNativeCursor(nativeCursor);
        }
        
        @Override
        public void setDefaultMouseCursor() {
        }
        
        @Override
        public boolean isFullscreen() {
            return Display.isFullscreen();
        }
        
        @Override
        public void setFullscreen(final boolean b) throws SlickException {
            if (b == this.isFullscreen()) {
                return;
            }
            if (b) {
                final int width = Display.getDisplayMode().getWidth();
                final int height = Display.getDisplayMode().getHeight();
                int n;
                int n2;
                if (this.width / (float)this.height >= width / (float)height) {
                    n = width;
                    n2 = (int)(this.height / (this.width / (float)width));
                }
                else {
                    n = (int)(this.width / (this.height / (float)height));
                    n2 = height;
                }
                final int n3 = (width - n) / 2;
                final int n4 = (height - n2) / 2;
                GL11.glViewport(n3, n4, n, n2);
                this.enterOrtho();
                this.getInput().setOffset(-n3 * (float)this.width / n, -n4 * (float)this.height / n2);
                this.getInput().setScale(this.width / (float)n, this.height / (float)n2);
                this.width = width;
                this.height = height;
                Display.setFullscreen(true);
            }
            else {
                this.getInput().setOffset(0.0f, 0.0f);
                this.getInput().setScale(1.0f, 1.0f);
                this.width = this.this$0.getWidth();
                this.height = this.this$0.getHeight();
                GL11.glViewport(0, 0, this.width, this.height);
                this.enterOrtho();
                Display.setFullscreen(false);
            }
        }
        
        public void runloop() throws Exception {
            while (this.running) {
                this.updateAndRender(this.getDelta());
                this.updateFPS();
                Display.update();
            }
            Display.destroy();
        }
    }
    
    public class ConsolePanel extends Panel
    {
        public TextArea textArea;
        public AppletGameContainer this$0;
        
        public ConsolePanel(final AppletGameContainer this$0, final Exception ex) {
            this.this$0 = this$0;
            this.textArea = new TextArea();
            this.setLayout(new BorderLayout());
            this.setBackground(Color.black);
            this.setForeground(Color.white);
            final Font font = new Font("Arial", 1, 14);
            final Label comp = new Label("SLICK CONSOLE", 1);
            comp.setFont(font);
            this.add(comp, "First");
            final StringWriter out = new StringWriter();
            ex.printStackTrace(new PrintWriter(out));
            this.textArea.setText(out.toString());
            this.textArea.setEditable(false);
            this.add(this.textArea, "Center");
            this.add(new Panel(), "Before");
            this.add(new Panel(), "After");
            final Panel comp2 = new Panel();
            comp2.setLayout(new GridLayout(0, 1));
            final Label comp3 = new Label("An error occured while running the applet.", 1);
            final Label comp4 = new Label("Plese contact support to resolve this issue.", 1);
            comp3.setFont(font);
            comp4.setFont(font);
            comp2.add(comp3);
            comp2.add(comp4);
            this.add(comp2, "Last");
        }
    }
}
