// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

public abstract class BasicGame implements Game, InputListener
{
    public static int MAX_CONTROLLERS;
    public static int MAX_CONTROLLER_BUTTONS;
    public String title;
    public boolean[] controllerLeft;
    public boolean[] controllerRight;
    public boolean[] controllerUp;
    public boolean[] controllerDown;
    public boolean[][] controllerButton;
    
    public BasicGame(final String title) {
        this.controllerLeft = new boolean[20];
        this.controllerRight = new boolean[20];
        this.controllerUp = new boolean[20];
        this.controllerDown = new boolean[20];
        this.controllerButton = new boolean[20][100];
        this.title = title;
    }
    
    @Override
    public void setInput(final Input input) {
    }
    
    @Override
    public boolean closeRequested() {
        return true;
    }
    
    @Override
    public String getTitle() {
        return this.title;
    }
    
    @Override
    public abstract void init(final GameContainer p0) throws SlickException;
    
    @Override
    public void keyPressed(final int n, final char c) {
    }
    
    @Override
    public void keyReleased(final int n, final char c) {
    }
    
    @Override
    public void mouseMoved(final int n, final int n2, final int n3, final int n4) {
    }
    
    @Override
    public void mouseDragged(final int n, final int n2, final int n3, final int n4) {
    }
    
    @Override
    public void mouseClicked(final int n, final int n2, final int n3, final int n4) {
    }
    
    @Override
    public void mousePressed(final int n, final int n2, final int n3) {
    }
    
    @Override
    public void controllerButtonPressed(final int n, final int n2) {
        this.controllerButton[n][n2] = true;
    }
    
    @Override
    public void controllerButtonReleased(final int n, final int n2) {
        this.controllerButton[n][n2] = false;
    }
    
    @Override
    public void controllerDownPressed(final int n) {
        this.controllerDown[n] = true;
    }
    
    @Override
    public void controllerDownReleased(final int n) {
        this.controllerDown[n] = false;
    }
    
    @Override
    public void controllerLeftPressed(final int n) {
        this.controllerLeft[n] = true;
    }
    
    @Override
    public void controllerLeftReleased(final int n) {
        this.controllerLeft[n] = false;
    }
    
    @Override
    public void controllerRightPressed(final int n) {
        this.controllerRight[n] = true;
    }
    
    @Override
    public void controllerRightReleased(final int n) {
        this.controllerRight[n] = false;
    }
    
    @Override
    public void controllerUpPressed(final int n) {
        this.controllerUp[n] = true;
    }
    
    @Override
    public void controllerUpReleased(final int n) {
        this.controllerUp[n] = false;
    }
    
    @Override
    public void mouseReleased(final int n, final int n2, final int n3) {
    }
    
    @Override
    public abstract void update(final GameContainer p0, final int p1) throws SlickException;
    
    @Override
    public void mouseWheelMoved(final int n) {
    }
    
    @Override
    public boolean isAcceptingInput() {
        return true;
    }
    
    @Override
    public void inputEnded() {
    }
    
    @Override
    public void inputStarted() {
    }
    
    static {
        BasicGame.MAX_CONTROLLER_BUTTONS = 100;
        BasicGame.MAX_CONTROLLERS = 20;
    }
}
