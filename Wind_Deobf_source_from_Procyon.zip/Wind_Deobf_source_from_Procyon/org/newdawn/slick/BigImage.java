// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.util.OperationNotSupportedException;
import org.newdawn.slick.opengl.ImageData;
import org.newdawn.slick.util.ResourceLoader;
import org.newdawn.slick.opengl.ImageDataFactory;
import java.nio.ByteBuffer;
import org.newdawn.slick.opengl.LoadableImageData;
import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.newdawn.slick.opengl.renderer.SGL;

public class BigImage extends Image
{
    public static SGL GL;
    public static Image lastBind;
    public Image[][] images;
    public int xcount;
    public int ycount;
    public int realWidth;
    public int realHeight;
    
    public static int getMaxSingleImageSize() {
        final IntBuffer intBuffer = BufferUtils.createIntBuffer(16);
        BigImage.GL.glGetInteger(3379, intBuffer);
        return intBuffer.get(0);
    }
    
    public BigImage() {
        this.inited = true;
    }
    
    public BigImage(final String s) throws SlickException {
        this(s, 2);
    }
    
    public BigImage(final String s, final int n) throws SlickException {
        this.build(s, n, getMaxSingleImageSize());
    }
    
    public BigImage(final String s, final int n, final int n2) throws SlickException {
        this.build(s, n, n2);
    }
    
    public BigImage(final LoadableImageData loadableImageData, final ByteBuffer byteBuffer, final int n) {
        this.build(loadableImageData, byteBuffer, n, getMaxSingleImageSize());
    }
    
    public BigImage(final LoadableImageData loadableImageData, final ByteBuffer byteBuffer, final int n, final int n2) {
        this.build(loadableImageData, byteBuffer, n, n2);
    }
    
    public Image getTile(final int n, final int n2) {
        return this.images[n][n2];
    }
    
    public void build(final String s, final int n, final int n2) throws SlickException {
        final LoadableImageData imageData = ImageDataFactory.getImageDataFor(s);
        this.build(imageData, imageData.loadImage(ResourceLoader.getResourceAsStream(s), false, null), n, n2);
    }
    
    public void build(final LoadableImageData loadableImageData, final ByteBuffer byteBuffer, final int n, final int n2) {
        final int texWidth = loadableImageData.getTexWidth();
        final int texHeight = loadableImageData.getTexHeight();
        final int width = loadableImageData.getWidth();
        this.width = width;
        this.realWidth = width;
        final int height = loadableImageData.getHeight();
        this.height = height;
        this.realHeight = height;
        if (texWidth <= n2 && texHeight <= n2) {
            this.images = new Image[1][1];
            this.images[0][0] = new Image(new ImageData(this, loadableImageData, texHeight, byteBuffer, texWidth) {
                public LoadableImageData val$data;
                public int val$dataHeight;
                public ByteBuffer val$imageBuffer;
                public int val$dataWidth;
                public BigImage this$0;
                
                @Override
                public int getDepth() {
                    return this.val$data.getDepth();
                }
                
                @Override
                public int getHeight() {
                    return this.val$dataHeight;
                }
                
                @Override
                public ByteBuffer getImageBufferData() {
                    return this.val$imageBuffer;
                }
                
                @Override
                public int getTexHeight() {
                    return this.val$dataHeight;
                }
                
                @Override
                public int getTexWidth() {
                    return this.val$dataWidth;
                }
                
                @Override
                public int getWidth() {
                    return this.val$dataWidth;
                }
            }, n);
            this.xcount = 1;
            this.ycount = 1;
            this.inited = true;
            return;
        }
        this.xcount = (this.realWidth - 1) / n2 + 1;
        this.ycount = (this.realHeight - 1) / n2 + 1;
        this.images = new Image[this.xcount][this.ycount];
        final int n3 = loadableImageData.getDepth() / 8;
        for (int i = 0; i < this.xcount; ++i) {
            for (int j = 0; j < this.ycount; ++j) {
                final int min = Math.min(this.realWidth - i * n2, n2);
                final int min2 = Math.min(this.realHeight - j * n2, n2);
                final ByteBuffer byteBuffer2 = BufferUtils.createByteBuffer(n2 * n2 * n3);
                final int n4 = i * n2 * n3;
                final byte[] array = new byte[n2 * n3];
                for (int k = 0; k < n2; ++k) {
                    byteBuffer.position((j * n2 + k) * texWidth * n3 + n4);
                    byteBuffer.get(array, 0, n2 * n3);
                    byteBuffer2.put(array);
                }
                byteBuffer2.flip();
                this.images[i][j] = new Image(new ImageData(this, loadableImageData, min2, min, byteBuffer2, n2, n2) {
                    public LoadableImageData val$data;
                    public int val$imageHeight;
                    public int val$imageWidth;
                    public ByteBuffer val$subBuffer;
                    public int val$ySize;
                    public int val$xSize;
                    public BigImage this$0;
                    
                    @Override
                    public int getDepth() {
                        return this.val$data.getDepth();
                    }
                    
                    @Override
                    public int getHeight() {
                        return this.val$imageHeight;
                    }
                    
                    @Override
                    public int getWidth() {
                        return this.val$imageWidth;
                    }
                    
                    @Override
                    public ByteBuffer getImageBufferData() {
                        return this.val$subBuffer;
                    }
                    
                    @Override
                    public int getTexHeight() {
                        return this.val$ySize;
                    }
                    
                    @Override
                    public int getTexWidth() {
                        return this.val$xSize;
                    }
                }, n);
            }
        }
        this.inited = true;
    }
    
    @Override
    public void bind() {
        throw new OperationNotSupportedException("Can't bind big images yet");
    }
    
    @Override
    public Image copy() {
        throw new OperationNotSupportedException("Can't copy big images yet");
    }
    
    @Override
    public void draw() {
        this.draw(0.0f, 0.0f);
    }
    
    @Override
    public void draw(final float n, final float n2, final Color color) {
        this.draw(n, n2, (float)this.width, (float)this.height, color);
    }
    
    @Override
    public void draw(final float n, final float n2, final float n3, final Color color) {
        this.draw(n, n2, this.width * n3, this.height * n3, color);
    }
    
    @Override
    public void draw(final float n, final float n2, final float n3, final float n4, final Color color) {
        final float n5 = n3 / this.realWidth;
        final float n6 = n4 / this.realHeight;
        BigImage.GL.glTranslatef(n, n2, 0.0f);
        BigImage.GL.glScalef(n5, n6, 1.0f);
        float n7 = 0.0f;
        for (int i = 0; i < this.xcount; ++i) {
            float n8 = 0.0f;
            for (int j = 0; j < this.ycount; ++j) {
                final Image image = this.images[i][j];
                image.draw(n7, n8, (float)image.getWidth(), (float)image.getHeight(), color);
                n8 += image.getHeight();
                if (j == this.ycount - 1) {
                    n7 += image.getWidth();
                }
            }
        }
        BigImage.GL.glScalef(1.0f / n5, 1.0f / n6, 1.0f);
        BigImage.GL.glTranslatef(-n, -n2, 0.0f);
    }
    
    @Override
    public void draw(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8) {
        this.getSubImage((int)n5, (int)n6, (int)(n7 - n5), (int)(n8 - n6)).draw(n, n2, (float)(int)(n3 - n), (float)(int)(n4 - n2));
    }
    
    @Override
    public void draw(final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.draw(n, n2, (float)(int)(n5 - n3), (float)(int)(n6 - n4), n3, n4, n5, n6);
    }
    
    @Override
    public void draw(final float n, final float n2, final float n3, final float n4) {
        this.draw(n, n2, n3, n4, Color.white);
    }
    
    @Override
    public void draw(final float n, final float n2, final float n3) {
        this.draw(n, n2, n3, Color.white);
    }
    
    @Override
    public void draw(final float n, final float n2) {
        this.draw(n, n2, Color.white);
    }
    
    @Override
    public void drawEmbedded(final float n, final float n2, final float n3, final float n4) {
        final float n5 = n3 / this.realWidth;
        final float n6 = n4 / this.realHeight;
        float n7 = 0.0f;
        for (int i = 0; i < this.xcount; ++i) {
            float n8 = 0.0f;
            for (int j = 0; j < this.ycount; ++j) {
                final Image lastBind = this.images[i][j];
                if (BigImage.lastBind == null || lastBind.getTexture() != BigImage.lastBind.getTexture()) {
                    if (BigImage.lastBind != null) {
                        BigImage.lastBind.endUse();
                    }
                    (BigImage.lastBind = lastBind).startUse();
                }
                lastBind.drawEmbedded(n7 + n, n8 + n2, (float)lastBind.getWidth(), (float)lastBind.getHeight());
                n8 += lastBind.getHeight();
                if (j == this.ycount - 1) {
                    n7 += lastBind.getWidth();
                }
            }
        }
    }
    
    @Override
    public void drawFlash(final float n, final float n2, final float n3, final float n4) {
        final float n5 = n3 / this.realWidth;
        final float n6 = n4 / this.realHeight;
        BigImage.GL.glTranslatef(n, n2, 0.0f);
        BigImage.GL.glScalef(n5, n6, 1.0f);
        float n7 = 0.0f;
        for (int i = 0; i < this.xcount; ++i) {
            float n8 = 0.0f;
            for (int j = 0; j < this.ycount; ++j) {
                final Image image = this.images[i][j];
                image.drawFlash(n7, n8, (float)image.getWidth(), (float)image.getHeight());
                n8 += image.getHeight();
                if (j == this.ycount - 1) {
                    n7 += image.getWidth();
                }
            }
        }
        BigImage.GL.glScalef(1.0f / n5, 1.0f / n6, 1.0f);
        BigImage.GL.glTranslatef(-n, -n2, 0.0f);
    }
    
    @Override
    public void drawFlash(final float n, final float n2) {
        this.drawFlash(n, n2, (float)this.width, (float)this.height);
    }
    
    @Override
    public void endUse() {
        if (BigImage.lastBind != null) {
            BigImage.lastBind.endUse();
        }
        BigImage.lastBind = null;
    }
    
    @Override
    public void startUse() {
    }
    
    @Override
    public void ensureInverted() {
        throw new OperationNotSupportedException("Doesn't make sense for tiled operations");
    }
    
    @Override
    public Color getColor(final int n, final int n2) {
        throw new OperationNotSupportedException("Can't use big images as buffers");
    }
    
    @Override
    public Image getFlippedCopy(final boolean b, final boolean b2) {
        final BigImage bigImage = new BigImage();
        bigImage.images = this.images;
        bigImage.xcount = this.xcount;
        bigImage.ycount = this.ycount;
        bigImage.width = this.width;
        bigImage.height = this.height;
        bigImage.realWidth = this.realWidth;
        bigImage.realHeight = this.realHeight;
        if (b) {
            final Image[][] images = bigImage.images;
            bigImage.images = new Image[this.xcount][this.ycount];
            for (int i = 0; i < this.xcount; ++i) {
                for (int j = 0; j < this.ycount; ++j) {
                    bigImage.images[i][j] = images[this.xcount - 1 - i][j].getFlippedCopy(true, false);
                }
            }
        }
        if (b2) {
            final Image[][] images2 = bigImage.images;
            bigImage.images = new Image[this.xcount][this.ycount];
            for (int k = 0; k < this.xcount; ++k) {
                for (int l = 0; l < this.ycount; ++l) {
                    bigImage.images[k][l] = images2[k][this.ycount - 1 - l].getFlippedCopy(false, true);
                }
            }
        }
        return bigImage;
    }
    
    @Override
    public Graphics getGraphics() throws SlickException {
        throw new OperationNotSupportedException("Can't use big images as offscreen buffers");
    }
    
    @Override
    public Image getScaledCopy(final float n) {
        return this.getScaledCopy((int)(n * this.width), (int)(n * this.height));
    }
    
    @Override
    public Image getScaledCopy(final int width, final int height) {
        final BigImage bigImage = new BigImage();
        bigImage.images = this.images;
        bigImage.xcount = this.xcount;
        bigImage.ycount = this.ycount;
        bigImage.width = width;
        bigImage.height = height;
        bigImage.realWidth = this.realWidth;
        bigImage.realHeight = this.realHeight;
        return bigImage;
    }
    
    @Override
    public Image getSubImage(final int n, final int n2, final int n3, final int n4) {
        final BigImage bigImage = new BigImage();
        bigImage.width = n3;
        bigImage.height = n4;
        bigImage.realWidth = n3;
        bigImage.realHeight = n4;
        bigImage.images = new Image[this.xcount][this.ycount];
        float b = 0.0f;
        final int a = n + n3;
        final int a2 = n2 + n4;
        int n5 = 0;
        for (int i = 0; i < this.xcount; ++i) {
            float b2 = 0.0f;
            int b3 = 0;
            boolean b4 = false;
            for (int j = 0; j < this.ycount; ++j) {
                final Image image = this.images[i][j];
                final int b5 = (int)(b + image.getWidth());
                final int b6 = (int)(b2 + image.getHeight());
                final int n6 = (int)Math.max((float)n, b);
                final int n7 = (int)Math.max((float)n2, b2);
                final int min = Math.min(a, b5);
                final int min2 = Math.min(a2, b6);
                final int n8 = min - n6;
                final int n9 = min2 - n7;
                if (n8 > 0 && n9 > 0) {
                    final Image subImage = image.getSubImage((int)(n6 - b), (int)(n7 - b2), min - n6, min2 - n7);
                    b4 = true;
                    bigImage.images[n5][b3] = subImage;
                    ++b3;
                    bigImage.ycount = Math.max(bigImage.ycount, b3);
                }
                b2 += image.getHeight();
                if (j == this.ycount - 1) {
                    b += image.getWidth();
                }
            }
            if (b4) {
                ++n5;
                final BigImage bigImage2 = bigImage;
                ++bigImage2.xcount;
            }
        }
        return bigImage;
    }
    
    @Override
    public Texture getTexture() {
        throw new OperationNotSupportedException("Can't use big images as offscreen buffers");
    }
    
    @Override
    public void initImpl() {
        throw new OperationNotSupportedException("Can't use big images as offscreen buffers");
    }
    
    @Override
    public void reinit() {
        throw new OperationNotSupportedException("Can't use big images as offscreen buffers");
    }
    
    @Override
    public void setTexture(final Texture texture) {
        throw new OperationNotSupportedException("Can't use big images as offscreen buffers");
    }
    
    public Image getSubImage(final int n, final int n2) {
        return this.images[n][n2];
    }
    
    public int getHorizontalImageCount() {
        return this.xcount;
    }
    
    public int getVerticalImageCount() {
        return this.ycount;
    }
    
    @Override
    public String toString() {
        return "[BIG IMAGE]";
    }
    
    @Override
    public void destroy() throws SlickException {
        for (int i = 0; i < this.xcount; ++i) {
            for (int j = 0; j < this.ycount; ++j) {
                this.images[i][j].destroy();
            }
        }
    }
    
    @Override
    public void draw(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8, final Color color) {
        this.getSubImage((int)n5, (int)n6, (int)(n7 - n5), (int)(n8 - n6)).draw(n, n2, (float)(int)(n3 - n), (float)(int)(n4 - n2), color);
    }
    
    @Override
    public void drawCentered(final float n, final float n2) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void drawEmbedded(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8, final Color color) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void drawEmbedded(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void drawFlash(final float n, final float n2, final float n3, final float n4, final Color color) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void drawSheared(final float n, final float n2, final float n3, final float n4) {
        throw new UnsupportedOperationException();
    }
    
    static {
        BigImage.GL = Renderer.get();
    }
}
