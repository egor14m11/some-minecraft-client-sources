// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import javax.swing.SwingUtilities;
import org.lwjgl.opengl.Display;
import java.awt.Canvas;

public class CanvasGameContainer extends Canvas
{
    public Container container;
    public Game game;
    
    public CanvasGameContainer(final Game game) throws SlickException {
        this(game, false);
    }
    
    public CanvasGameContainer(final Game game, final boolean b) throws SlickException {
        this.game = game;
        this.setIgnoreRepaint(true);
        this.requestFocus();
        this.setSize(500, 500);
        (this.container = new Container(game, b)).setForceExit(false);
    }
    
    public void start() throws SlickException {
        SwingUtilities.invokeLater(new Runnable(this) {
            public CanvasGameContainer this$0;
            
            @Override
            public void run() {
                Input.disableControllers();
                Display.setParent((Canvas)this.this$0);
                this.this$0.container.setup();
                CanvasGameContainer.access$000(this.this$0);
            }
        });
    }
    
    public void scheduleUpdate() {
        if (!this.isVisible()) {
            return;
        }
        SwingUtilities.invokeLater(new Runnable(this) {
            public CanvasGameContainer this$0;
            
            @Override
            public void run() {
                this.this$0.container.gameLoop();
                this.this$0.container.checkDimensions();
                CanvasGameContainer.access$000(this.this$0);
            }
        });
    }
    
    public void dispose() {
    }
    
    public GameContainer getContainer() {
        return this.container;
    }
    
    public static void access$000(final CanvasGameContainer canvasGameContainer) {
        canvasGameContainer.scheduleUpdate();
    }
    
    private class Container extends AppGameContainer
    {
        public CanvasGameContainer this$0;
        
        public Container(final CanvasGameContainer this$0, final Game game, final boolean b) throws SlickException {
            this.this$0 = this$0;
            super(game, this$0.getWidth(), this$0.getHeight(), false);
            this.width = this$0.getWidth();
            this.height = this$0.getHeight();
            if (b) {
                enableSharedContext();
            }
        }
        
        @Override
        public void updateFPS() {
            super.updateFPS();
        }
        
        @Override
        public boolean running() {
            return super.running() && this.this$0.isDisplayable();
        }
        
        @Override
        public int getHeight() {
            return this.this$0.getHeight();
        }
        
        @Override
        public int getWidth() {
            return this.this$0.getWidth();
        }
        
        public void checkDimensions() {
            if (this.width != this.this$0.getWidth() || this.height != this.this$0.getHeight()) {
                this.setDisplayMode(this.this$0.getWidth(), this.this$0.getHeight(), false);
            }
        }
    }
}
