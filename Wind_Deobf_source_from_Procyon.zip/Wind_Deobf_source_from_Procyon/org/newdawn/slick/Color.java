// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import java.nio.FloatBuffer;
import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.opengl.renderer.SGL;
import java.io.Serializable;

public class Color implements Serializable
{
    public static long serialVersionUID;
    public transient SGL GL;
    public static Color transparent;
    public static Color white;
    public static Color yellow;
    public static Color red;
    public static Color blue;
    public static Color green;
    public static Color black;
    public static Color gray;
    public static Color cyan;
    public static Color darkGray;
    public static Color lightGray;
    public static Color pink;
    public static Color orange;
    public static Color magenta;
    public float r;
    public float g;
    public float b;
    public float a;
    
    public Color(final Color color) {
        this.GL = Renderer.get();
        this.a = 1.0f;
        this.r = color.r;
        this.g = color.g;
        this.b = color.b;
        this.a = color.a;
    }
    
    public Color(final java.awt.Color color) {
        this.GL = Renderer.get();
        this.a = 1.0f;
        this.r = color.getRed() / 255.0f;
        this.g = color.getGreen() / 255.0f;
        this.b = color.getBlue() / 255.0f;
    }
    
    public Color(final FloatBuffer floatBuffer) {
        this.GL = Renderer.get();
        this.a = 1.0f;
        this.r = floatBuffer.get();
        this.g = floatBuffer.get();
        this.b = floatBuffer.get();
        this.a = floatBuffer.get();
    }
    
    public Color(final float r, final float g, final float b) {
        this.GL = Renderer.get();
        this.a = 1.0f;
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = 1.0f;
    }
    
    public Color(final float a, final float a2, final float a3, final float a4) {
        this.GL = Renderer.get();
        this.a = 1.0f;
        this.r = Math.min(a, 1.0f);
        this.g = Math.min(a2, 1.0f);
        this.b = Math.min(a3, 1.0f);
        this.a = Math.min(a4, 1.0f);
    }
    
    public Color(final int n, final int n2, final int n3) {
        this.GL = Renderer.get();
        this.a = 1.0f;
        this.r = n / 255.0f;
        this.g = n2 / 255.0f;
        this.b = n3 / 255.0f;
        this.a = 1.0f;
    }
    
    public Color(final int n, final int n2, final int n3, final int n4) {
        this.GL = Renderer.get();
        this.a = 1.0f;
        this.r = n / 255.0f;
        this.g = n2 / 255.0f;
        this.b = n3 / 255.0f;
        this.a = n4 / 255.0f;
    }
    
    public Color(final int n) {
        this.GL = Renderer.get();
        this.a = 1.0f;
        final int n2 = (n & 0xFF0000) >> 16;
        final int n3 = (n & 0xFF00) >> 8;
        final int n4 = n & 0xFF;
        int n5 = (n & 0xFF000000) >> 24;
        if (n5 < 0) {
            n5 += 256;
        }
        if (n5 == 0) {
            n5 = 255;
        }
        this.r = n2 / 255.0f;
        this.g = n3 / 255.0f;
        this.b = n4 / 255.0f;
        this.a = n5 / 255.0f;
    }
    
    public static Color decode(final String nm) {
        return new Color(Integer.decode(nm));
    }
    
    public void bind() {
        this.GL.glColor4f(this.r, this.g, this.b, this.a);
    }
    
    @Override
    public int hashCode() {
        return (int)(this.r + this.g + this.b + this.a) * 255;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o instanceof Color) {
            final Color color = (Color)o;
            return color.r == this.r && color.g == this.g && color.b == this.b && color.a == this.a;
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "Color (" + this.r + "," + this.g + "," + this.b + "," + this.a + ")";
    }
    
    public Color darker() {
        return this.darker(0.0f);
    }
    
    public Color darker(float n) {
        n = 1.0f - n;
        return new Color(this.r * n, this.g * n, this.b * n, this.a);
    }
    
    public Color brighter() {
        return this.brighter(0.0f);
    }
    
    public int getRed() {
        return (int)(this.r * 255.0f);
    }
    
    public int getGreen() {
        return (int)(this.g * 255.0f);
    }
    
    public int getBlue() {
        return (int)(this.b * 255.0f);
    }
    
    public int getAlpha() {
        return (int)(this.a * 255.0f);
    }
    
    public int getRedByte() {
        return (int)(this.r * 255.0f);
    }
    
    public int getGreenByte() {
        return (int)(this.g * 255.0f);
    }
    
    public int getBlueByte() {
        return (int)(this.b * 255.0f);
    }
    
    public int getAlphaByte() {
        return (int)(this.a * 255.0f);
    }
    
    public Color brighter(float n) {
        ++n;
        return new Color(this.r * n, this.g * n, this.b * n, this.a);
    }
    
    public Color multiply(final Color color) {
        return new Color(this.r * color.r, this.g * color.g, this.b * color.b, this.a * color.a);
    }
    
    public void add(final Color color) {
        this.r += color.r;
        this.g += color.g;
        this.b += color.b;
        this.a += color.a;
    }
    
    public void scale(final float n) {
        this.r *= n;
        this.g *= n;
        this.b *= n;
        this.a *= n;
    }
    
    public Color addToCopy(final Color color) {
        final Color color3;
        final Color color2 = color3 = new Color(this.r, this.g, this.b, this.a);
        color3.r += color.r;
        final Color color4 = color2;
        color4.g += color.g;
        final Color color5 = color2;
        color5.b += color.b;
        final Color color6 = color2;
        color6.a += color.a;
        return color2;
    }
    
    public Color scaleCopy(final float n) {
        final Color color2;
        final Color color = color2 = new Color(this.r, this.g, this.b, this.a);
        color2.r *= n;
        final Color color3 = color;
        color3.g *= n;
        final Color color4 = color;
        color4.b *= n;
        final Color color5 = color;
        color5.a *= n;
        return color;
    }
    
    static {
        Color.serialVersionUID = ((long)2033261791 ^ 0x792459CCL);
        Color.transparent = new Color(0.0f, 0.0f, 0.0f, 0.0f);
        Color.white = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        Color.yellow = new Color(1.0f, 1.0f, 0.0f, 1.0f);
        Color.red = new Color(1.0f, 0.0f, 0.0f, 1.0f);
        Color.blue = new Color(0.0f, 0.0f, 1.0f, 1.0f);
        Color.green = new Color(0.0f, 1.0f, 0.0f, 1.0f);
        Color.black = new Color(0.0f, 0.0f, 0.0f, 1.0f);
        Color.gray = new Color(0.0f, 0.0f, 0.0f, 1.0f);
        Color.cyan = new Color(0.0f, 1.0f, 1.0f, 1.0f);
        Color.darkGray = new Color(0.0f, 0.0f, 0.0f, 1.0f);
        Color.lightGray = new Color(0.0f, 0.0f, 0.0f, 1.0f);
        Color.pink = new Color(255, 175, 175, 255);
        Color.orange = new Color(255, 200, 0, 255);
        Color.magenta = new Color(255, 0, 255, 255);
    }
}
