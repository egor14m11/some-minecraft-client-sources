// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.util.FastTrig;
import org.newdawn.slick.geom.ShapeRenderer;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.opengl.TextureImpl;
import java.nio.FloatBuffer;
import java.security.AccessController;
import java.security.PrivilegedAction;
import org.lwjgl.BufferUtils;
import java.util.ArrayList;
import java.nio.ByteBuffer;
import java.nio.DoubleBuffer;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.opengl.renderer.LineStripRenderer;
import org.newdawn.slick.opengl.renderer.SGL;

public class Graphics
{
    public static SGL GL;
    public static LineStripRenderer LSR;
    public static int MODE_NORMAL;
    public static int MODE_ALPHA_MAP;
    public static int MODE_ALPHA_BLEND;
    public static int MODE_COLOR_MULTIPLY;
    public static int MODE_ADD;
    public static int MODE_SCREEN;
    public static int DEFAULT_SEGMENTS;
    public static Graphics currentGraphics;
    public static Font DEFAULT_FONT;
    public float sx;
    public float sy;
    public Font font;
    public Color currentColor;
    public int screenWidth;
    public int screenHeight;
    public boolean pushed;
    public Rectangle clip;
    public DoubleBuffer worldClip;
    public ByteBuffer readBuffer;
    public boolean antialias;
    public Rectangle worldClipRecord;
    public int currentDrawingMode;
    public float lineWidth;
    public ArrayList stack;
    public int stackIndex;
    
    public static void setCurrent(final Graphics currentGraphics) {
        if (Graphics.currentGraphics != currentGraphics) {
            if (Graphics.currentGraphics != null) {
                Graphics.currentGraphics.disable();
            }
            (Graphics.currentGraphics = currentGraphics).enable();
        }
    }
    
    public Graphics() {
        this.sx = 1.0f;
        this.sy = 1.0f;
        this.currentColor = Color.white;
        this.worldClip = BufferUtils.createDoubleBuffer(4);
        this.readBuffer = BufferUtils.createByteBuffer(4);
        this.currentDrawingMode = Graphics.MODE_NORMAL;
        this.lineWidth = 1.0f;
        this.stack = new ArrayList();
    }
    
    public Graphics(final int screenWidth, final int screenHeight) {
        this.sx = 1.0f;
        this.sy = 1.0f;
        this.currentColor = Color.white;
        this.worldClip = BufferUtils.createDoubleBuffer(4);
        this.readBuffer = BufferUtils.createByteBuffer(4);
        this.currentDrawingMode = Graphics.MODE_NORMAL;
        this.lineWidth = 1.0f;
        this.stack = new ArrayList();
        if (Graphics.DEFAULT_FONT == null) {
            AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction(this) {
                public Graphics this$0;
                
                @Override
                public Object run() {
                    Graphics.DEFAULT_FONT = new AngelCodeFont("org/newdawn/slick/data/defaultfont.fnt", "org/newdawn/slick/data/defaultfont.png");
                    return null;
                }
            });
        }
        this.font = Graphics.DEFAULT_FONT;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
    }
    
    public void setDimensions(final int screenWidth, final int screenHeight) {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
    }
    
    public void setDrawMode(final int currentDrawingMode) {
        this.predraw();
        this.currentDrawingMode = currentDrawingMode;
        if (this.currentDrawingMode == Graphics.MODE_NORMAL) {
            Graphics.GL.glEnable(3042);
            Graphics.GL.glColorMask(true, true, true, true);
            Graphics.GL.glBlendFunc(770, 771);
        }
        if (this.currentDrawingMode == Graphics.MODE_ALPHA_MAP) {
            Graphics.GL.glDisable(3042);
            Graphics.GL.glColorMask(false, false, false, true);
        }
        if (this.currentDrawingMode == Graphics.MODE_ALPHA_BLEND) {
            Graphics.GL.glEnable(3042);
            Graphics.GL.glColorMask(true, true, true, false);
            Graphics.GL.glBlendFunc(772, 773);
        }
        if (this.currentDrawingMode == Graphics.MODE_COLOR_MULTIPLY) {
            Graphics.GL.glEnable(3042);
            Graphics.GL.glColorMask(true, true, true, true);
            Graphics.GL.glBlendFunc(769, 768);
        }
        if (this.currentDrawingMode == Graphics.MODE_ADD) {
            Graphics.GL.glEnable(3042);
            Graphics.GL.glColorMask(true, true, true, true);
            Graphics.GL.glBlendFunc(1, 1);
        }
        if (this.currentDrawingMode == Graphics.MODE_SCREEN) {
            Graphics.GL.glEnable(3042);
            Graphics.GL.glColorMask(true, true, true, true);
            Graphics.GL.glBlendFunc(1, 769);
        }
        this.postdraw();
    }
    
    public void clearAlphaMap() {
        this.pushTransform();
        Graphics.GL.glLoadIdentity();
        final int currentDrawingMode = this.currentDrawingMode;
        this.setDrawMode(Graphics.MODE_ALPHA_MAP);
        this.setColor(new Color(0, 0, 0, 0));
        this.fillRect(0.0f, 0.0f, (float)this.screenWidth, (float)this.screenHeight);
        this.setColor(this.currentColor);
        this.setDrawMode(currentDrawingMode);
        this.popTransform();
    }
    
    public void predraw() {
        setCurrent(this);
    }
    
    public void postdraw() {
    }
    
    public void enable() {
    }
    
    public void flush() {
        if (Graphics.currentGraphics == this) {
            Graphics.currentGraphics.disable();
            Graphics.currentGraphics = null;
        }
    }
    
    public void disable() {
    }
    
    public Font getFont() {
        return this.font;
    }
    
    public void setBackground(final Color color) {
        this.predraw();
        Graphics.GL.glClearColor(color.r, color.g, color.b, color.a);
        this.postdraw();
    }
    
    public Color getBackground() {
        this.predraw();
        final FloatBuffer floatBuffer = BufferUtils.createFloatBuffer(16);
        Graphics.GL.glGetFloat(3106, floatBuffer);
        this.postdraw();
        return new Color(floatBuffer);
    }
    
    public void clear() {
        this.predraw();
        Graphics.GL.glClear(16384);
        this.postdraw();
    }
    
    public void resetTransform() {
        this.sx = 1.0f;
        this.sy = 1.0f;
        if (this.pushed) {
            this.predraw();
            Graphics.GL.glPopMatrix();
            this.pushed = false;
            this.postdraw();
        }
    }
    
    public void checkPush() {
        if (!this.pushed) {
            this.predraw();
            Graphics.GL.glPushMatrix();
            this.pushed = true;
            this.postdraw();
        }
    }
    
    public void scale(final float n, final float n2) {
        this.sx *= n;
        this.sy *= n2;
        this.checkPush();
        this.predraw();
        Graphics.GL.glScalef(n, n2, 1.0f);
        this.postdraw();
    }
    
    public void rotate(final float n, final float n2, final float n3) {
        this.checkPush();
        this.predraw();
        this.translate(n, n2);
        Graphics.GL.glRotatef(n3, 0.0f, 0.0f, 1.0f);
        this.translate(-n, -n2);
        this.postdraw();
    }
    
    public void translate(final float n, final float n2) {
        this.checkPush();
        this.predraw();
        Graphics.GL.glTranslatef(n, n2, 0.0f);
        this.postdraw();
    }
    
    public void setFont(final Font font) {
        this.font = font;
    }
    
    public void resetFont() {
        this.font = Graphics.DEFAULT_FONT;
    }
    
    public void setColor(final Color color) {
        if (color == null) {
            return;
        }
        this.currentColor = new Color(color);
        this.predraw();
        this.currentColor.bind();
        this.postdraw();
    }
    
    public Color getColor() {
        return new Color(this.currentColor);
    }
    
    public void drawLine(float n, float n2, float n3, float n4) {
        final float n5 = this.lineWidth - 1.0f;
        if (Graphics.LSR.applyGLLineFixes()) {
            if (n == n3) {
                if (n2 > n4) {
                    final float n6 = n4;
                    n4 = n2;
                    n2 = n6;
                }
                final float n7 = 1.0f / this.sy;
                final float n8 = n5 / this.sy;
                this.fillRect(n - n8 / 2.0f, n2 - n8 / 2.0f, n8 + n7, n4 - n2 + n8 + n7);
                return;
            }
            if (n2 == n4) {
                if (n > n3) {
                    final float n9 = n3;
                    n3 = n;
                    n = n9;
                }
                final float n10 = 1.0f / this.sx;
                final float n11 = n5 / this.sx;
                this.fillRect(n - n11 / 2.0f, n2 - n11 / 2.0f, n3 - n + n11 + n10, n11 + n10);
                return;
            }
        }
        this.predraw();
        this.currentColor.bind();
        TextureImpl.bindNone();
        Graphics.LSR.start();
        Graphics.LSR.vertex(n, n2);
        Graphics.LSR.vertex(n3, n4);
        Graphics.LSR.end();
        this.postdraw();
    }
    
    public void draw(final Shape shape, final ShapeFill shapeFill) {
        this.predraw();
        TextureImpl.bindNone();
        ShapeRenderer.draw(shape, shapeFill);
        this.currentColor.bind();
        this.postdraw();
    }
    
    public void fill(final Shape shape, final ShapeFill shapeFill) {
        this.predraw();
        TextureImpl.bindNone();
        ShapeRenderer.fill(shape, shapeFill);
        this.currentColor.bind();
        this.postdraw();
    }
    
    public void draw(final Shape shape) {
        this.predraw();
        TextureImpl.bindNone();
        this.currentColor.bind();
        ShapeRenderer.draw(shape);
        this.postdraw();
    }
    
    public void fill(final Shape shape) {
        this.predraw();
        TextureImpl.bindNone();
        this.currentColor.bind();
        ShapeRenderer.fill(shape);
        this.postdraw();
    }
    
    public void texture(final Shape shape, final Image image) {
        this.texture(shape, image, 0.0f, 0.0f, false);
    }
    
    public void texture(final Shape shape, final Image image, final ShapeFill shapeFill) {
        this.texture(shape, image, 0.0f, 0.0f, shapeFill);
    }
    
    public void texture(final Shape shape, final Image image, final boolean b) {
        if (b) {
            this.texture(shape, image, 1.0f, 1.0f, true);
        }
        else {
            this.texture(shape, image, 0.0f, 0.0f, false);
        }
    }
    
    public void texture(final Shape shape, final Image image, final float n, final float n2) {
        this.texture(shape, image, n, n2, false);
    }
    
    public void texture(final Shape shape, final Image image, final float n, final float n2, final boolean b) {
        this.predraw();
        TextureImpl.bindNone();
        this.currentColor.bind();
        if (b) {
            ShapeRenderer.textureFit(shape, image, n, n2);
        }
        else {
            ShapeRenderer.texture(shape, image, n, n2);
        }
        this.postdraw();
    }
    
    public void texture(final Shape shape, final Image image, final float n, final float n2, final ShapeFill shapeFill) {
        this.predraw();
        TextureImpl.bindNone();
        this.currentColor.bind();
        ShapeRenderer.texture(shape, image, n, n2, shapeFill);
        this.postdraw();
    }
    
    public void drawRect(final float n, final float n2, final float n3, final float n4) {
        this.getLineWidth();
        this.drawLine(n, n2, n + n3, n2);
        this.drawLine(n + n3, n2, n + n3, n2 + n4);
        this.drawLine(n + n3, n2 + n4, n, n2 + n4);
        this.drawLine(n, n2 + n4, n, n2);
    }
    
    public void clearClip() {
        this.clip = null;
        this.predraw();
        Graphics.GL.glDisable(3089);
        this.postdraw();
    }
    
    public void setWorldClip(final float n, final float n2, final float n3, final float n4) {
        this.predraw();
        this.worldClipRecord = new Rectangle(n, n2, n3, n4);
        Graphics.GL.glEnable(12288);
        this.worldClip.put(1.0).put(0.0).put(0.0).put(-n).flip();
        Graphics.GL.glClipPlane(12288, this.worldClip);
        Graphics.GL.glEnable(12289);
        this.worldClip.put(-1.0).put(0.0).put(0.0).put(n + n3).flip();
        Graphics.GL.glClipPlane(12289, this.worldClip);
        Graphics.GL.glEnable(12290);
        this.worldClip.put(0.0).put(1.0).put(0.0).put(-n2).flip();
        Graphics.GL.glClipPlane(12290, this.worldClip);
        Graphics.GL.glEnable(12291);
        this.worldClip.put(0.0).put(-1.0).put(0.0).put(n2 + n4).flip();
        Graphics.GL.glClipPlane(12291, this.worldClip);
        this.postdraw();
    }
    
    public void clearWorldClip() {
        this.predraw();
        this.worldClipRecord = null;
        Graphics.GL.glDisable(12288);
        Graphics.GL.glDisable(12289);
        Graphics.GL.glDisable(12290);
        Graphics.GL.glDisable(12291);
        this.postdraw();
    }
    
    public void setWorldClip(final Rectangle rectangle) {
        if (rectangle == null) {
            this.clearWorldClip();
        }
        else {
            this.setWorldClip(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight());
        }
    }
    
    public Rectangle getWorldClip() {
        return this.worldClipRecord;
    }
    
    public void setClip(final int n, final int n2, final int n3, final int n4) {
        this.predraw();
        if (this.clip == null) {
            Graphics.GL.glEnable(3089);
            this.clip = new Rectangle((float)n, (float)n2, (float)n3, (float)n4);
        }
        else {
            this.clip.setBounds((float)n, (float)n2, (float)n3, (float)n4);
        }
        Graphics.GL.glScissor(n, this.screenHeight - n2 - n4, n3, n4);
        this.postdraw();
    }
    
    public void setClip(final Rectangle rectangle) {
        if (rectangle == null) {
            this.clearClip();
            return;
        }
        this.setClip((int)rectangle.getX(), (int)rectangle.getY(), (int)rectangle.getWidth(), (int)rectangle.getHeight());
    }
    
    public Rectangle getClip() {
        return this.clip;
    }
    
    public void fillRect(final float n, final float n2, final float n3, final float n4, final Image image, final float n5, final float n6) {
        final int n7 = (int)Math.ceil(n3 / image.getWidth()) + 2;
        final int n8 = (int)Math.ceil(n4 / image.getHeight()) + 2;
        final Rectangle worldClip = this.getWorldClip();
        this.setWorldClip(n, n2, n3, n4);
        this.predraw();
        for (int i = 0; i < n7; ++i) {
            for (int j = 0; j < n8; ++j) {
                image.draw(i * image.getWidth() + n - n5, j * image.getHeight() + n2 - n6);
            }
        }
        this.postdraw();
        this.setWorldClip(worldClip);
    }
    
    public void fillRect(final float n, final float n2, final float n3, final float n4) {
        this.predraw();
        TextureImpl.bindNone();
        this.currentColor.bind();
        Graphics.GL.glBegin(7);
        Graphics.GL.glVertex2f(n, n2);
        Graphics.GL.glVertex2f(n + n3, n2);
        Graphics.GL.glVertex2f(n + n3, n2 + n4);
        Graphics.GL.glVertex2f(n, n2 + n4);
        Graphics.GL.glEnd();
        this.postdraw();
    }
    
    public void drawOval(final float n, final float n2, final float n3, final float n4) {
        this.drawOval(n, n2, n3, n4, 50);
    }
    
    public void drawOval(final float n, final float n2, final float n3, final float n4, final int n5) {
        this.drawArc(n, n2, n3, n4, n5, 0.0f, 360.0f);
    }
    
    public void drawArc(final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.drawArc(n, n2, n3, n4, 50, n5, n6);
    }
    
    public void drawArc(final float n, final float n2, final float n3, final float n4, final int n5, final float n6, float n7) {
        this.predraw();
        TextureImpl.bindNone();
        this.currentColor.bind();
        while (n7 < n6) {
            n7 += 360.0f;
        }
        final float n8 = n + n3 / 2.0f;
        final float n9 = n2 + n4 / 2.0f;
        Graphics.LSR.start();
        for (int n10 = 360 / n5, i = (int)n6; i < (int)(n7 + n10); i += n10) {
            float n11 = (float)i;
            if (n11 > n7) {
                n11 = n7;
            }
            Graphics.LSR.vertex((float)(n8 + FastTrig.cos(Math.toRadians(n11)) * n3 / 2.0), (float)(n9 + FastTrig.sin(Math.toRadians(n11)) * n4 / 2.0));
        }
        Graphics.LSR.end();
        this.postdraw();
    }
    
    public void fillOval(final float n, final float n2, final float n3, final float n4) {
        this.fillOval(n, n2, n3, n4, 50);
    }
    
    public void fillOval(final float n, final float n2, final float n3, final float n4, final int n5) {
        this.fillArc(n, n2, n3, n4, n5, 0.0f, 360.0f);
    }
    
    public void fillArc(final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.fillArc(n, n2, n3, n4, 50, n5, n6);
    }
    
    public void fillArc(final float n, final float n2, final float n3, final float n4, final int n5, final float n6, float n7) {
        this.predraw();
        TextureImpl.bindNone();
        this.currentColor.bind();
        while (n7 < n6) {
            n7 += 360.0f;
        }
        final float n8 = n + n3 / 2.0f;
        final float n9 = n2 + n4 / 2.0f;
        Graphics.GL.glBegin(6);
        final int n10 = 360 / n5;
        Graphics.GL.glVertex2f(n8, n9);
        for (int i = (int)n6; i < (int)(n7 + n10); i += n10) {
            float n11 = (float)i;
            if (n11 > n7) {
                n11 = n7;
            }
            Graphics.GL.glVertex2f((float)(n8 + FastTrig.cos(Math.toRadians(n11)) * n3 / 2.0), (float)(n9 + FastTrig.sin(Math.toRadians(n11)) * n4 / 2.0));
        }
        Graphics.GL.glEnd();
        if (this.antialias) {
            Graphics.GL.glBegin(6);
            Graphics.GL.glVertex2f(n8, n9);
            if (n7 != 360.0f) {
                n7 -= 10.0f;
            }
            for (int j = (int)n6; j < (int)(n7 + n10); j += n10) {
                float n12 = (float)j;
                if (n12 > n7) {
                    n12 = n7;
                }
                Graphics.GL.glVertex2f((float)(n8 + FastTrig.cos(Math.toRadians(n12 + 10.0f)) * n3 / 2.0), (float)(n9 + FastTrig.sin(Math.toRadians(n12 + 10.0f)) * n4 / 2.0));
            }
            Graphics.GL.glEnd();
        }
        this.postdraw();
    }
    
    public void drawRoundRect(final float n, final float n2, final float n3, final float n4, final int n5) {
        this.drawRoundRect(n, n2, n3, n4, n5, 50);
    }
    
    public void drawRoundRect(final float n, final float n2, final float a, final float b, int n3, final int n4) {
        if (n3 < 0) {
            throw new IllegalArgumentException("corner radius must be > 0");
        }
        if (n3 == 0) {
            this.drawRect(n, n2, a, b);
            return;
        }
        final int n5 = (int)Math.min(a, b) / 2;
        if (n3 > n5) {
            n3 = n5;
        }
        this.drawLine(n + n3, n2, n + a - n3, n2);
        this.drawLine(n, n2 + n3, n, n2 + b - n3);
        this.drawLine(n + a, n2 + n3, n + a, n2 + b - n3);
        this.drawLine(n + n3, n2 + b, n + a - n3, n2 + b);
        final float n6 = (float)(n3 * 2);
        this.drawArc(n + a - n6, n2 + b - n6, n6, n6, n4, 0.0f, 90.0f);
        this.drawArc(n, n2 + b - n6, n6, n6, n4, 90.0f, 180.0f);
        this.drawArc(n + a - n6, n2, n6, n6, n4, 270.0f, 360.0f);
        this.drawArc(n, n2, n6, n6, n4, 180.0f, 270.0f);
    }
    
    public void fillRoundRect(final float n, final float n2, final float n3, final float n4, final int n5) {
        this.fillRoundRect(n, n2, n3, n4, n5, 50);
    }
    
    public void fillRoundRect(final float n, final float n2, final float a, final float b, int n3, final int n4) {
        if (n3 < 0) {
            throw new IllegalArgumentException("corner radius must be > 0");
        }
        if (n3 == 0) {
            this.fillRect(n, n2, a, b);
            return;
        }
        final int n5 = (int)Math.min(a, b) / 2;
        if (n3 > n5) {
            n3 = n5;
        }
        final float n6 = (float)(n3 * 2);
        this.fillRect(n + n3, n2, a - n6, (float)n3);
        this.fillRect(n, n2 + n3, (float)n3, b - n6);
        this.fillRect(n + a - n3, n2 + n3, (float)n3, b - n6);
        this.fillRect(n + n3, n2 + b - n3, a - n6, (float)n3);
        this.fillRect(n + n3, n2 + n3, a - n6, b - n6);
        this.fillArc(n + a - n6, n2 + b - n6, n6, n6, n4, 0.0f, 90.0f);
        this.fillArc(n, n2 + b - n6, n6, n6, n4, 90.0f, 180.0f);
        this.fillArc(n + a - n6, n2, n6, n6, n4, 270.0f, 360.0f);
        this.fillArc(n, n2, n6, n6, n4, 180.0f, 270.0f);
    }
    
    public void setLineWidth(final float n) {
        this.predraw();
        this.lineWidth = n;
        Graphics.LSR.setWidth(n);
        Graphics.GL.glPointSize(n);
        this.postdraw();
    }
    
    public float getLineWidth() {
        return this.lineWidth;
    }
    
    public void resetLineWidth() {
        this.predraw();
        Renderer.getLineStripRenderer().setWidth(1.0f);
        Graphics.GL.glLineWidth(1.0f);
        Graphics.GL.glPointSize(1.0f);
        this.postdraw();
    }
    
    public void setAntiAlias(final boolean b) {
        this.predraw();
        this.antialias = b;
        Graphics.LSR.setAntiAlias(b);
        if (b) {
            Graphics.GL.glEnable(2881);
        }
        else {
            Graphics.GL.glDisable(2881);
        }
        this.postdraw();
    }
    
    public boolean isAntiAlias() {
        return this.antialias;
    }
    
    public void drawString(final String s, final float n, final float n2) {
        this.predraw();
        this.font.drawString(n, n2, s, this.currentColor);
        this.postdraw();
    }
    
    public void drawImage(final Image image, final float n, final float n2, final Color color) {
        this.predraw();
        image.draw(n, n2, color);
        this.currentColor.bind();
        this.postdraw();
    }
    
    public void drawAnimation(final Animation animation, final float n, final float n2) {
        this.drawAnimation(animation, n, n2, Color.white);
    }
    
    public void drawAnimation(final Animation animation, final float n, final float n2, final Color color) {
        this.predraw();
        animation.draw(n, n2, color);
        this.currentColor.bind();
        this.postdraw();
    }
    
    public void drawImage(final Image image, final float n, final float n2) {
        this.drawImage(image, n, n2, Color.white);
    }
    
    public void drawImage(final Image image, final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8) {
        this.predraw();
        image.draw(n, n2, n3, n4, n5, n6, n7, n8);
        this.currentColor.bind();
        this.postdraw();
    }
    
    public void drawImage(final Image image, final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.drawImage(image, n, n2, n + image.getWidth(), n2 + image.getHeight(), n3, n4, n5, n6);
    }
    
    public void copyArea(final Image image, final int n, final int n2) {
        final int n3 = image.getTexture().hasAlpha() ? 6408 : 6407;
        image.bind();
        Graphics.GL.glCopyTexImage2D(3553, 0, n3, n, this.screenHeight - (n2 + image.getHeight()), image.getTexture().getTextureWidth(), image.getTexture().getTextureHeight(), 0);
        image.ensureInverted();
    }
    
    public int translate(final byte b) {
        if (b < 0) {
            return 256 + b;
        }
        return b;
    }
    
    public Color getPixel(final int n, final int n2) {
        this.predraw();
        Graphics.GL.glReadPixels(n, this.screenHeight - n2, 1, 1, 6408, 5121, this.readBuffer);
        this.postdraw();
        return new Color(this.translate(this.readBuffer.get(0)), this.translate(this.readBuffer.get(1)), this.translate(this.readBuffer.get(2)), this.translate(this.readBuffer.get(3)));
    }
    
    public void getArea(final int n, final int n2, final int n3, final int n4, final ByteBuffer byteBuffer) {
        if (byteBuffer.capacity() < n3 * n4 * 4) {
            throw new IllegalArgumentException("Byte buffer provided to get area is not big enough");
        }
        this.predraw();
        Graphics.GL.glReadPixels(n, this.screenHeight - n2 - n4, n3, n4, 6408, 5121, byteBuffer);
        this.postdraw();
    }
    
    public void drawImage(final Image image, final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8, final Color color) {
        this.predraw();
        image.draw(n, n2, n3, n4, n5, n6, n7, n8, color);
        this.currentColor.bind();
        this.postdraw();
    }
    
    public void drawImage(final Image image, final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final Color color) {
        this.drawImage(image, n, n2, n + image.getWidth(), n2 + image.getHeight(), n3, n4, n5, n6, color);
    }
    
    public void drawGradientLine(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8, final float n9, final float n10, final float n11, final float n12) {
        this.predraw();
        TextureImpl.bindNone();
        Graphics.GL.glBegin(1);
        Graphics.GL.glColor4f(n3, n4, n5, n6);
        Graphics.GL.glVertex2f(n, n2);
        Graphics.GL.glColor4f(n9, n10, n11, n12);
        Graphics.GL.glVertex2f(n7, n8);
        Graphics.GL.glEnd();
        this.postdraw();
    }
    
    public void drawGradientLine(final float n, final float n2, final Color color, final float n3, final float n4, final Color color2) {
        this.predraw();
        TextureImpl.bindNone();
        Graphics.GL.glBegin(1);
        color.bind();
        Graphics.GL.glVertex2f(n, n2);
        color2.bind();
        Graphics.GL.glVertex2f(n3, n4);
        Graphics.GL.glEnd();
        this.postdraw();
    }
    
    public void pushTransform() {
        this.predraw();
        FloatBuffer floatBuffer;
        if (this.stackIndex >= this.stack.size()) {
            floatBuffer = BufferUtils.createFloatBuffer(18);
            this.stack.add(floatBuffer);
        }
        else {
            floatBuffer = this.stack.get(this.stackIndex);
        }
        Graphics.GL.glGetFloat(2982, floatBuffer);
        floatBuffer.put(16, this.sx);
        floatBuffer.put(17, this.sy);
        ++this.stackIndex;
        this.postdraw();
    }
    
    public void popTransform() {
        if (this.stackIndex == 0) {
            throw new RuntimeException("Attempt to pop a transform that hasn't be pushed");
        }
        this.predraw();
        --this.stackIndex;
        final FloatBuffer floatBuffer = this.stack.get(this.stackIndex);
        Graphics.GL.glLoadMatrix(floatBuffer);
        this.sx = floatBuffer.get(16);
        this.sy = floatBuffer.get(17);
        this.postdraw();
    }
    
    public void destroy() {
    }
    
    static {
        Graphics.DEFAULT_SEGMENTS = 50;
        Graphics.GL = Renderer.get();
        Graphics.LSR = Renderer.getLineStripRenderer();
        Graphics.MODE_NORMAL = 1;
        Graphics.MODE_ALPHA_MAP = 2;
        Graphics.MODE_ALPHA_BLEND = 3;
        Graphics.MODE_COLOR_MULTIPLY = 4;
        Graphics.MODE_ADD = 5;
        Graphics.MODE_SCREEN = 6;
        Graphics.currentGraphics = null;
    }
}
