// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.opengl.pbuffer.GraphicsFactory;
import org.newdawn.slick.opengl.ImageData;
import org.newdawn.slick.opengl.TextureImpl;
import java.io.InputStream;
import org.newdawn.slick.opengl.InternalTextureLoader;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.renderer.SGL;

public class Image implements Renderable
{
    public static int TOP_LEFT;
    public static int TOP_RIGHT;
    public static int BOTTOM_RIGHT;
    public static int BOTTOM_LEFT;
    public static SGL GL;
    public static Image inUse;
    public static int FILTER_LINEAR;
    public static int FILTER_NEAREST;
    public Texture texture;
    public int width;
    public int height;
    public float textureWidth;
    public float textureHeight;
    public float textureOffsetX;
    public float textureOffsetY;
    public float angle;
    public float alpha;
    public String ref;
    public boolean inited;
    public byte[] pixelData;
    public boolean destroyed;
    public float centerX;
    public float centerY;
    public String name;
    public Color[] corners;
    public int filter;
    public boolean flipped;
    public Color transparent;
    
    public Image(final Image image) {
        this.alpha = 1.0f;
        this.inited = false;
        this.filter = 9729;
        this.width = image.getWidth();
        this.height = image.getHeight();
        this.texture = image.texture;
        this.textureWidth = image.textureWidth;
        this.textureHeight = image.textureHeight;
        this.ref = image.ref;
        this.textureOffsetX = image.textureOffsetX;
        this.textureOffsetY = image.textureOffsetY;
        this.centerX = (float)(this.width / 2);
        this.centerY = (float)(this.height / 2);
        this.inited = true;
    }
    
    public Image() {
        this.alpha = 1.0f;
        this.inited = false;
        this.filter = 9729;
    }
    
    public Image(final Texture texture) {
        this.alpha = 1.0f;
        this.inited = false;
        this.filter = 9729;
        this.texture = texture;
        this.ref = texture.toString();
        this.clampTexture();
    }
    
    public Image(final String s) throws SlickException {
        this(s, false);
    }
    
    public Image(final String s, final Color color) throws SlickException {
        this(s, false, 1, color);
    }
    
    public Image(final String s, final boolean b) throws SlickException {
        this(s, b, 1);
    }
    
    public Image(final String s, final boolean b, final int n) throws SlickException {
        this(s, b, n, null);
    }
    
    public Image(final String ref, final boolean flipped, final int n, final Color transparent) throws SlickException {
        this.alpha = 1.0f;
        this.inited = false;
        this.filter = 9729;
        this.filter = ((n == 1) ? 9729 : 9728);
        this.transparent = transparent;
        this.flipped = flipped;
        this.ref = ref;
        int[] array = null;
        if (transparent != null) {
            array = new int[] { (int)(transparent.r * 255.0f), (int)(transparent.g * 255.0f), (int)(transparent.b * 255.0f) };
        }
        this.texture = InternalTextureLoader.get().getTexture(ref, flipped, this.filter, array);
    }
    
    public void setFilter(final int n) {
        this.filter = ((n == 1) ? 9729 : 9728);
        this.texture.bind();
        Image.GL.glTexParameteri(3553, 10241, this.filter);
        Image.GL.glTexParameteri(3553, 10240, this.filter);
    }
    
    public Image(final int n, final int n2) throws SlickException {
        this(n, n2, 2);
    }
    
    public Image(final int n, final int n2, final int n3) throws SlickException {
        this.alpha = 1.0f;
        this.inited = false;
        this.filter = 9729;
        this.ref = super.toString();
        this.filter = ((n3 == 1) ? 9729 : 9728);
        this.texture = InternalTextureLoader.get().createTexture(n, n2, this.filter);
        this.init();
    }
    
    public Image(final InputStream inputStream, final String s, final boolean b) throws SlickException {
        this(inputStream, s, b, 1);
    }
    
    public Image(final InputStream inputStream, final String s, final boolean b, final int n) throws SlickException {
        this.alpha = 1.0f;
        this.inited = false;
        this.filter = 9729;
        this.load(inputStream, s, b, n, null);
    }
    
    public Image(final ImageBuffer imageBuffer) {
        this(imageBuffer, 1);
        TextureImpl.bindNone();
    }
    
    public Image(final ImageBuffer imageBuffer, final int n) {
        this((ImageData)imageBuffer, n);
        TextureImpl.bindNone();
    }
    
    public Image(final ImageData imageData) {
        this(imageData, 1);
    }
    
    public Image(final ImageData imageData, final int n) {
        this.alpha = 1.0f;
        this.inited = false;
        this.filter = 9729;
        this.filter = ((n == 1) ? 9729 : 9728);
        this.texture = InternalTextureLoader.get().getTexture(imageData, this.filter);
        this.ref = this.texture.toString();
    }
    
    public int getFilter() {
        return this.filter;
    }
    
    public String getResourceReference() {
        return this.ref;
    }
    
    public void setImageColor(final float n, final float n2, final float n3, final float n4) {
        this.setColor(0, n, n2, n3, n4);
        this.setColor(1, n, n2, n3, n4);
        this.setColor(3, n, n2, n3, n4);
        this.setColor(2, n, n2, n3, n4);
    }
    
    public void setImageColor(final float n, final float n2, final float n3) {
        this.setColor(0, n, n2, n3);
        this.setColor(1, n, n2, n3);
        this.setColor(3, n, n2, n3);
        this.setColor(2, n, n2, n3);
    }
    
    public void setColor(final int n, final float r, final float g, final float b, final float a) {
        if (this.corners == null) {
            this.corners = new Color[] { new Color(1.0f, 1.0f, 1.0f, 1.0f), new Color(1.0f, 1.0f, 1.0f, 1.0f), new Color(1.0f, 1.0f, 1.0f, 1.0f), new Color(1.0f, 1.0f, 1.0f, 1.0f) };
        }
        this.corners[n].r = r;
        this.corners[n].g = g;
        this.corners[n].b = b;
        this.corners[n].a = a;
    }
    
    public void setColor(final int n, final float r, final float g, final float b) {
        if (this.corners == null) {
            this.corners = new Color[] { new Color(1.0f, 1.0f, 1.0f, 1.0f), new Color(1.0f, 1.0f, 1.0f, 1.0f), new Color(1.0f, 1.0f, 1.0f, 1.0f), new Color(1.0f, 1.0f, 1.0f, 1.0f) };
        }
        this.corners[n].r = r;
        this.corners[n].g = g;
        this.corners[n].b = b;
    }
    
    public void clampTexture() {
        if (Image.GL.canTextureMirrorClamp()) {
            Image.GL.glTexParameteri(3553, 10242, 34627);
            Image.GL.glTexParameteri(3553, 10243, 34627);
        }
        else {
            Image.GL.glTexParameteri(3553, 10242, 10496);
            Image.GL.glTexParameteri(3553, 10243, 10496);
        }
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    
    public Graphics getGraphics() throws SlickException {
        return GraphicsFactory.getGraphicsForImage(this);
    }
    
    public void load(final InputStream inputStream, final String ref, final boolean b, final int n, final Color color) throws SlickException {
        this.filter = ((n == 1) ? 9729 : 9728);
        this.ref = ref;
        int[] array = null;
        if (color != null) {
            array = new int[] { (int)(color.r * 255.0f), (int)(color.g * 255.0f), (int)(color.b * 255.0f) };
        }
        this.texture = InternalTextureLoader.get().getTexture(inputStream, ref, b, this.filter, array);
    }
    
    public void bind() {
        this.texture.bind();
    }
    
    public void reinit() {
        this.inited = false;
        this.init();
    }
    
    public void init() {
        if (this.inited) {
            return;
        }
        this.inited = true;
        if (this.texture != null) {
            this.width = this.texture.getImageWidth();
            this.height = this.texture.getImageHeight();
            this.textureOffsetX = 0.0f;
            this.textureOffsetY = 0.0f;
            this.textureWidth = this.texture.getWidth();
            this.textureHeight = this.texture.getHeight();
        }
        this.initImpl();
        this.centerX = (float)(this.width / 2);
        this.centerY = (float)(this.height / 2);
    }
    
    public void initImpl() {
    }
    
    public void draw() {
        this.draw(0.0f, 0.0f);
    }
    
    public void drawCentered(final float n, final float n2) {
        this.draw(n - this.getWidth() / 2, n2 - this.getHeight() / 2);
    }
    
    @Override
    public void draw(final float n, final float n2) {
        this.init();
        this.draw(n, n2, (float)this.width, (float)this.height);
    }
    
    public void draw(final float n, final float n2, final Color color) {
        this.init();
        this.draw(n, n2, (float)this.width, (float)this.height, color);
    }
    
    public void drawEmbedded(final float n, final float n2, final float n3, final float n4) {
        this.init();
        if (this.corners == null) {
            Image.GL.glTexCoord2f(this.textureOffsetX, this.textureOffsetY);
            Image.GL.glVertex3f(n, n2, 0.0f);
            Image.GL.glTexCoord2f(this.textureOffsetX, this.textureOffsetY + this.textureHeight);
            Image.GL.glVertex3f(n, n2 + n4, 0.0f);
            Image.GL.glTexCoord2f(this.textureOffsetX + this.textureWidth, this.textureOffsetY + this.textureHeight);
            Image.GL.glVertex3f(n + n3, n2 + n4, 0.0f);
            Image.GL.glTexCoord2f(this.textureOffsetX + this.textureWidth, this.textureOffsetY);
            Image.GL.glVertex3f(n + n3, n2, 0.0f);
        }
        else {
            this.corners[0].bind();
            Image.GL.glTexCoord2f(this.textureOffsetX, this.textureOffsetY);
            Image.GL.glVertex3f(n, n2, 0.0f);
            this.corners[3].bind();
            Image.GL.glTexCoord2f(this.textureOffsetX, this.textureOffsetY + this.textureHeight);
            Image.GL.glVertex3f(n, n2 + n4, 0.0f);
            this.corners[2].bind();
            Image.GL.glTexCoord2f(this.textureOffsetX + this.textureWidth, this.textureOffsetY + this.textureHeight);
            Image.GL.glVertex3f(n + n3, n2 + n4, 0.0f);
            this.corners[1].bind();
            Image.GL.glTexCoord2f(this.textureOffsetX + this.textureWidth, this.textureOffsetY);
            Image.GL.glVertex3f(n + n3, n2, 0.0f);
        }
    }
    
    public float getTextureOffsetX() {
        this.init();
        return this.textureOffsetX;
    }
    
    public float getTextureOffsetY() {
        this.init();
        return this.textureOffsetY;
    }
    
    public float getTextureWidth() {
        this.init();
        return this.textureWidth;
    }
    
    public float getTextureHeight() {
        this.init();
        return this.textureHeight;
    }
    
    public void draw(final float n, final float n2, final float n3) {
        this.init();
        this.draw(n, n2, this.width * n3, this.height * n3, Color.white);
    }
    
    public void draw(final float n, final float n2, final float n3, final Color color) {
        this.init();
        this.draw(n, n2, this.width * n3, this.height * n3, color);
    }
    
    public void draw(final float n, final float n2, final float n3, final float n4) {
        this.init();
        this.draw(n, n2, n3, n4, Color.white);
    }
    
    public void drawSheared(final float n, final float n2, final float n3, final float n4) {
        this.drawSheared(n, n2, n3, n4, Color.white);
    }
    
    public void drawSheared(final float n, final float n2, final float n3, final float n4, Color white) {
        if (this.alpha != 1.0f) {
            if (white == null) {
                white = Color.white;
            }
            final Color color;
            white = (color = new Color(white));
            color.a *= this.alpha;
        }
        if (white != null) {
            white.bind();
        }
        this.texture.bind();
        Image.GL.glTranslatef(n, n2, 0.0f);
        if (this.angle != 0.0f) {
            Image.GL.glTranslatef(this.centerX, this.centerY, 0.0f);
            Image.GL.glRotatef(this.angle, 0.0f, 0.0f, 1.0f);
            Image.GL.glTranslatef(-this.centerX, -this.centerY, 0.0f);
        }
        Image.GL.glBegin(7);
        this.init();
        Image.GL.glTexCoord2f(this.textureOffsetX, this.textureOffsetY);
        Image.GL.glVertex3f(0.0f, 0.0f, 0.0f);
        Image.GL.glTexCoord2f(this.textureOffsetX, this.textureOffsetY + this.textureHeight);
        Image.GL.glVertex3f(n3, (float)this.height, 0.0f);
        Image.GL.glTexCoord2f(this.textureOffsetX + this.textureWidth, this.textureOffsetY + this.textureHeight);
        Image.GL.glVertex3f(this.width + n3, this.height + n4, 0.0f);
        Image.GL.glTexCoord2f(this.textureOffsetX + this.textureWidth, this.textureOffsetY);
        Image.GL.glVertex3f((float)this.width, n4, 0.0f);
        Image.GL.glEnd();
        if (this.angle != 0.0f) {
            Image.GL.glTranslatef(this.centerX, this.centerY, 0.0f);
            Image.GL.glRotatef(-this.angle, 0.0f, 0.0f, 1.0f);
            Image.GL.glTranslatef(-this.centerX, -this.centerY, 0.0f);
        }
        Image.GL.glTranslatef(-n, -n2, 0.0f);
    }
    
    public void draw(final float n, final float n2, final float n3, final float n4, Color white) {
        if (this.alpha != 1.0f) {
            if (white == null) {
                white = Color.white;
            }
            final Color color;
            white = (color = new Color(white));
            color.a *= this.alpha;
        }
        if (white != null) {
            white.bind();
        }
        this.texture.bind();
        Image.GL.glTranslatef(n, n2, 0.0f);
        if (this.angle != 0.0f) {
            Image.GL.glTranslatef(this.centerX, this.centerY, 0.0f);
            Image.GL.glRotatef(this.angle, 0.0f, 0.0f, 1.0f);
            Image.GL.glTranslatef(-this.centerX, -this.centerY, 0.0f);
        }
        Image.GL.glBegin(7);
        this.drawEmbedded(0.0f, 0.0f, n3, n4);
        Image.GL.glEnd();
        if (this.angle != 0.0f) {
            Image.GL.glTranslatef(this.centerX, this.centerY, 0.0f);
            Image.GL.glRotatef(-this.angle, 0.0f, 0.0f, 1.0f);
            Image.GL.glTranslatef(-this.centerX, -this.centerY, 0.0f);
        }
        Image.GL.glTranslatef(-n, -n2, 0.0f);
    }
    
    public void drawFlash(final float n, final float n2, final float n3, final float n4) {
        this.drawFlash(n, n2, n3, n4, Color.white);
    }
    
    public void setCenterOfRotation(final float centerX, final float centerY) {
        this.centerX = centerX;
        this.centerY = centerY;
    }
    
    public float getCenterOfRotationX() {
        this.init();
        return this.centerX;
    }
    
    public float getCenterOfRotationY() {
        this.init();
        return this.centerY;
    }
    
    public void drawFlash(final float n, final float n2, final float n3, final float n4, final Color color) {
        this.init();
        color.bind();
        this.texture.bind();
        if (Image.GL.canSecondaryColor()) {
            Image.GL.glEnable(33880);
            Image.GL.glSecondaryColor3ubEXT((byte)(color.r * 255.0f), (byte)(color.g * 255.0f), (byte)(color.b * 255.0f));
        }
        Image.GL.glTexEnvi(8960, 8704, 8448);
        Image.GL.glTranslatef(n, n2, 0.0f);
        if (this.angle != 0.0f) {
            Image.GL.glTranslatef(this.centerX, this.centerY, 0.0f);
            Image.GL.glRotatef(this.angle, 0.0f, 0.0f, 1.0f);
            Image.GL.glTranslatef(-this.centerX, -this.centerY, 0.0f);
        }
        Image.GL.glBegin(7);
        this.drawEmbedded(0.0f, 0.0f, n3, n4);
        Image.GL.glEnd();
        if (this.angle != 0.0f) {
            Image.GL.glTranslatef(this.centerX, this.centerY, 0.0f);
            Image.GL.glRotatef(-this.angle, 0.0f, 0.0f, 1.0f);
            Image.GL.glTranslatef(-this.centerX, -this.centerY, 0.0f);
        }
        Image.GL.glTranslatef(-n, -n2, 0.0f);
        if (Image.GL.canSecondaryColor()) {
            Image.GL.glDisable(33880);
        }
    }
    
    public void drawFlash(final float n, final float n2) {
        this.drawFlash(n, n2, (float)this.getWidth(), (float)this.getHeight());
    }
    
    public void setRotation(final float n) {
        this.angle = n % 360.0f;
    }
    
    public float getRotation() {
        return this.angle;
    }
    
    public float getAlpha() {
        return this.alpha;
    }
    
    public void setAlpha(final float alpha) {
        this.alpha = alpha;
    }
    
    public void rotate(final float n) {
        this.angle += n;
        this.angle %= 360.0f;
    }
    
    public Image getSubImage(final int n, final int n2, final int width, final int height) {
        this.init();
        final float textureOffsetX = n / (float)this.width * this.textureWidth + this.textureOffsetX;
        final float textureOffsetY = n2 / (float)this.height * this.textureHeight + this.textureOffsetY;
        final float textureWidth = width / (float)this.width * this.textureWidth;
        final float textureHeight = height / (float)this.height * this.textureHeight;
        final Image image = new Image();
        image.inited = true;
        image.texture = this.texture;
        image.textureOffsetX = textureOffsetX;
        image.textureOffsetY = textureOffsetY;
        image.textureWidth = textureWidth;
        image.textureHeight = textureHeight;
        image.width = width;
        image.height = height;
        image.ref = this.ref;
        image.centerX = (float)(width / 2);
        image.centerY = (float)(height / 2);
        return image;
    }
    
    public void draw(final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.draw(n, n2, n + this.width, n2 + this.height, n3, n4, n5, n6);
    }
    
    public void draw(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8) {
        this.draw(n, n2, n3, n4, n5, n6, n7, n8, Color.white);
    }
    
    public void draw(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8, Color white) {
        this.init();
        if (this.alpha != 1.0f) {
            if (white == null) {
                white = Color.white;
            }
            final Color color;
            white = (color = new Color(white));
            color.a *= this.alpha;
        }
        white.bind();
        this.texture.bind();
        Image.GL.glTranslatef(n, n2, 0.0f);
        if (this.angle != 0.0f) {
            Image.GL.glTranslatef(this.centerX, this.centerY, 0.0f);
            Image.GL.glRotatef(this.angle, 0.0f, 0.0f, 1.0f);
            Image.GL.glTranslatef(-this.centerX, -this.centerY, 0.0f);
        }
        Image.GL.glBegin(7);
        this.drawEmbedded(0.0f, 0.0f, n3 - n, n4 - n2, n5, n6, n7, n8);
        Image.GL.glEnd();
        if (this.angle != 0.0f) {
            Image.GL.glTranslatef(this.centerX, this.centerY, 0.0f);
            Image.GL.glRotatef(-this.angle, 0.0f, 0.0f, 1.0f);
            Image.GL.glTranslatef(-this.centerX, -this.centerY, 0.0f);
        }
        Image.GL.glTranslatef(-n, -n2, 0.0f);
    }
    
    public void drawEmbedded(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8) {
        this.drawEmbedded(n, n2, n3, n4, n5, n6, n7, n8, null);
    }
    
    public void drawEmbedded(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8, final Color color) {
        if (color != null) {
            color.bind();
        }
        final float n9 = n3 - n;
        final float n10 = n4 - n2;
        final float n11 = n7 - n5;
        final float n12 = n8 - n6;
        final float n13 = n5 / this.width * this.textureWidth + this.textureOffsetX;
        final float n14 = n6 / this.height * this.textureHeight + this.textureOffsetY;
        final float n15 = n11 / this.width * this.textureWidth;
        final float n16 = n12 / this.height * this.textureHeight;
        Image.GL.glTexCoord2f(n13, n14);
        Image.GL.glVertex3f(n, n2, 0.0f);
        Image.GL.glTexCoord2f(n13, n14 + n16);
        Image.GL.glVertex3f(n, n2 + n10, 0.0f);
        Image.GL.glTexCoord2f(n13 + n15, n14 + n16);
        Image.GL.glVertex3f(n + n9, n2 + n10, 0.0f);
        Image.GL.glTexCoord2f(n13 + n15, n14);
        Image.GL.glVertex3f(n + n9, n2, 0.0f);
    }
    
    public void drawWarped(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8) {
        Color.white.bind();
        this.texture.bind();
        Image.GL.glTranslatef(n, n2, 0.0f);
        if (this.angle != 0.0f) {
            Image.GL.glTranslatef(this.centerX, this.centerY, 0.0f);
            Image.GL.glRotatef(this.angle, 0.0f, 0.0f, 1.0f);
            Image.GL.glTranslatef(-this.centerX, -this.centerY, 0.0f);
        }
        Image.GL.glBegin(7);
        this.init();
        Image.GL.glTexCoord2f(this.textureOffsetX, this.textureOffsetY);
        Image.GL.glVertex3f(0.0f, 0.0f, 0.0f);
        Image.GL.glTexCoord2f(this.textureOffsetX, this.textureOffsetY + this.textureHeight);
        Image.GL.glVertex3f(n3 - n, n4 - n2, 0.0f);
        Image.GL.glTexCoord2f(this.textureOffsetX + this.textureWidth, this.textureOffsetY + this.textureHeight);
        Image.GL.glVertex3f(n5 - n, n6 - n2, 0.0f);
        Image.GL.glTexCoord2f(this.textureOffsetX + this.textureWidth, this.textureOffsetY);
        Image.GL.glVertex3f(n7 - n, n8 - n2, 0.0f);
        Image.GL.glEnd();
        if (this.angle != 0.0f) {
            Image.GL.glTranslatef(this.centerX, this.centerY, 0.0f);
            Image.GL.glRotatef(-this.angle, 0.0f, 0.0f, 1.0f);
            Image.GL.glTranslatef(-this.centerX, -this.centerY, 0.0f);
        }
        Image.GL.glTranslatef(-n, -n2, 0.0f);
    }
    
    public int getWidth() {
        this.init();
        return this.width;
    }
    
    public int getHeight() {
        this.init();
        return this.height;
    }
    
    public Image copy() {
        this.init();
        return this.getSubImage(0, 0, this.width, this.height);
    }
    
    public Image getScaledCopy(final float n) {
        this.init();
        return this.getScaledCopy((int)(this.width * n), (int)(this.height * n));
    }
    
    public Image getScaledCopy(final int width, final int height) {
        this.init();
        final Image copy = this.copy();
        copy.width = width;
        copy.height = height;
        copy.centerX = (float)(width / 2);
        copy.centerY = (float)(height / 2);
        return copy;
    }
    
    public void ensureInverted() {
        if (this.textureHeight > 0.0f) {
            this.textureOffsetY += this.textureHeight;
            this.textureHeight = -this.textureHeight;
        }
    }
    
    public Image getFlippedCopy(final boolean b, final boolean b2) {
        this.init();
        final Image copy = this.copy();
        if (b) {
            copy.textureOffsetX = this.textureOffsetX + this.textureWidth;
            copy.textureWidth = -this.textureWidth;
        }
        if (b2) {
            copy.textureOffsetY = this.textureOffsetY + this.textureHeight;
            copy.textureHeight = -this.textureHeight;
        }
        return copy;
    }
    
    public void endUse() {
        if (Image.inUse != this) {
            throw new RuntimeException("The sprite sheet is not currently in use");
        }
        Image.inUse = null;
        Image.GL.glEnd();
    }
    
    public void startUse() {
        if (Image.inUse != null) {
            throw new RuntimeException("Attempt to start use of a sprite sheet before ending use with another - see endUse()");
        }
        (Image.inUse = this).init();
        Color.white.bind();
        this.texture.bind();
        Image.GL.glBegin(7);
    }
    
    @Override
    public String toString() {
        this.init();
        return "[Image " + this.ref + " " + this.width + "x" + this.height + "  " + this.textureOffsetX + "," + this.textureOffsetY + "," + this.textureWidth + "," + this.textureHeight + "]";
    }
    
    public Texture getTexture() {
        return this.texture;
    }
    
    public void setTexture(final Texture texture) {
        this.texture = texture;
        this.reinit();
    }
    
    public int translate(final byte b) {
        if (b < 0) {
            return 256 + b;
        }
        return b;
    }
    
    public Color getColor(int n, int n2) {
        if (this.pixelData == null) {
            this.pixelData = this.texture.getTextureData();
        }
        final int n3 = (int)(this.textureOffsetX * this.texture.getTextureWidth());
        final int n4 = (int)(this.textureOffsetY * this.texture.getTextureHeight());
        if (this.textureWidth < 0.0f) {
            n = n3 - n;
        }
        else {
            n += n3;
        }
        if (this.textureHeight < 0.0f) {
            n2 = n4 - n2;
        }
        else {
            n2 += n4;
        }
        final int n5 = (n + n2 * this.texture.getTextureWidth()) * (this.texture.hasAlpha() ? 4 : 3);
        if (this.texture.hasAlpha()) {
            return new Color(this.translate(this.pixelData[n5]), this.translate(this.pixelData[n5 + 1]), this.translate(this.pixelData[n5 + 2]), this.translate(this.pixelData[n5 + 3]));
        }
        return new Color(this.translate(this.pixelData[n5]), this.translate(this.pixelData[n5 + 1]), this.translate(this.pixelData[n5 + 2]));
    }
    
    public boolean isDestroyed() {
        return this.destroyed;
    }
    
    public void destroy() throws SlickException {
        if (this.isDestroyed()) {
            return;
        }
        this.destroyed = true;
        this.texture.release();
        GraphicsFactory.releaseGraphicsForImage(this);
    }
    
    public void flushPixelData() {
        this.pixelData = null;
    }
    
    static {
        Image.FILTER_NEAREST = 2;
        Image.FILTER_LINEAR = 1;
        Image.BOTTOM_LEFT = 3;
        Image.BOTTOM_RIGHT = 2;
        Image.TOP_RIGHT = 1;
        Image.TOP_LEFT = 0;
        Image.GL = Renderer.get();
    }
}
