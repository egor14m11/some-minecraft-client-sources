// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import java.nio.ByteOrder;
import org.lwjgl.BufferUtils;
import java.nio.ByteBuffer;
import org.newdawn.slick.opengl.ImageData;

public class ImageBuffer implements ImageData
{
    public int width;
    public int height;
    public int texWidth;
    public int texHeight;
    public byte[] rawData;
    
    public ImageBuffer(final int width, final int height) {
        this.width = width;
        this.height = height;
        this.texWidth = this.get2Fold(width);
        this.texHeight = this.get2Fold(height);
        this.rawData = new byte[this.texWidth * this.texHeight * 4];
    }
    
    public byte[] getRGBA() {
        return this.rawData;
    }
    
    @Override
    public int getDepth() {
        return 32;
    }
    
    @Override
    public int getHeight() {
        return this.height;
    }
    
    @Override
    public int getTexHeight() {
        return this.texHeight;
    }
    
    @Override
    public int getTexWidth() {
        return this.texWidth;
    }
    
    @Override
    public int getWidth() {
        return this.width;
    }
    
    @Override
    public ByteBuffer getImageBufferData() {
        final ByteBuffer byteBuffer = BufferUtils.createByteBuffer(this.rawData.length);
        byteBuffer.put(this.rawData);
        byteBuffer.flip();
        return byteBuffer;
    }
    
    public void setRGBA(final int i, final int j, final int n, final int n2, final int n3, final int n4) {
        if (i < 0 || i >= this.width || j < 0 || j >= this.height) {
            throw new RuntimeException("Specified location: " + i + "," + j + " outside of image");
        }
        final int n5 = (i + j * this.texWidth) * 4;
        if (ByteOrder.nativeOrder() == ByteOrder.BIG_ENDIAN) {
            this.rawData[n5] = (byte)n3;
            this.rawData[n5 + 1] = (byte)n2;
            this.rawData[n5 + 2] = (byte)n;
            this.rawData[n5 + 3] = (byte)n4;
        }
        else {
            this.rawData[n5] = (byte)n;
            this.rawData[n5 + 1] = (byte)n2;
            this.rawData[n5 + 2] = (byte)n3;
            this.rawData[n5 + 3] = (byte)n4;
        }
    }
    
    public Image getImage() {
        return new Image(this);
    }
    
    public Image getImage(final int n) {
        return new Image(this, n);
    }
    
    public int get2Fold(final int n) {
        int i;
        for (i = 2; i < n; i *= 2) {}
        return i;
    }
}
