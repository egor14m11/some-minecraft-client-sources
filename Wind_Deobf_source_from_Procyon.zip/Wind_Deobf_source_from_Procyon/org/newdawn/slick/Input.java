// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import org.lwjgl.opengl.Display;
import org.newdawn.slick.util.Log;
import org.lwjgl.input.Controllers;
import org.lwjgl.input.Controller;
import org.lwjgl.input.Mouse;
import java.util.Arrays;
import org.lwjgl.input.Keyboard;
import java.util.Collection;
import java.util.HashSet;
import java.util.ArrayList;

public class Input
{
    public static int ANY_CONTROLLER;
    public static int MAX_BUTTONS;
    public static int KEY_ESCAPE;
    public static int KEY_1;
    public static int KEY_2;
    public static int KEY_3;
    public static int KEY_4;
    public static int KEY_5;
    public static int KEY_6;
    public static int KEY_7;
    public static int KEY_8;
    public static int KEY_9;
    public static int KEY_0;
    public static int KEY_MINUS;
    public static int KEY_EQUALS;
    public static int KEY_BACK;
    public static int KEY_TAB;
    public static int KEY_Q;
    public static int KEY_W;
    public static int KEY_E;
    public static int KEY_R;
    public static int KEY_T;
    public static int KEY_Y;
    public static int KEY_U;
    public static int KEY_I;
    public static int KEY_O;
    public static int KEY_P;
    public static int KEY_LBRACKET;
    public static int KEY_RBRACKET;
    public static int KEY_RETURN;
    public static int KEY_ENTER;
    public static int KEY_LCONTROL;
    public static int KEY_A;
    public static int KEY_S;
    public static int KEY_D;
    public static int KEY_F;
    public static int KEY_G;
    public static int KEY_H;
    public static int KEY_J;
    public static int KEY_K;
    public static int KEY_L;
    public static int KEY_SEMICOLON;
    public static int KEY_APOSTROPHE;
    public static int KEY_GRAVE;
    public static int KEY_LSHIFT;
    public static int KEY_BACKSLASH;
    public static int KEY_Z;
    public static int KEY_X;
    public static int KEY_C;
    public static int KEY_V;
    public static int KEY_B;
    public static int KEY_N;
    public static int KEY_M;
    public static int KEY_COMMA;
    public static int KEY_PERIOD;
    public static int KEY_SLASH;
    public static int KEY_RSHIFT;
    public static int KEY_MULTIPLY;
    public static int KEY_LMENU;
    public static int KEY_SPACE;
    public static int KEY_CAPITAL;
    public static int KEY_F1;
    public static int KEY_F2;
    public static int KEY_F3;
    public static int KEY_F4;
    public static int KEY_F5;
    public static int KEY_F6;
    public static int KEY_F7;
    public static int KEY_F8;
    public static int KEY_F9;
    public static int KEY_F10;
    public static int KEY_NUMLOCK;
    public static int KEY_SCROLL;
    public static int KEY_NUMPAD7;
    public static int KEY_NUMPAD8;
    public static int KEY_NUMPAD9;
    public static int KEY_SUBTRACT;
    public static int KEY_NUMPAD4;
    public static int KEY_NUMPAD5;
    public static int KEY_NUMPAD6;
    public static int KEY_ADD;
    public static int KEY_NUMPAD1;
    public static int KEY_NUMPAD2;
    public static int KEY_NUMPAD3;
    public static int KEY_NUMPAD0;
    public static int KEY_DECIMAL;
    public static int KEY_F11;
    public static int KEY_F12;
    public static int KEY_F13;
    public static int KEY_F14;
    public static int KEY_F15;
    public static int KEY_KANA;
    public static int KEY_CONVERT;
    public static int KEY_NOCONVERT;
    public static int KEY_YEN;
    public static int KEY_NUMPADEQUALS;
    public static int KEY_CIRCUMFLEX;
    public static int KEY_AT;
    public static int KEY_COLON;
    public static int KEY_UNDERLINE;
    public static int KEY_KANJI;
    public static int KEY_STOP;
    public static int KEY_AX;
    public static int KEY_UNLABELED;
    public static int KEY_NUMPADENTER;
    public static int KEY_RCONTROL;
    public static int KEY_NUMPADCOMMA;
    public static int KEY_DIVIDE;
    public static int KEY_SYSRQ;
    public static int KEY_RMENU;
    public static int KEY_PAUSE;
    public static int KEY_HOME;
    public static int KEY_UP;
    public static int KEY_PRIOR;
    public static int KEY_LEFT;
    public static int KEY_RIGHT;
    public static int KEY_END;
    public static int KEY_DOWN;
    public static int KEY_NEXT;
    public static int KEY_INSERT;
    public static int KEY_DELETE;
    public static int KEY_LWIN;
    public static int KEY_RWIN;
    public static int KEY_APPS;
    public static int KEY_POWER;
    public static int KEY_SLEEP;
    public static int KEY_LALT;
    public static int KEY_RALT;
    public static int LEFT;
    public static int RIGHT;
    public static int UP;
    public static int DOWN;
    public static int BUTTON1;
    public static int BUTTON2;
    public static int BUTTON3;
    public static int BUTTON4;
    public static int BUTTON5;
    public static int BUTTON6;
    public static int BUTTON7;
    public static int BUTTON8;
    public static int BUTTON9;
    public static int BUTTON10;
    public static int MOUSE_LEFT_BUTTON;
    public static int MOUSE_RIGHT_BUTTON;
    public static int MOUSE_MIDDLE_BUTTON;
    public static boolean controllersInited;
    public static ArrayList controllers;
    public int lastMouseX;
    public int lastMouseY;
    public boolean[] mousePressed;
    public boolean[][] controllerPressed;
    public char[] keys;
    public boolean[] pressed;
    public long[] nextRepeat;
    public boolean[][] controls;
    public boolean consumed;
    public HashSet allListeners;
    public ArrayList keyListeners;
    public ArrayList keyListenersToAdd;
    public ArrayList mouseListeners;
    public ArrayList mouseListenersToAdd;
    public ArrayList controllerListeners;
    public int wheel;
    public int height;
    public boolean displayActive;
    public boolean keyRepeat;
    public int keyRepeatInitial;
    public int keyRepeatInterval;
    public boolean paused;
    public float scaleX;
    public float scaleY;
    public float xoffset;
    public float yoffset;
    public int doubleClickDelay;
    public long doubleClickTimeout;
    public int clickX;
    public int clickY;
    public int clickButton;
    public int pressedX;
    public int pressedY;
    public int mouseClickTolerance;
    
    public static void disableControllers() {
        Input.controllersInited = true;
    }
    
    public Input(final int n) {
        this.mousePressed = new boolean[10];
        this.controllerPressed = new boolean[100][100];
        this.keys = new char[1024];
        this.pressed = new boolean[1024];
        this.nextRepeat = new long[1024];
        this.controls = new boolean[10][110];
        this.consumed = false;
        this.allListeners = new HashSet();
        this.keyListeners = new ArrayList();
        this.keyListenersToAdd = new ArrayList();
        this.mouseListeners = new ArrayList();
        this.mouseListenersToAdd = new ArrayList();
        this.controllerListeners = new ArrayList();
        this.displayActive = true;
        this.scaleX = 1.0f;
        this.scaleY = 1.0f;
        this.xoffset = 0.0f;
        this.yoffset = 0.0f;
        this.doubleClickDelay = 250;
        this.doubleClickTimeout = ((long)753784873 ^ 0x2CEDD829L);
        this.pressedX = -1;
        this.pressedY = -1;
        this.mouseClickTolerance = 5;
        this.init(n);
    }
    
    public void setDoubleClickInterval(final int doubleClickDelay) {
        this.doubleClickDelay = doubleClickDelay;
    }
    
    public void setMouseClickTolerance(final int mouseClickTolerance) {
        this.mouseClickTolerance = mouseClickTolerance;
    }
    
    public void setScale(final float scaleX, final float scaleY) {
        this.scaleX = scaleX;
        this.scaleY = scaleY;
    }
    
    public void setOffset(final float xoffset, final float yoffset) {
        this.xoffset = xoffset;
        this.yoffset = yoffset;
    }
    
    public void resetInputTransform() {
        this.setOffset(0.0f, 0.0f);
        this.setScale(1.0f, 1.0f);
    }
    
    public void addListener(final InputListener inputListener) {
        this.addKeyListener(inputListener);
        this.addMouseListener(inputListener);
        this.addControllerListener(inputListener);
    }
    
    public void addKeyListener(final KeyListener e) {
        this.keyListenersToAdd.add(e);
    }
    
    public void addKeyListenerImpl(final KeyListener e) {
        if (this.keyListeners.contains(e)) {
            return;
        }
        this.keyListeners.add(e);
        this.allListeners.add(e);
    }
    
    public void addMouseListener(final MouseListener e) {
        this.mouseListenersToAdd.add(e);
    }
    
    public void addMouseListenerImpl(final MouseListener e) {
        if (this.mouseListeners.contains(e)) {
            return;
        }
        this.mouseListeners.add(e);
        this.allListeners.add(e);
    }
    
    public void addControllerListener(final ControllerListener e) {
        if (this.controllerListeners.contains(e)) {
            return;
        }
        this.controllerListeners.add(e);
        this.allListeners.add(e);
    }
    
    public void removeAllListeners() {
        this.removeAllKeyListeners();
        this.removeAllMouseListeners();
        this.removeAllControllerListeners();
    }
    
    public void removeAllKeyListeners() {
        this.allListeners.removeAll(this.keyListeners);
        this.keyListeners.clear();
    }
    
    public void removeAllMouseListeners() {
        this.allListeners.removeAll(this.mouseListeners);
        this.mouseListeners.clear();
    }
    
    public void removeAllControllerListeners() {
        this.allListeners.removeAll(this.controllerListeners);
        this.controllerListeners.clear();
    }
    
    public void addPrimaryListener(final InputListener inputListener) {
        this.removeListener(inputListener);
        this.keyListeners.add(0, inputListener);
        this.mouseListeners.add(0, inputListener);
        this.controllerListeners.add(0, inputListener);
        this.allListeners.add(inputListener);
    }
    
    public void removeListener(final InputListener inputListener) {
        this.removeKeyListener(inputListener);
        this.removeMouseListener(inputListener);
        this.removeControllerListener(inputListener);
    }
    
    public void removeKeyListener(final KeyListener keyListener) {
        this.keyListeners.remove(keyListener);
        if (!this.mouseListeners.contains(keyListener) && !this.controllerListeners.contains(keyListener)) {
            this.allListeners.remove(keyListener);
        }
    }
    
    public void removeControllerListener(final ControllerListener controllerListener) {
        this.controllerListeners.remove(controllerListener);
        if (!this.mouseListeners.contains(controllerListener) && !this.keyListeners.contains(controllerListener)) {
            this.allListeners.remove(controllerListener);
        }
    }
    
    public void removeMouseListener(final MouseListener mouseListener) {
        this.mouseListeners.remove(mouseListener);
        if (!this.controllerListeners.contains(mouseListener) && !this.keyListeners.contains(mouseListener)) {
            this.allListeners.remove(mouseListener);
        }
    }
    
    public void init(final int height) {
        this.height = height;
        this.lastMouseX = this.getMouseX();
        this.lastMouseY = this.getMouseY();
    }
    
    public static String getKeyName(final int n) {
        return Keyboard.getKeyName(n);
    }
    
    public boolean isKeyPressed(final int n) {
        if (this.pressed[n]) {
            this.pressed[n] = false;
            return true;
        }
        return false;
    }
    
    public boolean isMousePressed(final int n) {
        if (this.mousePressed[n]) {
            this.mousePressed[n] = false;
            return true;
        }
        return false;
    }
    
    public boolean isControlPressed(final int n) {
        return this.isControlPressed(n, 0);
    }
    
    public boolean isControlPressed(final int n, final int n2) {
        if (this.controllerPressed[n2][n]) {
            this.controllerPressed[n2][n] = false;
            return true;
        }
        return false;
    }
    
    public void clearControlPressedRecord() {
        for (int i = 0; i < Input.controllers.size(); ++i) {
            Arrays.fill(this.controllerPressed[i], false);
        }
    }
    
    public void clearKeyPressedRecord() {
        Arrays.fill(this.pressed, false);
    }
    
    public void clearMousePressedRecord() {
        Arrays.fill(this.mousePressed, false);
    }
    
    public boolean isKeyDown(final int n) {
        return Keyboard.isKeyDown(n);
    }
    
    public int getAbsoluteMouseX() {
        return Mouse.getX();
    }
    
    public int getAbsoluteMouseY() {
        return this.height - Mouse.getY();
    }
    
    public int getMouseX() {
        return (int)(Mouse.getX() * this.scaleX + this.xoffset);
    }
    
    public int getMouseY() {
        return (int)((this.height - Mouse.getY()) * this.scaleY + this.yoffset);
    }
    
    public boolean isMouseButtonDown(final int n) {
        return Mouse.isButtonDown(n);
    }
    
    public boolean anyMouseDown() {
        for (int i = 0; i < 3; ++i) {
            if (Mouse.isButtonDown(i)) {
                return true;
            }
        }
        return false;
    }
    
    public int getControllerCount() {
        this.initControllers();
        return Input.controllers.size();
    }
    
    public int getAxisCount(final int index) {
        return Input.controllers.get(index).getAxisCount();
    }
    
    public float getAxisValue(final int index, final int n) {
        return Input.controllers.get(index).getAxisValue(n);
    }
    
    public String getAxisName(final int index, final int n) {
        return Input.controllers.get(index).getAxisName(n);
    }
    
    public boolean isControllerLeft(final int n) {
        if (n >= this.getControllerCount()) {
            return false;
        }
        if (n == -1) {
            for (int i = 0; i < Input.controllers.size(); ++i) {
                if (this.isControllerLeft(i)) {
                    return true;
                }
            }
            return false;
        }
        return Input.controllers.get(n).getXAxisValue() < -0.5f || Input.controllers.get(n).getPovX() < -0.5f;
    }
    
    public boolean isControllerRight(final int n) {
        if (n >= this.getControllerCount()) {
            return false;
        }
        if (n == -1) {
            for (int i = 0; i < Input.controllers.size(); ++i) {
                if (this.isControllerRight(i)) {
                    return true;
                }
            }
            return false;
        }
        return Input.controllers.get(n).getXAxisValue() > 0.0f || Input.controllers.get(n).getPovX() > 0.0f;
    }
    
    public boolean isControllerUp(final int n) {
        if (n >= this.getControllerCount()) {
            return false;
        }
        if (n == -1) {
            for (int i = 0; i < Input.controllers.size(); ++i) {
                if (this.isControllerUp(i)) {
                    return true;
                }
            }
            return false;
        }
        return Input.controllers.get(n).getYAxisValue() < -0.5f || Input.controllers.get(n).getPovY() < -0.5f;
    }
    
    public boolean isControllerDown(final int n) {
        if (n >= this.getControllerCount()) {
            return false;
        }
        if (n == -1) {
            for (int i = 0; i < Input.controllers.size(); ++i) {
                if (this.isControllerDown(i)) {
                    return true;
                }
            }
            return false;
        }
        return Input.controllers.get(n).getYAxisValue() > 0.0f || Input.controllers.get(n).getPovY() > 0.0f;
    }
    
    public boolean isButtonPressed(final int n, final int index) {
        if (index >= this.getControllerCount()) {
            return false;
        }
        if (index == -1) {
            for (int i = 0; i < Input.controllers.size(); ++i) {
                if (this.isButtonPressed(n, i)) {
                    return true;
                }
            }
            return false;
        }
        return Input.controllers.get(index).isButtonPressed(n);
    }
    
    public boolean isButton1Pressed(final int n) {
        return this.isButtonPressed(0, n);
    }
    
    public boolean isButton2Pressed(final int n) {
        return this.isButtonPressed(1, n);
    }
    
    public boolean isButton3Pressed(final int n) {
        return this.isButtonPressed(2, n);
    }
    
    public void initControllers() throws SlickException {
        if (Input.controllersInited) {
            return;
        }
        Input.controllersInited = true;
        Controllers.create();
        for (int controllerCount = Controllers.getControllerCount(), i = 0; i < controllerCount; ++i) {
            final Controller controller = Controllers.getController(i);
            if (controller.getButtonCount() >= 3 && controller.getButtonCount() < 100) {
                Input.controllers.add(controller);
            }
        }
        Log.info("Found " + Input.controllers.size() + " controllers");
        for (int j = 0; j < Input.controllers.size(); ++j) {
            Log.info(j + " : " + ((Controller)Input.controllers.get(j)).getName());
        }
    }
    
    public void consumeEvent() {
        this.consumed = true;
    }
    
    public int resolveEventKey(final int n, final char c) {
        if (c == '=' || n == 0) {
            return 13;
        }
        return n;
    }
    
    public void considerDoubleClick(final int clickButton, final int clickX, final int clickY) {
        if (this.doubleClickTimeout == ((long)(-151906573) ^ 0xFFFFFFFFF6F216F3L)) {
            this.clickX = clickX;
            this.clickY = clickY;
            this.clickButton = clickButton;
            this.doubleClickTimeout = System.currentTimeMillis() + this.doubleClickDelay;
            this.fireMouseClicked(clickButton, clickX, clickY, 1);
        }
        else if (this.clickButton == clickButton && System.currentTimeMillis() < this.doubleClickTimeout) {
            this.fireMouseClicked(clickButton, clickX, clickY, 2);
            this.doubleClickTimeout = ((long)1407632475 ^ 0x53E6C45BL);
        }
    }
    
    public void poll(final int n, final int height) {
        if (this.paused) {
            this.clearControlPressedRecord();
            this.clearKeyPressedRecord();
            this.clearMousePressedRecord();
            while (Keyboard.next()) {}
            while (Mouse.next()) {}
            return;
        }
        if (!Display.isActive()) {
            this.clearControlPressedRecord();
            this.clearKeyPressedRecord();
            this.clearMousePressedRecord();
        }
        for (int i = 0; i < this.keyListenersToAdd.size(); ++i) {
            this.addKeyListenerImpl((KeyListener)this.keyListenersToAdd.get(i));
        }
        this.keyListenersToAdd.clear();
        for (int j = 0; j < this.mouseListenersToAdd.size(); ++j) {
            this.addMouseListenerImpl((MouseListener)this.mouseListenersToAdd.get(j));
        }
        this.mouseListenersToAdd.clear();
        if (this.doubleClickTimeout != ((long)346378561 ^ 0x14A55141L) && System.currentTimeMillis() > this.doubleClickTimeout) {
            this.doubleClickTimeout = ((long)(-1805900075) ^ 0xFFFFFFFF945C26D5L);
        }
        this.height = height;
        final Iterator<ControlledInputReciever> iterator = (Iterator<ControlledInputReciever>)this.allListeners.iterator();
        while (iterator.hasNext()) {
            iterator.next().inputStarted();
        }
        while (Keyboard.next()) {
            if (Keyboard.getEventKeyState()) {
                final int resolveEventKey = this.resolveEventKey(Keyboard.getEventKey(), Keyboard.getEventCharacter());
                this.keys[resolveEventKey] = Keyboard.getEventCharacter();
                this.pressed[resolveEventKey] = true;
                this.nextRepeat[resolveEventKey] = System.currentTimeMillis() + this.keyRepeatInitial;
                this.consumed = false;
                for (int k = 0; k < this.keyListeners.size(); ++k) {
                    final KeyListener keyListener = this.keyListeners.get(k);
                    if (keyListener.isAcceptingInput()) {
                        keyListener.keyPressed(resolveEventKey, Keyboard.getEventCharacter());
                        if (this.consumed) {
                            break;
                        }
                    }
                }
            }
            else {
                final int resolveEventKey2 = this.resolveEventKey(Keyboard.getEventKey(), Keyboard.getEventCharacter());
                this.nextRepeat[resolveEventKey2] = ((long)(-1389346276) ^ 0xFFFFFFFFAD30421CL);
                this.consumed = false;
                for (int l = 0; l < this.keyListeners.size(); ++l) {
                    final KeyListener keyListener2 = this.keyListeners.get(l);
                    if (keyListener2.isAcceptingInput()) {
                        keyListener2.keyReleased(resolveEventKey2, this.keys[resolveEventKey2]);
                        if (this.consumed) {
                            break;
                        }
                    }
                }
            }
        }
        while (Mouse.next()) {
            if (Mouse.getEventButton() >= 0) {
                if (Mouse.getEventButtonState()) {
                    this.consumed = false;
                    this.mousePressed[Mouse.getEventButton()] = true;
                    this.pressedX = (int)(this.xoffset + Mouse.getEventX() * this.scaleX);
                    this.pressedY = (int)(this.yoffset + (height - Mouse.getEventY()) * this.scaleY);
                    for (int index = 0; index < this.mouseListeners.size(); ++index) {
                        final MouseListener mouseListener = this.mouseListeners.get(index);
                        if (mouseListener.isAcceptingInput()) {
                            mouseListener.mousePressed(Mouse.getEventButton(), this.pressedX, this.pressedY);
                            if (this.consumed) {
                                break;
                            }
                        }
                    }
                }
                else {
                    this.consumed = false;
                    this.mousePressed[Mouse.getEventButton()] = false;
                    final int n2 = (int)(this.xoffset + Mouse.getEventX() * this.scaleX);
                    final int n3 = (int)(this.yoffset + (height - Mouse.getEventY()) * this.scaleY);
                    if (this.pressedX != -1 && this.pressedY != -1 && Math.abs(this.pressedX - n2) < this.mouseClickTolerance && Math.abs(this.pressedY - n3) < this.mouseClickTolerance) {
                        this.considerDoubleClick(Mouse.getEventButton(), n2, n3);
                        final int n4 = -1;
                        this.pressedY = n4;
                        this.pressedX = n4;
                    }
                    for (int index2 = 0; index2 < this.mouseListeners.size(); ++index2) {
                        final MouseListener mouseListener2 = this.mouseListeners.get(index2);
                        if (mouseListener2.isAcceptingInput()) {
                            mouseListener2.mouseReleased(Mouse.getEventButton(), n2, n3);
                            if (this.consumed) {
                                break;
                            }
                        }
                    }
                }
            }
            else {
                if (Mouse.isGrabbed() && this.displayActive && (Mouse.getEventDX() != 0 || Mouse.getEventDY() != 0)) {
                    this.consumed = false;
                    for (int index3 = 0; index3 < this.mouseListeners.size(); ++index3) {
                        final MouseListener mouseListener3 = this.mouseListeners.get(index3);
                        if (mouseListener3.isAcceptingInput()) {
                            if (this.anyMouseDown()) {
                                mouseListener3.mouseDragged(0, 0, Mouse.getEventDX(), -Mouse.getEventDY());
                            }
                            else {
                                mouseListener3.mouseMoved(0, 0, Mouse.getEventDX(), -Mouse.getEventDY());
                            }
                            if (this.consumed) {
                                break;
                            }
                        }
                    }
                }
                final int eventDWheel = Mouse.getEventDWheel();
                this.wheel += eventDWheel;
                if (eventDWheel == 0) {
                    continue;
                }
                this.consumed = false;
                for (int index4 = 0; index4 < this.mouseListeners.size(); ++index4) {
                    final MouseListener mouseListener4 = this.mouseListeners.get(index4);
                    if (mouseListener4.isAcceptingInput()) {
                        mouseListener4.mouseWheelMoved(eventDWheel);
                        if (this.consumed) {
                            break;
                        }
                    }
                }
            }
        }
        if (!this.displayActive || Mouse.isGrabbed()) {
            this.lastMouseX = this.getMouseX();
            this.lastMouseY = this.getMouseY();
        }
        else if (this.lastMouseX != this.getMouseX() || this.lastMouseY != this.getMouseY()) {
            this.consumed = false;
            for (int index5 = 0; index5 < this.mouseListeners.size(); ++index5) {
                final MouseListener mouseListener5 = this.mouseListeners.get(index5);
                if (mouseListener5.isAcceptingInput()) {
                    if (this.anyMouseDown()) {
                        mouseListener5.mouseDragged(this.lastMouseX, this.lastMouseY, this.getMouseX(), this.getMouseY());
                    }
                    else {
                        mouseListener5.mouseMoved(this.lastMouseX, this.lastMouseY, this.getMouseX(), this.getMouseY());
                    }
                    if (this.consumed) {
                        break;
                    }
                }
            }
            this.lastMouseX = this.getMouseX();
            this.lastMouseY = this.getMouseY();
        }
        if (Input.controllersInited) {
            for (int index6 = 0; index6 < this.getControllerCount(); ++index6) {
                for (int min = Math.min(Input.controllers.get(index6).getButtonCount() + 3, 24), n5 = 0; n5 <= min; ++n5) {
                    if (this.controls[index6][n5] && !this.isControlDwn(n5, index6)) {
                        this.controls[index6][n5] = false;
                        this.fireControlRelease(n5, index6);
                    }
                    else if (!this.controls[index6][n5] && this.isControlDwn(n5, index6)) {
                        this.controllerPressed[index6][n5] = true;
                        this.controls[index6][n5] = true;
                        this.fireControlPress(n5, index6);
                    }
                }
            }
        }
        if (this.keyRepeat) {
            for (int n6 = 0; n6 < 1024; ++n6) {
                if (this.pressed[n6] && this.nextRepeat[n6] != ((long)32921282 ^ 0x1F656C2L) && System.currentTimeMillis() > this.nextRepeat[n6]) {
                    this.nextRepeat[n6] = System.currentTimeMillis() + this.keyRepeatInterval;
                    this.consumed = false;
                    for (int index7 = 0; index7 < this.keyListeners.size(); ++index7) {
                        final KeyListener keyListener3 = this.keyListeners.get(index7);
                        if (keyListener3.isAcceptingInput()) {
                            keyListener3.keyPressed(n6, this.keys[n6]);
                            if (this.consumed) {
                                break;
                            }
                        }
                    }
                }
            }
        }
        final Iterator<ControlledInputReciever> iterator2 = (Iterator<ControlledInputReciever>)this.allListeners.iterator();
        while (iterator2.hasNext()) {
            iterator2.next().inputEnded();
        }
        if (Display.isCreated()) {
            this.displayActive = Display.isActive();
        }
    }
    
    @Deprecated
    public void enableKeyRepeat(final int n, final int n2) {
        Keyboard.enableRepeatEvents(true);
    }
    
    public void enableKeyRepeat() {
        Keyboard.enableRepeatEvents(true);
    }
    
    public void disableKeyRepeat() {
        Keyboard.enableRepeatEvents(false);
    }
    
    public boolean isKeyRepeatEnabled() {
        return Keyboard.areRepeatEventsEnabled();
    }
    
    public void fireControlPress(final int n, final int n2) {
        this.consumed = false;
        for (int i = 0; i < this.controllerListeners.size(); ++i) {
            final ControllerListener controllerListener = this.controllerListeners.get(i);
            if (controllerListener.isAcceptingInput()) {
                switch (n) {
                    case 0: {
                        controllerListener.controllerLeftPressed(n2);
                        break;
                    }
                    case 1: {
                        controllerListener.controllerRightPressed(n2);
                        break;
                    }
                    case 2: {
                        controllerListener.controllerUpPressed(n2);
                        break;
                    }
                    case 3: {
                        controllerListener.controllerDownPressed(n2);
                        break;
                    }
                    default: {
                        controllerListener.controllerButtonPressed(n2, n - 4 + 1);
                        break;
                    }
                }
                if (this.consumed) {
                    break;
                }
            }
        }
    }
    
    public void fireControlRelease(final int n, final int n2) {
        this.consumed = false;
        for (int i = 0; i < this.controllerListeners.size(); ++i) {
            final ControllerListener controllerListener = this.controllerListeners.get(i);
            if (controllerListener.isAcceptingInput()) {
                switch (n) {
                    case 0: {
                        controllerListener.controllerLeftReleased(n2);
                        break;
                    }
                    case 1: {
                        controllerListener.controllerRightReleased(n2);
                        break;
                    }
                    case 2: {
                        controllerListener.controllerUpReleased(n2);
                        break;
                    }
                    case 3: {
                        controllerListener.controllerDownReleased(n2);
                        break;
                    }
                    default: {
                        controllerListener.controllerButtonReleased(n2, n - 4 + 1);
                        break;
                    }
                }
                if (this.consumed) {
                    break;
                }
            }
        }
    }
    
    public boolean isControlDwn(final int n, final int n2) {
        switch (n) {
            case 0: {
                return this.isControllerLeft(n2);
            }
            case 1: {
                return this.isControllerRight(n2);
            }
            case 2: {
                return this.isControllerUp(n2);
            }
            case 3: {
                return this.isControllerDown(n2);
            }
            default: {
                if (n >= 4) {
                    return this.isButtonPressed(n - 4, n2);
                }
                throw new RuntimeException("Unknown control index");
            }
        }
    }
    
    public void pause() {
        this.paused = true;
        this.clearKeyPressedRecord();
        this.clearMousePressedRecord();
        this.clearControlPressedRecord();
    }
    
    public void resume() {
        this.paused = false;
    }
    
    public void fireMouseClicked(final int n, final int n2, final int n3, final int n4) {
        this.consumed = false;
        for (int i = 0; i < this.mouseListeners.size(); ++i) {
            final MouseListener mouseListener = this.mouseListeners.get(i);
            if (mouseListener.isAcceptingInput()) {
                mouseListener.mouseClicked(n, n2, n3, n4);
                if (this.consumed) {
                    break;
                }
            }
        }
    }
    
    static {
        Input.MOUSE_MIDDLE_BUTTON = 2;
        Input.MOUSE_RIGHT_BUTTON = 1;
        Input.MOUSE_LEFT_BUTTON = 0;
        Input.BUTTON10 = 13;
        Input.BUTTON9 = 12;
        Input.BUTTON8 = 11;
        Input.BUTTON7 = 10;
        Input.BUTTON6 = 9;
        Input.BUTTON5 = 8;
        Input.BUTTON4 = 7;
        Input.BUTTON3 = 6;
        Input.BUTTON2 = 5;
        Input.BUTTON1 = 4;
        Input.DOWN = 3;
        Input.UP = 2;
        Input.RIGHT = 1;
        Input.LEFT = 0;
        Input.KEY_RALT = 184;
        Input.KEY_LALT = 56;
        Input.KEY_SLEEP = 223;
        Input.KEY_POWER = 222;
        Input.KEY_APPS = 221;
        Input.KEY_RWIN = 220;
        Input.KEY_LWIN = 219;
        Input.KEY_DELETE = 211;
        Input.KEY_INSERT = 210;
        Input.KEY_NEXT = 209;
        Input.KEY_DOWN = 208;
        Input.KEY_END = 207;
        Input.KEY_RIGHT = 205;
        Input.KEY_LEFT = 203;
        Input.KEY_PRIOR = 201;
        Input.KEY_UP = 200;
        Input.KEY_HOME = 199;
        Input.KEY_PAUSE = 197;
        Input.KEY_RMENU = 184;
        Input.KEY_SYSRQ = 183;
        Input.KEY_DIVIDE = 181;
        Input.KEY_NUMPADCOMMA = 179;
        Input.KEY_RCONTROL = 157;
        Input.KEY_NUMPADENTER = 156;
        Input.KEY_UNLABELED = 151;
        Input.KEY_AX = 150;
        Input.KEY_STOP = 149;
        Input.KEY_KANJI = 148;
        Input.KEY_UNDERLINE = 147;
        Input.KEY_COLON = 146;
        Input.KEY_AT = 145;
        Input.KEY_CIRCUMFLEX = 144;
        Input.KEY_NUMPADEQUALS = 141;
        Input.KEY_YEN = 125;
        Input.KEY_NOCONVERT = 123;
        Input.KEY_CONVERT = 121;
        Input.KEY_KANA = 112;
        Input.KEY_F15 = 102;
        Input.KEY_F14 = 101;
        Input.KEY_F13 = 100;
        Input.KEY_F12 = 88;
        Input.KEY_F11 = 87;
        Input.KEY_DECIMAL = 83;
        Input.KEY_NUMPAD0 = 82;
        Input.KEY_NUMPAD3 = 81;
        Input.KEY_NUMPAD2 = 80;
        Input.KEY_NUMPAD1 = 79;
        Input.KEY_ADD = 78;
        Input.KEY_NUMPAD6 = 77;
        Input.KEY_NUMPAD5 = 76;
        Input.KEY_NUMPAD4 = 75;
        Input.KEY_SUBTRACT = 74;
        Input.KEY_NUMPAD9 = 73;
        Input.KEY_NUMPAD8 = 72;
        Input.KEY_NUMPAD7 = 71;
        Input.KEY_SCROLL = 70;
        Input.KEY_NUMLOCK = 69;
        Input.KEY_F10 = 68;
        Input.KEY_F9 = 67;
        Input.KEY_F8 = 66;
        Input.KEY_F7 = 65;
        Input.KEY_F6 = 64;
        Input.KEY_F5 = 63;
        Input.KEY_F4 = 62;
        Input.KEY_F3 = 61;
        Input.KEY_F2 = 60;
        Input.KEY_F1 = 59;
        Input.KEY_CAPITAL = 58;
        Input.KEY_SPACE = 57;
        Input.KEY_LMENU = 56;
        Input.KEY_MULTIPLY = 55;
        Input.KEY_RSHIFT = 54;
        Input.KEY_SLASH = 53;
        Input.KEY_PERIOD = 52;
        Input.KEY_COMMA = 51;
        Input.KEY_M = 50;
        Input.KEY_N = 49;
        Input.KEY_B = 48;
        Input.KEY_V = 47;
        Input.KEY_C = 46;
        Input.KEY_X = 45;
        Input.KEY_Z = 44;
        Input.KEY_BACKSLASH = 43;
        Input.KEY_LSHIFT = 42;
        Input.KEY_GRAVE = 41;
        Input.KEY_APOSTROPHE = 40;
        Input.KEY_SEMICOLON = 39;
        Input.KEY_L = 38;
        Input.KEY_K = 37;
        Input.KEY_J = 36;
        Input.KEY_H = 35;
        Input.KEY_G = 34;
        Input.KEY_F = 33;
        Input.KEY_D = 32;
        Input.KEY_S = 31;
        Input.KEY_A = 30;
        Input.KEY_LCONTROL = 29;
        Input.KEY_ENTER = 28;
        Input.KEY_RETURN = 28;
        Input.KEY_RBRACKET = 27;
        Input.KEY_LBRACKET = 26;
        Input.KEY_P = 25;
        Input.KEY_O = 24;
        Input.KEY_I = 23;
        Input.KEY_U = 22;
        Input.KEY_Y = 21;
        Input.KEY_T = 20;
        Input.KEY_R = 19;
        Input.KEY_E = 18;
        Input.KEY_W = 17;
        Input.KEY_Q = 16;
        Input.KEY_TAB = 15;
        Input.KEY_BACK = 14;
        Input.KEY_EQUALS = 13;
        Input.KEY_MINUS = 12;
        Input.KEY_0 = 11;
        Input.KEY_9 = 10;
        Input.KEY_8 = 9;
        Input.KEY_7 = 8;
        Input.KEY_6 = 7;
        Input.KEY_5 = 6;
        Input.KEY_4 = 5;
        Input.KEY_3 = 4;
        Input.KEY_2 = 3;
        Input.KEY_1 = 2;
        Input.KEY_ESCAPE = 1;
        Input.MAX_BUTTONS = 100;
        Input.ANY_CONTROLLER = -1;
        Input.controllersInited = false;
        Input.controllers = new ArrayList();
    }
    
    private class NullOutputStream extends OutputStream
    {
        public Input this$0;
        
        public NullOutputStream(final Input this$0) {
            this.this$0 = this$0;
        }
        
        @Override
        public void write(final int n) throws IOException {
        }
    }
}
