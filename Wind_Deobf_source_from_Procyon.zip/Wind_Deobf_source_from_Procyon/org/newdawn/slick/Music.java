// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.newdawn.slick.openal.AudioImpl;
import java.io.InputStream;
import java.net.URL;
import org.newdawn.slick.openal.SoundStore;
import java.util.ArrayList;
import org.newdawn.slick.openal.Audio;

public class Music
{
    public static Music currentMusic;
    public Audio sound;
    public boolean playing;
    public ArrayList listeners;
    public float volume;
    public float fadeStartGain;
    public float fadeEndGain;
    public int fadeTime;
    public int fadeDuration;
    public boolean stopAfterFade;
    public boolean positioning;
    public float requiredPosition;
    
    public static void poll(final int n) {
        if (Music.currentMusic != null) {
            SoundStore.get().poll(n);
            if (!SoundStore.get().isMusicPlaying()) {
                if (!Music.currentMusic.positioning) {
                    final Music currentMusic = Music.currentMusic;
                    Music.currentMusic = null;
                    currentMusic.fireMusicEnded();
                }
            }
            else {
                Music.currentMusic.update(n);
            }
        }
    }
    
    public Music(final String s) throws SlickException {
        this(s, false);
    }
    
    public Music(final URL url) throws SlickException {
        this(url, false);
    }
    
    public Music(final InputStream inputStream, final String s) throws SlickException {
        this.listeners = new ArrayList();
        this.volume = 1.0f;
        this.requiredPosition = -1.0f;
        SoundStore.get().init();
        if (s.toLowerCase().endsWith(".ogg")) {
            this.sound = SoundStore.get().getOgg(inputStream);
        }
        else if (s.toLowerCase().endsWith(".wav")) {
            this.sound = SoundStore.get().getWAV(inputStream);
        }
        else if (s.toLowerCase().endsWith(".xm") || s.toLowerCase().endsWith(".mod")) {
            this.sound = SoundStore.get().getMOD(inputStream);
        }
        else {
            if (!s.toLowerCase().endsWith(".aif") && !s.toLowerCase().endsWith(".aiff")) {
                throw new SlickException("Only .xm, .mod, .ogg, and .aif/f are currently supported.");
            }
            this.sound = SoundStore.get().getAIF(inputStream);
        }
    }
    
    public Music(final URL url, final boolean b) throws SlickException {
        this.listeners = new ArrayList();
        this.volume = 1.0f;
        this.requiredPosition = -1.0f;
        SoundStore.get().init();
        final String file = url.getFile();
        if (file.toLowerCase().endsWith(".ogg")) {
            if (b) {
                this.sound = SoundStore.get().getOggStream(url);
            }
            else {
                this.sound = SoundStore.get().getOgg(url.openStream());
            }
        }
        else if (file.toLowerCase().endsWith(".wav")) {
            this.sound = SoundStore.get().getWAV(url.openStream());
        }
        else if (file.toLowerCase().endsWith(".xm") || file.toLowerCase().endsWith(".mod")) {
            this.sound = SoundStore.get().getMOD(url.openStream());
        }
        else {
            if (!file.toLowerCase().endsWith(".aif") && !file.toLowerCase().endsWith(".aiff")) {
                throw new SlickException("Only .xm, .mod, .ogg, and .aif/f are currently supported.");
            }
            this.sound = SoundStore.get().getAIF(url.openStream());
        }
    }
    
    public Music(final String s, final boolean b) throws SlickException {
        this.listeners = new ArrayList();
        this.volume = 1.0f;
        this.requiredPosition = -1.0f;
        SoundStore.get().init();
        if (s.toLowerCase().endsWith(".ogg")) {
            if (b) {
                this.sound = SoundStore.get().getOggStream(s);
            }
            else {
                this.sound = SoundStore.get().getOgg(s);
            }
        }
        else if (s.toLowerCase().endsWith(".wav")) {
            this.sound = SoundStore.get().getWAV(s);
        }
        else if (s.toLowerCase().endsWith(".xm") || s.toLowerCase().endsWith(".mod")) {
            this.sound = SoundStore.get().getMOD(s);
        }
        else {
            if (!s.toLowerCase().endsWith(".aif") && !s.toLowerCase().endsWith(".aiff")) {
                throw new SlickException("Only .xm, .mod, .ogg, and .aif/f are currently supported.");
            }
            this.sound = SoundStore.get().getAIF(s);
        }
    }
    
    public void addListener(final MusicListener e) {
        this.listeners.add(e);
    }
    
    public void removeListener(final MusicListener o) {
        this.listeners.remove(o);
    }
    
    public void fireMusicEnded() {
        this.playing = false;
        for (int i = 0; i < this.listeners.size(); ++i) {
            ((MusicListener)this.listeners.get(i)).musicEnded(this);
        }
    }
    
    public void fireMusicSwapped(final Music music) {
        this.playing = false;
        for (int i = 0; i < this.listeners.size(); ++i) {
            ((MusicListener)this.listeners.get(i)).musicSwapped(this, music);
        }
    }
    
    public void loop() {
        this.loop(1.0f, 1.0f);
    }
    
    public void play() {
        this.play(1.0f, 1.0f);
    }
    
    public void play(final float n, final float n2) {
        this.startMusic(n, n2, false);
    }
    
    public void loop(final float n, final float n2) {
        this.startMusic(n, n2, true);
    }
    
    public void startMusic(final float n, float volume, final boolean b) {
        if (Music.currentMusic != null) {
            Music.currentMusic.stop();
            Music.currentMusic.fireMusicSwapped(this);
        }
        Music.currentMusic = this;
        if (volume < 0.0f) {
            volume = 0.0f;
        }
        if (volume > 1.0f) {
            volume = 1.0f;
        }
        this.sound.playAsMusic(n, volume, b);
        this.playing = true;
        this.setVolume(volume);
        if (this.requiredPosition != -1.0f) {
            this.setPosition(this.requiredPosition);
        }
    }
    
    public void pause() {
        this.playing = false;
        AudioImpl.pauseMusic();
    }
    
    public void stop() {
        this.sound.stop();
    }
    
    public void resume() {
        this.playing = true;
        AudioImpl.restartMusic();
    }
    
    public boolean playing() {
        return Music.currentMusic == this && this.playing;
    }
    
    public void setVolume(float n) {
        if (n > 1.0f) {
            n = 1.0f;
        }
        else if (n < 0.0f) {
            n = 0.0f;
        }
        this.volume = n;
        if (Music.currentMusic == this) {
            SoundStore.get().setCurrentMusicVolume(n);
        }
    }
    
    public float getVolume() {
        return this.volume;
    }
    
    public void fade(final int n, final float fadeEndGain, final boolean stopAfterFade) {
        this.stopAfterFade = stopAfterFade;
        this.fadeStartGain = this.volume;
        this.fadeEndGain = fadeEndGain;
        this.fadeDuration = n;
        this.fadeTime = n;
    }
    
    public void update(final int n) {
        if (!this.playing) {
            return;
        }
        if (this.fadeTime > 0) {
            this.fadeTime -= n;
            if (this.fadeTime < 0) {
                this.fadeTime = 0;
                if (this.stopAfterFade) {
                    this.stop();
                    return;
                }
            }
            this.setVolume(this.fadeStartGain + (this.fadeEndGain - this.fadeStartGain) * (1.0f - this.fadeTime / (float)this.fadeDuration));
        }
    }
    
    public boolean setPosition(final float n) {
        if (this.playing) {
            this.requiredPosition = -1.0f;
            this.positioning = true;
            this.playing = false;
            final boolean setPosition = this.sound.setPosition(n);
            this.playing = true;
            this.positioning = false;
            return setPosition;
        }
        this.requiredPosition = n;
        return false;
    }
    
    public float getPosition() {
        return this.sound.getPosition();
    }
}
