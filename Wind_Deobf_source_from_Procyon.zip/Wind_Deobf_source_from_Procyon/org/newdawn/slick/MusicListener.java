// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

public interface MusicListener
{
    void musicEnded(final Music p0);
    
    void musicSwapped(final Music p0, final Music p1);
}
