// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.newdawn.slick.util.ResourceLoader;
import java.util.HashMap;

public class PackedSpriteSheet
{
    public Image image;
    public String basePath;
    public HashMap sections;
    public int filter;
    
    public PackedSpriteSheet(final String s) throws SlickException {
        this(s, null);
    }
    
    public PackedSpriteSheet(String replace, final Color color) throws SlickException {
        this.sections = new HashMap();
        this.filter = 2;
        replace = replace.replace('\\', '/');
        this.basePath = replace.substring(0, replace.lastIndexOf("/") + 1);
        this.loadDefinition(replace, color);
    }
    
    public PackedSpriteSheet(final String s, final int n) throws SlickException {
        this(s, n, null);
    }
    
    public PackedSpriteSheet(String replace, final int filter, final Color color) throws SlickException {
        this.sections = new HashMap();
        this.filter = 2;
        this.filter = filter;
        replace = replace.replace('\\', '/');
        this.basePath = replace.substring(0, replace.lastIndexOf("/") + 1);
        this.loadDefinition(replace, color);
    }
    
    public Image getFullImage() {
        return this.image;
    }
    
    public Image getSprite(final String s) {
        final Section section = this.sections.get(s);
        if (section == null) {
            throw new RuntimeException("Unknown sprite from packed sheet: " + s);
        }
        return this.image.getSubImage(section.x, section.y, section.width, section.height);
    }
    
    public SpriteSheet getSpriteSheet(final String key) {
        final Image sprite = this.getSprite(key);
        final Section section = this.sections.get(key);
        return new SpriteSheet(sprite, section.width / section.tilesx, section.height / section.tilesy);
    }
    
    public void loadDefinition(final String s, final Color color) throws SlickException {
        final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(ResourceLoader.getResourceAsStream(s)));
        this.image = new Image(this.basePath + bufferedReader.readLine(), false, this.filter, color);
        while (bufferedReader.ready()) {
            if (bufferedReader.readLine() == null) {
                break;
            }
            final Section value = new Section(bufferedReader);
            this.sections.put(value.name, value);
            if (bufferedReader.readLine() == null) {
                break;
            }
        }
    }
    
    private class Section
    {
        public int x;
        public int y;
        public int width;
        public int height;
        public int tilesx;
        public int tilesy;
        public String name;
        public PackedSpriteSheet this$0;
        
        public Section(final PackedSpriteSheet this$0, final BufferedReader bufferedReader) throws IOException {
            this.this$0 = this$0;
            this.name = bufferedReader.readLine().trim();
            this.x = Integer.parseInt(bufferedReader.readLine().trim());
            this.y = Integer.parseInt(bufferedReader.readLine().trim());
            this.width = Integer.parseInt(bufferedReader.readLine().trim());
            this.height = Integer.parseInt(bufferedReader.readLine().trim());
            this.tilesx = Integer.parseInt(bufferedReader.readLine().trim());
            this.tilesy = Integer.parseInt(bufferedReader.readLine().trim());
            bufferedReader.readLine().trim();
            bufferedReader.readLine().trim();
            this.tilesx = Math.max(1, this.tilesx);
            this.tilesy = Math.max(1, this.tilesy);
        }
    }
}
