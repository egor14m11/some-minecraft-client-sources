// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

public interface Renderable
{
    void draw(final float p0, final float p1);
}
