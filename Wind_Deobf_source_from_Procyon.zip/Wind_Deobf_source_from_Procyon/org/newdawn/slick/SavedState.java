// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.newdawn.slick.util.Log;
import javax.jnlp.ServiceManager;
import java.io.IOException;
import org.newdawn.slick.muffin.FileMuffin;
import org.newdawn.slick.muffin.WebstartMuffin;
import java.util.HashMap;
import org.newdawn.slick.muffin.Muffin;

public class SavedState
{
    public String fileName;
    public Muffin muffin;
    public HashMap numericData;
    public HashMap stringData;
    
    public SavedState(final String fileName) throws SlickException {
        this.numericData = new HashMap();
        this.stringData = new HashMap();
        this.fileName = fileName;
        if (this.isWebstartAvailable()) {
            this.muffin = new WebstartMuffin();
        }
        else {
            this.muffin = new FileMuffin();
        }
        this.load();
    }
    
    public double getNumber(final String s) {
        return this.getNumber(s, 0.0);
    }
    
    public double getNumber(final String key, final double n) {
        final Double n2 = this.numericData.get(key);
        if (n2 == null) {
            return n;
        }
        return n2;
    }
    
    public void setNumber(final String key, final double value) {
        this.numericData.put(key, new Double(value));
    }
    
    public String getString(final String s) {
        return this.getString(s, null);
    }
    
    public String getString(final String key, final String s) {
        final String s2 = this.stringData.get(key);
        if (s2 == null) {
            return s;
        }
        return s2;
    }
    
    public void setString(final String key, final String value) {
        this.stringData.put(key, value);
    }
    
    public void save() throws IOException {
        this.muffin.saveFile(this.numericData, this.fileName + "_Number");
        this.muffin.saveFile(this.stringData, this.fileName + "_String");
    }
    
    public void load() throws IOException {
        this.numericData = this.muffin.loadFile(this.fileName + "_Number");
        this.stringData = this.muffin.loadFile(this.fileName + "_String");
    }
    
    public void clear() {
        this.numericData.clear();
        this.stringData.clear();
    }
    
    public boolean isWebstartAvailable() {
        Class.forName("javax.jnlp.ServiceManager");
        ServiceManager.lookup("javax.jnlp.PersistenceService");
        Log.info("Webstart detected using Muffins");
        return true;
    }
}
