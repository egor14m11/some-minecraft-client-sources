// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.opengl.SlickCallable;
import org.newdawn.slick.opengl.renderer.SGL;

public class ScalableGame implements Game
{
    public static SGL GL;
    public float normalWidth;
    public float normalHeight;
    public Game held;
    public boolean maintainAspect;
    public int targetWidth;
    public int targetHeight;
    public GameContainer container;
    
    public ScalableGame(final Game game, final int n, final int n2) {
        this(game, n, n2, false);
    }
    
    public ScalableGame(final Game held, final int n, final int n2, final boolean maintainAspect) {
        this.held = held;
        this.normalWidth = (float)n;
        this.normalHeight = (float)n2;
        this.maintainAspect = maintainAspect;
    }
    
    @Override
    public void init(final GameContainer container) throws SlickException {
        this.container = container;
        this.recalculateScale();
        this.held.init(container);
    }
    
    public void recalculateScale() throws SlickException {
        this.targetWidth = this.container.getWidth();
        this.targetHeight = this.container.getHeight();
        if (this.maintainAspect) {
            final boolean b = this.normalWidth / this.normalHeight > 1.6;
            final boolean b2 = this.targetWidth / (float)this.targetHeight > 1.6;
            final float n = this.targetWidth / this.normalWidth;
            final float n2 = this.targetHeight / this.normalHeight;
            if (b & b2) {
                final float n3 = (n < n2) ? n : n2;
                this.targetWidth = (int)(this.normalWidth * n3);
                this.targetHeight = (int)(this.normalHeight * n3);
            }
            else if (b & !b2) {
                this.targetWidth = (int)(this.normalWidth * n);
                this.targetHeight = (int)(this.normalHeight * n);
            }
            else if (!b & b2) {
                this.targetWidth = (int)(this.normalWidth * n2);
                this.targetHeight = (int)(this.normalHeight * n2);
            }
            else {
                final float n4 = (n < n2) ? n : n2;
                this.targetWidth = (int)(this.normalWidth * n4);
                this.targetHeight = (int)(this.normalHeight * n4);
            }
        }
        if (this.held instanceof InputListener) {
            this.container.getInput().addListener((InputListener)this.held);
        }
        this.container.getInput().setScale(this.normalWidth / this.targetWidth, this.normalHeight / this.targetHeight);
        int n5 = 0;
        int n6 = 0;
        if (this.targetHeight < this.container.getHeight()) {
            n5 = (this.container.getHeight() - this.targetHeight) / 2;
        }
        if (this.targetWidth < this.container.getWidth()) {
            n6 = (this.container.getWidth() - this.targetWidth) / 2;
        }
        this.container.getInput().setOffset(-n6 / (this.targetWidth / this.normalWidth), -n5 / (this.targetHeight / this.normalHeight));
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        if (this.targetHeight != gameContainer.getHeight() || this.targetWidth != gameContainer.getWidth()) {
            this.recalculateScale();
        }
        this.held.update(gameContainer, n);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        int n = 0;
        int n2 = 0;
        if (this.targetHeight < gameContainer.getHeight()) {
            n = (gameContainer.getHeight() - this.targetHeight) / 2;
        }
        if (this.targetWidth < gameContainer.getWidth()) {
            n2 = (gameContainer.getWidth() - this.targetWidth) / 2;
        }
        SlickCallable.enterSafeBlock();
        graphics.setClip(n2, n, this.targetWidth, this.targetHeight);
        ScalableGame.GL.glTranslatef((float)n2, (float)n, 0.0f);
        graphics.scale(this.targetWidth / this.normalWidth, this.targetHeight / this.normalHeight);
        ScalableGame.GL.glPushMatrix();
        this.held.render(gameContainer, graphics);
        ScalableGame.GL.glPopMatrix();
        graphics.clearClip();
        SlickCallable.leaveSafeBlock();
        this.renderOverlay(gameContainer, graphics);
    }
    
    public void renderOverlay(final GameContainer gameContainer, final Graphics graphics) {
    }
    
    @Override
    public boolean closeRequested() {
        return this.held.closeRequested();
    }
    
    @Override
    public String getTitle() {
        return this.held.getTitle();
    }
    
    static {
        ScalableGame.GL = Renderer.get();
    }
}
