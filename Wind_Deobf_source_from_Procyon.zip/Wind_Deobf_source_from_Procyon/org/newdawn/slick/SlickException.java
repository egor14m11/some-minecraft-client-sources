// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

public class SlickException extends Exception
{
    public SlickException(final String message) {
        super(message);
    }
    
    public SlickException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
