// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import java.net.URL;
import org.newdawn.slick.openal.SoundStore;
import java.io.InputStream;
import org.newdawn.slick.openal.Audio;

public class Sound
{
    public Audio sound;
    
    public Sound(final InputStream inputStream, final String s) throws SlickException {
        SoundStore.get().init();
        if (s.toLowerCase().endsWith(".ogg")) {
            this.sound = SoundStore.get().getOgg(inputStream);
        }
        else if (s.toLowerCase().endsWith(".wav")) {
            this.sound = SoundStore.get().getWAV(inputStream);
        }
        else if (s.toLowerCase().endsWith(".aif")) {
            this.sound = SoundStore.get().getAIF(inputStream);
        }
        else {
            if (!s.toLowerCase().endsWith(".xm") && !s.toLowerCase().endsWith(".mod")) {
                throw new SlickException("Only .xm, .mod, .aif, .wav and .ogg are currently supported.");
            }
            this.sound = SoundStore.get().getMOD(inputStream);
        }
    }
    
    public Sound(final URL url) throws SlickException {
        SoundStore.get().init();
        final String file = url.getFile();
        if (file.toLowerCase().endsWith(".ogg")) {
            this.sound = SoundStore.get().getOgg(url.openStream());
        }
        else if (file.toLowerCase().endsWith(".wav")) {
            this.sound = SoundStore.get().getWAV(url.openStream());
        }
        else if (file.toLowerCase().endsWith(".aif")) {
            this.sound = SoundStore.get().getAIF(url.openStream());
        }
        else {
            if (!file.toLowerCase().endsWith(".xm") && !file.toLowerCase().endsWith(".mod")) {
                throw new SlickException("Only .xm, .mod, .aif, .wav and .ogg are currently supported.");
            }
            this.sound = SoundStore.get().getMOD(url.openStream());
        }
    }
    
    public Sound(final String s) throws SlickException {
        SoundStore.get().init();
        if (s.toLowerCase().endsWith(".ogg")) {
            this.sound = SoundStore.get().getOgg(s);
        }
        else if (s.toLowerCase().endsWith(".wav")) {
            this.sound = SoundStore.get().getWAV(s);
        }
        else if (s.toLowerCase().endsWith(".aif")) {
            this.sound = SoundStore.get().getAIF(s);
        }
        else {
            if (!s.toLowerCase().endsWith(".xm") && !s.toLowerCase().endsWith(".mod")) {
                throw new SlickException("Only .xm, .mod, .aif, .wav and .ogg are currently supported.");
            }
            this.sound = SoundStore.get().getMOD(s);
        }
    }
    
    public void play() {
        this.play(1.0f, 1.0f);
    }
    
    public void play(final float n, final float n2) {
        this.sound.playAsSoundEffect(n, n2 * SoundStore.get().getSoundVolume(), false);
    }
    
    public void playAt(final float n, final float n2, final float n3) {
        this.playAt(1.0f, 1.0f, n, n2, n3);
    }
    
    public void playAt(final float n, final float n2, final float n3, final float n4, final float n5) {
        this.sound.playAsSoundEffect(n, n2 * SoundStore.get().getSoundVolume(), false, n3, n4, n5);
    }
    
    public void loop() {
        this.loop(1.0f, 1.0f);
    }
    
    public void loop(final float n, final float n2) {
        this.sound.playAsSoundEffect(n, n2 * SoundStore.get().getSoundVolume(), true);
    }
    
    public boolean playing() {
        return this.sound.isPlaying();
    }
    
    public void stop() {
        this.sound.stop();
    }
}
