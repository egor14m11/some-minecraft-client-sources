// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.newdawn.slick.opengl.Texture;
import java.io.InputStream;
import java.io.IOException;
import java.net.URL;

public class SpriteSheet extends Image
{
    public int tw;
    public int th;
    public int margin;
    public Image[][] subImages;
    public int spacing;
    public Image target;
    
    public SpriteSheet(final URL url, final int n, final int n2) throws SlickException, IOException {
        this(new Image(url.openStream(), url.toString(), false), n, n2);
    }
    
    public SpriteSheet(final Image target, final int tw, final int th) {
        super(target);
        this.margin = 0;
        this.target = target;
        this.tw = tw;
        this.th = th;
        this.initImpl();
    }
    
    public SpriteSheet(final Image target, final int tw, final int th, final int spacing, final int margin) {
        super(target);
        this.margin = 0;
        this.target = target;
        this.tw = tw;
        this.th = th;
        this.spacing = spacing;
        this.margin = margin;
        this.initImpl();
    }
    
    public SpriteSheet(final Image image, final int n, final int n2, final int n3) {
        this(image, n, n2, n3, 0);
    }
    
    public SpriteSheet(final String s, final int n, final int n2, final int n3) throws SlickException {
        this(s, n, n2, null, n3);
    }
    
    public SpriteSheet(final String s, final int n, final int n2) throws SlickException {
        this(s, n, n2, null);
    }
    
    public SpriteSheet(final String s, final int n, final int n2, final Color color) throws SlickException {
        this(s, n, n2, color, 0);
    }
    
    public SpriteSheet(final String s, final int tw, final int th, final Color color, final int spacing) throws SlickException {
        super(s, false, 2, color);
        this.margin = 0;
        this.target = this;
        this.tw = tw;
        this.th = th;
        this.spacing = spacing;
    }
    
    public SpriteSheet(final String s, final InputStream inputStream, final int tw, final int th) throws SlickException {
        super(inputStream, s, false);
        this.margin = 0;
        this.target = this;
        this.tw = tw;
        this.th = th;
    }
    
    @Override
    public void initImpl() {
        if (this.subImages != null) {
            return;
        }
        final int n = (this.getWidth() - this.margin * 2 - this.tw) / (this.tw + this.spacing) + 1;
        int n2 = (this.getHeight() - this.margin * 2 - this.th) / (this.th + this.spacing) + 1;
        if ((this.getHeight() - this.th) % (this.th + this.spacing) != 0) {
            ++n2;
        }
        this.subImages = new Image[n][n2];
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n2; ++j) {
                this.subImages[i][j] = this.getSprite(i, j);
            }
        }
    }
    
    public Image getSubImage(final int n, final int n2) {
        this.init();
        if (n < 0 || n >= this.subImages.length) {
            throw new RuntimeException("SubImage out of sheet bounds: " + n + "," + n2);
        }
        if (n2 < 0 || n2 >= this.subImages[0].length) {
            throw new RuntimeException("SubImage out of sheet bounds: " + n + "," + n2);
        }
        return this.subImages[n][n2];
    }
    
    public Image getSprite(final int n, final int n2) {
        this.target.init();
        this.initImpl();
        if (n < 0 || n >= this.subImages.length) {
            throw new RuntimeException("SubImage out of sheet bounds: " + n + "," + n2);
        }
        if (n2 < 0 || n2 >= this.subImages[0].length) {
            throw new RuntimeException("SubImage out of sheet bounds: " + n + "," + n2);
        }
        return this.target.getSubImage(n * (this.tw + this.spacing) + this.margin, n2 * (this.th + this.spacing) + this.margin, this.tw, this.th);
    }
    
    public int getHorizontalCount() {
        this.target.init();
        this.initImpl();
        return this.subImages.length;
    }
    
    public int getVerticalCount() {
        this.target.init();
        this.initImpl();
        return this.subImages[0].length;
    }
    
    public void renderInUse(final int n, final int n2, final int n3, final int n4) {
        this.subImages[n3][n4].drawEmbedded((float)n, (float)n2, (float)this.tw, (float)this.th);
    }
    
    @Override
    public void endUse() {
        if (this.target == this) {
            super.endUse();
            return;
        }
        this.target.endUse();
    }
    
    @Override
    public void startUse() {
        if (this.target == this) {
            super.startUse();
            return;
        }
        this.target.startUse();
    }
    
    @Override
    public void setTexture(final Texture texture) {
        if (this.target == this) {
            super.setTexture(texture);
            return;
        }
        this.target.setTexture(texture);
    }
}
