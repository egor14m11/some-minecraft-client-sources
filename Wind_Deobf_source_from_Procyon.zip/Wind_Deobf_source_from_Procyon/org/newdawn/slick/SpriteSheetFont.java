// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

public class SpriteSheetFont implements Font
{
    public SpriteSheet font;
    public char startingCharacter;
    public int charWidth;
    public int charHeight;
    public int horizontalCount;
    public int numChars;
    
    public SpriteSheetFont(final SpriteSheet font, final char startingCharacter) {
        this.font = font;
        this.startingCharacter = startingCharacter;
        this.horizontalCount = font.getHorizontalCount();
        final int verticalCount = font.getVerticalCount();
        this.charWidth = font.getWidth() / this.horizontalCount;
        this.charHeight = font.getHeight() / verticalCount;
        this.numChars = this.horizontalCount * verticalCount;
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s) {
        this.drawString(n, n2, s, Color.white);
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s, final Color color) {
        this.drawString(n, n2, s, color, 0, s.length() - 1);
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s, final Color color, final int n3, final int n4) {
        final byte[] bytes = s.getBytes("US-ASCII");
        for (int i = 0; i < bytes.length; ++i) {
            final int n5 = bytes[i] - this.startingCharacter;
            if (n5 < this.numChars) {
                final int n6 = n5 % this.horizontalCount;
                final int n7 = n5 / this.horizontalCount;
                if (i >= n3 || i <= n4) {
                    this.font.getSprite(n6, n7).draw(n + i * this.charWidth, n2, color);
                }
            }
        }
    }
    
    @Override
    public int getHeight(final String s) {
        return this.charHeight;
    }
    
    @Override
    public int getWidth(final String s) {
        return this.charWidth * s.length();
    }
    
    @Override
    public int getLineHeight() {
        return this.charHeight;
    }
}
