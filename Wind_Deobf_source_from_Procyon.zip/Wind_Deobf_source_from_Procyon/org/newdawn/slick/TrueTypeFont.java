// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.util.BufferedImageUtil;
import java.awt.image.ImageObserver;
import java.awt.Image;
import java.awt.Color;
import java.awt.RenderingHints;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import org.newdawn.slick.opengl.GLUtils;
import java.util.HashMap;
import java.awt.FontMetrics;
import org.newdawn.slick.opengl.Texture;
import java.util.Map;
import org.newdawn.slick.opengl.renderer.SGL;

public class TrueTypeFont implements Font
{
    public static SGL GL;
    public IntObject[] charArray;
    public Map customChars;
    public boolean antiAlias;
    public int fontSize;
    public int fontHeight;
    public Texture fontTexture;
    public int textureWidth;
    public int textureHeight;
    public java.awt.Font font;
    public FontMetrics fontMetrics;
    
    public TrueTypeFont(final java.awt.Font font, final boolean antiAlias, final char[] array) {
        this.charArray = new IntObject[256];
        this.customChars = new HashMap();
        this.fontSize = 0;
        this.fontHeight = 0;
        this.textureWidth = 512;
        this.textureHeight = 512;
        GLUtils.checkGLContext();
        this.font = font;
        this.fontSize = font.getSize();
        this.antiAlias = antiAlias;
        this.createSet(array);
    }
    
    public TrueTypeFont(final java.awt.Font font, final boolean b) {
        this(font, b, null);
    }
    
    public BufferedImage getFontImage(final char c) {
        final Graphics2D graphics2D = (Graphics2D)new BufferedImage(1, 1, 2).getGraphics();
        if (this.antiAlias) {
            graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        }
        graphics2D.setFont(this.font);
        this.fontMetrics = graphics2D.getFontMetrics();
        int charWidth = this.fontMetrics.charWidth(c);
        if (charWidth <= 0) {
            charWidth = 1;
        }
        int height = this.fontMetrics.getHeight();
        if (height <= 0) {
            height = this.fontSize;
        }
        final BufferedImage bufferedImage = new BufferedImage(charWidth, height, 2);
        final Graphics2D graphics2D2 = (Graphics2D)bufferedImage.getGraphics();
        if (this.antiAlias) {
            graphics2D2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        }
        graphics2D2.setFont(this.font);
        graphics2D2.setColor(Color.WHITE);
        graphics2D2.drawString(String.valueOf(c), 0, 0 + this.fontMetrics.getAscent());
        return bufferedImage;
    }
    
    public void createSet(final char[] array) {
        if (array != null && array.length > 0) {
            this.textureWidth *= 2;
        }
        final BufferedImage bufferedImage = new BufferedImage(this.textureWidth, this.textureHeight, 2);
        final Graphics2D graphics2D = (Graphics2D)bufferedImage.getGraphics();
        graphics2D.setColor(new Color(255, 255, 255, 1));
        graphics2D.fillRect(0, 0, this.textureWidth, this.textureHeight);
        int height = 0;
        int storedX = 0;
        int storedY = 0;
        for (int n = (array != null) ? array.length : 0, i = 0; i < 256 + n; ++i) {
            final char value = (i < 256) ? ((char)i) : array[i - 256];
            final BufferedImage fontImage = this.getFontImage(value);
            final IntObject intObject = new IntObject(null);
            intObject.width = fontImage.getWidth();
            intObject.height = fontImage.getHeight();
            if (storedX + intObject.width >= this.textureWidth) {
                storedX = 0;
                storedY += height;
                height = 0;
            }
            intObject.storedX = storedX;
            intObject.storedY = storedY;
            if (intObject.height > this.fontHeight) {
                this.fontHeight = intObject.height;
            }
            if (intObject.height > height) {
                height = intObject.height;
            }
            graphics2D.drawImage(fontImage, storedX, storedY, null);
            storedX += intObject.width;
            if (i < 256) {
                this.charArray[i] = intObject;
            }
            else {
                this.customChars.put(new Character(value), intObject);
            }
        }
        this.fontTexture = BufferedImageUtil.getTexture(this.font.toString(), bufferedImage);
    }
    
    public void drawQuad(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final float n8) {
        final float n9 = n3 - n;
        final float n10 = n4 - n2;
        final float n11 = n5 / this.textureWidth;
        final float n12 = n6 / this.textureHeight;
        final float n13 = n7 - n5;
        final float n14 = n8 - n6;
        final float n15 = n13 / this.textureWidth;
        final float n16 = n14 / this.textureHeight;
        TrueTypeFont.GL.glTexCoord2f(n11, n12);
        TrueTypeFont.GL.glVertex2f(n, n2);
        TrueTypeFont.GL.glTexCoord2f(n11, n12 + n16);
        TrueTypeFont.GL.glVertex2f(n, n2 + n10);
        TrueTypeFont.GL.glTexCoord2f(n11 + n15, n12 + n16);
        TrueTypeFont.GL.glVertex2f(n + n9, n2 + n10);
        TrueTypeFont.GL.glTexCoord2f(n11 + n15, n12);
        TrueTypeFont.GL.glVertex2f(n + n9, n2);
    }
    
    @Override
    public int getWidth(final String s) {
        int n = 0;
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            IntObject intObject;
            if (char1 < '\u0100') {
                intObject = this.charArray[char1];
            }
            else {
                intObject = this.customChars.get(new Character(char1));
            }
            if (intObject != null) {
                n += intObject.width;
            }
        }
        return n;
    }
    
    public int getHeight() {
        return this.fontHeight;
    }
    
    @Override
    public int getHeight(final String s) {
        return this.fontHeight;
    }
    
    @Override
    public int getLineHeight() {
        return this.fontHeight;
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s, final org.newdawn.slick.Color color) {
        this.drawString(n, n2, s, color, 0, s.length() - 1);
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s, final org.newdawn.slick.Color color, final int n3, final int n4) {
        color.bind();
        this.fontTexture.bind();
        TrueTypeFont.GL.glBegin(7);
        int n5 = 0;
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            IntObject intObject;
            if (char1 < '\u0100') {
                intObject = this.charArray[char1];
            }
            else {
                intObject = this.customChars.get(new Character(char1));
            }
            if (intObject != null) {
                if (i >= n3 || i <= n4) {
                    this.drawQuad(n + n5, n2, n + n5 + intObject.width, n2 + intObject.height, (float)intObject.storedX, (float)intObject.storedY, (float)(intObject.storedX + intObject.width), (float)(intObject.storedY + intObject.height));
                }
                n5 += intObject.width;
            }
        }
        TrueTypeFont.GL.glEnd();
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s) {
        this.drawString(n, n2, s, org.newdawn.slick.Color.white);
    }
    
    static {
        TrueTypeFont.GL = Renderer.get();
    }
    
    private class IntObject
    {
        public int width;
        public int height;
        public int storedX;
        public int storedY;
        public TrueTypeFont this$0;
        
        public IntObject(final TrueTypeFont this$0) {
            this.this$0 = this$0;
        }
        
        public IntObject(final TrueTypeFont trueTypeFont, final TrueTypeFont$1 object) {
            this(trueTypeFont);
        }
    }
}
