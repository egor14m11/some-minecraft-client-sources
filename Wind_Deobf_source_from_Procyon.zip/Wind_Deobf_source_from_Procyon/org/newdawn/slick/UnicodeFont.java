// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.newdawn.slick.opengl.renderer.Renderer;
import java.lang.reflect.Field;
import java.awt.font.FontRenderContext;
import java.awt.Rectangle;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureImpl;
import java.util.Iterator;
import java.util.Collections;
import java.awt.font.GlyphVector;
import java.util.Collection;
import java.awt.FontMetrics;
import org.newdawn.slick.font.GlyphPage;
import java.text.AttributedCharacterIterator;
import java.awt.font.TextAttribute;
import java.util.Map;
import java.util.ArrayList;
import org.newdawn.slick.font.HieroSettings;
import java.io.InputStream;
import org.newdawn.slick.util.ResourceLoader;
import java.util.LinkedHashMap;
import java.util.List;
import org.newdawn.slick.font.Glyph;
import java.util.Comparator;
import org.newdawn.slick.opengl.renderer.SGL;

public class UnicodeFont implements Font
{
    public static int DISPLAY_LIST_CACHE_SIZE;
    public static int MAX_GLYPH_CODE;
    public static int PAGE_SIZE;
    public static int PAGES;
    public static SGL GL;
    public static DisplayList EMPTY_DISPLAY_LIST;
    public static Comparator heightComparator;
    public java.awt.Font font;
    public String ttfFileRef;
    public int ascent;
    public int descent;
    public int leading;
    public int spaceWidth;
    public Glyph[][] glyphs;
    public List glyphPages;
    public List queuedGlyphs;
    public List effects;
    public int paddingTop;
    public int paddingLeft;
    public int paddingBottom;
    public int paddingRight;
    public int paddingAdvanceX;
    public int paddingAdvanceY;
    public Glyph missingGlyph;
    public int glyphPageWidth;
    public int glyphPageHeight;
    public boolean displayListCaching;
    public int baseDisplayListID;
    public int eldestDisplayListID;
    public DisplayList eldestDisplayList;
    public LinkedHashMap displayLists;
    
    public static java.awt.Font createFont(final String s) throws SlickException {
        return java.awt.Font.createFont(0, ResourceLoader.getResourceAsStream(s));
    }
    
    public static java.awt.Font createFont(final InputStream fontStream) throws SlickException {
        return java.awt.Font.createFont(0, fontStream);
    }
    
    public UnicodeFont(final String s, final String s2) throws SlickException {
        this(s, new HieroSettings(s2));
    }
    
    public UnicodeFont(final String ttfFileRef, final HieroSettings hieroSettings) throws SlickException {
        this.glyphs = new Glyph[2175][];
        this.glyphPages = new ArrayList();
        this.queuedGlyphs = new ArrayList(256);
        this.effects = new ArrayList();
        this.glyphPageWidth = 512;
        this.glyphPageHeight = 512;
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public UnicodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                final DisplayList list = entry.getValue();
                if (list != null) {
                    UnicodeFont.access$002(this.this$0, list.id);
                }
                return this.size() > 200;
            }
        };
        this.ttfFileRef = ttfFileRef;
        this.initializeFont(createFont(ttfFileRef), hieroSettings.getFontSize(), hieroSettings.isBold(), hieroSettings.isItalic());
        this.loadSettings(hieroSettings);
    }
    
    public UnicodeFont(final String ttfFileRef, final int n, final boolean b, final boolean b2) throws SlickException {
        this.glyphs = new Glyph[2175][];
        this.glyphPages = new ArrayList();
        this.queuedGlyphs = new ArrayList(256);
        this.effects = new ArrayList();
        this.glyphPageWidth = 512;
        this.glyphPageHeight = 512;
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public UnicodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                final DisplayList list = entry.getValue();
                if (list != null) {
                    UnicodeFont.access$002(this.this$0, list.id);
                }
                return this.size() > 200;
            }
        };
        this.ttfFileRef = ttfFileRef;
        this.initializeFont(createFont(ttfFileRef), n, b, b2);
    }
    
    public UnicodeFont(final java.awt.Font font, final String s) throws SlickException {
        this(font, new HieroSettings(s));
    }
    
    public UnicodeFont(final java.awt.Font font, final HieroSettings hieroSettings) {
        this.glyphs = new Glyph[2175][];
        this.glyphPages = new ArrayList();
        this.queuedGlyphs = new ArrayList(256);
        this.effects = new ArrayList();
        this.glyphPageWidth = 512;
        this.glyphPageHeight = 512;
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public UnicodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                final DisplayList list = entry.getValue();
                if (list != null) {
                    UnicodeFont.access$002(this.this$0, list.id);
                }
                return this.size() > 200;
            }
        };
        this.initializeFont(font, hieroSettings.getFontSize(), hieroSettings.isBold(), hieroSettings.isItalic());
        this.loadSettings(hieroSettings);
    }
    
    public UnicodeFont(final java.awt.Font font) {
        this.glyphs = new Glyph[2175][];
        this.glyphPages = new ArrayList();
        this.queuedGlyphs = new ArrayList(256);
        this.effects = new ArrayList();
        this.glyphPageWidth = 512;
        this.glyphPageHeight = 512;
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public UnicodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                final DisplayList list = entry.getValue();
                if (list != null) {
                    UnicodeFont.access$002(this.this$0, list.id);
                }
                return this.size() > 200;
            }
        };
        this.initializeFont(font, font.getSize(), font.isBold(), font.isItalic());
    }
    
    public UnicodeFont(final InputStream inputStream, final int n) {
        this.glyphs = new Glyph[2175][];
        this.glyphPages = new ArrayList();
        this.queuedGlyphs = new ArrayList(256);
        this.effects = new ArrayList();
        this.glyphPageWidth = 512;
        this.glyphPageHeight = 512;
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public UnicodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                final DisplayList list = entry.getValue();
                if (list != null) {
                    UnicodeFont.access$002(this.this$0, list.id);
                }
                return this.size() > 200;
            }
        };
        this.initializeFont(createFont(inputStream), n, false, false);
    }
    
    public UnicodeFont(final java.awt.Font font, final int n, final boolean b, final boolean b2) {
        this.glyphs = new Glyph[2175][];
        this.glyphPages = new ArrayList();
        this.queuedGlyphs = new ArrayList(256);
        this.effects = new ArrayList();
        this.glyphPageWidth = 512;
        this.glyphPageHeight = 512;
        this.displayListCaching = true;
        this.baseDisplayListID = -1;
        this.displayLists = new LinkedHashMap(this, 200, 1.0f, true) {
            public UnicodeFont this$0;
            
            public boolean removeEldestEntry(final Map.Entry entry) {
                final DisplayList list = entry.getValue();
                if (list != null) {
                    UnicodeFont.access$002(this.this$0, list.id);
                }
                return this.size() > 200;
            }
        };
        this.initializeFont(font, n, b, b2);
    }
    
    public void initializeFont(final java.awt.Font font, final int n, final boolean b, final boolean b2) {
        final Map<TextAttribute, ?> attributes = font.getAttributes();
        attributes.put(TextAttribute.SIZE, new Float((float)n));
        attributes.put(TextAttribute.WEIGHT, b ? TextAttribute.WEIGHT_BOLD : TextAttribute.WEIGHT_REGULAR);
        attributes.put(TextAttribute.POSTURE, b2 ? TextAttribute.POSTURE_OBLIQUE : TextAttribute.POSTURE_REGULAR);
        attributes.put((TextAttribute)TextAttribute.class.getDeclaredField("KERNING").get(null), TextAttribute.class.getDeclaredField("KERNING_ON").get(null));
        this.font = font.deriveFont(attributes);
        final FontMetrics fontMetrics = GlyphPage.getScratchGraphics().getFontMetrics(this.font);
        this.ascent = fontMetrics.getAscent();
        this.descent = fontMetrics.getDescent();
        this.leading = fontMetrics.getLeading();
        final char[] charArray = " ".toCharArray();
        this.spaceWidth = this.font.layoutGlyphVector(GlyphPage.renderContext, charArray, 0, charArray.length, 0).getGlyphLogicalBounds(0).getBounds().width;
    }
    
    public void loadSettings(final HieroSettings hieroSettings) {
        this.paddingTop = hieroSettings.getPaddingTop();
        this.paddingLeft = hieroSettings.getPaddingLeft();
        this.paddingBottom = hieroSettings.getPaddingBottom();
        this.paddingRight = hieroSettings.getPaddingRight();
        this.paddingAdvanceX = hieroSettings.getPaddingAdvanceX();
        this.paddingAdvanceY = hieroSettings.getPaddingAdvanceY();
        this.glyphPageWidth = hieroSettings.getGlyphPageWidth();
        this.glyphPageHeight = hieroSettings.getGlyphPageHeight();
        this.effects.addAll(hieroSettings.getEffects());
    }
    
    public void addGlyphs(final int n, final int n2) {
        for (int i = n; i <= n2; ++i) {
            this.addGlyphs(new String(Character.toChars(i)));
        }
    }
    
    public void addGlyphs(final String s) {
        if (s == null) {
            throw new IllegalArgumentException("text cannot be null.");
        }
        final char[] charArray = s.toCharArray();
        final GlyphVector layoutGlyphVector = this.font.layoutGlyphVector(GlyphPage.renderContext, charArray, 0, charArray.length, 0);
        for (int i = 0; i < layoutGlyphVector.getNumGlyphs(); ++i) {
            final int codePoint = s.codePointAt(layoutGlyphVector.getGlyphCharIndex(i));
            this.getGlyph(layoutGlyphVector.getGlyphCode(i), codePoint, this.getGlyphBounds(layoutGlyphVector, i, codePoint), layoutGlyphVector, i);
        }
    }
    
    public void addAsciiGlyphs() {
        this.addGlyphs(32, 255);
    }
    
    public void addNeheGlyphs() {
        this.addGlyphs(32, 128);
    }
    
    public boolean loadGlyphs() throws SlickException {
        return this.loadGlyphs(-1);
    }
    
    public boolean loadGlyphs(int n) throws SlickException {
        if (this.queuedGlyphs.isEmpty()) {
            return false;
        }
        if (this.effects.isEmpty()) {
            throw new IllegalStateException("The UnicodeFont must have at least one effect before any glyphs can be loaded.");
        }
        final Iterator<Glyph> iterator = (Iterator<Glyph>)this.queuedGlyphs.iterator();
        while (iterator.hasNext()) {
            final Glyph missingGlyph = iterator.next();
            final int codePoint = missingGlyph.getCodePoint();
            if (missingGlyph.getWidth() == 0 || codePoint == 32) {
                iterator.remove();
            }
            else {
                if (!missingGlyph.isMissing()) {
                    continue;
                }
                if (this.missingGlyph != null) {
                    if (missingGlyph == this.missingGlyph) {
                        continue;
                    }
                    iterator.remove();
                }
                else {
                    this.missingGlyph = missingGlyph;
                }
            }
        }
        Collections.sort((List<Object>)this.queuedGlyphs, UnicodeFont.heightComparator);
        final Iterator<GlyphPage> iterator2 = this.glyphPages.iterator();
        while (iterator2.hasNext()) {
            n -= iterator2.next().loadGlyphs(this.queuedGlyphs, n);
            if (n == 0 || this.queuedGlyphs.isEmpty()) {
                return true;
            }
        }
        while (!this.queuedGlyphs.isEmpty()) {
            final GlyphPage glyphPage = new GlyphPage(this, this.glyphPageWidth, this.glyphPageHeight);
            this.glyphPages.add(glyphPage);
            n -= glyphPage.loadGlyphs(this.queuedGlyphs, n);
            if (n == 0) {
                return true;
            }
        }
        return true;
    }
    
    public void clearGlyphs() {
        for (int i = 0; i < 2175; ++i) {
            this.glyphs[i] = null;
        }
        final Iterator<GlyphPage> iterator = this.glyphPages.iterator();
        while (iterator.hasNext()) {
            iterator.next().getImage().destroy();
        }
        this.glyphPages.clear();
        if (this.baseDisplayListID != -1) {
            UnicodeFont.GL.glDeleteLists(this.baseDisplayListID, this.displayLists.size());
            this.baseDisplayListID = -1;
        }
        this.queuedGlyphs.clear();
        this.missingGlyph = null;
    }
    
    public void destroy() {
        this.clearGlyphs();
    }
    
    public DisplayList drawDisplayList(float n, float n2, final String s, final Color color, final int beginIndex, final int n3) {
        if (s == null) {
            throw new IllegalArgumentException("text cannot be null.");
        }
        if (s.length() == 0) {
            return UnicodeFont.EMPTY_DISPLAY_LIST;
        }
        if (color == null) {
            throw new IllegalArgumentException("color cannot be null.");
        }
        n -= this.paddingLeft;
        n2 -= this.paddingTop;
        final String substring = s.substring(beginIndex, n3);
        color.bind();
        TextureImpl.bindNone();
        DisplayList list = null;
        if (this.displayListCaching && this.queuedGlyphs.isEmpty()) {
            if (this.baseDisplayListID == -1) {
                this.baseDisplayListID = UnicodeFont.GL.glGenLists(200);
                if (this.baseDisplayListID == 0) {
                    this.baseDisplayListID = -1;
                    this.displayListCaching = false;
                    return new DisplayList();
                }
            }
            list = this.displayLists.get(substring);
            if (list != null) {
                if (!list.invalid) {
                    UnicodeFont.GL.glTranslatef(n, n2, 0.0f);
                    UnicodeFont.GL.glCallList(list.id);
                    UnicodeFont.GL.glTranslatef(-n, -n2, 0.0f);
                    return list;
                }
                list.invalid = false;
            }
            else if (list == null) {
                list = new DisplayList();
                final int size = this.displayLists.size();
                this.displayLists.put(substring, list);
                if (size < 200) {
                    list.id = this.baseDisplayListID + size;
                }
                else {
                    list.id = this.eldestDisplayListID;
                }
            }
            this.displayLists.put(substring, list);
        }
        UnicodeFont.GL.glTranslatef(n, n2, 0.0f);
        if (list != null) {
            UnicodeFont.GL.glNewList(list.id, 4865);
        }
        final char[] charArray = s.substring(0, n3).toCharArray();
        final GlyphVector layoutGlyphVector = this.font.layoutGlyphVector(GlyphPage.renderContext, charArray, 0, charArray.length, 0);
        int max = 0;
        int max2 = 0;
        int n4 = 0;
        int n5 = 0;
        int ascent = this.ascent;
        int n6 = 0;
        Texture texture = null;
        for (int i = 0; i < layoutGlyphVector.getNumGlyphs(); ++i) {
            final int glyphCharIndex = layoutGlyphVector.getGlyphCharIndex(i);
            if (glyphCharIndex >= beginIndex) {
                if (glyphCharIndex > n3) {
                    break;
                }
                final int codePoint = s.codePointAt(glyphCharIndex);
                final Rectangle glyphBounds = this.getGlyphBounds(layoutGlyphVector, i, codePoint);
                final Glyph glyph = this.getGlyph(layoutGlyphVector.getGlyphCode(i), codePoint, glyphBounds, layoutGlyphVector, i);
                if (n6 != 0 && codePoint != 10) {
                    n5 = -glyphBounds.x;
                    n6 = 0;
                }
                Image image = glyph.getImage();
                if (image == null && this.missingGlyph != null && glyph.isMissing()) {
                    image = this.missingGlyph.getImage();
                }
                if (image != null) {
                    final Texture texture2 = image.getTexture();
                    if (texture != null && texture != texture2) {
                        UnicodeFont.GL.glEnd();
                        texture = null;
                    }
                    if (texture == null) {
                        texture2.bind();
                        UnicodeFont.GL.glBegin(7);
                        texture = texture2;
                    }
                    image.drawEmbedded((float)(glyphBounds.x + n5), (float)(glyphBounds.y + ascent), (float)image.getWidth(), (float)image.getHeight());
                }
                if (i >= 0) {
                    n5 += this.paddingRight + this.paddingLeft + this.paddingAdvanceX;
                }
                max = Math.max(max, glyphBounds.x + n5 + glyphBounds.width);
                max2 = Math.max(max2, this.ascent + glyphBounds.y + glyphBounds.height);
                if (codePoint == 10) {
                    n6 = 1;
                    ascent += this.getLineHeight();
                    ++n4;
                    max2 = 0;
                }
            }
        }
        if (texture != null) {
            UnicodeFont.GL.glEnd();
        }
        if (list != null) {
            UnicodeFont.GL.glEndList();
            if (!this.queuedGlyphs.isEmpty()) {
                list.invalid = true;
            }
        }
        UnicodeFont.GL.glTranslatef(-n, -n2, 0.0f);
        if (list == null) {
            list = new DisplayList();
        }
        list.width = (short)max;
        list.height = (short)(n4 * this.getLineHeight() + max2);
        return list;
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s, final Color color, final int n3, final int n4) {
        this.drawString(n, n2, s, color, n3, n4, false);
    }
    
    public void drawString(final float p0, final float p1, final String p2, final Color p3, final int p4, final int p5, final boolean p6) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc_w           "§"
        //     4: invokevirtual   java/lang/String.split:(Ljava/lang/String;)[Ljava/lang/String;
        //     7: astore          8
        //     9: aload           4
        //    11: astore          9
        //    13: iconst_0       
        //    14: istore          10
        //    16: iload           10
        //    18: aload           8
        //    20: arraylength    
        //    21: if_icmpge       136
        //    24: aload           8
        //    26: iload           10
        //    28: aaload         
        //    29: astore          11
        //    31: aload           9
        //    33: astore          12
        //    35: iload           10
        //    37: ifne            50
        //    40: aload_3        
        //    41: ldc_w           "§"
        //    44: invokevirtual   java/lang/String.startsWith:(Ljava/lang/String;)Z
        //    47: ifne            55
        //    50: iload           10
        //    52: ifle            92
        //    55: aload           11
        //    57: invokevirtual   java/lang/String.length:()I
        //    60: iconst_1       
        //    61: if_icmple       92
        //    64: aload           11
        //    66: iconst_0       
        //    67: invokevirtual   java/lang/String.charAt:(I)C
        //    70: invokestatic    dev/windhook/utils/Colors.getSlickColor:(C)Lorg/newdawn/slick/Color;
        //    73: astore          12
        //    75: aload           12
        //    77: astore          9
        //    79: aload           11
        //    81: iconst_1       
        //    82: aload           11
        //    84: invokevirtual   java/lang/String.length:()I
        //    87: invokevirtual   java/lang/String.substring:(II)Ljava/lang/String;
        //    90: astore          11
        //    92: aload_0        
        //    93: fload_1        
        //    94: fload_2        
        //    95: aload           11
        //    97: aload           12
        //    99: iconst_0       
        //   100: aload           11
        //   102: invokevirtual   java/lang/String.length:()I
        //   105: invokevirtual   org/newdawn/slick/UnicodeFont.drawDisplayList:(FFLjava/lang/String;Lorg/newdawn/slick/Color;II)Lorg/newdawn/slick/UnicodeFont$DisplayList;
        //   108: pop            
        //   109: fload_1        
        //   110: aload_0        
        //   111: aload           11
        //   113: invokevirtual   org/newdawn/slick/UnicodeFont.getWidth:(Ljava/lang/String;)I
        //   116: iload           7
        //   118: ifeq            125
        //   121: iconst_1       
        //   122: goto            121
        //   125: iconst_0       
        //   126: iadd           
        //   127: i2f            
        //   128: fadd           
        //   129: fstore_1       
        //   130: iinc            10, 1
        //   133: goto            16
        //   136: return         
        //    StackMap: 5B 6F 33 FB
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0121 (coming from #0122).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s) {
        this.drawString(n, n2, s, Color.white);
    }
    
    public void drawString(final float n, final float n2, final String s, final boolean b) {
        this.drawString(n, n2, s, Color.white, b);
    }
    
    @Override
    public void drawString(final float n, final float n2, final String s, final Color color) {
        this.drawString(n, n2, s, color, 0, s.length());
    }
    
    public void drawString(final float n, final float n2, final String s, final Color color, final boolean b) {
        this.drawString(n, n2, s, color, 0, s.length(), b);
    }
    
    public Glyph getGlyph(final int n, final int n2, final Rectangle rectangle, final GlyphVector glyphVector, final int n3) {
        if (n < 0 || n >= 1114111) {
            return new Glyph(this, n2, rectangle, glyphVector, n3, this) {
                public UnicodeFont this$0;
                
                @Override
                public boolean isMissing() {
                    return true;
                }
            };
        }
        final int n4 = n / 512;
        final int n5 = n & 0x1FF;
        Glyph[] array = this.glyphs[n4];
        if (array != null) {
            final Glyph glyph = array[n5];
            if (glyph != null) {
                return glyph;
            }
        }
        else {
            final Glyph[][] glyphs = this.glyphs;
            final int n6 = n4;
            final Glyph[] array2 = new Glyph[512];
            glyphs[n6] = array2;
            array = array2;
        }
        final Glyph[] array3 = array;
        final int n7 = n5;
        final Glyph glyph2 = new Glyph(n2, rectangle, glyphVector, n3, this);
        array3[n7] = glyph2;
        final Glyph glyph3 = glyph2;
        this.queuedGlyphs.add(glyph3);
        return glyph3;
    }
    
    public Rectangle getGlyphBounds(final GlyphVector glyphVector, final int index, final int n) {
        final Rectangle glyphPixelBounds = glyphVector.getGlyphPixelBounds(index, GlyphPage.renderContext, 0.0f, 0.0f);
        if (n == 32) {
            glyphPixelBounds.width = this.spaceWidth;
        }
        return glyphPixelBounds;
    }
    
    public int getSpaceWidth() {
        return this.spaceWidth;
    }
    
    @Override
    public int getWidth(final String key) {
        if (key == null) {
            throw new IllegalArgumentException("text cannot be null.");
        }
        if (key.length() == 0) {
            return 0;
        }
        if (this.displayListCaching) {
            final DisplayList list = this.displayLists.get(key);
            if (list != null) {
                return list.width;
            }
        }
        final char[] charArray = key.toCharArray();
        final GlyphVector layoutGlyphVector = this.font.layoutGlyphVector(GlyphPage.renderContext, charArray, 0, charArray.length, 0);
        int max = 0;
        int n = 0;
        int n2 = 0;
        for (int i = 0; i < layoutGlyphVector.getNumGlyphs(); ++i) {
            final int codePoint = key.codePointAt(layoutGlyphVector.getGlyphCharIndex(i));
            final Rectangle glyphBounds = this.getGlyphBounds(layoutGlyphVector, i, codePoint);
            if (n2 != 0 && codePoint != 10) {
                n = -glyphBounds.x;
            }
            if (i > 0) {
                n += this.paddingLeft + this.paddingRight + this.paddingAdvanceX;
            }
            max = Math.max(max, glyphBounds.x + n + glyphBounds.width);
            if (codePoint == 10) {
                n2 = 1;
            }
        }
        return max;
    }
    
    @Override
    public int getHeight(final String key) {
        if (key == null) {
            throw new IllegalArgumentException("text cannot be null.");
        }
        if (key.length() == 0) {
            return 0;
        }
        if (this.displayListCaching) {
            final DisplayList list = this.displayLists.get(key);
            if (list != null) {
                return list.height;
            }
        }
        final char[] charArray = key.toCharArray();
        final GlyphVector layoutGlyphVector = this.font.layoutGlyphVector(GlyphPage.renderContext, charArray, 0, charArray.length, 0);
        int n = 0;
        int max = 0;
        for (int i = 0; i < layoutGlyphVector.getNumGlyphs(); ++i) {
            final int codePoint = key.codePointAt(layoutGlyphVector.getGlyphCharIndex(i));
            if (codePoint != 32) {
                final Rectangle glyphBounds = this.getGlyphBounds(layoutGlyphVector, i, codePoint);
                max = Math.max(max, this.ascent + glyphBounds.y + glyphBounds.height);
                if (codePoint == 10) {
                    ++n;
                    max = 0;
                }
            }
        }
        return n * this.getLineHeight() + max;
    }
    
    public int getYOffset(String substring) {
        if (substring == null) {
            throw new IllegalArgumentException("text cannot be null.");
        }
        DisplayList list = null;
        if (this.displayListCaching) {
            list = this.displayLists.get(substring);
            if (list != null && list.yOffset != null) {
                return list.yOffset;
            }
        }
        final int index = substring.indexOf(10);
        if (index != -1) {
            substring = substring.substring(0, index);
        }
        final char[] charArray = substring.toCharArray();
        final int n = this.ascent + this.font.layoutGlyphVector(GlyphPage.renderContext, charArray, 0, charArray.length, 0).getPixelBounds(null, 0.0f, 0.0f).y;
        if (list != null) {
            list.yOffset = new Short((short)n);
        }
        return n;
    }
    
    public java.awt.Font getFont() {
        return this.font;
    }
    
    public int getPaddingTop() {
        return this.paddingTop;
    }
    
    public void setPaddingTop(final int paddingTop) {
        this.paddingTop = paddingTop;
    }
    
    public int getPaddingLeft() {
        return this.paddingLeft;
    }
    
    public void setPaddingLeft(final int paddingLeft) {
        this.paddingLeft = paddingLeft;
    }
    
    public int getPaddingBottom() {
        return this.paddingBottom;
    }
    
    public void setPaddingBottom(final int paddingBottom) {
        this.paddingBottom = paddingBottom;
    }
    
    public int getPaddingRight() {
        return this.paddingRight;
    }
    
    public void setPaddingRight(final int paddingRight) {
        this.paddingRight = paddingRight;
    }
    
    public int getPaddingAdvanceX() {
        return this.paddingAdvanceX;
    }
    
    public void setPaddingAdvanceX(final int paddingAdvanceX) {
        this.paddingAdvanceX = paddingAdvanceX;
    }
    
    public int getPaddingAdvanceY() {
        return this.paddingAdvanceY;
    }
    
    public void setPaddingAdvanceY(final int paddingAdvanceY) {
        this.paddingAdvanceY = paddingAdvanceY;
    }
    
    @Override
    public int getLineHeight() {
        return this.descent + this.ascent + this.leading + this.paddingTop + this.paddingBottom + this.paddingAdvanceY;
    }
    
    public int getAscent() {
        return this.ascent;
    }
    
    public int getDescent() {
        return this.descent;
    }
    
    public int getLeading() {
        return this.leading;
    }
    
    public int getGlyphPageWidth() {
        return this.glyphPageWidth;
    }
    
    public void setGlyphPageWidth(final int glyphPageWidth) {
        this.glyphPageWidth = glyphPageWidth;
    }
    
    public int getGlyphPageHeight() {
        return this.glyphPageHeight;
    }
    
    public void setGlyphPageHeight(final int glyphPageHeight) {
        this.glyphPageHeight = glyphPageHeight;
    }
    
    public List getGlyphPages() {
        return this.glyphPages;
    }
    
    public List getEffects() {
        return this.effects;
    }
    
    public boolean isCaching() {
        return this.displayListCaching;
    }
    
    public void setDisplayListCaching(final boolean displayListCaching) {
        this.displayListCaching = displayListCaching;
    }
    
    public String getFontFile() {
        if (this.ttfFileRef == null) {
            final Object invoke = Class.forName("sun.font.FontManager").getDeclaredMethod("getFont2D", java.awt.Font.class).invoke(null, this.font);
            final Field declaredField = Class.forName("sun.font.PhysicalFont").getDeclaredField("platName");
            declaredField.setAccessible(true);
            this.ttfFileRef = (String)declaredField.get(invoke);
            if (this.ttfFileRef == null) {
                this.ttfFileRef = "";
            }
        }
        if (this.ttfFileRef.length() == 0) {
            return null;
        }
        return this.ttfFileRef;
    }
    
    public static int access$002(final UnicodeFont unicodeFont, final int eldestDisplayListID) {
        return unicodeFont.eldestDisplayListID = eldestDisplayListID;
    }
    
    static {
        UnicodeFont.PAGES = 2175;
        UnicodeFont.PAGE_SIZE = 512;
        UnicodeFont.MAX_GLYPH_CODE = 1114111;
        UnicodeFont.DISPLAY_LIST_CACHE_SIZE = 200;
        UnicodeFont.GL = Renderer.get();
        UnicodeFont.EMPTY_DISPLAY_LIST = new DisplayList();
        UnicodeFont.heightComparator = new Comparator() {
            @Override
            public int compare(final Object o, final Object o2) {
                return ((Glyph)o).getHeight() - ((Glyph)o2).getHeight();
            }
        };
    }
    
    public static class DisplayList
    {
        public boolean invalid;
        public int id;
        public Short yOffset;
        public short width;
        public short height;
        public Object userData;
    }
}
