// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

import org.w3c.dom.NodeList;
import org.w3c.dom.Element;
import org.newdawn.slick.util.ResourceLoader;
import javax.xml.parsers.DocumentBuilderFactory;
import java.util.HashMap;

public class XMLPackedSheet
{
    public Image image;
    public HashMap sprites;
    
    public XMLPackedSheet(final String s, final String s2) throws SlickException {
        this.sprites = new HashMap();
        this.image = new Image(s, false, 2);
        final NodeList elementsByTagName = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ResourceLoader.getResourceAsStream(s2)).getElementsByTagName("sprite");
        for (int i = 0; i < elementsByTagName.getLength(); ++i) {
            final Element element = (Element)elementsByTagName.item(i);
            this.sprites.put(element.getAttribute("name"), this.image.getSubImage(Integer.parseInt(element.getAttribute("x")), Integer.parseInt(element.getAttribute("y")), Integer.parseInt(element.getAttribute("width")), Integer.parseInt(element.getAttribute("height"))));
        }
    }
    
    public Image getSprite(final String key) {
        return this.sprites.get(key);
    }
}
