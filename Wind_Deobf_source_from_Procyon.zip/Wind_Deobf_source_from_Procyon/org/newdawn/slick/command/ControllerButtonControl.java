// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.command;

public class ControllerButtonControl extends ControllerControl
{
    public ControllerButtonControl(final int n, final int n2) {
        super(n, 0, n2);
    }
    
    @Override
    public int hashCode() {
        return super.hashCode();
    }
    
    @Override
    public boolean equals(final Object o) {
        return super.equals(o);
    }
}
