// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.command;

public abstract class ControllerControl implements Control
{
    public static int BUTTON_EVENT;
    public static int LEFT_EVENT;
    public static int RIGHT_EVENT;
    public static int UP_EVENT;
    public static int DOWN_EVENT;
    public int event;
    public int button;
    public int controllerNumber;
    
    public ControllerControl(final int controllerNumber, final int event, final int button) {
        this.event = event;
        this.button = button;
        this.controllerNumber = controllerNumber;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == null) {
            return false;
        }
        if (!(o instanceof ControllerControl)) {
            return false;
        }
        final ControllerControl controllerControl = (ControllerControl)o;
        return controllerControl.controllerNumber == this.controllerNumber && controllerControl.event == this.event && controllerControl.button == this.button;
    }
    
    @Override
    public int hashCode() {
        return this.event + this.button + this.controllerNumber;
    }
    
    static {
        ControllerControl.DOWN_EVENT = 4;
        ControllerControl.UP_EVENT = 3;
        ControllerControl.RIGHT_EVENT = 2;
        ControllerControl.LEFT_EVENT = 1;
        ControllerControl.BUTTON_EVENT = 0;
    }
}
