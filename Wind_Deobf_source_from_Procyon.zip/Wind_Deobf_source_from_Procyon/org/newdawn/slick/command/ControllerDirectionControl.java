// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.command;

public class ControllerDirectionControl extends ControllerControl
{
    public static Direction LEFT;
    public static Direction UP;
    public static Direction DOWN;
    public static Direction RIGHT;
    
    public ControllerDirectionControl(final int n, final Direction direction) {
        super(n, Direction.access$000(direction), 0);
    }
    
    @Override
    public int hashCode() {
        return super.hashCode();
    }
    
    @Override
    public boolean equals(final Object o) {
        return super.equals(o);
    }
    
    static {
        ControllerDirectionControl.LEFT = new Direction(1);
        ControllerDirectionControl.UP = new Direction(3);
        ControllerDirectionControl.DOWN = new Direction(4);
        ControllerDirectionControl.RIGHT = new Direction(2);
    }
    
    private static class Direction
    {
        public int event;
        
        public Direction(final int event) {
            this.event = event;
        }
        
        public static int access$000(final Direction direction) {
            return direction.event;
        }
    }
}
