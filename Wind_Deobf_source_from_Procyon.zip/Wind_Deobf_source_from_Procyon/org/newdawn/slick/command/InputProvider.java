// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.command;

import org.newdawn.slick.util.InputAdapter;
import java.util.Map;
import java.util.Iterator;
import java.util.List;
import org.newdawn.slick.InputListener;
import org.newdawn.slick.Input;
import java.util.ArrayList;
import java.util.HashMap;

public class InputProvider
{
    public HashMap commands;
    public ArrayList listeners;
    public Input input;
    public HashMap commandState;
    public boolean active;
    
    public InputProvider(final Input input) {
        this.listeners = new ArrayList();
        this.commandState = new HashMap();
        this.active = true;
        (this.input = input).addListener(new InputListenerImpl(null));
        this.commands = new HashMap();
    }
    
    public List getUniqueCommands() {
        final ArrayList<Command> list = new ArrayList<Command>();
        for (final Command command : this.commands.values()) {
            if (!list.contains(command)) {
                list.add(command);
            }
        }
        return list;
    }
    
    public List getControlsFor(final Command command) {
        final ArrayList<Control> list = new ArrayList<Control>();
        for (final Map.Entry<Control, V> entry : this.commands.entrySet()) {
            final Control control = entry.getKey();
            if ((Command)entry.getValue() == command) {
                list.add(control);
            }
        }
        return list;
    }
    
    public void setActive(final boolean active) {
        this.active = active;
    }
    
    public boolean isActive() {
        return this.active;
    }
    
    public void addListener(final InputProviderListener e) {
        this.listeners.add(e);
    }
    
    public void removeListener(final InputProviderListener o) {
        this.listeners.remove(o);
    }
    
    public void bindCommand(final Control key, final Command key2) {
        this.commands.put(key, key2);
        if (this.commandState.get(key2) == null) {
            this.commandState.put(key2, new CommandState(null));
        }
    }
    
    public void clearCommand(final Command command) {
        final List controls = this.getControlsFor(command);
        for (int i = 0; i < controls.size(); ++i) {
            this.unbindCommand(controls.get(i));
        }
    }
    
    public void unbindCommand(final Control key) {
        final Command key2 = this.commands.remove(key);
        if (key2 != null && !this.commands.keySet().contains(key2)) {
            this.commandState.remove(key2);
        }
    }
    
    public CommandState getState(final Command key) {
        return this.commandState.get(key);
    }
    
    public boolean isCommandControlDown(final Command command) {
        return this.getState(command).isDown();
    }
    
    public boolean isCommandControlPressed(final Command command) {
        return this.getState(command).isPressed();
    }
    
    public void firePressed(final Command command) {
        CommandState.access$202(this.getState(command), true);
        CommandState.access$302(this.getState(command), true);
        if (!this.isActive()) {
            return;
        }
        for (int i = 0; i < this.listeners.size(); ++i) {
            ((InputProviderListener)this.listeners.get(i)).controlPressed(command);
        }
    }
    
    public void fireReleased(final Command command) {
        CommandState.access$202(this.getState(command), false);
        if (!this.isActive()) {
            return;
        }
        for (int i = 0; i < this.listeners.size(); ++i) {
            ((InputProviderListener)this.listeners.get(i)).controlReleased(command);
        }
    }
    
    public static HashMap access$400(final InputProvider inputProvider) {
        return inputProvider.commands;
    }
    
    private class CommandState
    {
        public boolean down;
        public boolean pressed;
        public InputProvider this$0;
        
        public CommandState(final InputProvider this$0) {
            this.this$0 = this$0;
        }
        
        public boolean isPressed() {
            if (this.pressed) {
                this.pressed = false;
                return true;
            }
            return false;
        }
        
        public boolean isDown() {
            return this.down;
        }
        
        public CommandState(final InputProvider inputProvider, final InputProvider$1 object) {
            this(inputProvider);
        }
        
        public static boolean access$202(final CommandState commandState, final boolean down) {
            return commandState.down = down;
        }
        
        public static boolean access$302(final CommandState commandState, final boolean pressed) {
            return commandState.pressed = pressed;
        }
    }
    
    private class InputListenerImpl extends InputAdapter
    {
        public InputProvider this$0;
        
        public InputListenerImpl(final InputProvider this$0) {
            this.this$0 = this$0;
        }
        
        @Override
        public boolean isAcceptingInput() {
            return true;
        }
        
        @Override
        public void keyPressed(final int n, final char c) {
            final Command command = InputProvider.access$400(this.this$0).get(new KeyControl(n));
            if (command != null) {
                this.this$0.firePressed(command);
            }
        }
        
        @Override
        public void keyReleased(final int n, final char c) {
            final Command command = InputProvider.access$400(this.this$0).get(new KeyControl(n));
            if (command != null) {
                this.this$0.fireReleased(command);
            }
        }
        
        @Override
        public void mousePressed(final int n, final int n2, final int n3) {
            final Command command = InputProvider.access$400(this.this$0).get(new MouseButtonControl(n));
            if (command != null) {
                this.this$0.firePressed(command);
            }
        }
        
        @Override
        public void mouseReleased(final int n, final int n2, final int n3) {
            final Command command = InputProvider.access$400(this.this$0).get(new MouseButtonControl(n));
            if (command != null) {
                this.this$0.fireReleased(command);
            }
        }
        
        @Override
        public void controllerLeftPressed(final int n) {
            final Command command = InputProvider.access$400(this.this$0).get(new ControllerDirectionControl(n, ControllerDirectionControl.LEFT));
            if (command != null) {
                this.this$0.firePressed(command);
            }
        }
        
        @Override
        public void controllerLeftReleased(final int n) {
            final Command command = InputProvider.access$400(this.this$0).get(new ControllerDirectionControl(n, ControllerDirectionControl.LEFT));
            if (command != null) {
                this.this$0.fireReleased(command);
            }
        }
        
        @Override
        public void controllerRightPressed(final int n) {
            final Command command = InputProvider.access$400(this.this$0).get(new ControllerDirectionControl(n, ControllerDirectionControl.RIGHT));
            if (command != null) {
                this.this$0.firePressed(command);
            }
        }
        
        @Override
        public void controllerRightReleased(final int n) {
            final Command command = InputProvider.access$400(this.this$0).get(new ControllerDirectionControl(n, ControllerDirectionControl.RIGHT));
            if (command != null) {
                this.this$0.fireReleased(command);
            }
        }
        
        @Override
        public void controllerUpPressed(final int n) {
            final Command command = InputProvider.access$400(this.this$0).get(new ControllerDirectionControl(n, ControllerDirectionControl.UP));
            if (command != null) {
                this.this$0.firePressed(command);
            }
        }
        
        @Override
        public void controllerUpReleased(final int n) {
            final Command command = InputProvider.access$400(this.this$0).get(new ControllerDirectionControl(n, ControllerDirectionControl.UP));
            if (command != null) {
                this.this$0.fireReleased(command);
            }
        }
        
        @Override
        public void controllerDownPressed(final int n) {
            final Command command = InputProvider.access$400(this.this$0).get(new ControllerDirectionControl(n, ControllerDirectionControl.DOWN));
            if (command != null) {
                this.this$0.firePressed(command);
            }
        }
        
        @Override
        public void controllerDownReleased(final int n) {
            final Command command = InputProvider.access$400(this.this$0).get(new ControllerDirectionControl(n, ControllerDirectionControl.DOWN));
            if (command != null) {
                this.this$0.fireReleased(command);
            }
        }
        
        @Override
        public void controllerButtonPressed(final int n, final int n2) {
            final Command command = InputProvider.access$400(this.this$0).get(new ControllerButtonControl(n, n2));
            if (command != null) {
                this.this$0.firePressed(command);
            }
        }
        
        @Override
        public void controllerButtonReleased(final int n, final int n2) {
            final Command command = InputProvider.access$400(this.this$0).get(new ControllerButtonControl(n, n2));
            if (command != null) {
                this.this$0.fireReleased(command);
            }
        }
        
        public InputListenerImpl(final InputProvider inputProvider, final InputProvider$1 object) {
            this(inputProvider);
        }
    }
}
