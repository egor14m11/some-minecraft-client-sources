// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.command;

public interface InputProviderListener
{
    void controlPressed(final Command p0);
    
    void controlReleased(final Command p0);
}
