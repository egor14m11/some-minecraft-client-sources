// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.fills;

import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.Color;
import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.ShapeFill;

public class GradientFill implements ShapeFill
{
    public Vector2f none;
    public Vector2f start;
    public Vector2f end;
    public Color startCol;
    public Color endCol;
    public boolean local;
    
    public GradientFill(final float n, final float n2, final Color color, final float n3, final float n4, final Color color2) {
        this(n, n2, color, n3, n4, color2, false);
    }
    
    public GradientFill(final float n, final float n2, final Color color, final float n3, final float n4, final Color color2, final boolean b) {
        this(new Vector2f(n, n2), color, new Vector2f(n3, n4), color2, b);
    }
    
    public GradientFill(final Vector2f vector2f, final Color color, final Vector2f vector2f2, final Color color2, final boolean local) {
        this.none = new Vector2f(0.0f, 0.0f);
        this.local = false;
        this.start = new Vector2f(vector2f);
        this.end = new Vector2f(vector2f2);
        this.startCol = new Color(color);
        this.endCol = new Color(color2);
        this.local = local;
    }
    
    public GradientFill getInvertedCopy() {
        return new GradientFill(this.start, this.endCol, this.end, this.startCol, this.local);
    }
    
    public void setLocal(final boolean local) {
        this.local = local;
    }
    
    public Vector2f getStart() {
        return this.start;
    }
    
    public Vector2f getEnd() {
        return this.end;
    }
    
    public Color getStartColor() {
        return this.startCol;
    }
    
    public Color getEndColor() {
        return this.endCol;
    }
    
    public void setStart(final float n, final float n2) {
        this.setStart(new Vector2f(n, n2));
    }
    
    public void setStart(final Vector2f vector2f) {
        this.start = new Vector2f(vector2f);
    }
    
    public void setEnd(final float n, final float n2) {
        this.setEnd(new Vector2f(n, n2));
    }
    
    public void setEnd(final Vector2f vector2f) {
        this.end = new Vector2f(vector2f);
    }
    
    public void setStartColor(final Color color) {
        this.startCol = new Color(color);
    }
    
    public void setEndColor(final Color color) {
        this.endCol = new Color(color);
    }
    
    @Override
    public Color colorAt(final Shape shape, final float n, final float n2) {
        if (this.local) {
            return this.colorAt(n - shape.getCenterX(), n2 - shape.getCenterY());
        }
        return this.colorAt(n, n2);
    }
    
    public Color colorAt(final float n, final float n2) {
        final float n3 = this.end.getX() - this.start.getX();
        final float n4 = this.end.getY() - this.start.getY();
        final float n5 = -n4;
        final float n6 = n3;
        final float n7 = n6 * n3 - n5 * n4;
        if (n7 == 0.0f) {
            return Color.black;
        }
        final float n8 = (n5 * (this.start.getY() - n2) - n6 * (this.start.getX() - n)) / n7;
        final float n9 = (n3 * (this.start.getY() - n2) - n4 * (this.start.getX() - n)) / n7;
        float n10 = n8;
        if (n10 < 0.0f) {
            n10 = 0.0f;
        }
        if (n10 > 1.0f) {
            n10 = 1.0f;
        }
        final float n11 = 1.0f - n10;
        final Color color = new Color(1, 1, 1, 1);
        color.r = n10 * this.endCol.r + n11 * this.startCol.r;
        color.b = n10 * this.endCol.b + n11 * this.startCol.b;
        color.g = n10 * this.endCol.g + n11 * this.startCol.g;
        color.a = n10 * this.endCol.a + n11 * this.startCol.a;
        return color;
    }
    
    @Override
    public Vector2f getOffsetAt(final Shape shape, final float n, final float n2) {
        return this.none;
    }
}
