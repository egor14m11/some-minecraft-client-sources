// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.font;

import java.awt.font.GlyphMetrics;
import org.newdawn.slick.UnicodeFont;
import java.awt.font.GlyphVector;
import java.awt.Rectangle;
import org.newdawn.slick.Image;
import java.awt.Shape;

public class Glyph
{
    public int codePoint;
    public short width;
    public short height;
    public short yOffset;
    public boolean isMissing;
    public Shape shape;
    public Image image;
    
    public Glyph(final int codePoint, final Rectangle rectangle, final GlyphVector glyphVector, final int glyphIndex, final UnicodeFont unicodeFont) {
        this.codePoint = codePoint;
        final GlyphMetrics glyphMetrics = glyphVector.getGlyphMetrics(glyphIndex);
        int n = (int)glyphMetrics.getLSB();
        if (n > 0) {
            n = 0;
        }
        int n2 = (int)glyphMetrics.getRSB();
        if (n2 > 0) {
            n2 = 0;
        }
        final int n3 = rectangle.width - n - n2;
        final int height = rectangle.height;
        if (n3 > 0 && height > 0) {
            final int paddingTop = unicodeFont.getPaddingTop();
            final int paddingRight = unicodeFont.getPaddingRight();
            final int paddingBottom = unicodeFont.getPaddingBottom();
            final int paddingLeft = unicodeFont.getPaddingLeft();
            final int n4 = 1;
            this.width = (short)(n3 + paddingLeft + paddingRight + n4);
            this.height = (short)(height + paddingTop + paddingBottom + n4);
            this.yOffset = (short)(unicodeFont.getAscent() + rectangle.y - paddingTop);
        }
        this.shape = glyphVector.getGlyphOutline(glyphIndex, (float)(-rectangle.x + unicodeFont.getPaddingLeft()), (float)(-rectangle.y + unicodeFont.getPaddingTop()));
        this.isMissing = !unicodeFont.getFont().canDisplay((char)codePoint);
    }
    
    public int getCodePoint() {
        return this.codePoint;
    }
    
    public boolean isMissing() {
        return this.isMissing;
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public Shape getShape() {
        return this.shape;
    }
    
    public void setShape(final Shape shape) {
        this.shape = shape;
    }
    
    public Image getImage() {
        return this.image;
    }
    
    public void setImage(final Image image) {
        this.image = image;
    }
    
    public int getYOffset() {
        return this.yOffset;
    }
}
