// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.font;

import java.awt.RenderingHints;
import java.nio.ByteOrder;
import org.newdawn.slick.opengl.renderer.Renderer;
import java.util.ListIterator;
import java.awt.image.WritableRaster;
import java.awt.Shape;
import org.newdawn.slick.font.effects.Effect;
import java.awt.Composite;
import java.awt.AlphaComposite;
import java.util.Iterator;
import org.newdawn.slick.opengl.TextureImpl;
import org.newdawn.slick.Color;
import org.newdawn.slick.SlickException;
import java.util.ArrayList;
import java.util.List;
import org.newdawn.slick.Image;
import org.newdawn.slick.UnicodeFont;
import java.awt.font.FontRenderContext;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.nio.IntBuffer;
import java.nio.ByteBuffer;
import org.newdawn.slick.opengl.renderer.SGL;

public class GlyphPage
{
    public static SGL GL;
    public static int MAX_GLYPH_SIZE;
    public static ByteBuffer scratchByteBuffer;
    public static IntBuffer scratchIntBuffer;
    public static BufferedImage scratchImage;
    public static Graphics2D scratchGraphics;
    public static FontRenderContext renderContext;
    public UnicodeFont unicodeFont;
    public int pageWidth;
    public int pageHeight;
    public Image pageImage;
    public int pageX;
    public int pageY;
    public int rowHeight;
    public boolean orderAscending;
    public List pageGlyphs;
    
    public static Graphics2D getScratchGraphics() {
        return GlyphPage.scratchGraphics;
    }
    
    public GlyphPage(final UnicodeFont unicodeFont, final int pageWidth, final int pageHeight) throws SlickException {
        this.pageGlyphs = new ArrayList(32);
        this.unicodeFont = unicodeFont;
        this.pageWidth = pageWidth;
        this.pageHeight = pageHeight;
        this.pageImage = new Image(pageWidth, pageHeight);
    }
    
    public int loadGlyphs(final List list, final int n) throws SlickException {
        if (this.rowHeight != 0 && n == -1) {
            int pageX = this.pageX;
            int pageY = this.pageY;
            int rowHeight = this.rowHeight;
            final Iterator iterator = this.getIterator(list);
            while (iterator.hasNext()) {
                final Glyph glyph = iterator.next();
                final int width = glyph.getWidth();
                final int height = glyph.getHeight();
                if (pageX + width >= this.pageWidth) {
                    pageX = 0;
                    pageY += rowHeight;
                    rowHeight = height;
                }
                else if (height > rowHeight) {
                    rowHeight = height;
                }
                if (pageY + rowHeight >= this.pageWidth) {
                    return 0;
                }
                pageX += width;
            }
        }
        Color.white.bind();
        this.pageImage.bind();
        int n2 = 0;
        final Iterator iterator2 = this.getIterator(list);
        while (iterator2.hasNext()) {
            final Glyph glyph2 = iterator2.next();
            final int min = Math.min(256, glyph2.getWidth());
            final int min2 = Math.min(256, glyph2.getHeight());
            if (this.rowHeight == 0) {
                this.rowHeight = min2;
            }
            else if (this.pageX + min >= this.pageWidth) {
                if (this.pageY + this.rowHeight + min2 >= this.pageHeight) {
                    break;
                }
                this.pageX = 0;
                this.pageY += this.rowHeight;
                this.rowHeight = min2;
            }
            else if (min2 > this.rowHeight) {
                if (this.pageY + min2 >= this.pageHeight) {
                    break;
                }
                this.rowHeight = min2;
            }
            this.renderGlyph(glyph2, min, min2);
            this.pageGlyphs.add(glyph2);
            this.pageX += min;
            iterator2.remove();
            if (++n2 == n) {
                this.orderAscending = !this.orderAscending;
                break;
            }
        }
        TextureImpl.bindNone();
        this.orderAscending = !this.orderAscending;
        return n2;
    }
    
    public void renderGlyph(final Glyph glyph, final int w, final int n) throws SlickException {
        GlyphPage.scratchGraphics.setComposite(AlphaComposite.Clear);
        GlyphPage.scratchGraphics.fillRect(0, 0, 256, 256);
        GlyphPage.scratchGraphics.setComposite(AlphaComposite.SrcOver);
        GlyphPage.scratchGraphics.setColor(java.awt.Color.white);
        final Iterator<Effect> iterator = (Iterator<Effect>)this.unicodeFont.getEffects().iterator();
        while (iterator.hasNext()) {
            iterator.next().draw(GlyphPage.scratchImage, GlyphPage.scratchGraphics, this.unicodeFont, glyph);
        }
        glyph.setShape(null);
        final WritableRaster raster = GlyphPage.scratchImage.getRaster();
        final int[] array = new int[w];
        for (int i = 0; i < n; ++i) {
            raster.getDataElements(0, i, w, 1, array);
            GlyphPage.scratchIntBuffer.put(array);
        }
        GlyphPage.GL.glTexSubImage2D(3553, 0, this.pageX, this.pageY, w, n, 32993, 5121, GlyphPage.scratchByteBuffer);
        GlyphPage.scratchIntBuffer.clear();
        glyph.setImage(this.pageImage.getSubImage(this.pageX, this.pageY, w, n));
    }
    
    public Iterator getIterator(final List list) {
        if (this.orderAscending) {
            return list.iterator();
        }
        return new Iterator(this, list.listIterator(list.size())) {
            public ListIterator val$iter;
            public GlyphPage this$0;
            
            @Override
            public boolean hasNext() {
                return this.val$iter.hasPrevious();
            }
            
            @Override
            public Object next() {
                return this.val$iter.previous();
            }
            
            @Override
            public void remove() {
                this.val$iter.remove();
            }
        };
    }
    
    public List getGlyphs() {
        return this.pageGlyphs;
    }
    
    public Image getImage() {
        return this.pageImage;
    }
    
    static {
        GlyphPage.MAX_GLYPH_SIZE = 256;
        GlyphPage.GL = Renderer.get();
        (GlyphPage.scratchByteBuffer = ByteBuffer.allocateDirect(262144)).order(ByteOrder.LITTLE_ENDIAN);
        GlyphPage.scratchIntBuffer = GlyphPage.scratchByteBuffer.asIntBuffer();
        GlyphPage.scratchImage = new BufferedImage(256, 256, 2);
        (GlyphPage.scratchGraphics = (Graphics2D)GlyphPage.scratchImage.getGraphics()).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        GlyphPage.scratchGraphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        GlyphPage.scratchGraphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        GlyphPage.renderContext = GlyphPage.scratchGraphics.getFontRenderContext();
    }
}
