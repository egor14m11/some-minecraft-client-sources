// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.font;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.File;
import java.util.Iterator;
import org.newdawn.slick.font.effects.ConfigurableEffect;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.util.ResourceLoader;
import java.util.ArrayList;
import java.util.List;

public class HieroSettings
{
    public int fontSize;
    public boolean bold;
    public boolean italic;
    public int paddingTop;
    public int paddingLeft;
    public int paddingBottom;
    public int paddingRight;
    public int paddingAdvanceX;
    public int paddingAdvanceY;
    public int glyphPageWidth;
    public int glyphPageHeight;
    public List effects;
    
    public HieroSettings() {
        this.fontSize = 12;
        this.bold = false;
        this.italic = false;
        this.glyphPageWidth = 512;
        this.glyphPageHeight = 512;
        this.effects = new ArrayList();
    }
    
    public HieroSettings(final String s) throws SlickException {
        this(ResourceLoader.getResourceAsStream(s));
    }
    
    public HieroSettings(final InputStream in) throws SlickException {
        this.fontSize = 12;
        this.bold = false;
        this.italic = false;
        this.glyphPageWidth = 512;
        this.glyphPageHeight = 512;
        this.effects = new ArrayList();
        final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
        while (true) {
            final String line = bufferedReader.readLine();
            if (line == null) {
                break;
            }
            final String trim = line.trim();
            if (trim.length() == 0) {
                continue;
            }
            final String[] split = trim.split("=", 2);
            final String trim2 = split[0].trim();
            final String string = split[1];
            if (trim2.equals("font.size")) {
                this.fontSize = Integer.parseInt(string);
            }
            else if (trim2.equals("font.bold")) {
                this.bold = Boolean.valueOf(string);
            }
            else if (trim2.equals("font.italic")) {
                this.italic = Boolean.valueOf(string);
            }
            else if (trim2.equals("pad.top")) {
                this.paddingTop = Integer.parseInt(string);
            }
            else if (trim2.equals("pad.right")) {
                this.paddingRight = Integer.parseInt(string);
            }
            else if (trim2.equals("pad.bottom")) {
                this.paddingBottom = Integer.parseInt(string);
            }
            else if (trim2.equals("pad.left")) {
                this.paddingLeft = Integer.parseInt(string);
            }
            else if (trim2.equals("pad.advance.x")) {
                this.paddingAdvanceX = Integer.parseInt(string);
            }
            else if (trim2.equals("pad.advance.y")) {
                this.paddingAdvanceY = Integer.parseInt(string);
            }
            else if (trim2.equals("glyph.page.width")) {
                this.glyphPageWidth = Integer.parseInt(string);
            }
            else if (trim2.equals("glyph.page.height")) {
                this.glyphPageHeight = Integer.parseInt(string);
            }
            else if (trim2.equals("effect.class")) {
                this.effects.add(Class.forName(string).newInstance());
            }
            else {
                if (!trim2.startsWith("effect.")) {
                    continue;
                }
                final String substring = trim2.substring(7);
                final ConfigurableEffect configurableEffect = this.effects.get(this.effects.size() - 1);
                final List values = configurableEffect.getValues();
                for (final ConfigurableEffect.Value value : values) {
                    if (value.getName().equals(substring)) {
                        value.setString(string);
                        break;
                    }
                }
                configurableEffect.setValues(values);
            }
        }
        bufferedReader.close();
    }
    
    public int getPaddingTop() {
        return this.paddingTop;
    }
    
    public void setPaddingTop(final int paddingTop) {
        this.paddingTop = paddingTop;
    }
    
    public int getPaddingLeft() {
        return this.paddingLeft;
    }
    
    public void setPaddingLeft(final int paddingLeft) {
        this.paddingLeft = paddingLeft;
    }
    
    public int getPaddingBottom() {
        return this.paddingBottom;
    }
    
    public void setPaddingBottom(final int paddingBottom) {
        this.paddingBottom = paddingBottom;
    }
    
    public int getPaddingRight() {
        return this.paddingRight;
    }
    
    public void setPaddingRight(final int paddingRight) {
        this.paddingRight = paddingRight;
    }
    
    public int getPaddingAdvanceX() {
        return this.paddingAdvanceX;
    }
    
    public void setPaddingAdvanceX(final int paddingAdvanceX) {
        this.paddingAdvanceX = paddingAdvanceX;
    }
    
    public int getPaddingAdvanceY() {
        return this.paddingAdvanceY;
    }
    
    public void setPaddingAdvanceY(final int paddingAdvanceY) {
        this.paddingAdvanceY = paddingAdvanceY;
    }
    
    public int getGlyphPageWidth() {
        return this.glyphPageWidth;
    }
    
    public void setGlyphPageWidth(final int glyphPageWidth) {
        this.glyphPageWidth = glyphPageWidth;
    }
    
    public int getGlyphPageHeight() {
        return this.glyphPageHeight;
    }
    
    public void setGlyphPageHeight(final int glyphPageHeight) {
        this.glyphPageHeight = glyphPageHeight;
    }
    
    public int getFontSize() {
        return this.fontSize;
    }
    
    public void setFontSize(final int fontSize) {
        this.fontSize = fontSize;
    }
    
    public boolean isBold() {
        return this.bold;
    }
    
    public void setBold(final boolean bold) {
        this.bold = bold;
    }
    
    public boolean isItalic() {
        return this.italic;
    }
    
    public void setItalic(final boolean italic) {
        this.italic = italic;
    }
    
    public List getEffects() {
        return this.effects;
    }
    
    public void save(final File file) throws IOException {
        final PrintStream printStream = new PrintStream(new FileOutputStream(file));
        printStream.println("font.size=" + this.fontSize);
        printStream.println("font.bold=" + this.bold);
        printStream.println("font.italic=" + this.italic);
        printStream.println();
        printStream.println("pad.top=" + this.paddingTop);
        printStream.println("pad.right=" + this.paddingRight);
        printStream.println("pad.bottom=" + this.paddingBottom);
        printStream.println("pad.left=" + this.paddingLeft);
        printStream.println("pad.advance.x=" + this.paddingAdvanceX);
        printStream.println("pad.advance.y=" + this.paddingAdvanceY);
        printStream.println();
        printStream.println("glyph.page.width=" + this.glyphPageWidth);
        printStream.println("glyph.page.height=" + this.glyphPageHeight);
        printStream.println();
        for (final ConfigurableEffect configurableEffect : this.effects) {
            printStream.println("effect.class=" + configurableEffect.getClass().getName());
            for (final ConfigurableEffect.Value value : configurableEffect.getValues()) {
                printStream.println("effect." + value.getName() + "=" + value.getString());
            }
            printStream.println();
        }
        printStream.close();
    }
}
