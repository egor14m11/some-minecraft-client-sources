// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.font.effects;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import org.newdawn.slick.font.Glyph;
import org.newdawn.slick.UnicodeFont;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.Color;

public class ColorEffect implements ConfigurableEffect
{
    public Color color;
    
    public ColorEffect() {
        this.color = Color.white;
    }
    
    public ColorEffect(final Color color) {
        this.color = Color.white;
        this.color = color;
    }
    
    @Override
    public void draw(final BufferedImage bufferedImage, final Graphics2D graphics2D, final UnicodeFont unicodeFont, final Glyph glyph) {
        graphics2D.setColor(this.color);
        graphics2D.fill(glyph.getShape());
    }
    
    public Color getColor() {
        return this.color;
    }
    
    public void setColor(final Color color) {
        if (color == null) {
            throw new IllegalArgumentException("color cannot be null.");
        }
        this.color = color;
    }
    
    @Override
    public String toString() {
        return "Color";
    }
    
    @Override
    public List getValues() {
        final ArrayList<Value> list = new ArrayList<Value>();
        list.add(EffectUtil.colorValue("Color", this.color));
        return list;
    }
    
    @Override
    public void setValues(final List list) {
        for (final Value value : list) {
            if (value.getName().equals("Color")) {
                this.setColor((Color)value.getObject());
            }
        }
    }
}
