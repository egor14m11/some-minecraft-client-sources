// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.font.effects;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JPanel;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import javax.swing.JDialog;
import java.awt.EventQueue;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.SpinnerModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import java.awt.Component;
import javax.swing.JColorChooser;
import java.awt.Color;
import java.awt.Composite;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class EffectUtil
{
    public static BufferedImage scratchImage;
    
    public static BufferedImage getScratchImage() {
        final Graphics2D graphics2D = (Graphics2D)EffectUtil.scratchImage.getGraphics();
        graphics2D.setComposite(AlphaComposite.Clear);
        graphics2D.fillRect(0, 0, 256, 256);
        graphics2D.setComposite(AlphaComposite.SrcOver);
        graphics2D.setColor(Color.white);
        return EffectUtil.scratchImage;
    }
    
    public static ConfigurableEffect.Value colorValue(final String s, final Color color) {
        return new DefaultValue(s, toString(color)) {
            @Override
            public void showDialog() {
                final Color showDialog = JColorChooser.showDialog(null, "Choose a color", EffectUtil.fromString(this.value));
                if (showDialog != null) {
                    this.value = EffectUtil.toString(showDialog);
                }
            }
            
            @Override
            public Object getObject() {
                return EffectUtil.fromString(this.value);
            }
        };
    }
    
    public static ConfigurableEffect.Value intValue(final String s, final int i, final String s2) {
        return new DefaultValue(s, String.valueOf(i), i, s2) {
            public int val$currentValue;
            public String val$description;
            
            @Override
            public void showDialog() {
                final JSpinner spinner = new JSpinner(new SpinnerNumberModel(this.val$currentValue, -32768, 32767, 1));
                if (this.showValueDialog(spinner, this.val$description)) {
                    this.value = String.valueOf(spinner.getValue());
                }
            }
            
            @Override
            public Object getObject() {
                return Integer.valueOf(this.value);
            }
        };
    }
    
    public static ConfigurableEffect.Value floatValue(final String s, final float f, final float n, final float n2, final String s2) {
        return new DefaultValue(s, String.valueOf(f), f, n, n2, s2) {
            public float val$currentValue;
            public float val$min;
            public float val$max;
            public String val$description;
            
            @Override
            public void showDialog() {
                final JSpinner spinner = new JSpinner(new SpinnerNumberModel(this.val$currentValue, this.val$min, this.val$max, 0.0));
                if (this.showValueDialog(spinner, this.val$description)) {
                    this.value = String.valueOf(((Double)spinner.getValue()).floatValue());
                }
            }
            
            @Override
            public Object getObject() {
                return Float.valueOf(this.value);
            }
        };
    }
    
    public static ConfigurableEffect.Value booleanValue(final String s, final boolean b, final String s2) {
        return new DefaultValue(s, String.valueOf(b), b, s2) {
            public boolean val$currentValue;
            public String val$description;
            
            @Override
            public void showDialog() {
                final JCheckBox checkBox = new JCheckBox();
                checkBox.setSelected(this.val$currentValue);
                if (this.showValueDialog(checkBox, this.val$description)) {
                    this.value = String.valueOf(checkBox.isSelected());
                }
            }
            
            @Override
            public Object getObject() {
                return Boolean.valueOf(this.value);
            }
        };
    }
    
    public static ConfigurableEffect.Value optionValue(final String s, final String s2, final String[][] array, final String s3) {
        return new DefaultValue(s, s2.toString(), array, s2, s3) {
            public String[][] val$options;
            public String val$currentValue;
            public String val$description;
            
            @Override
            public void showDialog() {
                int selectedIndex = -1;
                final DefaultComboBoxModel<Object> aModel = new DefaultComboBoxModel<Object>();
                for (int i = 0; i < this.val$options.length; ++i) {
                    aModel.addElement(this.val$options[i][0]);
                    if (this.getValue(i).equals(this.val$currentValue)) {
                        selectedIndex = i;
                    }
                }
                final JComboBox comboBox = new JComboBox(aModel);
                comboBox.setSelectedIndex(selectedIndex);
                if (this.showValueDialog(comboBox, this.val$description)) {
                    this.value = this.getValue(comboBox.getSelectedIndex());
                }
            }
            
            public String getValue(final int n) {
                if (this.val$options[n].length == 1) {
                    return this.val$options[n][0];
                }
                return this.val$options[n][1];
            }
            
            @Override
            public String toString() {
                for (int i = 0; i < this.val$options.length; ++i) {
                    if (this.getValue(i).equals(this.value)) {
                        return this.val$options[i][0].toString();
                    }
                }
                return "";
            }
            
            @Override
            public Object getObject() {
                return this.value;
            }
        };
    }
    
    public static String toString(final Color color) {
        if (color == null) {
            throw new IllegalArgumentException("color cannot be null.");
        }
        String s = Integer.toHexString(color.getRed());
        if (s.length() == 1) {
            s = "0" + s;
        }
        String s2 = Integer.toHexString(color.getGreen());
        if (s2.length() == 1) {
            s2 = "0" + s2;
        }
        String s3 = Integer.toHexString(color.getBlue());
        if (s3.length() == 1) {
            s3 = "0" + s3;
        }
        return s + s2 + s3;
    }
    
    public static Color fromString(final String s) {
        if (s == null || s.length() != 6) {
            return Color.white;
        }
        return new Color(Integer.parseInt(s.substring(0, 2), 16), Integer.parseInt(s.substring(2, 4), 16), Integer.parseInt(s.substring(4, 6), 16));
    }
    
    static {
        EffectUtil.scratchImage = new BufferedImage(256, 256, 2);
    }
    
    private abstract static class DefaultValue implements ConfigurableEffect.Value
    {
        public String value;
        public String name;
        
        public DefaultValue(final String name, final String value) {
            this.value = value;
            this.name = name;
        }
        
        @Override
        public void setString(final String value) {
            this.value = value;
        }
        
        @Override
        public String getString() {
            return this.value;
        }
        
        @Override
        public String getName() {
            return this.name;
        }
        
        @Override
        public String toString() {
            if (this.value == null) {
                return "";
            }
            return this.value.toString();
        }
        
        public boolean showValueDialog(final JComponent component, final String s) {
            final ValueDialog valueDialog = new ValueDialog(component, this.name, s);
            valueDialog.setTitle(this.name);
            valueDialog.setLocationRelativeTo(null);
            EventQueue.invokeLater(new Runnable(this, component) {
                public JComponent val$component;
                public DefaultValue this$0;
                
                @Override
                public void run() {
                    JComponent component = this.val$component;
                    if (component instanceof JSpinner) {
                        component = ((JSpinner.DefaultEditor)((JSpinner)this.val$component).getEditor()).getTextField();
                    }
                    component.requestFocusInWindow();
                }
            });
            valueDialog.setVisible(true);
            return valueDialog.okPressed;
        }
    }
    
    private static class ValueDialog extends JDialog
    {
        public boolean okPressed;
        
        public ValueDialog(final JComponent comp, final String str, final String text) {
            this.okPressed = false;
            this.setDefaultCloseOperation(2);
            this.setLayout(new GridBagLayout());
            this.setModal(true);
            if (comp instanceof JSpinner) {
                ((JSpinner.DefaultEditor)((JSpinner)comp).getEditor()).getTextField().setColumns(4);
            }
            final JPanel comp2 = new JPanel();
            comp2.setLayout(new GridBagLayout());
            this.getContentPane().add(comp2, new GridBagConstraints(0, 0, 2, 1, 1.0, 0.0, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
            comp2.setBackground(Color.white);
            comp2.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.black));
            final JTextArea comp3 = new JTextArea(text);
            comp2.add(comp3, new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, 10, 1, new Insets(5, 5, 5, 5), 0, 0));
            comp3.setWrapStyleWord(true);
            comp3.setLineWrap(true);
            comp3.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
            comp3.setEditable(false);
            final JPanel comp4 = new JPanel();
            this.getContentPane().add(comp4, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, 10, 0, new Insets(5, 5, 0, 5), 0, 0));
            comp4.add(new JLabel(str + ":"));
            comp4.add(comp);
            final JPanel comp5 = new JPanel();
            this.getContentPane().add(comp5, new GridBagConstraints(0, 2, 2, 1, 0.0, 0.0, 13, 0, new Insets(0, 0, 0, 0), 0, 0));
            final JButton comp6 = new JButton("OK");
            comp5.add(comp6);
            comp6.addActionListener(new ActionListener(this) {
                public ValueDialog this$0;
                
                @Override
                public void actionPerformed(final ActionEvent actionEvent) {
                    this.this$0.okPressed = true;
                    this.this$0.setVisible(false);
                }
            });
            final JButton comp7 = new JButton("Cancel");
            comp5.add(comp7);
            comp7.addActionListener(new ActionListener(this) {
                public ValueDialog this$0;
                
                @Override
                public void actionPerformed(final ActionEvent actionEvent) {
                    this.this$0.setVisible(false);
                }
            });
            this.setSize(new Dimension(320, 175));
        }
    }
}
