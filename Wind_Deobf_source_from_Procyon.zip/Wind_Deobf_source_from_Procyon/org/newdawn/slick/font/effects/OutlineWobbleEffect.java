// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.font.effects;

import java.awt.geom.FlatteningPathIterator;
import java.awt.geom.AffineTransform;
import java.awt.BasicStroke;
import java.awt.geom.GeneralPath;
import java.awt.Shape;
import java.util.Iterator;
import java.util.List;
import java.awt.Color;
import java.awt.Stroke;

public class OutlineWobbleEffect extends OutlineEffect
{
    public float detail;
    public float amplitude;
    
    public OutlineWobbleEffect() {
        this.detail = 1.0f;
        this.amplitude = 1.0f;
        this.setStroke(new WobbleStroke(null));
    }
    
    public float getDetail() {
        return this.detail;
    }
    
    public void setDetail(final float detail) {
        this.detail = detail;
    }
    
    public float getAmplitude() {
        return this.amplitude;
    }
    
    public void setAmplitude(final float amplitude) {
        this.amplitude = amplitude;
    }
    
    public OutlineWobbleEffect(final int n, final Color color) {
        super(n, color);
        this.detail = 1.0f;
        this.amplitude = 1.0f;
    }
    
    @Override
    public String toString() {
        return "Outline (Wobble)";
    }
    
    @Override
    public List getValues() {
        final List values = super.getValues();
        values.remove(2);
        values.add(EffectUtil.floatValue("Detail", this.detail, 1.0f, 50.0f, "This setting controls how detailed the outline will be. Smaller numbers cause the outline to have more detail."));
        values.add(EffectUtil.floatValue("Amplitude", this.amplitude, 0.0f, 50.0f, "This setting controls the amplitude of the outline."));
        return values;
    }
    
    @Override
    public void setValues(final List values) {
        super.setValues(values);
        for (final ConfigurableEffect.Value value : values) {
            if (value.getName().equals("Detail")) {
                this.detail = (float)value.getObject();
            }
            else {
                if (!value.getName().equals("Amplitude")) {
                    continue;
                }
                this.amplitude = (float)value.getObject();
            }
        }
    }
    
    public static float access$100(final OutlineWobbleEffect outlineWobbleEffect) {
        return outlineWobbleEffect.detail;
    }
    
    public static float access$200(final OutlineWobbleEffect outlineWobbleEffect) {
        return outlineWobbleEffect.amplitude;
    }
    
    private class WobbleStroke implements Stroke
    {
        public static float FLATNESS;
        public OutlineWobbleEffect this$0;
        
        public WobbleStroke(final OutlineWobbleEffect this$0) {
            this.this$0 = this$0;
        }
        
        @Override
        public Shape createStrokedShape(Shape strokedShape) {
            final GeneralPath generalPath = new GeneralPath();
            strokedShape = new BasicStroke(this.this$0.getWidth(), 2, this.this$0.getJoin()).createStrokedShape(strokedShape);
            final FlatteningPathIterator flatteningPathIterator = new FlatteningPathIterator(strokedShape.getPathIterator(null), 1.0);
            final float[] array = new float[6];
            float randomize = 0.0f;
            float randomize2 = 0.0f;
            float n = 0.0f;
            float n2 = 0.0f;
            float n3 = 0.0f;
            while (!flatteningPathIterator.isDone()) {
                switch (flatteningPathIterator.currentSegment(array)) {
                    case 0: {
                        n = (randomize = this.randomize(array[0]));
                        n2 = (randomize2 = this.randomize(array[1]));
                        generalPath.moveTo(randomize, randomize2);
                        n3 = 0.0f;
                        break;
                    }
                    case 4: {
                        array[0] = randomize;
                        array[1] = randomize2;
                    }
                    case 1: {
                        final float randomize3 = this.randomize(array[0]);
                        final float randomize4 = this.randomize(array[1]);
                        final float n4 = randomize3 - n;
                        final float n5 = randomize4 - n2;
                        final float n6 = (float)Math.sqrt(n4 * n4 + n5 * n5);
                        if (n6 >= n3) {
                            final float n7 = 1.0f / n6;
                            while (n6 >= n3) {
                                generalPath.lineTo(this.randomize(n + n3 * n4 * n7), this.randomize(n2 + n3 * n5 * n7));
                                n3 += OutlineWobbleEffect.access$100(this.this$0);
                            }
                        }
                        n3 -= n6;
                        n = randomize3;
                        n2 = randomize4;
                        break;
                    }
                }
                flatteningPathIterator.next();
            }
            return generalPath;
        }
        
        public float randomize(final float n) {
            return n + (float)Math.random() * OutlineWobbleEffect.access$200(this.this$0) * 2.0f - 1.0f;
        }
        
        public WobbleStroke(final OutlineWobbleEffect outlineWobbleEffect, final OutlineWobbleEffect$1 object) {
            this(outlineWobbleEffect);
        }
        
        static {
            WobbleStroke.FLATNESS = 1.0f;
        }
    }
}
