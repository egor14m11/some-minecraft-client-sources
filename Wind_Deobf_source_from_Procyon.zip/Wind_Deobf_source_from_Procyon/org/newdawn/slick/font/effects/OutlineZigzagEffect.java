// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.font.effects;

import java.awt.BasicStroke;
import java.awt.geom.FlatteningPathIterator;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.Shape;
import java.util.Iterator;
import java.util.List;
import java.awt.Color;
import java.awt.Stroke;

public class OutlineZigzagEffect extends OutlineEffect
{
    public float amplitude;
    public float wavelength;
    
    public OutlineZigzagEffect() {
        this.amplitude = 1.0f;
        this.wavelength = 3.0f;
        this.setStroke(new ZigzagStroke(null));
    }
    
    public float getWavelength() {
        return this.wavelength;
    }
    
    public void setWavelength(final float wavelength) {
        this.wavelength = wavelength;
    }
    
    public float getAmplitude() {
        return this.amplitude;
    }
    
    public void setAmplitude(final float amplitude) {
        this.amplitude = amplitude;
    }
    
    public OutlineZigzagEffect(final int n, final Color color) {
        super(n, color);
        this.amplitude = 1.0f;
        this.wavelength = 3.0f;
    }
    
    @Override
    public String toString() {
        return "Outline (Zigzag)";
    }
    
    @Override
    public List getValues() {
        final List values = super.getValues();
        values.add(EffectUtil.floatValue("Wavelength", this.wavelength, 1.0f, 100.0f, "This setting controls the wavelength of the outline. The smaller the value, the more segments will be used to draw the outline."));
        values.add(EffectUtil.floatValue("Amplitude", this.amplitude, 0.0f, 50.0f, "This setting controls the amplitude of the outline. The bigger the value, the more the zigzags will vary."));
        return values;
    }
    
    @Override
    public void setValues(final List values) {
        super.setValues(values);
        for (final ConfigurableEffect.Value value : values) {
            if (value.getName().equals("Wavelength")) {
                this.wavelength = (float)value.getObject();
            }
            else {
                if (!value.getName().equals("Amplitude")) {
                    continue;
                }
                this.amplitude = (float)value.getObject();
            }
        }
    }
    
    public static float access$100(final OutlineZigzagEffect outlineZigzagEffect) {
        return outlineZigzagEffect.wavelength;
    }
    
    public static float access$200(final OutlineZigzagEffect outlineZigzagEffect) {
        return outlineZigzagEffect.amplitude;
    }
    
    private class ZigzagStroke implements Stroke
    {
        public static float FLATNESS;
        public OutlineZigzagEffect this$0;
        
        public ZigzagStroke(final OutlineZigzagEffect this$0) {
            this.this$0 = this$0;
        }
        
        @Override
        public Shape createStrokedShape(final Shape shape) {
            final GeneralPath s = new GeneralPath();
            final FlatteningPathIterator flatteningPathIterator = new FlatteningPathIterator(shape.getPathIterator(null), 1.0);
            final float[] array = new float[6];
            float x = 0.0f;
            float y = 0.0f;
            float n = 0.0f;
            float n2 = 0.0f;
            float n3 = 0.0f;
            int n4 = 0;
            while (!flatteningPathIterator.isDone()) {
                final int currentSegment = flatteningPathIterator.currentSegment(array);
                switch (currentSegment) {
                    case 0: {
                        n = (x = array[0]);
                        n2 = (y = array[1]);
                        s.moveTo(x, y);
                        n3 = OutlineZigzagEffect.access$100(this.this$0) / 2.0f;
                        break;
                    }
                    case 4: {
                        array[0] = x;
                        array[1] = y;
                    }
                    case 1: {
                        final float n5 = array[0];
                        final float n6 = array[1];
                        final float n7 = n5 - n;
                        final float n8 = n6 - n2;
                        final float n9 = (float)Math.sqrt(n7 * n7 + n8 * n8);
                        if (n9 >= n3) {
                            final float n10 = 1.0f / n9;
                            while (n9 >= n3) {
                                final float n11 = n + n3 * n7 * n10;
                                final float n12 = n2 + n3 * n8 * n10;
                                if ((n4 & 0x1) == 0x0) {
                                    s.lineTo(n11 + OutlineZigzagEffect.access$200(this.this$0) * n8 * n10, n12 - OutlineZigzagEffect.access$200(this.this$0) * n7 * n10);
                                }
                                else {
                                    s.lineTo(n11 - OutlineZigzagEffect.access$200(this.this$0) * n8 * n10, n12 + OutlineZigzagEffect.access$200(this.this$0) * n7 * n10);
                                }
                                n3 += OutlineZigzagEffect.access$100(this.this$0);
                                ++n4;
                            }
                        }
                        n3 -= n9;
                        n = n5;
                        n2 = n6;
                        if (currentSegment == 4) {
                            s.closePath();
                            break;
                        }
                        break;
                    }
                }
                flatteningPathIterator.next();
            }
            return new BasicStroke(this.this$0.getWidth(), 2, this.this$0.getJoin()).createStrokedShape(s);
        }
        
        public ZigzagStroke(final OutlineZigzagEffect outlineZigzagEffect, final OutlineZigzagEffect$1 object) {
            this(outlineZigzagEffect);
        }
        
        static {
            ZigzagStroke.FLATNESS = 1.0f;
        }
    }
}
