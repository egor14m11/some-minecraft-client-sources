// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.font.effects;

import java.util.ArrayList;
import java.util.List;
import java.awt.image.ConvolveOp;
import java.awt.RenderingHints;
import java.awt.image.Kernel;
import java.util.Iterator;
import java.awt.Composite;
import java.awt.AlphaComposite;
import org.newdawn.slick.font.Glyph;
import org.newdawn.slick.UnicodeFont;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.Color;

public class ShadowEffect implements ConfigurableEffect
{
    public static int NUM_KERNELS;
    public static float[][] GAUSSIAN_BLUR_KERNELS;
    public Color color;
    public float opacity;
    public float xDistance;
    public float yDistance;
    public int blurKernelSize;
    public int blurPasses;
    
    public ShadowEffect() {
        this.color = Color.black;
        this.opacity = 0.0f;
        this.xDistance = 2.0f;
        this.yDistance = 2.0f;
        this.blurKernelSize = 0;
        this.blurPasses = 1;
    }
    
    public ShadowEffect(final Color color, final int n, final int n2, final float opacity) {
        this.color = Color.black;
        this.opacity = 0.0f;
        this.xDistance = 2.0f;
        this.yDistance = 2.0f;
        this.blurKernelSize = 0;
        this.blurPasses = 1;
        this.color = color;
        this.xDistance = (float)n;
        this.yDistance = (float)n2;
        this.opacity = opacity;
    }
    
    @Override
    public void draw(final BufferedImage bufferedImage, Graphics2D graphics2D, final UnicodeFont unicodeFont, final Glyph glyph) {
        graphics2D = (Graphics2D)graphics2D.create();
        graphics2D.translate(this.xDistance, this.yDistance);
        graphics2D.setColor(new Color(this.color.getRed(), this.color.getGreen(), this.color.getBlue(), Math.round(this.opacity * 255.0f)));
        graphics2D.fill(glyph.getShape());
        for (final Effect effect : unicodeFont.getEffects()) {
            if (effect instanceof OutlineEffect) {
                final Composite composite = graphics2D.getComposite();
                graphics2D.setComposite(AlphaComposite.Src);
                graphics2D.setStroke(((OutlineEffect)effect).getStroke());
                graphics2D.draw(glyph.getShape());
                graphics2D.setComposite(composite);
                break;
            }
        }
        graphics2D.dispose();
        if (this.blurKernelSize > 1 && this.blurKernelSize < 16 && this.blurPasses > 0) {
            this.blur(bufferedImage);
        }
    }
    
    public void blur(final BufferedImage bufferedImage) {
        final float[] array = ShadowEffect.GAUSSIAN_BLUR_KERNELS[this.blurKernelSize - 1];
        final Kernel kernel = new Kernel(array.length, 1, array);
        final Kernel kernel2 = new Kernel(1, array.length, array);
        final RenderingHints renderingHints = new RenderingHints(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        final ConvolveOp convolveOp = new ConvolveOp(kernel, 1, renderingHints);
        final ConvolveOp convolveOp2 = new ConvolveOp(kernel2, 1, renderingHints);
        final BufferedImage scratchImage = EffectUtil.getScratchImage();
        for (int i = 0; i < this.blurPasses; ++i) {
            convolveOp.filter(bufferedImage, scratchImage);
            convolveOp2.filter(scratchImage, bufferedImage);
        }
    }
    
    public Color getColor() {
        return this.color;
    }
    
    public void setColor(final Color color) {
        this.color = color;
    }
    
    public float getXDistance() {
        return this.xDistance;
    }
    
    public void setXDistance(final float xDistance) {
        this.xDistance = xDistance;
    }
    
    public float getYDistance() {
        return this.yDistance;
    }
    
    public void setYDistance(final float yDistance) {
        this.yDistance = yDistance;
    }
    
    public int getBlurKernelSize() {
        return this.blurKernelSize;
    }
    
    public void setBlurKernelSize(final int blurKernelSize) {
        this.blurKernelSize = blurKernelSize;
    }
    
    public int getBlurPasses() {
        return this.blurPasses;
    }
    
    public void setBlurPasses(final int blurPasses) {
        this.blurPasses = blurPasses;
    }
    
    public float getOpacity() {
        return this.opacity;
    }
    
    public void setOpacity(final float opacity) {
        this.opacity = opacity;
    }
    
    @Override
    public String toString() {
        return "Shadow";
    }
    
    @Override
    public List getValues() {
        final ArrayList<Value> list = new ArrayList<Value>();
        list.add(EffectUtil.colorValue("Color", this.color));
        list.add(EffectUtil.floatValue("Opacity", this.opacity, 0.0f, 1.0f, "This setting sets the translucency of the shadow."));
        list.add(EffectUtil.floatValue("X distance", this.xDistance, 0.0f, Float.MAX_VALUE, "This setting is the amount of pixels to offset the shadow on the x axis. The glyphs will need padding so the shadow doesn't get clipped."));
        list.add(EffectUtil.floatValue("Y distance", this.yDistance, 0.0f, Float.MAX_VALUE, "This setting is the amount of pixels to offset the shadow on the y axis. The glyphs will need padding so the shadow doesn't get clipped."));
        final ArrayList<String[]> list2 = new ArrayList<String[]>();
        list2.add(new String[] { "None", "0" });
        for (int i = 2; i < 16; ++i) {
            list2.add(new String[] { String.valueOf(i) });
        }
        list.add(EffectUtil.optionValue("Blur kernel size", String.valueOf(this.blurKernelSize), list2.toArray(new String[list2.size()][]), "This setting controls how many neighboring pixels are used to blur the shadow. Set to \"None\" for no blur."));
        list.add(EffectUtil.intValue("Blur passes", this.blurPasses, "The setting is the number of times to apply a blur to the shadow. Set to \"0\" for no blur."));
        return list;
    }
    
    @Override
    public void setValues(final List list) {
        for (final Value value : list) {
            if (value.getName().equals("Color")) {
                this.color = (Color)value.getObject();
            }
            else if (value.getName().equals("Opacity")) {
                this.opacity = (float)value.getObject();
            }
            else if (value.getName().equals("X distance")) {
                this.xDistance = (float)value.getObject();
            }
            else if (value.getName().equals("Y distance")) {
                this.yDistance = (float)value.getObject();
            }
            else if (value.getName().equals("Blur kernel size")) {
                this.blurKernelSize = Integer.parseInt((String)value.getObject());
            }
            else {
                if (!value.getName().equals("Blur passes")) {
                    continue;
                }
                this.blurPasses = (int)value.getObject();
            }
        }
    }
    
    public static float[][] generateGaussianBlurKernels(final int n) {
        final float[][] generatePascalsTriangle = generatePascalsTriangle(n);
        final float[][] array = new float[generatePascalsTriangle.length][];
        for (int i = 0; i < array.length; ++i) {
            float n2 = 0.0f;
            array[i] = new float[generatePascalsTriangle[i].length];
            for (int j = 0; j < generatePascalsTriangle[i].length; ++j) {
                n2 += generatePascalsTriangle[i][j];
            }
            final float n3 = 1.0f / n2;
            for (int k = 0; k < generatePascalsTriangle[i].length; ++k) {
                array[i][k] = n3 * generatePascalsTriangle[i][k];
            }
        }
        return array;
    }
    
    public static float[][] generatePascalsTriangle(int n) {
        if (n < 2) {
            n = 2;
        }
        final float[][] array = new float[n][];
        array[0] = new float[1];
        array[1] = new float[2];
        array[0][0] = 1.0f;
        array[1][0] = 1.0f;
        array[1][1] = 1.0f;
        for (int i = 2; i < n; ++i) {
            (array[i] = new float[i + 1])[0] = 1.0f;
            array[i][i] = 1.0f;
            for (int j = 1; j < array[i].length - 1; ++j) {
                array[i][j] = array[i - 1][j - 1] + array[i - 1][j];
            }
        }
        return array;
    }
    
    static {
        ShadowEffect.NUM_KERNELS = 16;
        ShadowEffect.GAUSSIAN_BLUR_KERNELS = generateGaussianBlurKernels(16);
    }
}
