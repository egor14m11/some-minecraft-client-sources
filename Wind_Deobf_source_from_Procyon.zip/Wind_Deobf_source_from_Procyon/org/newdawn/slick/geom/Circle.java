// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

public strictfp class Circle extends Ellipse
{
    public float radius;
    
    public Circle(final float n, final float n2, final float n3) {
        this(n, n2, n3, 50);
    }
    
    public Circle(final float n, final float n2, final float n3, final int n4) {
        super(n, n2, n3, n3, n4);
        this.x = n - n3;
        this.y = n2 - n3;
        this.radius = n3;
        this.boundingCircleRadius = n3;
    }
    
    @Override
    public strictfp float getCenterX() {
        return this.getX() + this.radius;
    }
    
    @Override
    public strictfp float getCenterY() {
        return this.getY() + this.radius;
    }
    
    public strictfp void setRadius(final float radius) {
        if (radius != this.radius) {
            this.pointsDirty = true;
            this.setRadii(this.radius = radius, radius);
        }
    }
    
    public strictfp float getRadius() {
        return this.radius;
    }
    
    @Override
    public strictfp boolean intersects(final Shape shape) {
        if (shape instanceof Circle) {
            final Circle circle = (Circle)shape;
            final float n = this.getRadius() + circle.getRadius();
            if (Math.abs(circle.getCenterX() - this.getCenterX()) > n) {
                return false;
            }
            if (Math.abs(circle.getCenterY() - this.getCenterY()) > n) {
                return false;
            }
            final float n2 = n * n;
            final float abs = Math.abs(circle.getCenterX() - this.getCenterX());
            final float abs2 = Math.abs(circle.getCenterY() - this.getCenterY());
            return n2 >= abs * abs + abs2 * abs2;
        }
        else {
            if (shape instanceof Rectangle) {
                return this.intersects((Rectangle)shape);
            }
            return super.intersects(shape);
        }
    }
    
    @Override
    public strictfp boolean contains(final float n, final float n2) {
        return (n - this.getX()) * (n - this.getX()) + (n2 - this.getY()) * (n2 - this.getY()) < this.getRadius() * this.getRadius();
    }
    
    public strictfp boolean contains(final Line line) {
        return this.contains(line.getX1(), line.getY1()) && this.contains(line.getX2(), line.getY2());
    }
    
    @Override
    public strictfp void findCenter() {
        (this.center = new float[2])[0] = this.x + this.radius;
        this.center[1] = this.y + this.radius;
    }
    
    @Override
    public strictfp void calculateRadius() {
        this.boundingCircleRadius = this.radius;
    }
    
    public strictfp boolean intersects(final Rectangle rectangle) {
        if (rectangle.contains(this.x + this.radius, this.y + this.radius)) {
            return true;
        }
        final float x = rectangle.getX();
        final float y = rectangle.getY();
        final float n = rectangle.getX() + rectangle.getWidth();
        final float n2 = rectangle.getY() + rectangle.getHeight();
        final Line[] array = { new Line(x, y, n, y), new Line(n, y, n, n2), new Line(n, n2, x, n2), new Line(x, n2, x, y) };
        final float n3 = this.getRadius() * this.getRadius();
        final Vector2f vector2f = new Vector2f(this.getCenterX(), this.getCenterY());
        for (int i = 0; i < 4; ++i) {
            if (array[i].distanceSquared(vector2f) < n3) {
                return true;
            }
        }
        return false;
    }
    
    public strictfp boolean intersects(final Line line) {
        final Vector2f vector2f = new Vector2f(line.getX1(), line.getY1());
        final Vector2f vector2f2 = new Vector2f(line.getX2(), line.getY2());
        final Vector2f vector2f3 = new Vector2f(this.getCenterX(), this.getCenterY());
        final Vector2f sub = vector2f2.copy().sub(vector2f);
        final Vector2f sub2 = vector2f3.copy().sub(vector2f);
        final float length = sub.length();
        final float n = sub2.dot(sub) / length;
        Vector2f add;
        if (n < 0.0f) {
            add = vector2f;
        }
        else if (n > length) {
            add = vector2f2;
        }
        else {
            add = vector2f.copy().add(sub.copy().scale(n / length));
        }
        return vector2f3.copy().sub(add).lengthSquared() <= this.getRadius() * this.getRadius();
    }
}
