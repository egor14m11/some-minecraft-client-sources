// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

public class Curve extends Shape
{
    public Vector2f p1;
    public Vector2f c1;
    public Vector2f c2;
    public Vector2f p2;
    public int segments;
    
    public Curve(final Vector2f vector2f, final Vector2f vector2f2, final Vector2f vector2f3, final Vector2f vector2f4) {
        this(vector2f, vector2f2, vector2f3, vector2f4, 20);
    }
    
    public Curve(final Vector2f vector2f, final Vector2f vector2f2, final Vector2f vector2f3, final Vector2f vector2f4, final int segments) {
        this.p1 = new Vector2f(vector2f);
        this.c1 = new Vector2f(vector2f2);
        this.c2 = new Vector2f(vector2f3);
        this.p2 = new Vector2f(vector2f4);
        this.segments = segments;
        this.pointsDirty = true;
    }
    
    public Vector2f pointAt(final float n) {
        final float n2 = 1.0f - n;
        final float n3 = n2 * n2 * n2;
        final float n4 = 3.0f * n2 * n2 * n;
        final float n5 = 3.0f * n2 * n * n;
        final float n6 = n * n * n;
        return new Vector2f(this.p1.x * n3 + this.c1.x * n4 + this.c2.x * n5 + this.p2.x * n6, this.p1.y * n3 + this.c1.y * n4 + this.c2.y * n5 + this.p2.y * n6);
    }
    
    @Override
    public void createPoints() {
        final float n = 1.0f / this.segments;
        this.points = new float[(this.segments + 1) * 2];
        for (int i = 0; i < this.segments + 1; ++i) {
            final Vector2f point = this.pointAt(i * n);
            this.points[i * 2] = point.x;
            this.points[i * 2 + 1] = point.y;
        }
    }
    
    @Override
    public Shape transform(final Transform transform) {
        final float[] array = new float[8];
        final float[] array2 = new float[8];
        array[0] = this.p1.x;
        array[1] = this.p1.y;
        array[2] = this.c1.x;
        array[3] = this.c1.y;
        array[4] = this.c2.x;
        array[5] = this.c2.y;
        array[6] = this.p2.x;
        array[7] = this.p2.y;
        transform.transform(array, 0, array2, 0, 4);
        return new Curve(new Vector2f(array2[0], array2[1]), new Vector2f(array2[2], array2[3]), new Vector2f(array2[4], array2[5]), new Vector2f(array2[6], array2[7]));
    }
    
    @Override
    public boolean closed() {
        return false;
    }
}
