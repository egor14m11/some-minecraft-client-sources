// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

import org.newdawn.slick.util.FastTrig;
import java.util.ArrayList;

public class Ellipse extends Shape
{
    public static int DEFAULT_SEGMENT_COUNT;
    public int segmentCount;
    public float radius1;
    public float radius2;
    
    public Ellipse(final float n, final float n2, final float n3, final float n4) {
        this(n, n2, n3, n4, 50);
    }
    
    public Ellipse(final float n, final float n2, final float radius1, final float radius2, final int segmentCount) {
        this.x = n - radius1;
        this.y = n2 - radius2;
        this.radius1 = radius1;
        this.radius2 = radius2;
        this.segmentCount = segmentCount;
        this.checkPoints();
    }
    
    public void setRadii(final float radius1, final float radius2) {
        this.setRadius1(radius1);
        this.setRadius2(radius2);
    }
    
    public float getRadius1() {
        return this.radius1;
    }
    
    public void setRadius1(final float radius1) {
        if (radius1 != this.radius1) {
            this.radius1 = radius1;
            this.pointsDirty = true;
        }
    }
    
    public float getRadius2() {
        return this.radius2;
    }
    
    public void setRadius2(final float radius2) {
        if (radius2 != this.radius2) {
            this.radius2 = radius2;
            this.pointsDirty = true;
        }
    }
    
    @Override
    public void createPoints() {
        final ArrayList<Float> list = new ArrayList<Float>();
        this.maxX = -1.4E-45f;
        this.maxY = -1.4E-45f;
        this.minX = Float.MAX_VALUE;
        this.minY = Float.MAX_VALUE;
        final float n = 0.0f;
        final float n2 = 359.0f;
        final float n3 = this.x + this.radius1;
        final float n4 = this.y + this.radius2;
        final int n5 = 360 / this.segmentCount;
        for (float n6 = n; n6 <= n2 + n5; n6 += n5) {
            float n7 = n6;
            if (n7 > n2) {
                n7 = n2;
            }
            final float value = (float)(n3 + FastTrig.cos(Math.toRadians(n7)) * this.radius1);
            final float value2 = (float)(n4 + FastTrig.sin(Math.toRadians(n7)) * this.radius2);
            if (value > this.maxX) {
                this.maxX = value;
            }
            if (value2 > this.maxY) {
                this.maxY = value2;
            }
            if (value < this.minX) {
                this.minX = value;
            }
            if (value2 < this.minY) {
                this.minY = value2;
            }
            list.add(new Float(value));
            list.add(new Float(value2));
        }
        this.points = new float[list.size()];
        for (int i = 0; i < this.points.length; ++i) {
            this.points[i] = list.get(i);
        }
    }
    
    @Override
    public Shape transform(final Transform transform) {
        this.checkPoints();
        final Polygon polygon = new Polygon();
        final float[] points = new float[this.points.length];
        transform.transform(this.points, 0, points, 0, this.points.length / 2);
        polygon.points = points;
        polygon.checkPoints();
        return polygon;
    }
    
    @Override
    public void findCenter() {
        (this.center = new float[2])[0] = this.x + this.radius1;
        this.center[1] = this.y + this.radius2;
    }
    
    @Override
    public void calculateRadius() {
        this.boundingCircleRadius = ((this.radius1 > this.radius2) ? this.radius1 : this.radius2);
    }
    
    static {
        Ellipse.DEFAULT_SEGMENT_COUNT = 50;
    }
}
