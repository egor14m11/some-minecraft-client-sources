// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

import java.util.ArrayList;

public class GeomUtil
{
    public float EPSILON;
    public float EDGE_SCALE;
    public int MAX_POINTS;
    public GeomUtilListener listener;
    
    public GeomUtil() {
        this.EPSILON = 0.0f;
        this.EDGE_SCALE = 1.0f;
        this.MAX_POINTS = 10000;
    }
    
    public Shape[] subtract(Shape transform, Shape transform2) {
        transform = transform.transform(new Transform());
        transform2 = transform2.transform(new Transform());
        int n = 0;
        for (int i = 0; i < transform.getPointCount(); ++i) {
            if (transform2.contains(transform.getPoint(i)[0], transform.getPoint(i)[1])) {
                ++n;
            }
        }
        if (n == transform.getPointCount()) {
            return new Shape[0];
        }
        if (!transform.intersects(transform2)) {
            return new Shape[] { transform };
        }
        int n2 = 0;
        for (int j = 0; j < transform2.getPointCount(); ++j) {
            if (transform.contains(transform2.getPoint(j)[0], transform2.getPoint(j)[1]) && !this.onPath(transform, transform2.getPoint(j)[0], transform2.getPoint(j)[1])) {
                ++n2;
            }
        }
        for (int k = 0; k < transform.getPointCount(); ++k) {
            if (transform2.contains(transform.getPoint(k)[0], transform.getPoint(k)[1]) && !this.onPath(transform2, transform.getPoint(k)[0], transform.getPoint(k)[1])) {
                ++n2;
            }
        }
        if (n2 < 1) {
            return new Shape[] { transform };
        }
        return this.combine(transform, transform2, true);
    }
    
    public boolean onPath(final Shape shape, final float n, final float n2) {
        for (int i = 0; i < shape.getPointCount() + 1; ++i) {
            if (this.getLine(shape, rationalPoint(shape, i), rationalPoint(shape, i + 1)).distance(new Vector2f(n, n2)) < this.EPSILON * 100.0f) {
                return true;
            }
        }
        return false;
    }
    
    public void setListener(final GeomUtilListener listener) {
        this.listener = listener;
    }
    
    public Shape[] union(Shape transform, Shape transform2) {
        transform = transform.transform(new Transform());
        transform2 = transform2.transform(new Transform());
        if (!transform.intersects(transform2)) {
            return new Shape[] { transform, transform2 };
        }
        boolean b = false;
        int n = 0;
        for (int i = 0; i < transform.getPointCount(); ++i) {
            if (transform2.contains(transform.getPoint(i)[0], transform.getPoint(i)[1]) && !transform2.hasVertex(transform.getPoint(i)[0], transform.getPoint(i)[1])) {
                b = true;
                break;
            }
            if (transform2.hasVertex(transform.getPoint(i)[0], transform.getPoint(i)[1])) {
                ++n;
            }
        }
        for (int j = 0; j < transform2.getPointCount(); ++j) {
            if (transform.contains(transform2.getPoint(j)[0], transform2.getPoint(j)[1]) && !transform.hasVertex(transform2.getPoint(j)[0], transform2.getPoint(j)[1])) {
                b = true;
                break;
            }
        }
        if (!b && n < 2) {
            return new Shape[] { transform, transform2 };
        }
        return this.combine(transform, transform2, false);
    }
    
    public Shape[] combine(final Shape shape, final Shape shape2, final boolean b) {
        if (b) {
            final ArrayList<Shape> list = new ArrayList<Shape>();
            final ArrayList<Vector2f> list2 = new ArrayList<Vector2f>();
            for (int i = 0; i < shape.getPointCount(); ++i) {
                final float[] point = shape.getPoint(i);
                if (shape2.contains(point[0], point[1])) {
                    list2.add(new Vector2f(point[0], point[1]));
                    if (this.listener != null) {
                        this.listener.pointExcluded(point[0], point[1]);
                    }
                }
            }
            for (int j = 0; j < shape.getPointCount(); ++j) {
                final float[] point2 = shape.getPoint(j);
                if (!list2.contains(new Vector2f(point2[0], point2[1]))) {
                    final Shape combineSingle = this.combineSingle(shape, shape2, true, j);
                    list.add(combineSingle);
                    for (int k = 0; k < combineSingle.getPointCount(); ++k) {
                        final float[] point3 = combineSingle.getPoint(k);
                        list2.add(new Vector2f(point3[0], point3[1]));
                    }
                }
            }
            return list.toArray(new Shape[0]);
        }
        for (int l = 0; l < shape.getPointCount(); ++l) {
            if (!shape2.contains(shape.getPoint(l)[0], shape.getPoint(l)[1]) && !shape2.hasVertex(shape.getPoint(l)[0], shape.getPoint(l)[1])) {
                return new Shape[] { this.combineSingle(shape, shape2, false, l) };
            }
        }
        return new Shape[] { shape2 };
    }
    
    public Shape combineSingle(final Shape shape, final Shape shape2, final boolean b, final int n) {
        Shape shape3 = shape;
        Shape shape4 = shape2;
        int n2 = n;
        int n3 = 1;
        final Polygon polygon = new Polygon();
        int n4 = 1;
        int n5 = 0;
        float n6 = shape3.getPoint(n2)[0];
        float n7 = shape3.getPoint(n2)[1];
        while (!polygon.hasVertex(n6, n7) || n4 != 0 || shape3 != shape) {
            n4 = 0;
            if (++n5 > this.MAX_POINTS) {
                break;
            }
            polygon.addPoint(n6, n7);
            if (this.listener != null) {
                this.listener.pointUsed(n6, n7);
            }
            final HitResult intersect = this.intersect(shape4, this.getLine(shape3, n6, n7, rationalPoint(shape3, n2 + n3)));
            if (intersect != null) {
                final Line line = intersect.line;
                final Vector2f pt = intersect.pt;
                n6 = pt.x;
                n7 = pt.y;
                if (this.listener != null) {
                    this.listener.pointIntersected(n6, n7);
                }
                if (shape4.hasVertex(n6, n7)) {
                    n2 = shape4.indexOf(pt.x, pt.y);
                    n3 = 1;
                    n6 = pt.x;
                    n7 = pt.y;
                    final Shape shape5 = shape3;
                    shape3 = shape4;
                    shape4 = shape5;
                }
                else {
                    final float n8 = line.getDX() / line.length();
                    final float n9 = line.getDY() / line.length();
                    final float n10 = n8 * this.EDGE_SCALE;
                    final float n11 = n9 * this.EDGE_SCALE;
                    if (shape3.contains(pt.x + n10, pt.y + n11)) {
                        if (b) {
                            if (shape3 == shape2) {
                                n2 = intersect.p2;
                                n3 = -1;
                            }
                            else {
                                n2 = intersect.p1;
                                n3 = 1;
                            }
                        }
                        else if (shape3 == shape) {
                            n2 = intersect.p2;
                            n3 = -1;
                        }
                        else {
                            n2 = intersect.p2;
                            n3 = -1;
                        }
                        final Shape shape6 = shape3;
                        shape3 = shape4;
                        shape4 = shape6;
                    }
                    else if (shape3.contains(pt.x - n10, pt.y - n11)) {
                        if (b) {
                            if (shape3 == shape) {
                                n2 = intersect.p2;
                                n3 = -1;
                            }
                            else {
                                n2 = intersect.p1;
                                n3 = 1;
                            }
                        }
                        else if (shape3 == shape2) {
                            n2 = intersect.p1;
                            n3 = 1;
                        }
                        else {
                            n2 = intersect.p1;
                            n3 = 1;
                        }
                        final Shape shape7 = shape3;
                        shape3 = shape4;
                        shape4 = shape7;
                    }
                    else {
                        if (b) {
                            break;
                        }
                        final int p4 = intersect.p1;
                        n3 = 1;
                        final Shape shape8 = shape3;
                        shape3 = shape4;
                        shape4 = shape8;
                        n2 = rationalPoint(shape3, p4 + n3);
                        n6 = shape3.getPoint(n2)[0];
                        n7 = shape3.getPoint(n2)[1];
                    }
                }
            }
            else {
                n2 = rationalPoint(shape3, n2 + n3);
                n6 = shape3.getPoint(n2)[0];
                n7 = shape3.getPoint(n2)[1];
            }
        }
        polygon.addPoint(n6, n7);
        if (this.listener != null) {
            this.listener.pointUsed(n6, n7);
        }
        return polygon;
    }
    
    public HitResult intersect(final Shape shape, final Line line) {
        float n = Float.MAX_VALUE;
        HitResult hitResult = null;
        for (int i = 0; i < shape.getPointCount(); ++i) {
            final int rationalPoint = rationalPoint(shape, i + 1);
            final Line line2 = this.getLine(shape, i, rationalPoint);
            final Vector2f intersect = line.intersect(line2, true);
            if (intersect != null) {
                final float distance = intersect.distance(line.getStart());
                if (distance < n && distance > this.EPSILON) {
                    hitResult = new HitResult();
                    hitResult.pt = intersect;
                    hitResult.line = line2;
                    hitResult.p1 = i;
                    hitResult.p2 = rationalPoint;
                    n = distance;
                }
            }
        }
        return hitResult;
    }
    
    public static int rationalPoint(final Shape shape, int i) {
        while (i < 0) {
            i += shape.getPointCount();
        }
        while (i >= shape.getPointCount()) {
            i -= shape.getPointCount();
        }
        return i;
    }
    
    public Line getLine(final Shape shape, final int n, final int n2) {
        final float[] point = shape.getPoint(n);
        final float[] point2 = shape.getPoint(n2);
        return new Line(point[0], point[1], point2[0], point2[1]);
    }
    
    public Line getLine(final Shape shape, final float n, final float n2, final int n3) {
        final float[] point = shape.getPoint(n3);
        return new Line(n, n2, point[0], point[1]);
    }
    
    public class HitResult
    {
        public Line line;
        public int p1;
        public int p2;
        public Vector2f pt;
        public GeomUtil this$0;
        
        public HitResult(final GeomUtil this$0) {
            this.this$0 = this$0;
        }
    }
}
