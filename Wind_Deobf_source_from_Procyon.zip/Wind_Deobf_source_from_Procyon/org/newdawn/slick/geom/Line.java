// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

public class Line extends Shape
{
    public Vector2f start;
    public Vector2f end;
    public Vector2f vec;
    public float lenSquared;
    public Vector2f loc;
    public Vector2f v;
    public Vector2f v2;
    public Vector2f proj;
    public Vector2f closest;
    public Vector2f other;
    public boolean outerEdge;
    public boolean innerEdge;
    
    public Line(final float n, final float n2, final boolean b, final boolean b2) {
        this(0.0f, 0.0f, n, n2);
    }
    
    public Line(final float n, final float n2) {
        this(n, n2, true, true);
    }
    
    public Line(final float n, final float n2, final float n3, final float n4) {
        this(new Vector2f(n, n2), new Vector2f(n3, n4));
    }
    
    public Line(final float n, final float n2, final float n3, final float n4, final boolean b) {
        this(new Vector2f(n, n2), new Vector2f(n + n3, n2 + n4));
    }
    
    public Line(final float[] array, final float[] array2) {
        this.loc = new Vector2f(0.0f, 0.0f);
        this.v = new Vector2f(0.0f, 0.0f);
        this.v2 = new Vector2f(0.0f, 0.0f);
        this.proj = new Vector2f(0.0f, 0.0f);
        this.closest = new Vector2f(0.0f, 0.0f);
        this.other = new Vector2f(0.0f, 0.0f);
        this.outerEdge = true;
        this.innerEdge = true;
        this.set(array, array2);
    }
    
    public Line(final Vector2f vector2f, final Vector2f vector2f2) {
        this.loc = new Vector2f(0.0f, 0.0f);
        this.v = new Vector2f(0.0f, 0.0f);
        this.v2 = new Vector2f(0.0f, 0.0f);
        this.proj = new Vector2f(0.0f, 0.0f);
        this.closest = new Vector2f(0.0f, 0.0f);
        this.other = new Vector2f(0.0f, 0.0f);
        this.outerEdge = true;
        this.innerEdge = true;
        this.set(vector2f, vector2f2);
    }
    
    public void set(final float[] array, final float[] array2) {
        this.set(array[0], array[1], array2[0], array2[1]);
    }
    
    public Vector2f getStart() {
        return this.start;
    }
    
    public Vector2f getEnd() {
        return this.end;
    }
    
    public float length() {
        return this.vec.length();
    }
    
    public float lengthSquared() {
        return this.vec.lengthSquared();
    }
    
    public void set(final Vector2f vector2f, final Vector2f vector2f2) {
        super.pointsDirty = true;
        if (this.start == null) {
            this.start = new Vector2f();
        }
        this.start.set(vector2f);
        if (this.end == null) {
            this.end = new Vector2f();
        }
        this.end.set(vector2f2);
        (this.vec = new Vector2f(vector2f2)).sub(vector2f);
        this.lenSquared = this.vec.lengthSquared();
    }
    
    public void set(final float n, final float n2, final float n3, final float n4) {
        super.pointsDirty = true;
        this.start.set(n, n2);
        this.end.set(n3, n4);
        final float n5 = n3 - n;
        final float n6 = n4 - n2;
        this.vec.set(n5, n6);
        this.lenSquared = n5 * n5 + n6 * n6;
    }
    
    public float getDX() {
        return this.end.getX() - this.start.getX();
    }
    
    public float getDY() {
        return this.end.getY() - this.start.getY();
    }
    
    @Override
    public float getX() {
        return this.getX1();
    }
    
    @Override
    public float getY() {
        return this.getY1();
    }
    
    public float getX1() {
        return this.start.getX();
    }
    
    public float getY1() {
        return this.start.getY();
    }
    
    public float getX2() {
        return this.end.getX();
    }
    
    public float getY2() {
        return this.end.getY();
    }
    
    public float distance(final Vector2f vector2f) {
        return (float)Math.sqrt(this.distanceSquared(vector2f));
    }
    
    public boolean on(final Vector2f vector2f) {
        this.getClosestPoint(vector2f, this.closest);
        return vector2f.equals(this.closest);
    }
    
    public float distanceSquared(final Vector2f vector2f) {
        this.getClosestPoint(vector2f, this.closest);
        this.closest.sub(vector2f);
        return this.closest.lengthSquared();
    }
    
    public void getClosestPoint(final Vector2f vector2f, final Vector2f vector2f2) {
        this.loc.set(vector2f);
        this.loc.sub(this.start);
        final float n = this.vec.dot(this.loc) / this.vec.lengthSquared();
        if (n < 0.0f) {
            vector2f2.set(this.start);
            return;
        }
        if (n > 1.0f) {
            vector2f2.set(this.end);
            return;
        }
        vector2f2.x = this.start.getX() + n * this.vec.getX();
        vector2f2.y = this.start.getY() + n * this.vec.getY();
    }
    
    @Override
    public String toString() {
        return "[Line " + this.start + "," + this.end + "]";
    }
    
    public Vector2f intersect(final Line line) {
        return this.intersect(line, false);
    }
    
    public Vector2f intersect(final Line line, final boolean b) {
        final Vector2f vector2f = new Vector2f();
        if (!this.intersect(line, b, vector2f)) {
            return null;
        }
        return vector2f;
    }
    
    public boolean intersect(final Line line, final boolean b, final Vector2f vector2f) {
        final float n = this.end.getX() - this.start.getX();
        final float n2 = line.end.getX() - line.start.getX();
        final float n3 = this.end.getY() - this.start.getY();
        final float n4 = line.end.getY() - line.start.getY();
        final float n5 = n4 * n - n2 * n3;
        if (n5 == 0.0f) {
            return false;
        }
        final float n6 = (n2 * (this.start.getY() - line.start.getY()) - n4 * (this.start.getX() - line.start.getX())) / n5;
        final float n7 = (n * (this.start.getY() - line.start.getY()) - n3 * (this.start.getX() - line.start.getX())) / n5;
        if (b && (n6 < 0.0f || n6 > 1.0f || n7 < 0.0f || n7 > 1.0f)) {
            return false;
        }
        final float n8 = n6;
        vector2f.set(this.start.getX() + n8 * (this.end.getX() - this.start.getX()), this.start.getY() + n8 * (this.end.getY() - this.start.getY()));
        return true;
    }
    
    @Override
    public void createPoints() {
        (this.points = new float[4])[0] = this.getX1();
        this.points[1] = this.getY1();
        this.points[2] = this.getX2();
        this.points[3] = this.getY2();
    }
    
    @Override
    public Shape transform(final Transform transform) {
        final float[] array = new float[4];
        this.createPoints();
        transform.transform(this.points, 0, array, 0, 2);
        return new Line(array[0], array[1], array[2], array[3]);
    }
    
    @Override
    public boolean closed() {
        return false;
    }
    
    @Override
    public boolean intersects(final Shape shape) {
        if (shape instanceof Circle) {
            return shape.intersects(this);
        }
        return super.intersects(shape);
    }
}
