// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class MannTriangulator implements Triangulator
{
    public static double EPSILON;
    public PointBag contour;
    public PointBag holes;
    public PointBag nextFreePointBag;
    public Point nextFreePoint;
    public List triangles;
    
    public MannTriangulator() {
        this.triangles = new ArrayList();
        this.contour = this.getPointBag();
    }
    
    @Override
    public void addPolyPoint(final float n, final float n2) {
        this.addPoint(new Vector2f(n, n2));
    }
    
    public void reset() {
        while (this.holes != null) {
            this.holes = this.freePointBag(this.holes);
        }
        this.contour.clear();
        this.holes = null;
    }
    
    @Override
    public void startHole() {
        final PointBag pointBag = this.getPointBag();
        pointBag.next = this.holes;
        this.holes = pointBag;
    }
    
    public void addPoint(final Vector2f vector2f) {
        if (this.holes == null) {
            this.contour.add(this.getPoint(vector2f));
        }
        else {
            this.holes.add(this.getPoint(vector2f));
        }
    }
    
    public Vector2f[] triangulate(Vector2f[] array) {
        this.contour.computeAngles();
        for (PointBag pointBag = this.holes; pointBag != null; pointBag = pointBag.next) {
            pointBag.computeAngles();
        }
        while (this.holes != null) {
            Point next = this.holes.first;
        Label_0247:
            do {
                if (next.angle <= 0.0) {
                    Point prev = this.contour.first;
                    do {
                        if (next.isInfront(prev) && prev.isInfront(next) && !this.contour.doesIntersectSegment(next.pt, prev.pt)) {
                            PointBag pointBag2 = this.holes;
                            while (!pointBag2.doesIntersectSegment(next.pt, prev.pt)) {
                                if ((pointBag2 = pointBag2.next) == null) {
                                    final Point point = this.getPoint(prev.pt);
                                    prev.insertAfter(point);
                                    final Point point2 = this.getPoint(next.pt);
                                    next.insertBefore(point2);
                                    prev.next = next;
                                    next.prev = prev;
                                    point2.next = point;
                                    point.prev = point2;
                                    prev.computeAngle();
                                    next.computeAngle();
                                    point.computeAngle();
                                    point2.computeAngle();
                                    this.holes.first = null;
                                    break Label_0247;
                                }
                            }
                        }
                    } while ((prev = prev.next) != this.contour.first);
                }
            } while ((next = next.next) != this.holes.first);
            this.holes = this.freePointBag(this.holes);
        }
        final int length = (this.contour.countPoints() - 2) * 3 + 1;
        if (array.length < length) {
            array = (Vector2f[])Array.newInstance(array.getClass().getComponentType(), length);
        }
        int n = 0;
        while (true) {
            Point point3 = this.contour.first;
            if (point3 == null) {
                break;
            }
            if (point3.next == point3.prev) {
                break;
            }
            do {
                if (point3.angle > 0.0) {
                    final Point prev2 = point3.prev;
                    final Point next2 = point3.next;
                    if ((next2.next == prev2 || (prev2.isInfront(next2) && next2.isInfront(prev2))) && !this.contour.doesIntersectSegment(prev2.pt, next2.pt)) {
                        array[n++] = point3.pt;
                        array[n++] = next2.pt;
                        array[n++] = prev2.pt;
                        break;
                    }
                    continue;
                }
            } while ((point3 = point3.next) != this.contour.first);
            final Point prev3 = point3.prev;
            final Point next3 = point3.next;
            this.contour.first = prev3;
            point3.unlink();
            this.freePoint(point3);
            next3.computeAngle();
            prev3.computeAngle();
        }
        array[n] = null;
        this.contour.clear();
        return array;
    }
    
    public PointBag getPointBag() {
        final PointBag nextFreePointBag = this.nextFreePointBag;
        if (nextFreePointBag != null) {
            this.nextFreePointBag = nextFreePointBag.next;
            nextFreePointBag.next = null;
            return nextFreePointBag;
        }
        return new PointBag();
    }
    
    public PointBag freePointBag(final PointBag nextFreePointBag) {
        final PointBag next = nextFreePointBag.next;
        nextFreePointBag.clear();
        nextFreePointBag.next = this.nextFreePointBag;
        this.nextFreePointBag = nextFreePointBag;
        return next;
    }
    
    public Point getPoint(final Vector2f pt) {
        final Point nextFreePoint = this.nextFreePoint;
        if (nextFreePoint != null) {
            this.nextFreePoint = nextFreePoint.next;
            nextFreePoint.next = null;
            nextFreePoint.prev = null;
            nextFreePoint.pt = pt;
            return nextFreePoint;
        }
        return new Point(pt);
    }
    
    public void freePoint(final Point nextFreePoint) {
        nextFreePoint.next = this.nextFreePoint;
        this.nextFreePoint = nextFreePoint;
    }
    
    public void freePoints(final Point nextFreePoint) {
        nextFreePoint.prev.next = this.nextFreePoint;
        nextFreePoint.prev = null;
        this.nextFreePoint = nextFreePoint;
    }
    
    @Override
    public boolean triangulate() {
        final Vector2f[] triangulate = this.triangulate(new Vector2f[0]);
        for (int n = 0; n < triangulate.length && triangulate[n] != null; ++n) {
            this.triangles.add(triangulate[n]);
        }
        return true;
    }
    
    @Override
    public int getTriangleCount() {
        return this.triangles.size() / 3;
    }
    
    @Override
    public float[] getTrianglePoint(final int n, final int n2) {
        final Vector2f vector2f = this.triangles.get(n * 3 + n2);
        return new float[] { vector2f.x, vector2f.y };
    }
    
    public static void access$000(final MannTriangulator mannTriangulator, final Point point) {
        mannTriangulator.freePoints(point);
    }
    
    static {
        MannTriangulator.EPSILON = 0.0;
    }
    
    private static class Point implements Serializable
    {
        public Vector2f pt;
        public Point prev;
        public Point next;
        public double nx;
        public double ny;
        public double angle;
        public double dist;
        
        public Point(final Vector2f pt) {
            this.pt = pt;
        }
        
        public void unlink() {
            this.prev.next = this.next;
            this.next.prev = this.prev;
            this.next = null;
            this.prev = null;
        }
        
        public void insertBefore(final Point point) {
            this.prev.next = point;
            point.prev = this.prev;
            point.next = this;
            this.prev = point;
        }
        
        public void insertAfter(final Point point) {
            this.next.prev = point;
            point.prev = this;
            point.next = this.next;
            this.next = point;
        }
        
        public double hypot(final double n, final double n2) {
            return Math.sqrt(n * n + n2 * n2);
        }
        
        public void computeAngle() {
            if (this.prev.pt.equals(this.pt)) {
                final Vector2f pt = this.pt;
                pt.x += 0.0f;
            }
            final double n = this.pt.x - this.prev.pt.x;
            final double n2 = this.pt.y - this.prev.pt.y;
            final double hypot = this.hypot(n, n2);
            final double nx = n / hypot;
            final double n3 = n2 / hypot;
            if (this.next.pt.equals(this.pt)) {
                final Vector2f pt2 = this.pt;
                pt2.y += 0.0f;
            }
            final double n4 = this.next.pt.x - this.pt.x;
            final double n5 = this.next.pt.y - this.pt.y;
            final double hypot2 = this.hypot(n4, n5);
            final double n6 = n4 / hypot2;
            final double ny = n5 / hypot2;
            final double n7 = -n3;
            final double n8 = nx;
            this.nx = (n7 - ny) * 0.0;
            this.ny = (n8 + n6) * 0.0;
            if (this.nx * this.nx + this.ny * this.ny < 0.0) {
                this.nx = nx;
                this.ny = ny;
                this.angle = 1.0;
                if (nx * n6 + n3 * ny > 0.0) {
                    this.nx = -nx;
                    this.ny = -n3;
                }
            }
            else {
                this.angle = this.nx * n6 + this.ny * ny;
            }
        }
        
        public double getAngle(final Point point) {
            final double n = point.pt.x - this.pt.x;
            final double n2 = point.pt.y - this.pt.y;
            return (this.nx * n + this.ny * n2) / this.hypot(n, n2);
        }
        
        public boolean isConcave() {
            return this.angle < 0.0;
        }
        
        public boolean isInfront(final double n, final double n2) {
            final boolean b = (this.prev.pt.y - this.pt.y) * n + (this.pt.x - this.prev.pt.x) * n2 >= 0.0;
            final boolean b2 = (this.pt.y - this.next.pt.y) * n + (this.next.pt.x - this.pt.x) * n2 >= 0.0;
            return (this.angle < 0.0) ? (b | b2) : (b & b2);
        }
        
        public boolean isInfront(final Point point) {
            return this.isInfront(point.pt.x - this.pt.x, point.pt.y - this.pt.y);
        }
    }
    
    protected class PointBag implements Serializable
    {
        public Point first;
        public PointBag next;
        public MannTriangulator this$0;
        
        public PointBag(final MannTriangulator this$0) {
            this.this$0 = this$0;
        }
        
        public void clear() {
            if (this.first != null) {
                MannTriangulator.access$000(this.this$0, this.first);
                this.first = null;
            }
        }
        
        public void add(final Point prev) {
            if (this.first != null) {
                this.first.insertBefore(prev);
            }
            else {
                this.first = prev;
                prev.next = prev;
                prev.prev = prev;
            }
        }
        
        public void computeAngles() {
            if (this.first == null) {
                return;
            }
            Point point = this.first;
            do {
                point.computeAngle();
            } while ((point = point.next) != this.first);
        }
        
        public boolean doesIntersectSegment(final Vector2f vector2f, final Vector2f vector2f2) {
            final double n = vector2f2.x - vector2f.x;
            final double n2 = vector2f2.y - vector2f.y;
            Point first = this.first;
            while (true) {
                final Point next = first.next;
                if (first.pt != vector2f && next.pt != vector2f && first.pt != vector2f2 && next.pt != vector2f2) {
                    final double n3 = next.pt.x - first.pt.x;
                    final double n4 = next.pt.y - first.pt.y;
                    final double a = n * n4 - n2 * n3;
                    if (Math.abs(a) > 0.0) {
                        final double n5 = first.pt.x - vector2f.x;
                        final double n6 = first.pt.y - vector2f.y;
                        final double n7 = (n4 * n5 - n3 * n6) / a;
                        final double n8 = (n2 * n5 - n * n6) / a;
                        if (n7 >= 0.0 && n7 <= 1.0 && n8 >= 0.0 && n8 <= 1.0) {
                            return true;
                        }
                    }
                }
                if (next == this.first) {
                    return false;
                }
                first = next;
            }
        }
        
        public int countPoints() {
            if (this.first == null) {
                return 0;
            }
            int n = 0;
            Point point = this.first;
            do {
                ++n;
            } while ((point = point.next) != this.first);
            return n;
        }
        
        public boolean contains(final Vector2f vector2f) {
            return this.first != null && (this.first.prev.pt.equals(vector2f) || this.first.pt.equals(vector2f));
        }
    }
}
