// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

import java.util.ArrayList;

public class MorphShape extends Shape
{
    public ArrayList shapes;
    public float offset;
    public Shape current;
    public Shape next;
    
    public MorphShape(final Shape next) {
        (this.shapes = new ArrayList()).add(next);
        this.points = new float[next.points.length];
        this.current = next;
        this.next = next;
    }
    
    public void addShape(final Shape e) {
        if (e.points.length != this.points.length) {
            throw new RuntimeException("Attempt to morph between two shapes with different vertex counts");
        }
        final Shape e2 = this.shapes.get(this.shapes.size() - 1);
        if (this.equalShapes(e2, e)) {
            this.shapes.add(e2);
        }
        else {
            this.shapes.add(e);
        }
        if (this.shapes.size() == 2) {
            this.next = this.shapes.get(1);
        }
    }
    
    public boolean equalShapes(final Shape shape, final Shape shape2) {
        shape.checkPoints();
        shape2.checkPoints();
        for (int i = 0; i < shape.points.length; ++i) {
            if (shape.points[i] != shape2.points[i]) {
                return false;
            }
        }
        return true;
    }
    
    public void setMorphTime(final float n) {
        final int n2 = (int)n;
        this.setFrame(this.rational(n2), this.rational(n2 + 1), n - n2);
    }
    
    public void updateMorphTime(final float n) {
        this.offset += n;
        if (this.offset < 0.0f) {
            int index = this.shapes.indexOf(this.current);
            if (index < 0) {
                index = this.shapes.size() - 1;
            }
            this.setFrame(index, this.rational(index + 1), this.offset);
            ++this.offset;
        }
        else if (this.offset > 1.0f) {
            int index2 = this.shapes.indexOf(this.next);
            if (index2 < 1) {
                index2 = 0;
            }
            this.setFrame(index2, this.rational(index2 + 1), this.offset);
            --this.offset;
        }
        else {
            this.pointsDirty = true;
        }
    }
    
    public void setExternalFrame(final Shape current) {
        this.current = current;
        this.next = this.shapes.get(0);
        this.offset = 0.0f;
    }
    
    public int rational(int i) {
        while (i >= this.shapes.size()) {
            i -= this.shapes.size();
        }
        while (i < 0) {
            i += this.shapes.size();
        }
        return i;
    }
    
    public void setFrame(final int index, final int index2, final float offset) {
        this.current = this.shapes.get(index);
        this.next = this.shapes.get(index2);
        this.offset = offset;
        this.pointsDirty = true;
    }
    
    @Override
    public void createPoints() {
        if (this.current == this.next) {
            System.arraycopy(this.current.points, 0, this.points, 0, this.points.length);
            return;
        }
        final float[] points = this.current.points;
        final float[] points2 = this.next.points;
        for (int i = 0; i < this.points.length; ++i) {
            this.points[i] = points[i] * (1.0f - this.offset);
            final float[] points3 = this.points;
            final int n = i;
            points3[n] += points2[i] * this.offset;
        }
    }
    
    @Override
    public Shape transform(final Transform transform) {
        this.createPoints();
        return new Polygon(this.points);
    }
}
