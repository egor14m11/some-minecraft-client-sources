// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

public class OverTriangulator implements Triangulator
{
    public float[][] triangles;
    
    public OverTriangulator(final Triangulator triangulator) {
        this.triangles = new float[triangulator.getTriangleCount() * 6 * 3][2];
        int n = 0;
        for (int i = 0; i < triangulator.getTriangleCount(); ++i) {
            float n2 = 0.0f;
            float n3 = 0.0f;
            for (int j = 0; j < 3; ++j) {
                final float[] trianglePoint = triangulator.getTrianglePoint(i, j);
                n2 += trianglePoint[0];
                n3 += trianglePoint[1];
            }
            final float n4 = n2 / 3.0f;
            final float n5 = n3 / 3.0f;
            for (int k = 0; k < 3; ++k) {
                int n6 = k + 1;
                if (n6 > 2) {
                    n6 = 0;
                }
                final float[] trianglePoint2 = triangulator.getTrianglePoint(i, k);
                final float[] trianglePoint3 = triangulator.getTrianglePoint(i, n6);
                trianglePoint2[0] = (trianglePoint2[0] + trianglePoint3[0]) / 2.0f;
                trianglePoint2[1] = (trianglePoint2[1] + trianglePoint3[1]) / 2.0f;
                this.triangles[n * 3 + 0][0] = n4;
                this.triangles[n * 3 + 0][1] = n5;
                this.triangles[n * 3 + 1][0] = trianglePoint2[0];
                this.triangles[n * 3 + 1][1] = trianglePoint2[1];
                this.triangles[n * 3 + 2][0] = trianglePoint3[0];
                this.triangles[n * 3 + 2][1] = trianglePoint3[1];
                ++n;
            }
            for (int l = 0; l < 3; ++l) {
                int n7 = l + 1;
                if (n7 > 2) {
                    n7 = 0;
                }
                final float[] trianglePoint4 = triangulator.getTrianglePoint(i, l);
                final float[] trianglePoint5 = triangulator.getTrianglePoint(i, n7);
                trianglePoint5[0] = (trianglePoint4[0] + trianglePoint5[0]) / 2.0f;
                trianglePoint5[1] = (trianglePoint4[1] + trianglePoint5[1]) / 2.0f;
                this.triangles[n * 3 + 0][0] = n4;
                this.triangles[n * 3 + 0][1] = n5;
                this.triangles[n * 3 + 1][0] = trianglePoint4[0];
                this.triangles[n * 3 + 1][1] = trianglePoint4[1];
                this.triangles[n * 3 + 2][0] = trianglePoint5[0];
                this.triangles[n * 3 + 2][1] = trianglePoint5[1];
                ++n;
            }
        }
    }
    
    @Override
    public void addPolyPoint(final float n, final float n2) {
    }
    
    @Override
    public int getTriangleCount() {
        return this.triangles.length / 3;
    }
    
    @Override
    public float[] getTrianglePoint(final int n, final int n2) {
        final float[] array = this.triangles[n * 3 + n2];
        return new float[] { array[0], array[1] };
    }
    
    @Override
    public void startHole() {
    }
    
    @Override
    public boolean triangulate() {
        return true;
    }
}
