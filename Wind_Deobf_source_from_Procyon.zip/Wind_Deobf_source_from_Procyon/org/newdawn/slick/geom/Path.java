// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

import java.util.ArrayList;

public class Path extends Shape
{
    public ArrayList localPoints;
    public float cx;
    public float cy;
    public boolean closed;
    public ArrayList holes;
    public ArrayList hole;
    
    public Path(final float cx, final float cy) {
        this.localPoints = new ArrayList();
        this.holes = new ArrayList();
        this.localPoints.add(new float[] { cx, cy });
        this.cx = cx;
        this.cy = cy;
        this.pointsDirty = true;
    }
    
    public void startHole(final float n, final float n2) {
        this.hole = new ArrayList();
        this.holes.add(this.hole);
    }
    
    public void lineTo(final float cx, final float cy) {
        if (this.hole != null) {
            this.hole.add(new float[] { cx, cy });
        }
        else {
            this.localPoints.add(new float[] { cx, cy });
        }
        this.cx = cx;
        this.cy = cy;
        this.pointsDirty = true;
    }
    
    public void close() {
        this.closed = true;
    }
    
    public void curveTo(final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.curveTo(n, n2, n3, n4, n5, n6, 10);
    }
    
    public void curveTo(final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final int n7) {
        if (this.cx == n && this.cy == n2) {
            return;
        }
        final Curve curve = new Curve(new Vector2f(this.cx, this.cy), new Vector2f(n3, n4), new Vector2f(n5, n6), new Vector2f(n, n2));
        final float n8 = 1.0f / n7;
        for (int i = 1; i < n7 + 1; ++i) {
            final Vector2f point = curve.pointAt(i * n8);
            if (this.hole != null) {
                this.hole.add(new float[] { point.x, point.y });
            }
            else {
                this.localPoints.add(new float[] { point.x, point.y });
            }
            this.cx = point.x;
            this.cy = point.y;
        }
        this.pointsDirty = true;
    }
    
    @Override
    public void createPoints() {
        this.points = new float[this.localPoints.size() * 2];
        for (int i = 0; i < this.localPoints.size(); ++i) {
            final float[] array = this.localPoints.get(i);
            this.points[i * 2] = array[0];
            this.points[i * 2 + 1] = array[1];
        }
    }
    
    @Override
    public Shape transform(final Transform transform) {
        final Path path = new Path(this.cx, this.cy);
        path.localPoints = this.transform(this.localPoints, transform);
        for (int i = 0; i < this.holes.size(); ++i) {
            path.holes.add(this.transform((ArrayList)this.holes.get(i), transform));
        }
        path.closed = this.closed;
        return path;
    }
    
    public ArrayList transform(final ArrayList list, final Transform transform) {
        final float[] array = new float[list.size() * 2];
        final float[] array2 = new float[list.size() * 2];
        for (int i = 0; i < list.size(); ++i) {
            array[i * 2] = ((float[])list.get(i))[0];
            array[i * 2 + 1] = ((float[])list.get(i))[1];
        }
        transform.transform(array, 0, array2, 0, list.size());
        final ArrayList<float[]> list2 = new ArrayList<float[]>();
        for (int j = 0; j < list.size(); ++j) {
            list2.add(new float[] { array2[j * 2], array2[j * 2 + 1] });
        }
        return list2;
    }
    
    @Override
    public boolean closed() {
        return this.closed;
    }
}
