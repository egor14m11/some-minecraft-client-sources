// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

import java.util.ArrayList;

public class Polygon extends Shape
{
    public boolean allowDups;
    public boolean closed;
    
    public Polygon(final float[] array) {
        this.allowDups = false;
        this.closed = true;
        final int length = array.length;
        this.points = new float[length];
        this.maxX = -1.4E-45f;
        this.maxY = -1.4E-45f;
        this.minX = Float.MAX_VALUE;
        this.minY = Float.MAX_VALUE;
        this.x = Float.MAX_VALUE;
        this.y = Float.MAX_VALUE;
        for (int i = 0; i < length; ++i) {
            this.points[i] = array[i];
            if (i % 2 == 0) {
                if (array[i] > this.maxX) {
                    this.maxX = array[i];
                }
                if (array[i] < this.minX) {
                    this.minX = array[i];
                }
                if (array[i] < this.x) {
                    this.x = array[i];
                }
            }
            else {
                if (array[i] > this.maxY) {
                    this.maxY = array[i];
                }
                if (array[i] < this.minY) {
                    this.minY = array[i];
                }
                if (array[i] < this.y) {
                    this.y = array[i];
                }
            }
        }
        this.findCenter();
        this.calculateRadius();
        this.pointsDirty = true;
    }
    
    public Polygon() {
        this.allowDups = false;
        this.closed = true;
        this.points = new float[0];
        this.maxX = -1.4E-45f;
        this.maxY = -1.4E-45f;
        this.minX = Float.MAX_VALUE;
        this.minY = Float.MAX_VALUE;
    }
    
    public void setAllowDuplicatePoints(final boolean allowDups) {
        this.allowDups = allowDups;
    }
    
    public void addPoint(final float minX, final float minY) {
        if (this.hasVertex(minX, minY) && !this.allowDups) {
            return;
        }
        final ArrayList<Float> list = new ArrayList<Float>();
        for (int i = 0; i < this.points.length; ++i) {
            list.add(new Float(this.points[i]));
        }
        list.add(new Float(minX));
        list.add(new Float(minY));
        final int size = list.size();
        this.points = new float[size];
        for (int j = 0; j < size; ++j) {
            this.points[j] = list.get(j);
        }
        if (minX > this.maxX) {
            this.maxX = minX;
        }
        if (minY > this.maxY) {
            this.maxY = minY;
        }
        if (minX < this.minX) {
            this.minX = minX;
        }
        if (minY < this.minY) {
            this.minY = minY;
        }
        this.findCenter();
        this.calculateRadius();
        this.pointsDirty = true;
    }
    
    @Override
    public Shape transform(final Transform transform) {
        this.checkPoints();
        final Polygon polygon = new Polygon();
        final float[] points = new float[this.points.length];
        transform.transform(this.points, 0, points, 0, this.points.length / 2);
        polygon.points = points;
        polygon.findCenter();
        polygon.closed = this.closed;
        return polygon;
    }
    
    @Override
    public void setX(final float x) {
        super.setX(x);
        this.pointsDirty = false;
    }
    
    @Override
    public void setY(final float y) {
        super.setY(y);
        this.pointsDirty = false;
    }
    
    @Override
    public void createPoints() {
    }
    
    @Override
    public boolean closed() {
        return this.closed;
    }
    
    public void setClosed(final boolean closed) {
        this.closed = closed;
    }
    
    public Polygon copy() {
        final float[] array = new float[this.points.length];
        System.arraycopy(this.points, 0, array, 0, array.length);
        return new Polygon(array);
    }
}
