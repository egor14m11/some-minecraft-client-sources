// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.Image;
import org.newdawn.slick.ShapeFill;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureImpl;
import org.newdawn.slick.opengl.renderer.LineStripRenderer;
import org.newdawn.slick.opengl.renderer.SGL;

public class ShapeRenderer
{
    public static SGL GL;
    public static LineStripRenderer LSR;
    
    public static void draw(final Shape shape) {
        final Texture lastBind = TextureImpl.getLastBind();
        TextureImpl.bindNone();
        final float[] points = shape.getPoints();
        ShapeRenderer.LSR.start();
        for (int i = 0; i < points.length; i += 2) {
            ShapeRenderer.LSR.vertex(points[i], points[i + 1]);
        }
        if (shape.closed()) {
            ShapeRenderer.LSR.vertex(points[0], points[1]);
        }
        ShapeRenderer.LSR.end();
        if (lastBind == null) {
            TextureImpl.bindNone();
        }
        else {
            lastBind.bind();
        }
    }
    
    public static void draw(final Shape shape, final ShapeFill shapeFill) {
        final float[] points = shape.getPoints();
        final Texture lastBind = TextureImpl.getLastBind();
        TextureImpl.bindNone();
        shape.getCenter();
        ShapeRenderer.GL.glBegin(3);
        for (int i = 0; i < points.length; i += 2) {
            shapeFill.colorAt(shape, points[i], points[i + 1]).bind();
            final Vector2f offset = shapeFill.getOffsetAt(shape, points[i], points[i + 1]);
            ShapeRenderer.GL.glVertex2f(points[i] + offset.x, points[i + 1] + offset.y);
        }
        if (shape.closed()) {
            shapeFill.colorAt(shape, points[0], points[1]).bind();
            final Vector2f offset2 = shapeFill.getOffsetAt(shape, points[0], points[1]);
            ShapeRenderer.GL.glVertex2f(points[0] + offset2.x, points[1] + offset2.y);
        }
        ShapeRenderer.GL.glEnd();
        if (lastBind == null) {
            TextureImpl.bindNone();
        }
        else {
            lastBind.bind();
        }
    }
    
    public static boolean validFill(final Shape shape) {
        return shape.getTriangles() != null && shape.getTriangles().getTriangleCount() != 0;
    }
    
    public static void fill(final Shape shape) {
        if (!validFill(shape)) {
            return;
        }
        final Texture lastBind = TextureImpl.getLastBind();
        TextureImpl.bindNone();
        fill(shape, new PointCallback() {
            @Override
            public float[] preRenderPoint(final Shape shape, final float n, final float n2) {
                return null;
            }
        });
        if (lastBind == null) {
            TextureImpl.bindNone();
        }
        else {
            lastBind.bind();
        }
    }
    
    public static void fill(final Shape shape, final PointCallback pointCallback) {
        final Triangulator triangles = shape.getTriangles();
        ShapeRenderer.GL.glBegin(4);
        for (int i = 0; i < triangles.getTriangleCount(); ++i) {
            for (int j = 0; j < 3; ++j) {
                final float[] trianglePoint = triangles.getTrianglePoint(i, j);
                final float[] preRenderPoint = pointCallback.preRenderPoint(shape, trianglePoint[0], trianglePoint[1]);
                if (preRenderPoint == null) {
                    ShapeRenderer.GL.glVertex2f(trianglePoint[0], trianglePoint[1]);
                }
                else {
                    ShapeRenderer.GL.glVertex2f(preRenderPoint[0], preRenderPoint[1]);
                }
            }
        }
        ShapeRenderer.GL.glEnd();
    }
    
    public static void texture(final Shape shape, final Image image) {
        texture(shape, image, 0.0f, 0.0f);
    }
    
    public static void textureFit(final Shape shape, final Image image) {
        textureFit(shape, image, 1.0f, 1.0f);
    }
    
    public static void texture(final Shape shape, final Image image, final float n, final float n2) {
        if (!validFill(shape)) {
            return;
        }
        final Texture lastBind = TextureImpl.getLastBind();
        image.getTexture().bind();
        fill(shape, new PointCallback(n, n2, image) {
            public float val$scaleX;
            public float val$scaleY;
            public Image val$image;
            
            @Override
            public float[] preRenderPoint(final Shape shape, final float n, final float n2) {
                ShapeRenderer.access$000().glTexCoord2f(this.val$image.getTextureOffsetX() + this.val$image.getTextureWidth() * (n * this.val$scaleX), this.val$image.getTextureOffsetY() + this.val$image.getTextureHeight() * (n2 * this.val$scaleY));
                return null;
            }
        });
        shape.getPoints();
        if (lastBind == null) {
            TextureImpl.bindNone();
        }
        else {
            lastBind.bind();
        }
    }
    
    public static void textureFit(final Shape shape, final Image image, final float n, final float n2) {
        if (!validFill(shape)) {
            return;
        }
        shape.getPoints();
        final Texture lastBind = TextureImpl.getLastBind();
        image.getTexture().bind();
        final float x = shape.getX();
        final float y = shape.getY();
        final float n3 = shape.getMaxX() - x;
        final float n4 = shape.getMaxY() - y;
        fill(shape, new PointCallback(n, n2, image) {
            public float val$scaleX;
            public float val$scaleY;
            public Image val$image;
            
            @Override
            public float[] preRenderPoint(final Shape shape, float n, float n2) {
                n -= shape.getMinX();
                n2 -= shape.getMinY();
                n /= shape.getMaxX() - shape.getMinX();
                n2 /= shape.getMaxY() - shape.getMinY();
                ShapeRenderer.access$000().glTexCoord2f(this.val$image.getTextureOffsetX() + this.val$image.getTextureWidth() * (n * this.val$scaleX), this.val$image.getTextureOffsetY() + this.val$image.getTextureHeight() * (n2 * this.val$scaleY));
                return null;
            }
        });
        if (lastBind == null) {
            TextureImpl.bindNone();
        }
        else {
            lastBind.bind();
        }
    }
    
    public static void fill(final Shape shape, final ShapeFill shapeFill) {
        if (!validFill(shape)) {
            return;
        }
        final Texture lastBind = TextureImpl.getLastBind();
        TextureImpl.bindNone();
        shape.getCenter();
        fill(shape, new PointCallback(shapeFill) {
            public ShapeFill val$fill;
            
            @Override
            public float[] preRenderPoint(final Shape shape, final float n, final float n2) {
                this.val$fill.colorAt(shape, n, n2).bind();
                final Vector2f offset = this.val$fill.getOffsetAt(shape, n, n2);
                return new float[] { offset.x + n, offset.y + n2 };
            }
        });
        if (lastBind == null) {
            TextureImpl.bindNone();
        }
        else {
            lastBind.bind();
        }
    }
    
    public static void texture(final Shape shape, final Image image, final float n, final float n2, final ShapeFill shapeFill) {
        if (!validFill(shape)) {
            return;
        }
        final Texture lastBind = TextureImpl.getLastBind();
        image.getTexture().bind();
        fill(shape, new PointCallback(shapeFill, shape.getCenter(), n, n2, image) {
            public ShapeFill val$fill;
            public float[] val$center;
            public float val$scaleX;
            public float val$scaleY;
            public Image val$image;
            
            @Override
            public float[] preRenderPoint(final Shape shape, float n, float n2) {
                this.val$fill.colorAt(shape, n - this.val$center[0], n2 - this.val$center[1]).bind();
                final Vector2f offset = this.val$fill.getOffsetAt(shape, n, n2);
                n += offset.x;
                n2 += offset.y;
                ShapeRenderer.access$000().glTexCoord2f(this.val$image.getTextureOffsetX() + this.val$image.getTextureWidth() * (n * this.val$scaleX), this.val$image.getTextureOffsetY() + this.val$image.getTextureHeight() * (n2 * this.val$scaleY));
                return new float[] { offset.x + n, offset.y + n2 };
            }
        });
        if (lastBind == null) {
            TextureImpl.bindNone();
        }
        else {
            lastBind.bind();
        }
    }
    
    public static void texture(final Shape shape, final Image image, final TexCoordGenerator texCoordGenerator) {
        final Texture lastBind = TextureImpl.getLastBind();
        image.getTexture().bind();
        shape.getCenter();
        fill(shape, new PointCallback(texCoordGenerator) {
            public TexCoordGenerator val$gen;
            
            @Override
            public float[] preRenderPoint(final Shape shape, final float n, final float n2) {
                final Vector2f coord = this.val$gen.getCoordFor(n, n2);
                ShapeRenderer.access$000().glTexCoord2f(coord.x, coord.y);
                return new float[] { n, n2 };
            }
        });
        if (lastBind == null) {
            TextureImpl.bindNone();
        }
        else {
            lastBind.bind();
        }
    }
    
    public static SGL access$000() {
        return ShapeRenderer.GL;
    }
    
    static {
        ShapeRenderer.GL = Renderer.get();
        ShapeRenderer.LSR = Renderer.getLineStripRenderer();
    }
    
    private interface PointCallback
    {
        float[] preRenderPoint(final Shape p0, final float p1, final float p2);
    }
}
