// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

public interface TexCoordGenerator
{
    Vector2f getCoordFor(final float p0, final float p1);
}
