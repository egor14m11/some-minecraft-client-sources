// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.geom;

import org.newdawn.slick.util.FastTrig;
import java.io.Serializable;

public strictfp class Vector2f implements Serializable
{
    public static long serialVersionUID;
    public float x;
    public float y;
    
    public Vector2f() {
    }
    
    public Vector2f(final float[] array) {
        this.x = array[0];
        this.y = array[1];
    }
    
    public Vector2f(final double theta) {
        this.x = 1.0f;
        this.y = 0.0f;
        this.setTheta(theta);
    }
    
    public strictfp void setTheta(double n) {
        if (n < -360.0 || n > 360.0) {
            n %= 360.0;
        }
        if (n < 0.0) {
            n += 360.0;
        }
        double theta = this.getTheta();
        if (n < -360.0 || n > 360.0) {
            theta %= 360.0;
        }
        if (n < 0.0) {}
        final float length = this.length();
        this.x = length * (float)FastTrig.cos(StrictMath.toRadians(n));
        this.y = length * (float)FastTrig.sin(StrictMath.toRadians(n));
    }
    
    public strictfp Vector2f add(final double n) {
        this.setTheta(this.getTheta() + n);
        return this;
    }
    
    public strictfp Vector2f sub(final double n) {
        this.setTheta(this.getTheta() - n);
        return this;
    }
    
    public strictfp double getTheta() {
        double degrees = StrictMath.toDegrees(StrictMath.atan2(this.y, this.x));
        if (degrees < -360.0 || degrees > 360.0) {
            degrees %= 360.0;
        }
        if (degrees < 0.0) {
            degrees += 360.0;
        }
        return degrees;
    }
    
    public strictfp float getX() {
        return this.x;
    }
    
    public strictfp float getY() {
        return this.y;
    }
    
    public Vector2f(final Vector2f vector2f) {
        this(vector2f.getX(), vector2f.getY());
    }
    
    public Vector2f(final float x, final float y) {
        this.x = x;
        this.y = y;
    }
    
    public strictfp void set(final Vector2f vector2f) {
        this.set(vector2f.getX(), vector2f.getY());
    }
    
    public strictfp float dot(final Vector2f vector2f) {
        return this.x * vector2f.getX() + this.y * vector2f.getY();
    }
    
    public strictfp Vector2f set(final float x, final float y) {
        this.x = x;
        this.y = y;
        return this;
    }
    
    public strictfp Vector2f getPerpendicular() {
        return new Vector2f(-this.y, this.x);
    }
    
    public strictfp Vector2f set(final float[] array) {
        return this.set(array[0], array[1]);
    }
    
    public strictfp Vector2f negate() {
        return new Vector2f(-this.x, -this.y);
    }
    
    public strictfp Vector2f negateLocal() {
        this.x = -this.x;
        this.y = -this.y;
        return this;
    }
    
    public strictfp Vector2f add(final Vector2f vector2f) {
        this.x += vector2f.getX();
        this.y += vector2f.getY();
        return this;
    }
    
    public strictfp Vector2f sub(final Vector2f vector2f) {
        this.x -= vector2f.getX();
        this.y -= vector2f.getY();
        return this;
    }
    
    public strictfp Vector2f scale(final float n) {
        this.x *= n;
        this.y *= n;
        return this;
    }
    
    public strictfp Vector2f normalise() {
        final float length = this.length();
        if (length == 0.0f) {
            return this;
        }
        this.x /= length;
        this.y /= length;
        return this;
    }
    
    public strictfp Vector2f getNormal() {
        final Vector2f copy = this.copy();
        copy.normalise();
        return copy;
    }
    
    public strictfp float lengthSquared() {
        return this.x * this.x + this.y * this.y;
    }
    
    public strictfp float length() {
        return (float)Math.sqrt(this.lengthSquared());
    }
    
    public strictfp void projectOntoUnit(final Vector2f vector2f, final Vector2f vector2f2) {
        final float dot = vector2f.dot(this);
        vector2f2.x = dot * vector2f.getX();
        vector2f2.y = dot * vector2f.getY();
    }
    
    public strictfp Vector2f copy() {
        return new Vector2f(this.x, this.y);
    }
    
    @Override
    public strictfp String toString() {
        return "[Vector2f " + this.x + "," + this.y + " (" + this.length() + ")]";
    }
    
    public strictfp float distance(final Vector2f vector2f) {
        return (float)Math.sqrt(this.distanceSquared(vector2f));
    }
    
    public strictfp float distanceSquared(final Vector2f vector2f) {
        final float n = vector2f.getX() - this.getX();
        final float n2 = vector2f.getY() - this.getY();
        return n * n + n2 * n2;
    }
    
    @Override
    public strictfp int hashCode() {
        return 997 * (int)this.x ^ 991 * (int)this.y;
    }
    
    @Override
    public strictfp boolean equals(final Object o) {
        if (o instanceof Vector2f) {
            final Vector2f vector2f = (Vector2f)o;
            return vector2f.x == this.x && vector2f.y == this.y;
        }
        return false;
    }
    
    static {
        Vector2f.serialVersionUID = ((long)172320891 ^ 0xA511A65L);
    }
}
