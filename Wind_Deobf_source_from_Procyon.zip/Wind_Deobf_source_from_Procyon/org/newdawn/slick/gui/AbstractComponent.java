// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.gui;

import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Graphics;
import java.util.Iterator;
import org.newdawn.slick.InputListener;
import java.util.HashSet;
import org.newdawn.slick.Input;
import java.util.Set;
import org.newdawn.slick.util.InputAdapter;

public abstract class AbstractComponent extends InputAdapter
{
    public static AbstractComponent currentFocus;
    public GUIContext container;
    public Set listeners;
    public boolean focus;
    public Input input;
    
    public AbstractComponent(final GUIContext container) {
        this.focus = false;
        this.container = container;
        this.listeners = new HashSet();
        (this.input = container.getInput()).addPrimaryListener(this);
        this.setLocation(0, 0);
    }
    
    public void addListener(final ComponentListener componentListener) {
        this.listeners.add(componentListener);
    }
    
    public void removeListener(final ComponentListener componentListener) {
        this.listeners.remove(componentListener);
    }
    
    public void notifyListeners() {
        final Iterator<ComponentListener> iterator = this.listeners.iterator();
        while (iterator.hasNext()) {
            iterator.next().componentActivated(this);
        }
    }
    
    public abstract void render(final GUIContext p0, final Graphics p1) throws SlickException;
    
    public abstract void setLocation(final int p0, final int p1);
    
    public abstract int getX();
    
    public abstract int getY();
    
    public abstract int getWidth();
    
    public abstract int getHeight();
    
    public void setFocus(final boolean focus) {
        if (focus) {
            if (AbstractComponent.currentFocus != null) {
                AbstractComponent.currentFocus.setFocus(false);
            }
            AbstractComponent.currentFocus = this;
        }
        else if (AbstractComponent.currentFocus == this) {
            AbstractComponent.currentFocus = null;
        }
        this.focus = focus;
    }
    
    public boolean hasFocus() {
        return this.focus;
    }
    
    public void consumeEvent() {
        this.input.consumeEvent();
    }
    
    @Override
    public void mouseReleased(final int n, final int n2, final int n3) {
        this.setFocus(Rectangle.contains((float)n2, (float)n3, (float)this.getX(), (float)this.getY(), (float)this.getWidth(), (float)this.getHeight()));
    }
    
    static {
        AbstractComponent.currentFocus = null;
    }
}
