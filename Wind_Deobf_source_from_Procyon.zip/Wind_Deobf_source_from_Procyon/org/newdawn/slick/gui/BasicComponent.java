// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.gui;

import org.newdawn.slick.SlickException;
import org.newdawn.slick.Graphics;

public abstract class BasicComponent extends AbstractComponent
{
    public int x;
    public int y;
    public int width;
    public int height;
    
    public BasicComponent(final GUIContext guiContext) {
        super(guiContext);
    }
    
    @Override
    public int getHeight() {
        return this.height;
    }
    
    @Override
    public int getWidth() {
        return this.width;
    }
    
    @Override
    public int getX() {
        return this.x;
    }
    
    @Override
    public int getY() {
        return this.y;
    }
    
    public abstract void renderImpl(final GUIContext p0, final Graphics p1);
    
    @Override
    public void render(final GUIContext guiContext, final Graphics graphics) throws SlickException {
        this.renderImpl(guiContext, graphics);
    }
    
    @Override
    public void setLocation(final int x, final int y) {
        this.x = x;
        this.y = y;
    }
}
