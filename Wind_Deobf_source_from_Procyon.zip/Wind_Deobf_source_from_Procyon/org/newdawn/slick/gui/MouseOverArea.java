// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.gui;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.Sound;
import org.newdawn.slick.Color;
import org.newdawn.slick.Image;

public class MouseOverArea extends AbstractComponent
{
    public static int NORMAL;
    public static int MOUSE_DOWN;
    public static int MOUSE_OVER;
    public Image normalImage;
    public Image mouseOverImage;
    public Image mouseDownImage;
    public Color normalColor;
    public Color mouseOverColor;
    public Color mouseDownColor;
    public Sound mouseOverSound;
    public Sound mouseDownSound;
    public Shape area;
    public Image currentImage;
    public Color currentColor;
    public boolean over;
    public boolean mouseDown;
    public int state;
    public boolean mouseUp;
    
    public MouseOverArea(final GUIContext guiContext, final Image image, final int n, final int n2, final ComponentListener componentListener) {
        this(guiContext, image, n, n2, image.getWidth(), image.getHeight());
        this.addListener(componentListener);
    }
    
    public MouseOverArea(final GUIContext guiContext, final Image image, final int n, final int n2) {
        this(guiContext, image, n, n2, image.getWidth(), image.getHeight());
    }
    
    public MouseOverArea(final GUIContext guiContext, final Image image, final int n, final int n2, final int n3, final int n4, final ComponentListener componentListener) {
        this(guiContext, image, n, n2, n3, n4);
        this.addListener(componentListener);
    }
    
    public MouseOverArea(final GUIContext guiContext, final Image image, final int n, final int n2, final int n3, final int n4) {
        this(guiContext, image, new Rectangle((float)n, (float)n2, (float)n3, (float)n4));
    }
    
    public MouseOverArea(final GUIContext guiContext, final Image image, final Shape area) {
        super(guiContext);
        this.normalColor = Color.white;
        this.mouseOverColor = Color.white;
        this.mouseDownColor = Color.white;
        this.state = 1;
        this.area = area;
        this.normalImage = image;
        this.currentImage = image;
        this.mouseOverImage = image;
        this.mouseDownImage = image;
        this.currentColor = this.normalColor;
        this.state = 1;
        final Input input = guiContext.getInput();
        this.over = this.area.contains((float)input.getMouseX(), (float)input.getMouseY());
        this.mouseDown = input.isMouseButtonDown(0);
        this.updateImage();
    }
    
    public void setLocation(final float x, final float y) {
        if (this.area != null) {
            this.area.setX(x);
            this.area.setY(y);
        }
    }
    
    public void setX(final float x) {
        this.area.setX(x);
    }
    
    public void setY(final float y) {
        this.area.setY(y);
    }
    
    @Override
    public int getX() {
        return (int)this.area.getX();
    }
    
    @Override
    public int getY() {
        return (int)this.area.getY();
    }
    
    public void setNormalColor(final Color normalColor) {
        this.normalColor = normalColor;
    }
    
    public void setMouseOverColor(final Color mouseOverColor) {
        this.mouseOverColor = mouseOverColor;
    }
    
    public void setMouseDownColor(final Color mouseDownColor) {
        this.mouseDownColor = mouseDownColor;
    }
    
    public void setNormalImage(final Image normalImage) {
        this.normalImage = normalImage;
    }
    
    public void setMouseOverImage(final Image mouseOverImage) {
        this.mouseOverImage = mouseOverImage;
    }
    
    public void setMouseDownImage(final Image mouseDownImage) {
        this.mouseDownImage = mouseDownImage;
    }
    
    @Override
    public void render(final GUIContext guiContext, final Graphics graphics) {
        if (this.currentImage != null) {
            this.currentImage.draw((float)(int)(this.area.getX() + (this.getWidth() - this.currentImage.getWidth()) / 2), (float)(int)(this.area.getY() + (this.getHeight() - this.currentImage.getHeight()) / 2), this.currentColor);
        }
        else {
            graphics.setColor(this.currentColor);
            graphics.fill(this.area);
        }
        this.updateImage();
    }
    
    public void updateImage() {
        if (!this.over) {
            this.currentImage = this.normalImage;
            this.currentColor = this.normalColor;
            this.state = 1;
            this.mouseUp = false;
        }
        else {
            if (this.mouseDown) {
                if (this.state != 2 && this.mouseUp) {
                    if (this.mouseDownSound != null) {
                        this.mouseDownSound.play();
                    }
                    this.currentImage = this.mouseDownImage;
                    this.currentColor = this.mouseDownColor;
                    this.state = 2;
                    this.notifyListeners();
                    this.mouseUp = false;
                }
                return;
            }
            this.mouseUp = true;
            if (this.state != 3) {
                if (this.mouseOverSound != null) {
                    this.mouseOverSound.play();
                }
                this.currentImage = this.mouseOverImage;
                this.currentColor = this.mouseOverColor;
                this.state = 3;
            }
        }
        this.mouseDown = false;
        this.state = 1;
    }
    
    public void setMouseOverSound(final Sound mouseOverSound) {
        this.mouseOverSound = mouseOverSound;
    }
    
    public void setMouseDownSound(final Sound mouseDownSound) {
        this.mouseDownSound = mouseDownSound;
    }
    
    @Override
    public void mouseMoved(final int n, final int n2, final int n3, final int n4) {
        this.over = this.area.contains((float)n3, (float)n4);
    }
    
    @Override
    public void mouseDragged(final int n, final int n2, final int n3, final int n4) {
        this.mouseMoved(n, n2, n3, n4);
    }
    
    @Override
    public void mousePressed(final int n, final int n2, final int n3) {
        this.over = this.area.contains((float)n2, (float)n3);
        if (n == 0) {
            this.mouseDown = true;
        }
    }
    
    @Override
    public void mouseReleased(final int n, final int n2, final int n3) {
        this.over = this.area.contains((float)n2, (float)n3);
        if (n == 0) {
            this.mouseDown = false;
        }
    }
    
    @Override
    public int getHeight() {
        return (int)(this.area.getMaxY() - this.area.getY());
    }
    
    @Override
    public int getWidth() {
        return (int)(this.area.getMaxX() - this.area.getX());
    }
    
    public boolean isMouseOver() {
        return this.over;
    }
    
    @Override
    public void setLocation(final int n, final int n2) {
        this.setLocation((float)n, (float)n2);
    }
    
    static {
        MouseOverArea.MOUSE_OVER = 3;
        MouseOverArea.MOUSE_DOWN = 2;
        MouseOverArea.NORMAL = 1;
    }
}
