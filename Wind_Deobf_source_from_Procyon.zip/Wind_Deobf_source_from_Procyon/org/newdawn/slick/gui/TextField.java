// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.gui;

import org.lwjgl.Sys;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Color;
import org.newdawn.slick.Font;

public class TextField extends AbstractComponent
{
    public static int INITIAL_KEY_REPEAT_INTERVAL;
    public static int KEY_REPEAT_INTERVAL;
    public int width;
    public int height;
    public int x;
    public int y;
    public int maxCharacter;
    public String value;
    public Font font;
    public Color border;
    public Color text;
    public Color background;
    public int cursorPos;
    public boolean visibleCursor;
    public int lastKey;
    public char lastChar;
    public long repeatTimer;
    public String oldText;
    public int oldCursorPos;
    public boolean consume;
    
    public TextField(final GUIContext guiContext, final Font font, final int n, final int n2, final int n3, final int n4, final ComponentListener componentListener) {
        this(guiContext, font, n, n2, n3, n4);
        this.addListener(componentListener);
    }
    
    public TextField(final GUIContext guiContext, final Font font, final int n, final int n2, final int width, final int height) {
        super(guiContext);
        this.maxCharacter = 10000;
        this.value = "";
        this.border = Color.white;
        this.text = Color.white;
        this.background = new Color(0.0f, 0.0f, 0.0f, 0.0f);
        this.visibleCursor = true;
        this.lastKey = -1;
        this.lastChar = '\0';
        this.consume = true;
        this.font = font;
        this.setLocation(n, n2);
        this.width = width;
        this.height = height;
    }
    
    public void setConsumeEvents(final boolean consume) {
        this.consume = consume;
    }
    
    public void deactivate() {
        this.setFocus(false);
    }
    
    @Override
    public void setLocation(final int x, final int y) {
        this.x = x;
        this.y = y;
    }
    
    @Override
    public int getX() {
        return this.x;
    }
    
    @Override
    public int getY() {
        return this.y;
    }
    
    @Override
    public int getWidth() {
        return this.width;
    }
    
    @Override
    public int getHeight() {
        return this.height;
    }
    
    public void setBackgroundColor(final Color background) {
        this.background = background;
    }
    
    public void setBorderColor(final Color border) {
        this.border = border;
    }
    
    public void setTextColor(final Color text) {
        this.text = text;
    }
    
    @Override
    public void render(final GUIContext guiContext, final Graphics graphics) {
        if (this.lastKey != -1) {
            if (this.input.isKeyDown(this.lastKey)) {
                if (this.repeatTimer < System.currentTimeMillis()) {
                    this.repeatTimer = System.currentTimeMillis() + ((long)(-102736125) ^ 0xFFFFFFFFF9E05F31L);
                    this.keyPressed(this.lastKey, this.lastChar);
                }
            }
            else {
                this.lastKey = -1;
            }
        }
        final Rectangle clip = graphics.getClip();
        graphics.setWorldClip((float)this.x, (float)this.y, (float)this.width, (float)this.height);
        final Color color = graphics.getColor();
        if (this.background != null) {
            graphics.setColor(this.background.multiply(color));
            graphics.fillRect((float)this.x, (float)this.y, (float)this.width, (float)this.height);
        }
        graphics.setColor(this.text.multiply(color));
        final Font font = graphics.getFont();
        final int width = this.font.getWidth(this.value.substring(0, this.cursorPos));
        int n = 0;
        if (width > this.width) {
            n = this.width - width - this.font.getWidth("_");
        }
        graphics.translate((float)(n + 2), 0.0f);
        graphics.setFont(this.font);
        graphics.drawString(this.value, (float)(this.x + 1), (float)(this.y + 1));
        if (this.hasFocus() && this.visibleCursor) {
            graphics.drawString("_", (float)(this.x + 1 + width + 2), (float)(this.y + 1));
        }
        graphics.translate((float)(-n - 2), 0.0f);
        if (this.border != null) {
            graphics.setColor(this.border.multiply(color));
            graphics.drawRect((float)this.x, (float)this.y, (float)this.width, (float)this.height);
        }
        graphics.setColor(color);
        graphics.setFont(font);
        graphics.clearWorldClip();
        graphics.setClip(clip);
    }
    
    public String getText() {
        return this.value;
    }
    
    public void setText(final String value) {
        this.value = value;
        if (this.cursorPos > value.length()) {
            this.cursorPos = value.length();
        }
    }
    
    public void setCursorPos(final int cursorPos) {
        this.cursorPos = cursorPos;
        if (this.cursorPos > this.value.length()) {
            this.cursorPos = this.value.length();
        }
    }
    
    public void setCursorVisible(final boolean visibleCursor) {
        this.visibleCursor = visibleCursor;
    }
    
    public void setMaxLength(final int maxCharacter) {
        this.maxCharacter = maxCharacter;
        if (this.value.length() > this.maxCharacter) {
            this.value = this.value.substring(0, this.maxCharacter);
        }
    }
    
    public void doPaste(final String s) {
        this.recordOldPosition();
        for (int i = 0; i < s.length(); ++i) {
            this.keyPressed(-1, s.charAt(i));
        }
    }
    
    public void recordOldPosition() {
        this.oldText = this.getText();
        this.oldCursorPos = this.cursorPos;
    }
    
    public void doUndo(final int cursorPos, final String text) {
        if (text != null) {
            this.setText(text);
            this.setCursorPos(cursorPos);
        }
    }
    
    @Override
    public void keyPressed(final int lastKey, final char c) {
        if (this.hasFocus()) {
            if (lastKey != -1) {
                if (lastKey == 47 && (this.input.isKeyDown(29) || this.input.isKeyDown(157))) {
                    final String clipboard = Sys.getClipboard();
                    if (clipboard != null) {
                        this.doPaste(clipboard);
                    }
                    return;
                }
                if (lastKey == 44 && (this.input.isKeyDown(29) || this.input.isKeyDown(157))) {
                    if (this.oldText != null) {
                        this.doUndo(this.oldCursorPos, this.oldText);
                    }
                    return;
                }
                if (this.input.isKeyDown(29) || this.input.isKeyDown(157)) {
                    return;
                }
                if (this.input.isKeyDown(56) || this.input.isKeyDown(184)) {
                    return;
                }
            }
            if (this.lastKey != lastKey) {
                this.lastKey = lastKey;
                this.repeatTimer = System.currentTimeMillis() + ((long)(-845893196) ^ 0xFFFFFFFFCD94B024L);
            }
            else {
                this.repeatTimer = System.currentTimeMillis() + ((long)859590053 ^ 0x333C4D97L);
            }
            this.lastChar = c;
            if (lastKey == 203) {
                if (this.cursorPos > 0) {
                    --this.cursorPos;
                }
                if (this.consume) {
                    this.container.getInput().consumeEvent();
                }
            }
            else if (lastKey == 205) {
                if (this.cursorPos < this.value.length()) {
                    ++this.cursorPos;
                }
                if (this.consume) {
                    this.container.getInput().consumeEvent();
                }
            }
            else if (lastKey == 14) {
                if (this.cursorPos > 0 && this.value.length() > 0) {
                    if (this.cursorPos < this.value.length()) {
                        this.value = this.value.substring(0, this.cursorPos - 1) + this.value.substring(this.cursorPos);
                    }
                    else {
                        this.value = this.value.substring(0, this.cursorPos - 1);
                    }
                    --this.cursorPos;
                }
                if (this.consume) {
                    this.container.getInput().consumeEvent();
                }
            }
            else if (lastKey == 211) {
                if (this.value.length() > this.cursorPos) {
                    this.value = this.value.substring(0, this.cursorPos) + this.value.substring(this.cursorPos + 1);
                }
                if (this.consume) {
                    this.container.getInput().consumeEvent();
                }
            }
            else if (c < '\u007f' && c > '\u001f' && this.value.length() < this.maxCharacter) {
                if (this.cursorPos < this.value.length()) {
                    this.value = this.value.substring(0, this.cursorPos) + c + this.value.substring(this.cursorPos);
                }
                else {
                    this.value = this.value.substring(0, this.cursorPos) + c;
                }
                ++this.cursorPos;
                if (this.consume) {
                    this.container.getInput().consumeEvent();
                }
            }
            else if (lastKey == 28) {
                this.notifyListeners();
                if (this.consume) {
                    this.container.getInput().consumeEvent();
                }
            }
        }
    }
    
    @Override
    public void setFocus(final boolean focus) {
        this.lastKey = -1;
        super.setFocus(focus);
    }
    
    static {
        TextField.KEY_REPEAT_INTERVAL = 50;
        TextField.INITIAL_KEY_REPEAT_INTERVAL = 400;
    }
}
