// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.imageout;

import java.io.IOException;
import org.newdawn.slick.Color;
import java.awt.image.RenderedImage;
import javax.imageio.ImageIO;
import java.util.Hashtable;
import java.awt.image.ColorModel;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.SampleModel;
import java.awt.image.Raster;
import java.awt.Point;
import java.awt.image.ComponentColorModel;
import java.awt.color.ColorSpace;
import java.awt.image.PixelInterleavedSampleModel;
import java.awt.image.DataBufferByte;
import java.nio.ByteBuffer;
import java.io.OutputStream;
import org.newdawn.slick.Image;

public class ImageIOWriter implements ImageWriter
{
    @Override
    public void saveImage(final Image image, final String formatName, final OutputStream output, final boolean b) throws IOException {
        int n = 4 * image.getWidth() * image.getHeight();
        if (!b) {
            n = 3 * image.getWidth() * image.getHeight();
        }
        final ByteBuffer allocate = ByteBuffer.allocate(n);
        for (int i = 0; i < image.getHeight(); ++i) {
            for (int j = 0; j < image.getWidth(); ++j) {
                final Color color = image.getColor(j, i);
                allocate.put((byte)(color.r * 255.0f));
                allocate.put((byte)(color.g * 255.0f));
                allocate.put((byte)(color.b * 255.0f));
                if (b) {
                    allocate.put((byte)(color.a * 255.0f));
                }
            }
        }
        final DataBufferByte db = new DataBufferByte(allocate.array(), n);
        PixelInterleavedSampleModel sm;
        ComponentColorModel cm;
        if (b) {
            sm = new PixelInterleavedSampleModel(0, image.getWidth(), image.getHeight(), 4, 4 * image.getWidth(), new int[] { 0, 1, 2, 3 });
            cm = new ComponentColorModel(ColorSpace.getInstance(1000), new int[] { 8, 8, 8, 8 }, true, false, 3, 0);
        }
        else {
            sm = new PixelInterleavedSampleModel(0, image.getWidth(), image.getHeight(), 3, 3 * image.getWidth(), new int[] { 0, 1, 2 });
            cm = new ComponentColorModel(ColorSpace.getInstance(1000), new int[] { 8, 8, 8, 0 }, false, false, 1, 0);
        }
        ImageIO.write(new BufferedImage(cm, Raster.createWritableRaster(sm, db, new Point(0, 0)), false, null), formatName, output);
    }
}
