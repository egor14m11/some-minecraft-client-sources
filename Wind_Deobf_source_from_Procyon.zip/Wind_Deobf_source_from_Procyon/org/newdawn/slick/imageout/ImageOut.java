// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.imageout;

import java.io.FileOutputStream;
import org.newdawn.slick.SlickException;
import java.io.OutputStream;
import org.newdawn.slick.Image;

public class ImageOut
{
    public static boolean DEFAULT_ALPHA_WRITE;
    public static String TGA;
    public static String PNG;
    public static String JPG;
    
    public static String[] getSupportedFormats() {
        return ImageWriterFactory.getSupportedFormats();
    }
    
    public static void write(final Image image, final String s, final OutputStream outputStream) throws SlickException {
        write(image, s, outputStream, false);
    }
    
    public static void write(final Image image, final String s, final OutputStream outputStream, final boolean b) throws SlickException {
        ImageWriterFactory.getWriterForFormat(s).saveImage(image, s, outputStream, b);
    }
    
    public static void write(final Image image, final String s) throws SlickException {
        write(image, s, false);
    }
    
    public static void write(final Image image, final String s, final boolean b) throws SlickException {
        final int lastIndex = s.lastIndexOf(46);
        if (lastIndex < 0) {
            throw new SlickException("Unable to determine format from: " + s);
        }
        write(image, s.substring(lastIndex + 1), new FileOutputStream(s), b);
    }
    
    public static void write(final Image image, final String s, final String s2) throws SlickException {
        write(image, s, s2, false);
    }
    
    public static void write(final Image image, final String s, final String name, final boolean b) throws SlickException {
        write(image, s, new FileOutputStream(name), b);
    }
    
    static {
        ImageOut.DEFAULT_ALPHA_WRITE = false;
        ImageOut.TGA = "tga";
        ImageOut.PNG = "png";
        ImageOut.JPG = "jpg";
    }
}
