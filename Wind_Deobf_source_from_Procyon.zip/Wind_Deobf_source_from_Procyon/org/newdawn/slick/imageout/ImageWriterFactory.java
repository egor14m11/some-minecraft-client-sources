// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.imageout;

import javax.imageio.ImageIO;
import org.newdawn.slick.SlickException;
import java.util.HashMap;

public class ImageWriterFactory
{
    public static HashMap writers;
    
    public static void registerWriter(final String key, final ImageWriter value) {
        ImageWriterFactory.writers.put(key, value);
    }
    
    public static String[] getSupportedFormats() {
        return (String[])ImageWriterFactory.writers.keySet().toArray(new String[0]);
    }
    
    public static ImageWriter getWriterForFormat(final String s) throws SlickException {
        final ImageWriter imageWriter = ImageWriterFactory.writers.get(s);
        if (imageWriter != null) {
            return imageWriter;
        }
        final ImageWriter imageWriter2 = ImageWriterFactory.writers.get(s.toLowerCase());
        if (imageWriter2 != null) {
            return imageWriter2;
        }
        final ImageWriter imageWriter3 = ImageWriterFactory.writers.get(s.toUpperCase());
        if (imageWriter3 != null) {
            return imageWriter3;
        }
        throw new SlickException("No image writer available for: " + s);
    }
    
    static {
        ImageWriterFactory.writers = new HashMap();
        final String[] writerFormatNames = ImageIO.getWriterFormatNames();
        final ImageIOWriter imageIOWriter = new ImageIOWriter();
        for (int i = 0; i < writerFormatNames.length; ++i) {
            registerWriter(writerFormatNames[i], imageIOWriter);
        }
        registerWriter("tga", new TGAWriter());
    }
}
