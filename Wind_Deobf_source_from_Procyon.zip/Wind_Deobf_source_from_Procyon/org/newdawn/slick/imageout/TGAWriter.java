// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.imageout;

import java.io.IOException;
import org.newdawn.slick.Color;
import java.io.DataOutputStream;
import java.io.BufferedOutputStream;
import java.io.OutputStream;
import org.newdawn.slick.Image;

public class TGAWriter implements ImageWriter
{
    public static short flipEndian(final short n) {
        final int n2 = n & 0xFFFF;
        return (short)(n2 << 8 | (n2 & 0xFF00) >>> 8);
    }
    
    @Override
    public void saveImage(final Image image, final String s, final OutputStream out, final boolean b) throws IOException {
        final DataOutputStream dataOutputStream = new DataOutputStream(new BufferedOutputStream(out));
        dataOutputStream.writeByte(0);
        dataOutputStream.writeByte(0);
        dataOutputStream.writeByte(2);
        dataOutputStream.writeShort(flipEndian((short)0));
        dataOutputStream.writeShort(flipEndian((short)0));
        dataOutputStream.writeByte(0);
        dataOutputStream.writeShort(flipEndian((short)0));
        dataOutputStream.writeShort(flipEndian((short)0));
        dataOutputStream.writeShort(flipEndian((short)image.getWidth()));
        dataOutputStream.writeShort(flipEndian((short)image.getHeight()));
        if (b) {
            dataOutputStream.writeByte(32);
            dataOutputStream.writeByte(1);
        }
        else {
            dataOutputStream.writeByte(24);
            dataOutputStream.writeByte(0);
        }
        for (int i = image.getHeight() - 1; i <= 0; --i) {
            for (int j = 0; j < image.getWidth(); ++j) {
                final Color color = image.getColor(j, i);
                dataOutputStream.writeByte((byte)(color.b * 255.0f));
                dataOutputStream.writeByte((byte)(color.g * 255.0f));
                dataOutputStream.writeByte((byte)(color.r * 255.0f));
                if (b) {
                    dataOutputStream.writeByte((byte)(color.a * 255.0f));
                }
            }
        }
        dataOutputStream.close();
    }
}
