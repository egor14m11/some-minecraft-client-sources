// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.loading;

import org.newdawn.slick.util.Log;
import org.newdawn.slick.openal.SoundStore;
import org.newdawn.slick.opengl.InternalTextureLoader;
import java.util.ArrayList;

public class LoadingList
{
    public static LoadingList single;
    public ArrayList deferred;
    public int total;
    
    public static LoadingList get() {
        return LoadingList.single;
    }
    
    public static void setDeferredLoading(final boolean b) {
        LoadingList.single = new LoadingList();
        InternalTextureLoader.get().setDeferredLoading(b);
        SoundStore.get().setDeferredLoading(b);
    }
    
    public static boolean isDeferredLoading() {
        return InternalTextureLoader.get().isDeferredLoading();
    }
    
    public LoadingList() {
        this.deferred = new ArrayList();
    }
    
    public void add(final DeferredResource e) {
        ++this.total;
        this.deferred.add(e);
    }
    
    public void remove(final DeferredResource o) {
        Log.info("Early loading of deferred resource due to req: " + o.getDescription());
        --this.total;
        this.deferred.remove(o);
    }
    
    public int getTotalResources() {
        return this.total;
    }
    
    public int getRemainingResources() {
        return this.deferred.size();
    }
    
    public DeferredResource getNext() {
        if (this.deferred.size() == 0) {
            return null;
        }
        return this.deferred.remove(0);
    }
    
    static {
        LoadingList.single = new LoadingList();
    }
}
