// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.muffin;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.util.HashMap;

public class FileMuffin implements Muffin
{
    @Override
    public void saveFile(final HashMap obj, final String child) throws IOException {
        final File parent = new File(new File(System.getProperty("user.home")), ".java");
        if (!parent.exists()) {
            parent.mkdir();
        }
        final ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(new File(parent, child)));
        objectOutputStream.writeObject(obj);
        objectOutputStream.close();
    }
    
    @Override
    public HashMap loadFile(final String child) throws IOException {
        HashMap hashMap = new HashMap();
        final File file = new File(new File(new File(System.getProperty("user.home")), ".java"), child);
        if (file.exists()) {
            final ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(file));
            hashMap = (HashMap)objectInputStream.readObject();
            objectInputStream.close();
        }
        return hashMap;
    }
}
