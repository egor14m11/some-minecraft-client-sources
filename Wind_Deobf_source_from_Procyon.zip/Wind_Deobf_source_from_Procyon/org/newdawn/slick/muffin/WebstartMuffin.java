// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.muffin;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.io.DataOutputStream;
import java.net.URL;
import javax.jnlp.BasicService;
import javax.jnlp.ServiceManager;
import javax.jnlp.PersistenceService;
import java.util.HashMap;

public class WebstartMuffin implements Muffin
{
    @Override
    public void saveFile(final HashMap hashMap, final String spec) throws IOException {
        final PersistenceService persistenceService = (PersistenceService)ServiceManager.lookup("javax.jnlp.PersistenceService");
        final URL url = new URL(((BasicService)ServiceManager.lookup("javax.jnlp.BasicService")).getCodeBase(), spec);
        persistenceService.delete(url);
        persistenceService.create(url, (long)(-133808363) ^ 0xFFFFFFFFF8063B15L);
        final DataOutputStream dataOutputStream = new DataOutputStream(persistenceService.get(url).getOutputStream(false));
        for (final String key : hashMap.keySet()) {
            dataOutputStream.writeUTF(key);
            if (spec.endsWith("Number")) {
                dataOutputStream.writeDouble((double)hashMap.get(key));
            }
            else {
                dataOutputStream.writeUTF((String)hashMap.get(key));
            }
        }
        dataOutputStream.flush();
        dataOutputStream.close();
    }
    
    @Override
    public HashMap loadFile(final String spec) throws IOException {
        final HashMap<String, Double> hashMap = new HashMap<String, Double>();
        final DataInputStream dataInputStream = new DataInputStream(((PersistenceService)ServiceManager.lookup("javax.jnlp.PersistenceService")).get(new URL(((BasicService)ServiceManager.lookup("javax.jnlp.BasicService")).getCodeBase(), spec)).getInputStream());
        if (spec.endsWith("Number")) {
            String utf;
            while ((utf = dataInputStream.readUTF()) != null) {
                hashMap.put(utf, new Double(dataInputStream.readDouble()));
            }
        }
        else {
            String utf2;
            while ((utf2 = dataInputStream.readUTF()) != null) {
                hashMap.put(utf2, (Double)dataInputStream.readUTF());
            }
        }
        dataInputStream.close();
        return hashMap;
    }
}
