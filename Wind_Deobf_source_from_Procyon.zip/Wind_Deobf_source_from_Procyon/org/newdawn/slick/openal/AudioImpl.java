// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

import org.lwjgl.openal.AL10;

public class AudioImpl implements Audio
{
    public SoundStore store;
    public int buffer;
    public int index;
    public float length;
    
    public AudioImpl(final SoundStore store, final int buffer) {
        this.index = -1;
        this.store = store;
        this.buffer = buffer;
        this.length = AL10.alGetBufferi(buffer, 8196) / (AL10.alGetBufferi(buffer, 8194) / 8) / (float)AL10.alGetBufferi(buffer, 8193) / AL10.alGetBufferi(buffer, 8195);
    }
    
    @Override
    public int getBufferID() {
        return this.buffer;
    }
    
    public AudioImpl() {
        this.index = -1;
    }
    
    @Override
    public void stop() {
        if (this.index != -1) {
            this.store.stopSource(this.index);
            this.index = -1;
        }
    }
    
    @Override
    public boolean isPlaying() {
        return this.index != -1 && this.store.isPlaying(this.index);
    }
    
    @Override
    public int playAsSoundEffect(final float n, final float n2, final boolean b) {
        this.index = this.store.playAsSound(this.buffer, n, n2, b);
        return this.store.getSource(this.index);
    }
    
    @Override
    public int playAsSoundEffect(final float n, final float n2, final boolean b, final float n3, final float n4, final float n5) {
        this.index = this.store.playAsSoundAt(this.buffer, n, n2, b, n3, n4, n5);
        return this.store.getSource(this.index);
    }
    
    @Override
    public int playAsMusic(final float n, final float n2, final boolean b) {
        this.store.playAsMusic(this.buffer, n, n2, b);
        this.index = 0;
        return this.store.getSource(0);
    }
    
    public static void pauseMusic() {
        SoundStore.get().pauseLoop();
    }
    
    public static void restartMusic() {
        SoundStore.get().restartLoop();
    }
    
    @Override
    public boolean setPosition(float n) {
        n %= this.length;
        AL10.alSourcef(this.store.getSource(this.index), 4132, n);
        return AL10.alGetError() == 0;
    }
    
    @Override
    public float getPosition() {
        return AL10.alGetSourcef(this.store.getSource(this.index), 4132);
    }
}
