// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

import java.net.URL;
import java.io.IOException;
import java.io.InputStream;

public class AudioLoader
{
    public static String AIF;
    public static String WAV;
    public static String OGG;
    public static String MOD;
    public static String XM;
    public static boolean inited;
    
    public static void init() {
        if (!AudioLoader.inited) {
            SoundStore.get().init();
            AudioLoader.inited = true;
        }
    }
    
    public static Audio getAudio(final String str, final InputStream inputStream) throws IOException {
        init();
        if (str.equals("AIF")) {
            return SoundStore.get().getAIF(inputStream);
        }
        if (str.equals("WAV")) {
            return SoundStore.get().getWAV(inputStream);
        }
        if (str.equals("OGG")) {
            return SoundStore.get().getOgg(inputStream);
        }
        throw new IOException("Unsupported format for non-streaming Audio: " + str);
    }
    
    public static Audio getStreamingAudio(final String str, final URL url) throws IOException {
        init();
        if (str.equals("OGG")) {
            return SoundStore.get().getOggStream(url);
        }
        if (str.equals("MOD")) {
            return SoundStore.get().getMOD(url.openStream());
        }
        if (str.equals("XM")) {
            return SoundStore.get().getMOD(url.openStream());
        }
        throw new IOException("Unsupported format for streaming Audio: " + str);
    }
    
    public static void update() {
        init();
        SoundStore.get().poll(0);
    }
    
    static {
        AudioLoader.XM = "XM";
        AudioLoader.MOD = "MOD";
        AudioLoader.OGG = "OGG";
        AudioLoader.WAV = "WAV";
        AudioLoader.AIF = "AIF";
        AudioLoader.inited = false;
    }
}
