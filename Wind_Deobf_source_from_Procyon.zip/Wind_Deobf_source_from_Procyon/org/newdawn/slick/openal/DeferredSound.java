// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

import java.io.IOException;
import org.newdawn.slick.util.Log;
import org.newdawn.slick.loading.LoadingList;
import java.io.InputStream;
import org.newdawn.slick.loading.DeferredResource;

public class DeferredSound extends AudioImpl implements DeferredResource
{
    public static int OGG;
    public static int WAV;
    public static int MOD;
    public static int AIF;
    public int type;
    public String ref;
    public Audio target;
    public InputStream in;
    
    public DeferredSound(final String ref, final InputStream in, final int type) {
        this.ref = ref;
        this.type = type;
        if (ref.equals(in.toString())) {
            this.in = in;
        }
        LoadingList.get().add(this);
    }
    
    public void checkTarget() {
        if (this.target == null) {
            throw new RuntimeException("Attempt to use deferred sound before loading");
        }
    }
    
    @Override
    public void load() throws IOException {
        final boolean deferredLoading = SoundStore.get().isDeferredLoading();
        SoundStore.get().setDeferredLoading(false);
        if (this.in != null) {
            switch (this.type) {
                case 1: {
                    this.target = SoundStore.get().getOgg(this.in);
                    break;
                }
                case 2: {
                    this.target = SoundStore.get().getWAV(this.in);
                    break;
                }
                case 3: {
                    this.target = SoundStore.get().getMOD(this.in);
                    break;
                }
                case 4: {
                    this.target = SoundStore.get().getAIF(this.in);
                    break;
                }
                default: {
                    Log.error("Unrecognised sound type: " + this.type);
                    break;
                }
            }
        }
        else {
            switch (this.type) {
                case 1: {
                    this.target = SoundStore.get().getOgg(this.ref);
                    break;
                }
                case 2: {
                    this.target = SoundStore.get().getWAV(this.ref);
                    break;
                }
                case 3: {
                    this.target = SoundStore.get().getMOD(this.ref);
                    break;
                }
                case 4: {
                    this.target = SoundStore.get().getAIF(this.ref);
                    break;
                }
                default: {
                    Log.error("Unrecognised sound type: " + this.type);
                    break;
                }
            }
        }
        SoundStore.get().setDeferredLoading(deferredLoading);
    }
    
    @Override
    public boolean isPlaying() {
        this.checkTarget();
        return this.target.isPlaying();
    }
    
    @Override
    public int playAsMusic(final float n, final float n2, final boolean b) {
        this.checkTarget();
        return this.target.playAsMusic(n, n2, b);
    }
    
    @Override
    public int playAsSoundEffect(final float n, final float n2, final boolean b) {
        this.checkTarget();
        return this.target.playAsSoundEffect(n, n2, b);
    }
    
    @Override
    public int playAsSoundEffect(final float n, final float n2, final boolean b, final float n3, final float n4, final float n5) {
        this.checkTarget();
        return this.target.playAsSoundEffect(n, n2, b, n3, n4, n5);
    }
    
    @Override
    public void stop() {
        this.checkTarget();
        this.target.stop();
    }
    
    @Override
    public String getDescription() {
        return this.ref;
    }
    
    static {
        DeferredSound.AIF = 4;
        DeferredSound.MOD = 3;
        DeferredSound.WAV = 2;
        DeferredSound.OGG = 1;
    }
}
