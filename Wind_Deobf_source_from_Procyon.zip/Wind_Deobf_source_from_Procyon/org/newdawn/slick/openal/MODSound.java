// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;
import java.io.IOException;
import java.io.InputStream;
import ibxm.Module;
import ibxm.OpenALMODPlayer;

public class MODSound extends AudioImpl
{
    public static OpenALMODPlayer player;
    public Module module;
    public SoundStore store;
    
    public MODSound(final SoundStore store, final InputStream inputStream) throws IOException {
        this.store = store;
        this.module = OpenALMODPlayer.loadModule(inputStream);
    }
    
    @Override
    public int playAsMusic(final float n, final float currentMusicVolume, final boolean b) {
        this.cleanUpSource();
        MODSound.player.play(this.module, this.store.getSource(0), b, SoundStore.get().isMusicOn());
        MODSound.player.setup(n, 1.0f);
        this.store.setCurrentMusicVolume(currentMusicVolume);
        this.store.setMOD(this);
        return this.store.getSource(0);
    }
    
    public void cleanUpSource() {
        AL10.alSourceStop(this.store.getSource(0));
        final IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
        for (int i = AL10.alGetSourcei(this.store.getSource(0), 4117); i > 0; --i) {
            AL10.alSourceUnqueueBuffers(this.store.getSource(0), intBuffer);
        }
        AL10.alSourcei(this.store.getSource(0), 4105, 0);
    }
    
    public void poll() {
        MODSound.player.update();
    }
    
    @Override
    public int playAsSoundEffect(final float n, final float n2, final boolean b) {
        return -1;
    }
    
    @Override
    public void stop() {
        this.store.setMOD(null);
    }
    
    @Override
    public float getPosition() {
        throw new RuntimeException("Positioning on modules is not currently supported");
    }
    
    @Override
    public boolean setPosition(final float n) {
        throw new RuntimeException("Positioning on modules is not currently supported");
    }
    
    static {
        MODSound.player = new OpenALMODPlayer();
    }
}
