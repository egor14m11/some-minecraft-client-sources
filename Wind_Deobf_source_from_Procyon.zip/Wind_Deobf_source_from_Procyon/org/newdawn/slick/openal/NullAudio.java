// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

public class NullAudio implements Audio
{
    @Override
    public int getBufferID() {
        return 0;
    }
    
    @Override
    public float getPosition() {
        return 0.0f;
    }
    
    @Override
    public boolean isPlaying() {
        return false;
    }
    
    @Override
    public int playAsMusic(final float n, final float n2, final boolean b) {
        return 0;
    }
    
    @Override
    public int playAsSoundEffect(final float n, final float n2, final boolean b) {
        return 0;
    }
    
    @Override
    public int playAsSoundEffect(final float n, final float n2, final boolean b, final float n3, final float n4, final float n5) {
        return 0;
    }
    
    @Override
    public boolean setPosition(final float n) {
        return false;
    }
    
    @Override
    public void stop() {
    }
}
