// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

import java.nio.ByteBuffer;

public class OggData
{
    public ByteBuffer data;
    public int rate;
    public int channels;
}
