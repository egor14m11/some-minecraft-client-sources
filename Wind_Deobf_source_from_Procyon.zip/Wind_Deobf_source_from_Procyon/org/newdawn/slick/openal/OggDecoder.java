// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

import java.nio.ByteBuffer;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class OggDecoder
{
    public int convsize;
    public byte[] convbuffer;
    
    public OggDecoder() {
        this.convsize = 16384;
        this.convbuffer = new byte[this.convsize];
    }
    
    public OggData getData(final InputStream inputStream) throws IOException {
        if (inputStream == null) {
            throw new IOException("Failed to read OGG, source does not exist?");
        }
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        final OggInputStream oggInputStream = new OggInputStream(inputStream);
        while (!oggInputStream.atEnd()) {
            byteArrayOutputStream.write(oggInputStream.read());
        }
        final OggData oggData = new OggData();
        oggData.channels = oggInputStream.getChannels();
        oggData.rate = oggInputStream.getRate();
        final byte[] byteArray = byteArrayOutputStream.toByteArray();
        (oggData.data = ByteBuffer.allocateDirect(byteArray.length)).put(byteArray);
        oggData.data.rewind();
        return oggData;
    }
}
