// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

import java.io.IOException;
import org.newdawn.slick.util.ResourceLoader;
import org.lwjgl.openal.AL10;
import org.lwjgl.BufferUtils;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;

public class OpenALStreamPlayer
{
    public static int BUFFER_COUNT;
    public static int sectionSize;
    public byte[] buffer;
    public IntBuffer bufferNames;
    public ByteBuffer bufferData;
    public IntBuffer unqueued;
    public int source;
    public int remainingBufferCount;
    public boolean loop;
    public boolean done;
    public AudioInputStream audio;
    public String ref;
    public URL url;
    public float pitch;
    public float positionOffset;
    
    public OpenALStreamPlayer(final int source, final String ref) {
        this.buffer = new byte[81920];
        this.bufferData = BufferUtils.createByteBuffer(81920);
        this.unqueued = BufferUtils.createIntBuffer(1);
        this.done = true;
        this.source = source;
        this.ref = ref;
        AL10.alGenBuffers(this.bufferNames = BufferUtils.createIntBuffer(3));
    }
    
    public OpenALStreamPlayer(final int source, final URL url) {
        this.buffer = new byte[81920];
        this.bufferData = BufferUtils.createByteBuffer(81920);
        this.unqueued = BufferUtils.createIntBuffer(1);
        this.done = true;
        this.source = source;
        this.url = url;
        AL10.alGenBuffers(this.bufferNames = BufferUtils.createIntBuffer(3));
    }
    
    public void initStreams() throws IOException {
        if (this.audio != null) {
            this.audio.close();
        }
        OggInputStream audio;
        if (this.url != null) {
            audio = new OggInputStream(this.url.openStream());
        }
        else {
            audio = new OggInputStream(ResourceLoader.getResourceAsStream(this.ref));
        }
        this.audio = audio;
        this.positionOffset = 0.0f;
    }
    
    public String getSource() {
        return (this.url == null) ? this.ref : this.url.toString();
    }
    
    public void removeBuffers() {
        final IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
        for (int i = AL10.alGetSourcei(this.source, 4117); i > 0; --i) {
            AL10.alSourceUnqueueBuffers(this.source, intBuffer);
        }
    }
    
    public void play(final boolean loop) throws IOException {
        this.loop = loop;
        this.initStreams();
        this.done = false;
        AL10.alSourceStop(this.source);
        this.removeBuffers();
        this.startPlayback();
    }
    
    public void setup(final float pitch) {
        this.pitch = pitch;
    }
    
    public boolean done() {
        return this.done;
    }
    
    public void update() {
        if (this.done) {
            return;
        }
        final float n = (float)this.audio.getRate();
        float n2;
        if (this.audio.getChannels() > 1) {
            n2 = 4.0f;
        }
        else {
            n2 = 2.0f;
        }
        for (int i = AL10.alGetSourcei(this.source, 4118); i > 0; --i) {
            this.unqueued.clear();
            AL10.alSourceUnqueueBuffers(this.source, this.unqueued);
            final int value = this.unqueued.get(0);
            this.positionOffset += AL10.alGetBufferi(value, 8196) / n2 / n;
            if (this.stream(value)) {
                AL10.alSourceQueueBuffers(this.source, this.unqueued);
            }
            else {
                --this.remainingBufferCount;
                if (this.remainingBufferCount == 0) {
                    this.done = true;
                }
            }
        }
        if (AL10.alGetSourcei(this.source, 4112) != 4114) {
            AL10.alSourcePlay(this.source);
        }
    }
    
    public boolean stream(final int n) {
        final int read = this.audio.read(this.buffer);
        if (read != -1) {
            this.bufferData.clear();
            this.bufferData.put(this.buffer, 0, read);
            this.bufferData.flip();
            AL10.alBufferData(n, (this.audio.getChannels() > 1) ? 4355 : 4353, this.bufferData, this.audio.getRate());
        }
        else {
            if (!this.loop) {
                this.done = true;
                return false;
            }
            this.initStreams();
            this.stream(n);
        }
        return true;
    }
    
    public boolean setPosition(final float n) {
        if (this.getPosition() > n) {
            this.initStreams();
        }
        final float n2 = (float)this.audio.getRate();
        float n3;
        if (this.audio.getChannels() > 1) {
            n3 = 4.0f;
        }
        else {
            n3 = 2.0f;
        }
        while (this.positionOffset < n) {
            final int read = this.audio.read(this.buffer);
            if (read == -1) {
                if (this.loop) {
                    this.initStreams();
                }
                else {
                    this.done = true;
                }
                return false;
            }
            this.positionOffset += read / n3 / n2;
        }
        this.startPlayback();
        return true;
    }
    
    public void startPlayback() {
        AL10.alSourcei(this.source, 4103, 0);
        AL10.alSourcef(this.source, 4099, this.pitch);
        this.remainingBufferCount = 3;
        for (int i = 0; i < 3; ++i) {
            this.stream(this.bufferNames.get(i));
        }
        AL10.alSourceQueueBuffers(this.source, this.bufferNames);
        AL10.alSourcePlay(this.source);
    }
    
    public float getPosition() {
        return this.positionOffset + AL10.alGetSourcef(this.source, 4132);
    }
    
    static {
        OpenALStreamPlayer.sectionSize = 81920;
        OpenALStreamPlayer.BUFFER_COUNT = 3;
    }
}
