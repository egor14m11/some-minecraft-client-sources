// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

import java.net.URL;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.IOException;
import org.newdawn.slick.util.ResourceLoader;
import java.security.AccessController;
import org.lwjgl.openal.AL;
import java.security.PrivilegedAction;
import org.newdawn.slick.util.Log;
import org.lwjgl.openal.AL10;
import org.lwjgl.BufferUtils;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;

public class SoundStore
{
    public static SoundStore store;
    public boolean sounds;
    public boolean music;
    public boolean soundWorks;
    public int sourceCount;
    public HashMap loaded;
    public int currentMusic;
    public IntBuffer sources;
    public int nextSource;
    public boolean inited;
    public MODSound mod;
    public OpenALStreamPlayer stream;
    public float musicVolume;
    public float soundVolume;
    public float lastCurrentMusicVolume;
    public boolean paused;
    public boolean deferred;
    public FloatBuffer sourceVel;
    public FloatBuffer sourcePos;
    public int maxSources;
    
    public SoundStore() {
        this.loaded = new HashMap();
        this.currentMusic = -1;
        this.inited = false;
        this.musicVolume = 1.0f;
        this.soundVolume = 1.0f;
        this.lastCurrentMusicVolume = 1.0f;
        this.sourceVel = BufferUtils.createFloatBuffer(3).put(new float[] { 0.0f, 0.0f, 0.0f });
        this.sourcePos = BufferUtils.createFloatBuffer(3);
        this.maxSources = 64;
    }
    
    public void clear() {
        SoundStore.store = new SoundStore();
    }
    
    public void disable() {
        this.inited = true;
    }
    
    public void setDeferredLoading(final boolean deferred) {
        this.deferred = deferred;
    }
    
    public boolean isDeferredLoading() {
        return this.deferred;
    }
    
    public void setMusicOn(final boolean music) {
        if (this.soundWorks) {
            this.music = music;
            if (music) {
                this.restartLoop();
                this.setMusicVolume(this.musicVolume);
            }
            else {
                this.pauseLoop();
            }
        }
    }
    
    public boolean isMusicOn() {
        return this.music;
    }
    
    public void setMusicVolume(float musicVolume) {
        if (musicVolume < 0.0f) {
            musicVolume = 0.0f;
        }
        if (musicVolume > 1.0f) {
            musicVolume = 1.0f;
        }
        this.musicVolume = musicVolume;
        if (this.soundWorks) {
            AL10.alSourcef(this.sources.get(0), 4106, this.lastCurrentMusicVolume * this.musicVolume);
        }
    }
    
    public float getCurrentMusicVolume() {
        return this.lastCurrentMusicVolume;
    }
    
    public void setCurrentMusicVolume(float lastCurrentMusicVolume) {
        if (lastCurrentMusicVolume < 0.0f) {
            lastCurrentMusicVolume = 0.0f;
        }
        if (lastCurrentMusicVolume > 1.0f) {
            lastCurrentMusicVolume = 1.0f;
        }
        if (this.soundWorks) {
            this.lastCurrentMusicVolume = lastCurrentMusicVolume;
            AL10.alSourcef(this.sources.get(0), 4106, this.lastCurrentMusicVolume * this.musicVolume);
        }
    }
    
    public void setSoundVolume(float soundVolume) {
        if (soundVolume < 0.0f) {
            soundVolume = 0.0f;
        }
        this.soundVolume = soundVolume;
    }
    
    public boolean soundWorks() {
        return this.soundWorks;
    }
    
    public boolean musicOn() {
        return this.music;
    }
    
    public float getSoundVolume() {
        return this.soundVolume;
    }
    
    public float getMusicVolume() {
        return this.musicVolume;
    }
    
    public int getSource(final int n) {
        if (!this.soundWorks) {
            return -1;
        }
        if (n < 0) {
            return -1;
        }
        return this.sources.get(n);
    }
    
    public void setSoundsOn(final boolean sounds) {
        if (this.soundWorks) {
            this.sounds = sounds;
        }
    }
    
    public boolean soundsOn() {
        return this.sounds;
    }
    
    public void setMaxSources(final int maxSources) {
        this.maxSources = maxSources;
    }
    
    public void init() {
        if (this.inited) {
            return;
        }
        Log.info("Initialising sounds..");
        this.inited = true;
        AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction(this) {
            public SoundStore this$0;
            
            @Override
            public Object run() {
                AL.create();
                SoundStore.access$002(this.this$0, true);
                SoundStore.access$102(this.this$0, true);
                SoundStore.access$202(this.this$0, true);
                Log.info("- Sound works");
                return null;
            }
        });
        if (this.soundWorks) {
            this.sourceCount = 0;
            this.sources = BufferUtils.createIntBuffer(this.maxSources);
            while (AL10.alGetError() == 0) {
                final IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
                AL10.alGenSources(intBuffer);
                if (AL10.alGetError() == 0) {
                    ++this.sourceCount;
                    this.sources.put(intBuffer.get(0));
                    if (this.sourceCount > this.maxSources - 1) {
                        break;
                    }
                    continue;
                }
            }
            Log.info("- " + this.sourceCount + " OpenAL source available");
            if (AL10.alGetError() != 0) {
                this.sounds = false;
                this.music = false;
                this.soundWorks = false;
                Log.error("- AL init failed");
            }
            else {
                final FloatBuffer put = BufferUtils.createFloatBuffer(6).put(new float[] { 0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f });
                final FloatBuffer put2 = BufferUtils.createFloatBuffer(3).put(new float[] { 0.0f, 0.0f, 0.0f });
                final FloatBuffer put3 = BufferUtils.createFloatBuffer(3).put(new float[] { 0.0f, 0.0f, 0.0f });
                put3.flip();
                put2.flip();
                put.flip();
                AL10.alListener(4100, put3);
                AL10.alListener(4102, put2);
                AL10.alListener(4111, put);
                Log.info("- Sounds source generated");
            }
        }
    }
    
    public void stopSource(final int n) {
        AL10.alSourceStop(this.sources.get(n));
    }
    
    public int playAsSound(final int n, final float n2, final float n3, final boolean b) {
        return this.playAsSoundAt(n, n2, n3, b, 0.0f, 0.0f, 0.0f);
    }
    
    public int playAsSoundAt(final int n, final float n2, float n3, final boolean b, final float n4, final float n5, final float n6) {
        n3 *= this.soundVolume;
        if (n3 == 0.0f) {
            n3 = 0.0f;
        }
        if (!this.soundWorks || !this.sounds) {
            return -1;
        }
        final int freeSource = this.findFreeSource();
        if (freeSource == -1) {
            return -1;
        }
        AL10.alSourceStop(this.sources.get(freeSource));
        AL10.alSourcei(this.sources.get(freeSource), 4105, n);
        AL10.alSourcef(this.sources.get(freeSource), 4099, n2);
        AL10.alSourcef(this.sources.get(freeSource), 4106, n3);
        AL10.alSourcei(this.sources.get(freeSource), 4103, (int)(b ? 1 : 0));
        this.sourcePos.clear();
        this.sourceVel.clear();
        this.sourceVel.put(new float[] { 0.0f, 0.0f, 0.0f });
        this.sourcePos.put(new float[] { n4, n5, n6 });
        this.sourcePos.flip();
        this.sourceVel.flip();
        AL10.alSource(this.sources.get(freeSource), 4100, this.sourcePos);
        AL10.alSource(this.sources.get(freeSource), 4102, this.sourceVel);
        AL10.alSourcePlay(this.sources.get(freeSource));
        return freeSource;
    }
    
    public boolean isPlaying(final int n) {
        return AL10.alGetSourcei(this.sources.get(n), 4112) == 4114;
    }
    
    public int findFreeSource() {
        for (int i = 1; i < this.sourceCount - 1; ++i) {
            final int alGetSourcei = AL10.alGetSourcei(this.sources.get(i), 4112);
            if (alGetSourcei != 4114 && alGetSourcei != 4115) {
                return i;
            }
        }
        return -1;
    }
    
    public void playAsMusic(final int n, final float n2, final float n3, final boolean b) {
        this.paused = false;
        this.setMOD(null);
        if (this.soundWorks) {
            if (this.currentMusic != -1) {
                AL10.alSourceStop(this.sources.get(0));
            }
            this.getMusicSource();
            AL10.alSourcei(this.sources.get(0), 4105, n);
            AL10.alSourcef(this.sources.get(0), 4099, n2);
            AL10.alSourcei(this.sources.get(0), 4103, (int)(b ? 1 : 0));
            this.currentMusic = this.sources.get(0);
            if (!this.music) {
                this.pauseLoop();
            }
            else {
                AL10.alSourcePlay(this.sources.get(0));
            }
        }
    }
    
    public int getMusicSource() {
        return this.sources.get(0);
    }
    
    public void setMusicPitch(final float n) {
        if (this.soundWorks) {
            AL10.alSourcef(this.sources.get(0), 4099, n);
        }
    }
    
    public void pauseLoop() {
        if (this.soundWorks && this.currentMusic != -1) {
            this.paused = true;
            AL10.alSourcePause(this.currentMusic);
        }
    }
    
    public void restartLoop() {
        if (this.music && this.soundWorks && this.currentMusic != -1) {
            this.paused = false;
            AL10.alSourcePlay(this.currentMusic);
        }
    }
    
    public boolean isPlaying(final OpenALStreamPlayer openALStreamPlayer) {
        return this.stream == openALStreamPlayer;
    }
    
    public Audio getMOD(final String s) throws IOException {
        return this.getMOD(s, ResourceLoader.getResourceAsStream(s));
    }
    
    public Audio getMOD(final InputStream inputStream) throws IOException {
        return this.getMOD(inputStream.toString(), inputStream);
    }
    
    public Audio getMOD(final String s, final InputStream inputStream) throws IOException {
        if (!this.soundWorks) {
            return new NullAudio();
        }
        if (!this.inited) {
            throw new RuntimeException("Can't load sounds until SoundStore is init(). Use the container init() method.");
        }
        if (this.deferred) {
            return new DeferredSound(s, inputStream, 3);
        }
        return new MODSound(this, inputStream);
    }
    
    public Audio getAIF(final String s) throws IOException {
        return this.getAIF(s, ResourceLoader.getResourceAsStream(s));
    }
    
    public Audio getAIF(final InputStream inputStream) throws IOException {
        return this.getAIF(inputStream.toString(), inputStream);
    }
    
    public Audio getAIF(final String s, final InputStream in) throws IOException {
        final BufferedInputStream bufferedInputStream = new BufferedInputStream(in);
        if (!this.soundWorks) {
            return new NullAudio();
        }
        if (!this.inited) {
            throw new RuntimeException("Can't load sounds until SoundStore is init(). Use the container init() method.");
        }
        if (this.deferred) {
            return new DeferredSound(s, bufferedInputStream, 4);
        }
        int n;
        if (this.loaded.get(s) != null) {
            n = this.loaded.get(s);
        }
        else {
            final IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
            final AiffData create = AiffData.create(bufferedInputStream);
            AL10.alGenBuffers(intBuffer);
            AL10.alBufferData(intBuffer.get(0), create.format, create.data, create.samplerate);
            this.loaded.put(s, new Integer(intBuffer.get(0)));
            n = intBuffer.get(0);
        }
        if (n == -1) {
            throw new IOException("Unable to load: " + s);
        }
        return new AudioImpl(this, n);
    }
    
    public Audio getWAV(final String s) throws IOException {
        return this.getWAV(s, ResourceLoader.getResourceAsStream(s));
    }
    
    public Audio getWAV(final InputStream inputStream) throws IOException {
        return this.getWAV(inputStream.toString(), inputStream);
    }
    
    public Audio getWAV(final String s, final InputStream inputStream) throws IOException {
        if (!this.soundWorks) {
            return new NullAudio();
        }
        if (!this.inited) {
            throw new RuntimeException("Can't load sounds until SoundStore is init(). Use the container init() method.");
        }
        if (this.deferred) {
            return new DeferredSound(s, inputStream, 2);
        }
        int n;
        if (this.loaded.get(s) != null) {
            n = this.loaded.get(s);
        }
        else {
            final IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
            final WaveData create = WaveData.create(inputStream);
            AL10.alGenBuffers(intBuffer);
            AL10.alBufferData(intBuffer.get(0), create.format, create.data, create.samplerate);
            this.loaded.put(s, new Integer(intBuffer.get(0)));
            n = intBuffer.get(0);
        }
        if (n == -1) {
            throw new IOException("Unable to load: " + s);
        }
        return new AudioImpl(this, n);
    }
    
    public Audio getOggStream(final String s) throws IOException {
        if (!this.soundWorks) {
            return new NullAudio();
        }
        this.setMOD(null);
        this.setStream(null);
        if (this.currentMusic != -1) {
            AL10.alSourceStop(this.sources.get(0));
        }
        this.getMusicSource();
        this.currentMusic = this.sources.get(0);
        return new StreamSound(new OpenALStreamPlayer(this.currentMusic, s));
    }
    
    public Audio getOggStream(final URL url) throws IOException {
        if (!this.soundWorks) {
            return new NullAudio();
        }
        this.setMOD(null);
        this.setStream(null);
        if (this.currentMusic != -1) {
            AL10.alSourceStop(this.sources.get(0));
        }
        this.getMusicSource();
        this.currentMusic = this.sources.get(0);
        return new StreamSound(new OpenALStreamPlayer(this.currentMusic, url));
    }
    
    public Audio getOgg(final String s) throws IOException {
        return this.getOgg(s, ResourceLoader.getResourceAsStream(s));
    }
    
    public Audio getOgg(final InputStream inputStream) throws IOException {
        return this.getOgg(inputStream.toString(), inputStream);
    }
    
    public Audio getOgg(final String s, final InputStream inputStream) throws IOException {
        if (!this.soundWorks) {
            return new NullAudio();
        }
        if (!this.inited) {
            throw new RuntimeException("Can't load sounds until SoundStore is init(). Use the container init() method.");
        }
        if (this.deferred) {
            return new DeferredSound(s, inputStream, 1);
        }
        int n;
        if (this.loaded.get(s) != null) {
            n = this.loaded.get(s);
        }
        else {
            final IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
            final OggData data = new OggDecoder().getData(inputStream);
            AL10.alGenBuffers(intBuffer);
            AL10.alBufferData(intBuffer.get(0), (data.channels > 1) ? 4355 : 4353, data.data, data.rate);
            this.loaded.put(s, new Integer(intBuffer.get(0)));
            n = intBuffer.get(0);
        }
        if (n == -1) {
            throw new IOException("Unable to load: " + s);
        }
        return new AudioImpl(this, n);
    }
    
    public void setMOD(final MODSound mod) {
        if (!this.soundWorks) {
            return;
        }
        this.currentMusic = this.sources.get(0);
        this.stopSource(0);
        if ((this.mod = mod) != null) {
            this.stream = null;
        }
        this.paused = false;
    }
    
    public void setStream(final OpenALStreamPlayer stream) {
        if (!this.soundWorks) {
            return;
        }
        this.currentMusic = this.sources.get(0);
        if ((this.stream = stream) != null) {
            this.mod = null;
        }
        this.paused = false;
    }
    
    public void poll(final int n) {
        if (!this.soundWorks) {
            return;
        }
        if (this.paused) {
            return;
        }
        if (this.music) {
            if (this.mod != null) {
                this.mod.poll();
            }
            if (this.stream != null) {
                this.stream.update();
            }
        }
    }
    
    public boolean isMusicPlaying() {
        if (!this.soundWorks) {
            return false;
        }
        final int alGetSourcei = AL10.alGetSourcei(this.sources.get(0), 4112);
        return alGetSourcei == 4114 || alGetSourcei == 4115;
    }
    
    public static SoundStore get() {
        return SoundStore.store;
    }
    
    public void stopSoundEffect(final int n) {
        AL10.alSourceStop(n);
    }
    
    public int getSourceCount() {
        return this.sourceCount;
    }
    
    public static boolean access$002(final SoundStore soundStore, final boolean soundWorks) {
        return soundStore.soundWorks = soundWorks;
    }
    
    public static boolean access$102(final SoundStore soundStore, final boolean sounds) {
        return soundStore.sounds = sounds;
    }
    
    public static boolean access$202(final SoundStore soundStore, final boolean music) {
        return soundStore.music = music;
    }
    
    static {
        SoundStore.store = new SoundStore();
    }
}
