// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;

public class StreamSound extends AudioImpl
{
    public OpenALStreamPlayer player;
    
    public StreamSound(final OpenALStreamPlayer player) {
        this.player = player;
    }
    
    @Override
    public boolean isPlaying() {
        return SoundStore.get().isPlaying(this.player);
    }
    
    @Override
    public int playAsMusic(final float n, final float n2, final boolean b) {
        this.cleanUpSource();
        this.player.setup(n);
        this.player.play(b);
        SoundStore.get().setStream(this.player);
        return SoundStore.get().getSource(0);
    }
    
    public void cleanUpSource() {
        final SoundStore value = SoundStore.get();
        AL10.alSourceStop(value.getSource(0));
        final IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
        for (int i = AL10.alGetSourcei(value.getSource(0), 4117); i > 0; --i) {
            AL10.alSourceUnqueueBuffers(value.getSource(0), intBuffer);
        }
        AL10.alSourcei(value.getSource(0), 4105, 0);
    }
    
    @Override
    public int playAsSoundEffect(final float n, final float n2, final boolean b, final float n3, final float n4, final float n5) {
        return this.playAsMusic(n, n2, b);
    }
    
    @Override
    public int playAsSoundEffect(final float n, final float n2, final boolean b) {
        return this.playAsMusic(n, n2, b);
    }
    
    @Override
    public void stop() {
        SoundStore.get().setStream(null);
    }
    
    @Override
    public boolean setPosition(final float position) {
        return this.player.setPosition(position);
    }
    
    @Override
    public float getPosition() {
        return this.player.getPosition();
    }
}
