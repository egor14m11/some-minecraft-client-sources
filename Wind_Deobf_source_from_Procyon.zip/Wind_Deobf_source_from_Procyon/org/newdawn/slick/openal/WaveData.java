// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.openal;

import java.nio.ShortBuffer;
import java.nio.ByteOrder;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import javax.sound.sampled.AudioSystem;
import java.io.BufferedInputStream;
import java.net.URL;
import java.nio.ByteBuffer;

public class WaveData
{
    public ByteBuffer data;
    public int format;
    public int samplerate;
    
    public WaveData(final ByteBuffer data, final int format, final int samplerate) {
        this.data = data;
        this.format = format;
        this.samplerate = samplerate;
    }
    
    public void dispose() {
        this.data.clear();
    }
    
    public static WaveData create(final URL url) {
        return create(AudioSystem.getAudioInputStream(new BufferedInputStream(url.openStream())));
    }
    
    public static WaveData create(final String name) {
        return create(WaveData.class.getClassLoader().getResource(name));
    }
    
    public static WaveData create(final InputStream stream) {
        return create(AudioSystem.getAudioInputStream(stream));
    }
    
    public static WaveData create(final byte[] buf) {
        return create(AudioSystem.getAudioInputStream(new BufferedInputStream(new ByteArrayInputStream(buf))));
    }
    
    public static WaveData create(final ByteBuffer byteBuffer) {
        byte[] array;
        if (byteBuffer.hasArray()) {
            array = byteBuffer.array();
        }
        else {
            array = new byte[byteBuffer.capacity()];
            byteBuffer.get(array);
        }
        return create(array);
    }
    
    public static WaveData create(final AudioInputStream audioInputStream) {
        final AudioFormat format = audioInputStream.getFormat();
        int n;
        if (format.getChannels() == 1) {
            if (format.getSampleSizeInBits() == 8) {
                n = 4352;
            }
            else {
                if (format.getSampleSizeInBits() != 16) {
                    throw new RuntimeException("Illegal sample size");
                }
                n = 4353;
            }
        }
        else {
            if (format.getChannels() != 2) {
                throw new RuntimeException("Only mono or stereo is supported");
            }
            if (format.getSampleSizeInBits() == 8) {
                n = 4354;
            }
            else {
                if (format.getSampleSizeInBits() != 16) {
                    throw new RuntimeException("Illegal sample size");
                }
                n = 4355;
            }
        }
        final byte[] b = new byte[format.getChannels() * (int)audioInputStream.getFrameLength() * format.getSampleSizeInBits() / 8];
        int read;
        for (int off = 0; (read = audioInputStream.read(b, off, b.length - off)) != -1 && off < b.length; off += read) {}
        final WaveData waveData = new WaveData(convertAudioBytes(b, format.getSampleSizeInBits() == 16), n, (int)format.getSampleRate());
        audioInputStream.close();
        return waveData;
    }
    
    public static ByteBuffer convertAudioBytes(final byte[] array, final boolean b) {
        final ByteBuffer allocateDirect = ByteBuffer.allocateDirect(array.length);
        allocateDirect.order(ByteOrder.nativeOrder());
        final ByteBuffer wrap = ByteBuffer.wrap(array);
        wrap.order(ByteOrder.LITTLE_ENDIAN);
        if (b) {
            final ShortBuffer shortBuffer = allocateDirect.asShortBuffer();
            final ShortBuffer shortBuffer2 = wrap.asShortBuffer();
            while (shortBuffer2.hasRemaining()) {
                shortBuffer.put(shortBuffer2.get());
            }
        }
        else {
            while (wrap.hasRemaining()) {
                allocateDirect.put(wrap.get());
            }
        }
        allocateDirect.rewind();
        return allocateDirect;
    }
}
