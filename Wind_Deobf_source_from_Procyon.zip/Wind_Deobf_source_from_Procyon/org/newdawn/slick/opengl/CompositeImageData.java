// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.opengl;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.io.InputStream;
import java.util.ArrayList;

public class CompositeImageData implements LoadableImageData
{
    public ArrayList sources;
    public LoadableImageData picked;
    
    public CompositeImageData() {
        this.sources = new ArrayList();
    }
    
    public void add(final LoadableImageData e) {
        this.sources.add(e);
    }
    
    @Override
    public ByteBuffer loadImage(final InputStream inputStream) throws IOException {
        return this.loadImage(inputStream, false, null);
    }
    
    @Override
    public ByteBuffer loadImage(final InputStream inputStream, final boolean b, final int[] array) throws IOException {
        return this.loadImage(inputStream, b, false, array);
    }
    
    @Override
    public ByteBuffer loadImage(final InputStream in, final boolean b, final boolean b2, final int[] array) throws IOException {
        final CompositeIOException ex = new CompositeIOException();
        ByteBuffer loadImage = null;
        final BufferedInputStream bufferedInputStream = new BufferedInputStream(in, in.available());
        bufferedInputStream.mark(in.available());
        final int index = 0;
        if (index < this.sources.size()) {
            bufferedInputStream.reset();
            final LoadableImageData picked = this.sources.get(index);
            loadImage = picked.loadImage(bufferedInputStream, b, b2, array);
            this.picked = picked;
        }
        if (this.picked == null) {
            throw ex;
        }
        return loadImage;
    }
    
    public void checkPicked() {
        if (this.picked == null) {
            throw new RuntimeException("Attempt to make use of uninitialised or invalid composite image data");
        }
    }
    
    @Override
    public int getDepth() {
        this.checkPicked();
        return this.picked.getDepth();
    }
    
    @Override
    public int getHeight() {
        this.checkPicked();
        return this.picked.getHeight();
    }
    
    @Override
    public ByteBuffer getImageBufferData() {
        this.checkPicked();
        return this.picked.getImageBufferData();
    }
    
    @Override
    public int getTexHeight() {
        this.checkPicked();
        return this.picked.getTexHeight();
    }
    
    @Override
    public int getTexWidth() {
        this.checkPicked();
        return this.picked.getTexWidth();
    }
    
    @Override
    public int getWidth() {
        this.checkPicked();
        return this.picked.getWidth();
    }
    
    @Override
    public void configureEdging(final boolean b) {
        for (int i = 0; i < this.sources.size(); ++i) {
            ((LoadableImageData)this.sources.get(i)).configureEdging(b);
        }
    }
}
