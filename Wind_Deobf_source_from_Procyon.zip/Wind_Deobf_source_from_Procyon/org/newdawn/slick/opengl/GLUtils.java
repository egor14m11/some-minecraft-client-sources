// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.opengl;

import org.newdawn.slick.opengl.renderer.Renderer;

public class GLUtils
{
    public static void checkGLContext() {
        Renderer.get().glGetError();
    }
}
