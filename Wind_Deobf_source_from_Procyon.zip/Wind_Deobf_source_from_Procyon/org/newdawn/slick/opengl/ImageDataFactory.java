// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.opengl;

import java.security.AccessController;
import org.newdawn.slick.util.Log;
import java.security.PrivilegedAction;

public class ImageDataFactory
{
    public static boolean usePngLoader;
    public static boolean pngLoaderPropertyChecked;
    public static String PNG_LOADER;
    
    public static void checkProperty() {
        if (!ImageDataFactory.pngLoaderPropertyChecked) {
            ImageDataFactory.pngLoaderPropertyChecked = true;
            AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction() {
                @Override
                public Object run() {
                    if ("false".equalsIgnoreCase(System.getProperty("org.newdawn.slick.pngloader"))) {
                        ImageDataFactory.access$002(false);
                    }
                    Log.info("Use Java PNG Loader = " + ImageDataFactory.access$000());
                    return null;
                }
            });
        }
    }
    
    public static LoadableImageData getImageDataFor(String lowerCase) {
        checkProperty();
        lowerCase = lowerCase.toLowerCase();
        if (lowerCase.endsWith(".tga")) {
            return new TGAImageData();
        }
        if (lowerCase.endsWith(".png")) {
            final CompositeImageData compositeImageData = new CompositeImageData();
            if (ImageDataFactory.usePngLoader) {
                compositeImageData.add(new PNGImageData());
            }
            compositeImageData.add(new ImageIOImageData());
            return compositeImageData;
        }
        return new ImageIOImageData();
    }
    
    public static boolean access$002(final boolean usePngLoader) {
        return ImageDataFactory.usePngLoader = usePngLoader;
    }
    
    public static boolean access$000() {
        return ImageDataFactory.usePngLoader;
    }
    
    static {
        ImageDataFactory.PNG_LOADER = "org.newdawn.slick.pngloader";
        ImageDataFactory.usePngLoader = true;
        ImageDataFactory.pngLoaderPropertyChecked = false;
    }
}
