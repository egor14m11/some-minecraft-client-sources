// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.opengl;

import org.newdawn.slick.util.Log;
import org.newdawn.slick.opengl.renderer.Renderer;
import org.lwjgl.BufferUtils;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.newdawn.slick.opengl.renderer.SGL;

public class TextureImpl implements Texture
{
    public static SGL GL;
    public static Texture lastBind;
    public int target;
    public int textureID;
    public int height;
    public int width;
    public int texWidth;
    public int texHeight;
    public float widthRatio;
    public float heightRatio;
    public boolean alpha;
    public String ref;
    public String cacheName;
    public ReloadData reloadData;
    
    public static Texture getLastBind() {
        return TextureImpl.lastBind;
    }
    
    public TextureImpl() {
    }
    
    public TextureImpl(final String ref, final int target, final int textureID) {
        this.target = target;
        this.ref = ref;
        this.textureID = textureID;
        TextureImpl.lastBind = this;
    }
    
    public void setCacheName(final String cacheName) {
        this.cacheName = cacheName;
    }
    
    @Override
    public boolean hasAlpha() {
        return this.alpha;
    }
    
    @Override
    public String getTextureRef() {
        return this.ref;
    }
    
    public void setAlpha(final boolean alpha) {
        this.alpha = alpha;
    }
    
    public static void bindNone() {
        TextureImpl.lastBind = null;
        TextureImpl.GL.glDisable(3553);
    }
    
    public static void unbind() {
        TextureImpl.lastBind = null;
    }
    
    @Override
    public void bind() {
        if (TextureImpl.lastBind != this) {
            TextureImpl.lastBind = this;
            TextureImpl.GL.glEnable(3553);
            TextureImpl.GL.glBindTexture(this.target, this.textureID);
        }
    }
    
    public void setHeight(final int height) {
        this.height = height;
        this.setHeight();
    }
    
    public void setWidth(final int width) {
        this.width = width;
        this.setWidth();
    }
    
    @Override
    public int getImageHeight() {
        return this.height;
    }
    
    @Override
    public int getImageWidth() {
        return this.width;
    }
    
    @Override
    public float getHeight() {
        return this.heightRatio;
    }
    
    @Override
    public float getWidth() {
        return this.widthRatio;
    }
    
    @Override
    public int getTextureHeight() {
        return this.texHeight;
    }
    
    @Override
    public int getTextureWidth() {
        return this.texWidth;
    }
    
    public void setTextureHeight(final int texHeight) {
        this.texHeight = texHeight;
        this.setHeight();
    }
    
    public void setTextureWidth(final int texWidth) {
        this.texWidth = texWidth;
        this.setWidth();
    }
    
    public void setHeight() {
        if (this.texHeight != 0) {
            this.heightRatio = this.height / (float)this.texHeight;
        }
    }
    
    public void setWidth() {
        if (this.texWidth != 0) {
            this.widthRatio = this.width / (float)this.texWidth;
        }
    }
    
    @Override
    public void release() {
        final IntBuffer intBuffer = this.createIntBuffer(1);
        intBuffer.put(this.textureID);
        intBuffer.flip();
        TextureImpl.GL.glDeleteTextures(intBuffer);
        if (TextureImpl.lastBind == this) {
            bindNone();
        }
        if (this.cacheName != null) {
            InternalTextureLoader.get().clear(this.cacheName);
        }
        else {
            InternalTextureLoader.get().clear(this.ref);
        }
    }
    
    @Override
    public int getTextureID() {
        return this.textureID;
    }
    
    public void setTextureID(final int textureID) {
        this.textureID = textureID;
    }
    
    public IntBuffer createIntBuffer(final int n) {
        final ByteBuffer allocateDirect = ByteBuffer.allocateDirect(4 * n);
        allocateDirect.order(ByteOrder.nativeOrder());
        return allocateDirect.asIntBuffer();
    }
    
    @Override
    public byte[] getTextureData() {
        final ByteBuffer byteBuffer = BufferUtils.createByteBuffer((this.hasAlpha() ? 4 : 3) * this.texWidth * this.texHeight);
        this.bind();
        TextureImpl.GL.glGetTexImage(3553, 0, this.hasAlpha() ? 6408 : 6407, 5121, byteBuffer);
        final byte[] dst = new byte[byteBuffer.limit()];
        byteBuffer.get(dst);
        byteBuffer.clear();
        return dst;
    }
    
    @Override
    public void setTextureFilter(final int n) {
        this.bind();
        TextureImpl.GL.glTexParameteri(this.target, 10241, n);
        TextureImpl.GL.glTexParameteri(this.target, 10240, n);
    }
    
    public void setTextureData(final int n, final int n2, final int n3, final int n4, final ByteBuffer byteBuffer) {
        ReloadData.access$102(this.reloadData = new ReloadData(null), n);
        ReloadData.access$202(this.reloadData, n2);
        ReloadData.access$302(this.reloadData, n3);
        ReloadData.access$402(this.reloadData, n4);
        ReloadData.access$502(this.reloadData, byteBuffer);
    }
    
    public void reload() {
        if (this.reloadData != null) {
            this.textureID = this.reloadData.reload();
        }
    }
    
    public static String access$600(final TextureImpl textureImpl) {
        return textureImpl.ref;
    }
    
    static {
        TextureImpl.GL = Renderer.get();
    }
    
    private class ReloadData
    {
        public int srcPixelFormat;
        public int componentCount;
        public int minFilter;
        public int magFilter;
        public ByteBuffer textureBuffer;
        public TextureImpl this$0;
        
        public ReloadData(final TextureImpl this$0) {
            this.this$0 = this$0;
        }
        
        public int reload() {
            Log.error("Reloading texture: " + TextureImpl.access$600(this.this$0));
            return InternalTextureLoader.get().reload(this.this$0, this.srcPixelFormat, this.componentCount, this.minFilter, this.magFilter, this.textureBuffer);
        }
        
        public ReloadData(final TextureImpl textureImpl, final TextureImpl$1 object) {
            this(textureImpl);
        }
        
        public static int access$102(final ReloadData reloadData, final int srcPixelFormat) {
            return reloadData.srcPixelFormat = srcPixelFormat;
        }
        
        public static int access$202(final ReloadData reloadData, final int componentCount) {
            return reloadData.componentCount = componentCount;
        }
        
        public static int access$302(final ReloadData reloadData, final int minFilter) {
            return reloadData.minFilter = minFilter;
        }
        
        public static int access$402(final ReloadData reloadData, final int magFilter) {
            return reloadData.magFilter = magFilter;
        }
        
        public static ByteBuffer access$502(final ReloadData reloadData, final ByteBuffer textureBuffer) {
            return reloadData.textureBuffer = textureBuffer;
        }
    }
}
