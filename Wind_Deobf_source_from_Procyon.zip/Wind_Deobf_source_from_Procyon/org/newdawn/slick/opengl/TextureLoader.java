// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.opengl;

import java.io.IOException;
import java.io.InputStream;

public class TextureLoader
{
    public static Texture getTexture(final String s, final InputStream inputStream) throws IOException {
        return getTexture(s, inputStream, false, 9729);
    }
    
    public static Texture getTexture(final String s, final InputStream inputStream, final boolean b) throws IOException {
        return getTexture(s, inputStream, b, 9729);
    }
    
    public static Texture getTexture(final String s, final InputStream inputStream, final int n) throws IOException {
        return getTexture(s, inputStream, false, n);
    }
    
    public static Texture getTexture(final String str, final InputStream inputStream, final boolean b, final int n) throws IOException {
        return InternalTextureLoader.get().getTexture(inputStream, inputStream.toString() + "." + str, b, n);
    }
}
