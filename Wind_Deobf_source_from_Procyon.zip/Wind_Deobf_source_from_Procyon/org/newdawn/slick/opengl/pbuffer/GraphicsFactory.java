// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.opengl.pbuffer;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.util.Log;
import org.newdawn.slick.SlickException;
import org.lwjgl.opengl.Pbuffer;
import org.lwjgl.opengl.GLContext;
import java.util.HashMap;

public class GraphicsFactory
{
    public static HashMap graphics;
    public static boolean pbuffer;
    public static boolean pbufferRT;
    public static boolean fbo;
    public static boolean init;
    
    public static void init() throws SlickException {
        GraphicsFactory.init = true;
        if (GraphicsFactory.fbo) {
            GraphicsFactory.fbo = GLContext.getCapabilities().GL_EXT_framebuffer_object;
        }
        GraphicsFactory.pbuffer = ((Pbuffer.getCapabilities() & 0x1) != 0x0);
        GraphicsFactory.pbufferRT = ((Pbuffer.getCapabilities() & 0x2) != 0x0);
        if (!GraphicsFactory.fbo && !GraphicsFactory.pbuffer && !GraphicsFactory.pbufferRT) {
            throw new SlickException("Your OpenGL card does not support offscreen buffers and hence can't handle the dynamic images required for this application.");
        }
        Log.info("Offscreen Buffers FBO=" + GraphicsFactory.fbo + " PBUFFER=" + GraphicsFactory.pbuffer + " PBUFFERRT=" + GraphicsFactory.pbufferRT);
    }
    
    public static void setUseFBO(final boolean fbo) {
        GraphicsFactory.fbo = fbo;
    }
    
    public static boolean usingFBO() {
        return GraphicsFactory.fbo;
    }
    
    public static boolean usingPBuffer() {
        return !GraphicsFactory.fbo && GraphicsFactory.pbuffer;
    }
    
    public static Graphics getGraphicsForImage(final Image image) throws SlickException {
        Graphics graphics = GraphicsFactory.graphics.get(image.getTexture());
        if (graphics == null) {
            graphics = createGraphics(image);
            GraphicsFactory.graphics.put(image.getTexture(), graphics);
        }
        return graphics;
    }
    
    public static void releaseGraphicsForImage(final Image image) throws SlickException {
        final Graphics graphics = GraphicsFactory.graphics.remove(image.getTexture());
        if (graphics != null) {
            graphics.destroy();
        }
    }
    
    public static Graphics createGraphics(final Image image) throws SlickException {
        init();
        if (GraphicsFactory.fbo) {
            return new FBOGraphics(image);
        }
        if (!GraphicsFactory.pbuffer) {
            throw new SlickException("Failed to create offscreen buffer even though the card reports it's possible");
        }
        if (GraphicsFactory.pbufferRT) {
            return new PBufferGraphics(image);
        }
        return new PBufferUniqueGraphics(image);
    }
    
    static {
        GraphicsFactory.graphics = new HashMap();
        GraphicsFactory.pbuffer = true;
        GraphicsFactory.pbufferRT = true;
        GraphicsFactory.fbo = true;
        GraphicsFactory.init = false;
    }
}
