// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.opengl.renderer;

public class Renderer
{
    public static int IMMEDIATE_RENDERER;
    public static int VERTEX_ARRAY_RENDERER;
    public static int DEFAULT_LINE_STRIP_RENDERER;
    public static int QUAD_BASED_LINE_STRIP_RENDERER;
    public static SGL renderer;
    public static LineStripRenderer lineStripRenderer;
    
    public static void setRenderer(final int i) {
        switch (i) {
            case 1: {
                setRenderer(new ImmediateModeOGLRenderer());
            }
            case 2: {
                setRenderer(new VAOGLRenderer());
            }
            default: {
                throw new RuntimeException("Unknown renderer type: " + i);
            }
        }
    }
    
    public static void setLineStripRenderer(final int i) {
        switch (i) {
            case 3: {
                setLineStripRenderer(new DefaultLineStripRenderer());
            }
            case 4: {
                setLineStripRenderer(new QuadBasedLineStripRenderer());
            }
            default: {
                throw new RuntimeException("Unknown line strip renderer type: " + i);
            }
        }
    }
    
    public static void setLineStripRenderer(final LineStripRenderer lineStripRenderer) {
        Renderer.lineStripRenderer = lineStripRenderer;
    }
    
    public static void setRenderer(final SGL renderer) {
        Renderer.renderer = renderer;
    }
    
    public static SGL get() {
        return Renderer.renderer;
    }
    
    public static LineStripRenderer getLineStripRenderer() {
        return Renderer.lineStripRenderer;
    }
    
    static {
        Renderer.QUAD_BASED_LINE_STRIP_RENDERER = 4;
        Renderer.DEFAULT_LINE_STRIP_RENDERER = 3;
        Renderer.VERTEX_ARRAY_RENDERER = 2;
        Renderer.IMMEDIATE_RENDERER = 1;
        Renderer.renderer = new ImmediateModeOGLRenderer();
        Renderer.lineStripRenderer = new DefaultLineStripRenderer();
    }
}
