// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.particles;

import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import org.newdawn.slick.util.FastTrig;
import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.Color;
import org.newdawn.slick.Image;
import java.util.ArrayList;

public class ConfigurableEmitter implements ParticleEmitter
{
    public static String relativePath;
    public Range spawnInterval;
    public Range spawnCount;
    public Range initialLife;
    public Range initialSize;
    public Range xOffset;
    public Range yOffset;
    public RandomValue spread;
    public SimpleValue angularOffset;
    public Range initialDistance;
    public Range speed;
    public SimpleValue growthFactor;
    public SimpleValue gravityFactor;
    public SimpleValue windFactor;
    public Range length;
    public ArrayList colors;
    public SimpleValue startAlpha;
    public SimpleValue endAlpha;
    public LinearInterpolator alpha;
    public LinearInterpolator size;
    public LinearInterpolator velocity;
    public LinearInterpolator scaleY;
    public Range emitCount;
    public int usePoints;
    public boolean useOriented;
    public boolean useAdditive;
    public String name;
    public String imageName;
    public Image image;
    public boolean updateImage;
    public boolean enabled;
    public float x;
    public float y;
    public int nextSpawn;
    public int timeout;
    public int particleCount;
    public ParticleSystem engine;
    public int leftToEmit;
    public boolean wrapUp;
    public boolean completed;
    public boolean adjust;
    public float adjustx;
    public float adjusty;
    
    public static void setRelativePath(String string) {
        if (!string.endsWith("/")) {
            string += "/";
        }
        ConfigurableEmitter.relativePath = string;
    }
    
    public ConfigurableEmitter(final String name) {
        this.spawnInterval = new Range(100.0f, 100.0f, null);
        this.spawnCount = new Range(5.0f, 5.0f, null);
        this.initialLife = new Range(1000.0f, 1000.0f, null);
        this.initialSize = new Range(10.0f, 10.0f, null);
        this.xOffset = new Range(0.0f, 0.0f, null);
        this.yOffset = new Range(0.0f, 0.0f, null);
        this.spread = new RandomValue(360.0f, null);
        this.angularOffset = new SimpleValue(0.0f, null);
        this.initialDistance = new Range(0.0f, 0.0f, null);
        this.speed = new Range(50.0f, 50.0f, null);
        this.growthFactor = new SimpleValue(0.0f, null);
        this.gravityFactor = new SimpleValue(0.0f, null);
        this.windFactor = new SimpleValue(0.0f, null);
        this.length = new Range(1000.0f, 1000.0f, null);
        this.colors = new ArrayList();
        this.startAlpha = new SimpleValue(255.0f, null);
        this.endAlpha = new SimpleValue(0.0f, null);
        this.emitCount = new Range(1000.0f, 1000.0f, null);
        this.usePoints = 1;
        this.useOriented = false;
        this.useAdditive = false;
        this.imageName = "";
        this.enabled = true;
        this.nextSpawn = 0;
        this.wrapUp = false;
        this.completed = false;
        this.name = name;
        this.leftToEmit = (int)this.emitCount.random();
        this.timeout = (int)this.length.random();
        this.colors.add(new ColorRecord(0.0f, Color.white));
        this.colors.add(new ColorRecord(1.0f, Color.red));
        final ArrayList<Vector2f> list = new ArrayList<Vector2f>();
        list.add(new Vector2f(0.0f, 0.0f));
        list.add(new Vector2f(1.0f, 255.0f));
        this.alpha = new LinearInterpolator(list, 0, 255);
        final ArrayList<Vector2f> list2 = new ArrayList<Vector2f>();
        list2.add(new Vector2f(0.0f, 0.0f));
        list2.add(new Vector2f(1.0f, 255.0f));
        this.size = new LinearInterpolator(list2, 0, 255);
        final ArrayList<Vector2f> list3 = new ArrayList<Vector2f>();
        list3.add(new Vector2f(0.0f, 0.0f));
        list3.add(new Vector2f(1.0f, 1.0f));
        this.velocity = new LinearInterpolator(list3, 0, 1);
        final ArrayList<Vector2f> list4 = new ArrayList<Vector2f>();
        list4.add(new Vector2f(0.0f, 0.0f));
        list4.add(new Vector2f(1.0f, 1.0f));
        this.scaleY = new LinearInterpolator(list4, 0, 1);
    }
    
    public void setImageName(String imageName) {
        if (imageName.length() == 0) {
            imageName = null;
        }
        if ((this.imageName = imageName) == null) {
            this.image = null;
        }
        else {
            this.updateImage = true;
        }
    }
    
    public String getImageName() {
        return this.imageName;
    }
    
    @Override
    public String toString() {
        return "[" + this.name + "]";
    }
    
    public void setPosition(final float n, final float n2) {
        this.setPosition(n, n2, true);
    }
    
    public void setPosition(final float x, final float y, final boolean b) {
        if (b) {
            this.adjust = true;
            this.adjustx -= this.x - x;
            this.adjusty -= this.y - y;
        }
        this.x = x;
        this.y = y;
    }
    
    public float getX() {
        return this.x;
    }
    
    public float getY() {
        return this.y;
    }
    
    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
    
    @Override
    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }
    
    @Override
    public void update(final ParticleSystem engine, final int n) {
        this.engine = engine;
        if (!this.adjust) {
            this.adjustx = 0.0f;
            this.adjusty = 0.0f;
        }
        else {
            this.adjust = false;
        }
        if (this.updateImage) {
            this.updateImage = false;
            this.image = new Image(ConfigurableEmitter.relativePath + this.imageName);
        }
        if ((this.wrapUp || (this.length.isEnabled() && this.timeout < 0) || (this.emitCount.isEnabled() && this.leftToEmit <= 0)) && this.particleCount == 0) {
            this.completed = true;
        }
        this.particleCount = 0;
        if (this.wrapUp) {
            return;
        }
        if (this.length.isEnabled()) {
            if (this.timeout < 0) {
                return;
            }
            this.timeout -= n;
        }
        if (this.emitCount.isEnabled() && this.leftToEmit <= 0) {
            return;
        }
        this.nextSpawn -= n;
        if (this.nextSpawn < 0) {
            this.nextSpawn = (int)this.spawnInterval.random();
            for (int n2 = (int)this.spawnCount.random(), i = 0; i < n2; ++i) {
                final Particle newParticle = engine.getNewParticle(this, this.initialLife.random());
                newParticle.setSize(this.initialSize.random());
                newParticle.setPosition(this.x + this.xOffset.random(), this.y + this.yOffset.random());
                newParticle.setVelocity(0.0f, 0.0f, 0.0f);
                final float random = this.initialDistance.random();
                final float random2 = this.speed.random();
                if (random != 0.0f || random2 != 0.0f) {
                    final float n3 = this.spread.getValue(0.0f) + this.angularOffset.getValue(0.0f) - this.spread.getValue() / 2.0f - 90.0f;
                    newParticle.adjustPosition((float)FastTrig.cos(Math.toRadians(n3)) * random, (float)FastTrig.sin(Math.toRadians(n3)) * random);
                    newParticle.setVelocity((float)FastTrig.cos(Math.toRadians(n3)), (float)FastTrig.sin(Math.toRadians(n3)), random2 * 0.0f);
                }
                if (this.image != null) {
                    newParticle.setImage(this.image);
                }
                final ColorRecord colorRecord = this.colors.get(0);
                newParticle.setColor(colorRecord.col.r, colorRecord.col.g, colorRecord.col.b, this.startAlpha.getValue(0.0f) / 255.0f);
                newParticle.setUsePoint(this.usePoints);
                newParticle.setOriented(this.useOriented);
                if (this.emitCount.isEnabled()) {
                    --this.leftToEmit;
                    if (this.leftToEmit <= 0) {
                        break;
                    }
                }
            }
        }
    }
    
    @Override
    public void updateParticle(final Particle particle, final int n) {
        ++this.particleCount;
        particle.x += this.adjustx;
        particle.y += this.adjusty;
        particle.adjustVelocity(this.windFactor.getValue(0.0f) * 0.0f * n, this.gravityFactor.getValue(0.0f) * 0.0f * n);
        final float n2 = particle.getLife() / particle.getOriginalLife();
        final float n3 = 1.0f - n2;
        float n4 = 0.0f;
        float n5 = 1.0f;
        Color col = null;
        Color col2 = null;
        for (int i = 0; i < this.colors.size() - 1; ++i) {
            final ColorRecord colorRecord = this.colors.get(i);
            final ColorRecord colorRecord2 = this.colors.get(i + 1);
            if (n3 >= colorRecord.pos && n3 <= colorRecord2.pos) {
                col = colorRecord.col;
                col2 = colorRecord2.col;
                n4 = 1.0f - (n3 - colorRecord.pos) / (colorRecord2.pos - colorRecord.pos);
                n5 = 1.0f - n4;
            }
        }
        if (col != null) {
            final float n6 = col.r * n4 + col2.r * n5;
            final float n7 = col.g * n4 + col2.g * n5;
            final float n8 = col.b * n4 + col2.b * n5;
            float n9;
            if (this.alpha.isActive()) {
                n9 = this.alpha.getValue(n3) / 255.0f;
            }
            else {
                n9 = this.startAlpha.getValue(0.0f) / 255.0f * n2 + this.endAlpha.getValue(0.0f) / 255.0f * n3;
            }
            particle.setColor(n6, n7, n8, n9);
        }
        if (this.size.isActive()) {
            particle.setSize(this.size.getValue(n3));
        }
        else {
            particle.adjustSize(n * this.growthFactor.getValue(0.0f) * 0.0f);
        }
        if (this.velocity.isActive()) {
            particle.setSpeed(this.velocity.getValue(n3));
        }
        if (this.scaleY.isActive()) {
            particle.setScaleY(this.scaleY.getValue(n3));
        }
    }
    
    @Override
    public boolean completed() {
        if (this.engine == null) {
            return false;
        }
        if (this.length.isEnabled()) {
            return this.timeout <= 0 && this.completed;
        }
        if (this.emitCount.isEnabled()) {
            return this.leftToEmit <= 0 && this.completed;
        }
        return this.wrapUp && this.completed;
    }
    
    public void replay() {
        this.reset();
        this.nextSpawn = 0;
        this.leftToEmit = (int)this.emitCount.random();
        this.timeout = (int)this.length.random();
    }
    
    public void reset() {
        this.completed = false;
        if (this.engine != null) {
            this.engine.releaseAll(this);
        }
    }
    
    public void replayCheck() {
        if (this.completed() && this.engine != null && this.engine.getParticleCount() == 0) {
            this.replay();
        }
    }
    
    public ConfigurableEmitter duplicate() {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ParticleIO.saveEmitter(byteArrayOutputStream, this);
        return ParticleIO.loadEmitter(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
    }
    
    public void addColorPoint(final float n, final Color color) {
        this.colors.add(new ColorRecord(n, color));
    }
    
    @Override
    public boolean useAdditive() {
        return this.useAdditive;
    }
    
    @Override
    public boolean isOriented() {
        return this.useOriented;
    }
    
    @Override
    public boolean usePoints(final ParticleSystem particleSystem) {
        return (this.usePoints == 1 && particleSystem.usePoints()) || this.usePoints == 2;
    }
    
    @Override
    public Image getImage() {
        return this.image;
    }
    
    @Override
    public void wrapUp() {
        this.wrapUp = true;
    }
    
    @Override
    public void resetState() {
        this.wrapUp = false;
        this.replay();
    }
    
    static {
        ConfigurableEmitter.relativePath = "";
    }
    
    public class SimpleValue implements Value
    {
        public float value;
        public float next;
        public ConfigurableEmitter this$0;
        
        public SimpleValue(final ConfigurableEmitter this$0, final float value) {
            this.this$0 = this$0;
            this.value = value;
        }
        
        @Override
        public float getValue(final float n) {
            return this.value;
        }
        
        public void setValue(final float value) {
            this.value = value;
        }
        
        public SimpleValue(final ConfigurableEmitter configurableEmitter, final float n, final ConfigurableEmitter$1 object) {
            this(configurableEmitter, n);
        }
    }
    
    public class RandomValue implements Value
    {
        public float value;
        public ConfigurableEmitter this$0;
        
        public RandomValue(final ConfigurableEmitter this$0, final float value) {
            this.this$0 = this$0;
            this.value = value;
        }
        
        @Override
        public float getValue(final float n) {
            return (float)(Math.random() * this.value);
        }
        
        public void setValue(final float value) {
            this.value = value;
        }
        
        public float getValue() {
            return this.value;
        }
        
        public RandomValue(final ConfigurableEmitter configurableEmitter, final float n, final ConfigurableEmitter$1 object) {
            this(configurableEmitter, n);
        }
    }
    
    public class LinearInterpolator implements Value
    {
        public ArrayList curve;
        public boolean active;
        public int min;
        public int max;
        public ConfigurableEmitter this$0;
        
        public LinearInterpolator(final ConfigurableEmitter this$0, final ArrayList curve, final int min, final int max) {
            this.this$0 = this$0;
            this.curve = curve;
            this.min = min;
            this.max = max;
            this.active = false;
        }
        
        public void setCurve(final ArrayList curve) {
            this.curve = curve;
        }
        
        public ArrayList getCurve() {
            return this.curve;
        }
        
        @Override
        public float getValue(final float n) {
            Vector2f vector2f = this.curve.get(0);
            for (int i = 1; i < this.curve.size(); ++i) {
                final Vector2f vector2f2 = this.curve.get(i);
                if (n >= vector2f.getX() && n <= vector2f2.getX()) {
                    return vector2f.getY() + (n - vector2f.getX()) / (vector2f2.getX() - vector2f.getX()) * (vector2f2.getY() - vector2f.getY());
                }
                vector2f = vector2f2;
            }
            return 0.0f;
        }
        
        public boolean isActive() {
            return this.active;
        }
        
        public void setActive(final boolean active) {
            this.active = active;
        }
        
        public int getMax() {
            return this.max;
        }
        
        public void setMax(final int max) {
            this.max = max;
        }
        
        public int getMin() {
            return this.min;
        }
        
        public void setMin(final int min) {
            this.min = min;
        }
    }
    
    public class ColorRecord
    {
        public float pos;
        public Color col;
        public ConfigurableEmitter this$0;
        
        public ColorRecord(final ConfigurableEmitter this$0, final float pos, final Color col) {
            this.this$0 = this$0;
            this.pos = pos;
            this.col = col;
        }
    }
    
    public class Range
    {
        public float max;
        public float min;
        public boolean enabled;
        public ConfigurableEmitter this$0;
        
        public Range(final ConfigurableEmitter this$0, final float min, final float max) {
            this.this$0 = this$0;
            this.enabled = false;
            this.min = min;
            this.max = max;
        }
        
        public float random() {
            return (float)(this.min + Math.random() * (this.max - this.min));
        }
        
        public boolean isEnabled() {
            return this.enabled;
        }
        
        public void setEnabled(final boolean enabled) {
            this.enabled = enabled;
        }
        
        public float getMax() {
            return this.max;
        }
        
        public void setMax(final float max) {
            this.max = max;
        }
        
        public float getMin() {
            return this.min;
        }
        
        public void setMin(final float min) {
            this.min = min;
        }
        
        public Range(final ConfigurableEmitter configurableEmitter, final float n, final float n2, final ConfigurableEmitter$1 object) {
            this(configurableEmitter, n, n2);
        }
    }
    
    public interface Value
    {
        float getValue(final float p0);
    }
}
