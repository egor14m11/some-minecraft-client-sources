// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.particles;

public interface ConfigurableEmitterFactory
{
    ConfigurableEmitter createEmitter(final String p0);
}
