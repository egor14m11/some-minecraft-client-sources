// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.particles;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.opengl.TextureImpl;
import org.newdawn.slick.Image;
import org.newdawn.slick.Color;
import org.newdawn.slick.opengl.renderer.SGL;

public class Particle
{
    public static SGL GL;
    public static int INHERIT_POINTS;
    public static int USE_POINTS;
    public static int USE_QUADS;
    public float x;
    public float y;
    public float velx;
    public float vely;
    public float size;
    public Color color;
    public float life;
    public float originalLife;
    public ParticleSystem engine;
    public ParticleEmitter emitter;
    public Image image;
    public int type;
    public int usePoints;
    public boolean oriented;
    public float scaleY;
    
    public Particle(final ParticleSystem engine) {
        this.size = 10.0f;
        this.color = Color.white;
        this.usePoints = 1;
        this.oriented = false;
        this.scaleY = 1.0f;
        this.engine = engine;
    }
    
    public float getX() {
        return this.x;
    }
    
    public float getY() {
        return this.y;
    }
    
    public void move(final float n, final float n2) {
        this.x += n;
        this.y += n2;
    }
    
    public float getSize() {
        return this.size;
    }
    
    public Color getColor() {
        return this.color;
    }
    
    public void setImage(final Image image) {
        this.image = image;
    }
    
    public float getOriginalLife() {
        return this.originalLife;
    }
    
    public float getLife() {
        return this.life;
    }
    
    public boolean inUse() {
        return this.life > 0.0f;
    }
    
    public void render() {
        if ((this.engine.usePoints() && this.usePoints == 1) || this.usePoints == 2) {
            TextureImpl.bindNone();
            Particle.GL.glEnable(2832);
            Particle.GL.glPointSize(this.size / 2.0f);
            this.color.bind();
            Particle.GL.glBegin(0);
            Particle.GL.glVertex2f(this.x, this.y);
            Particle.GL.glEnd();
        }
        else if (this.oriented || this.scaleY != 1.0f) {
            Particle.GL.glPushMatrix();
            Particle.GL.glTranslatef(this.x, this.y, 0.0f);
            if (this.oriented) {
                Particle.GL.glRotatef((float)(Math.atan2(this.y, this.x) * 180.0 / 3.141592653589793), 0.0f, 0.0f, 1.0f);
            }
            Particle.GL.glScalef(1.0f, this.scaleY, 1.0f);
            this.image.draw((float)(int)(-(this.size / 2.0f)), (float)(int)(-(this.size / 2.0f)), (float)(int)this.size, (float)(int)this.size, this.color);
            Particle.GL.glPopMatrix();
        }
        else {
            this.color.bind();
            this.image.drawEmbedded((float)(int)(this.x - this.size / 2.0f), (float)(int)(this.y - this.size / 2.0f), (float)(int)this.size, (float)(int)this.size);
        }
    }
    
    public void update(final int n) {
        this.emitter.updateParticle(this, n);
        this.life -= n;
        if (this.life > 0.0f) {
            this.x += n * this.velx;
            this.y += n * this.vely;
        }
        else {
            this.engine.release(this);
        }
    }
    
    public void init(final ParticleEmitter emitter, final float n) {
        this.x = 0.0f;
        this.emitter = emitter;
        this.y = 0.0f;
        this.velx = 0.0f;
        this.vely = 0.0f;
        this.size = 10.0f;
        this.type = 0;
        this.life = n;
        this.originalLife = n;
        this.oriented = false;
        this.scaleY = 1.0f;
    }
    
    public void setType(final int type) {
        this.type = type;
    }
    
    public void setUsePoint(final int usePoints) {
        this.usePoints = usePoints;
    }
    
    public int getType() {
        return this.type;
    }
    
    public void setSize(final float size) {
        this.size = size;
    }
    
    public void adjustSize(final float n) {
        this.size += n;
        this.size = Math.max(0.0f, this.size);
    }
    
    public void setLife(final float life) {
        this.life = life;
    }
    
    public void adjustLife(final float n) {
        this.life += n;
    }
    
    public void kill() {
        this.life = 1.0f;
    }
    
    public void setColor(final float r, final float g, final float b, final float a) {
        if (this.color == Color.white) {
            this.color = new Color(r, g, b, a);
        }
        else {
            this.color.r = r;
            this.color.g = g;
            this.color.b = b;
            this.color.a = a;
        }
    }
    
    public void setPosition(final float x, final float y) {
        this.x = x;
        this.y = y;
    }
    
    public void setVelocity(final float n, final float n2, final float n3) {
        this.velx = n * n3;
        this.vely = n2 * n3;
    }
    
    public void setSpeed(final float n) {
        final float n2 = (float)Math.sqrt(this.velx * this.velx + this.vely * this.vely);
        this.velx *= n;
        this.vely *= n;
        this.velx /= n2;
        this.vely /= n2;
    }
    
    public void setVelocity(final float n, final float n2) {
        this.setVelocity(n, n2, 1.0f);
    }
    
    public void adjustPosition(final float n, final float n2) {
        this.x += n;
        this.y += n2;
    }
    
    public void adjustColor(final float n, final float n2, final float n3, final float n4) {
        if (this.color == Color.white) {
            this.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        }
        final Color color = this.color;
        color.r += n;
        final Color color2 = this.color;
        color2.g += n2;
        final Color color3 = this.color;
        color3.b += n3;
        final Color color4 = this.color;
        color4.a += n4;
    }
    
    public void adjustColor(final int n, final int n2, final int n3, final int n4) {
        if (this.color == Color.white) {
            this.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        }
        final Color color = this.color;
        color.r += n / 255.0f;
        final Color color2 = this.color;
        color2.g += n2 / 255.0f;
        final Color color3 = this.color;
        color3.b += n3 / 255.0f;
        final Color color4 = this.color;
        color4.a += n4 / 255.0f;
    }
    
    public void adjustVelocity(final float n, final float n2) {
        this.velx += n;
        this.vely += n2;
    }
    
    public ParticleEmitter getEmitter() {
        return this.emitter;
    }
    
    @Override
    public String toString() {
        return super.toString() + " : " + this.life;
    }
    
    public boolean isOriented() {
        return this.oriented;
    }
    
    public void setOriented(final boolean oriented) {
        this.oriented = oriented;
    }
    
    public float getScaleY() {
        return this.scaleY;
    }
    
    public void setScaleY(final float scaleY) {
        this.scaleY = scaleY;
    }
    
    static {
        Particle.USE_QUADS = 3;
        Particle.USE_POINTS = 2;
        Particle.INHERIT_POINTS = 1;
        Particle.GL = Renderer.get();
    }
}
