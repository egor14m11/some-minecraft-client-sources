// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.particles;

import org.newdawn.slick.util.Log;
import org.newdawn.slick.geom.Vector2f;
import java.util.ArrayList;
import javax.xml.transform.Transformer;
import org.w3c.dom.Document;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import java.io.Writer;
import javax.xml.transform.stream.StreamResult;
import java.io.OutputStreamWriter;
import org.w3c.dom.Node;
import java.io.OutputStream;
import java.io.FileOutputStream;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;
import org.newdawn.slick.util.ResourceLoader;
import org.newdawn.slick.Color;

public class ParticleIO
{
    public static ParticleSystem loadConfiguredSystem(final String s, final Color color) throws IOException {
        return loadConfiguredSystem(ResourceLoader.getResourceAsStream(s), null, null, color);
    }
    
    public static ParticleSystem loadConfiguredSystem(final String s) throws IOException {
        return loadConfiguredSystem(ResourceLoader.getResourceAsStream(s), null, null, null);
    }
    
    public static ParticleSystem loadConfiguredSystem(final File file) throws IOException {
        return loadConfiguredSystem(new FileInputStream(file), null, null, null);
    }
    
    public static ParticleSystem loadConfiguredSystem(final InputStream inputStream, final Color color) throws IOException {
        return loadConfiguredSystem(inputStream, null, null, color);
    }
    
    public static ParticleSystem loadConfiguredSystem(final InputStream inputStream) throws IOException {
        return loadConfiguredSystem(inputStream, null, null, null);
    }
    
    public static ParticleSystem loadConfiguredSystem(final String s, final ConfigurableEmitterFactory configurableEmitterFactory) throws IOException {
        return loadConfiguredSystem(ResourceLoader.getResourceAsStream(s), configurableEmitterFactory, null, null);
    }
    
    public static ParticleSystem loadConfiguredSystem(final File file, final ConfigurableEmitterFactory configurableEmitterFactory) throws IOException {
        return loadConfiguredSystem(new FileInputStream(file), configurableEmitterFactory, null, null);
    }
    
    public static ParticleSystem loadConfiguredSystem(final InputStream inputStream, final ConfigurableEmitterFactory configurableEmitterFactory) throws IOException {
        return loadConfiguredSystem(inputStream, configurableEmitterFactory, null, null);
    }
    
    public static ParticleSystem loadConfiguredSystem(final InputStream is, ConfigurableEmitterFactory configurableEmitterFactory, ParticleSystem particleSystem, final Color color) throws IOException {
        if (configurableEmitterFactory == null) {
            configurableEmitterFactory = new ConfigurableEmitterFactory() {
                @Override
                public ConfigurableEmitter createEmitter(final String s) {
                    return new ConfigurableEmitter(s);
                }
            };
        }
        final Element documentElement = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is).getDocumentElement();
        if (!documentElement.getNodeName().equals("system")) {
            throw new IOException("Not a particle system file");
        }
        if (particleSystem == null) {
            particleSystem = new ParticleSystem("org/newdawn/slick/data/particle.tga", 2000, color);
        }
        if ("true".equals(documentElement.getAttribute("additive"))) {
            particleSystem.setBlendingMode(1);
        }
        else {
            particleSystem.setBlendingMode(2);
        }
        particleSystem.setUsePoints("true".equals(documentElement.getAttribute("points")));
        final NodeList elementsByTagName = documentElement.getElementsByTagName("emitter");
        for (int i = 0; i < elementsByTagName.getLength(); ++i) {
            final Element element = (Element)elementsByTagName.item(i);
            final ConfigurableEmitter emitter = configurableEmitterFactory.createEmitter("new");
            elementToEmitter(element, emitter);
            particleSystem.addEmitter(emitter);
        }
        particleSystem.setRemoveCompletedEmitters(false);
        return particleSystem;
    }
    
    public static void saveConfiguredSystem(final File file, final ParticleSystem particleSystem) throws IOException {
        saveConfiguredSystem(new FileOutputStream(file), particleSystem);
    }
    
    public static void saveConfiguredSystem(final OutputStream out, final ParticleSystem particleSystem) throws IOException {
        final Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        final Element element = document.createElement("system");
        element.setAttribute("additive", "" + (particleSystem.getBlendingMode() == 1));
        element.setAttribute("points", "" + particleSystem.usePoints());
        document.appendChild(element);
        for (int i = 0; i < particleSystem.getEmitterCount(); ++i) {
            final ParticleEmitter emitter = particleSystem.getEmitter(i);
            if (!(emitter instanceof ConfigurableEmitter)) {
                throw new RuntimeException("Only ConfigurableEmitter instances can be stored");
            }
            element.appendChild(emitterToElement(document, (ConfigurableEmitter)emitter));
        }
        final StreamResult streamResult = new StreamResult(new OutputStreamWriter(out, "utf-8"));
        final DOMSource domSource = new DOMSource(document);
        final Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty("indent", "yes");
        transformer.transform(domSource, streamResult);
    }
    
    public static ConfigurableEmitter loadEmitter(final String s) throws IOException {
        return loadEmitter(ResourceLoader.getResourceAsStream(s), null);
    }
    
    public static ConfigurableEmitter loadEmitter(final File file) throws IOException {
        return loadEmitter(new FileInputStream(file), null);
    }
    
    public static ConfigurableEmitter loadEmitter(final InputStream inputStream) throws IOException {
        return loadEmitter(inputStream, null);
    }
    
    public static ConfigurableEmitter loadEmitter(final String s, final ConfigurableEmitterFactory configurableEmitterFactory) throws IOException {
        return loadEmitter(ResourceLoader.getResourceAsStream(s), configurableEmitterFactory);
    }
    
    public static ConfigurableEmitter loadEmitter(final File file, final ConfigurableEmitterFactory configurableEmitterFactory) throws IOException {
        return loadEmitter(new FileInputStream(file), configurableEmitterFactory);
    }
    
    public static ConfigurableEmitter loadEmitter(final InputStream is, ConfigurableEmitterFactory configurableEmitterFactory) throws IOException {
        if (configurableEmitterFactory == null) {
            configurableEmitterFactory = new ConfigurableEmitterFactory() {
                @Override
                public ConfigurableEmitter createEmitter(final String s) {
                    return new ConfigurableEmitter(s);
                }
            };
        }
        final Document parse = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is);
        if (!parse.getDocumentElement().getNodeName().equals("emitter")) {
            throw new IOException("Not a particle emitter file");
        }
        final ConfigurableEmitter emitter = configurableEmitterFactory.createEmitter("new");
        elementToEmitter(parse.getDocumentElement(), emitter);
        return emitter;
    }
    
    public static void saveEmitter(final File file, final ConfigurableEmitter configurableEmitter) throws IOException {
        saveEmitter(new FileOutputStream(file), configurableEmitter);
    }
    
    public static void saveEmitter(final OutputStream out, final ConfigurableEmitter configurableEmitter) throws IOException {
        final Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        document.appendChild(emitterToElement(document, configurableEmitter));
        final StreamResult streamResult = new StreamResult(new OutputStreamWriter(out, "utf-8"));
        final DOMSource domSource = new DOMSource(document);
        final Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty("indent", "yes");
        transformer.transform(domSource, streamResult);
    }
    
    public static Element getFirstNamedElement(final Element element, final String s) {
        final NodeList elementsByTagName = element.getElementsByTagName(s);
        if (elementsByTagName.getLength() == 0) {
            return null;
        }
        return (Element)elementsByTagName.item(0);
    }
    
    public static void elementToEmitter(final Element element, final ConfigurableEmitter configurableEmitter) {
        configurableEmitter.name = element.getAttribute("name");
        configurableEmitter.setImageName(element.getAttribute("imageName"));
        final String attribute = element.getAttribute("renderType");
        configurableEmitter.usePoints = 1;
        if (attribute.equals("quads")) {
            configurableEmitter.usePoints = 3;
        }
        if (attribute.equals("points")) {
            configurableEmitter.usePoints = 2;
        }
        final String attribute2 = element.getAttribute("useOriented");
        if (attribute2 != null) {
            configurableEmitter.useOriented = "true".equals(attribute2);
        }
        final String attribute3 = element.getAttribute("useAdditive");
        if (attribute3 != null) {
            configurableEmitter.useAdditive = "true".equals(attribute3);
        }
        parseRangeElement(getFirstNamedElement(element, "spawnInterval"), configurableEmitter.spawnInterval);
        parseRangeElement(getFirstNamedElement(element, "spawnCount"), configurableEmitter.spawnCount);
        parseRangeElement(getFirstNamedElement(element, "initialLife"), configurableEmitter.initialLife);
        parseRangeElement(getFirstNamedElement(element, "initialSize"), configurableEmitter.initialSize);
        parseRangeElement(getFirstNamedElement(element, "xOffset"), configurableEmitter.xOffset);
        parseRangeElement(getFirstNamedElement(element, "yOffset"), configurableEmitter.yOffset);
        parseRangeElement(getFirstNamedElement(element, "initialDistance"), configurableEmitter.initialDistance);
        parseRangeElement(getFirstNamedElement(element, "speed"), configurableEmitter.speed);
        parseRangeElement(getFirstNamedElement(element, "length"), configurableEmitter.length);
        parseRangeElement(getFirstNamedElement(element, "emitCount"), configurableEmitter.emitCount);
        parseValueElement(getFirstNamedElement(element, "spread"), configurableEmitter.spread);
        parseValueElement(getFirstNamedElement(element, "angularOffset"), configurableEmitter.angularOffset);
        parseValueElement(getFirstNamedElement(element, "growthFactor"), configurableEmitter.growthFactor);
        parseValueElement(getFirstNamedElement(element, "gravityFactor"), configurableEmitter.gravityFactor);
        parseValueElement(getFirstNamedElement(element, "windFactor"), configurableEmitter.windFactor);
        parseValueElement(getFirstNamedElement(element, "startAlpha"), configurableEmitter.startAlpha);
        parseValueElement(getFirstNamedElement(element, "endAlpha"), configurableEmitter.endAlpha);
        parseValueElement(getFirstNamedElement(element, "alpha"), configurableEmitter.alpha);
        parseValueElement(getFirstNamedElement(element, "size"), configurableEmitter.size);
        parseValueElement(getFirstNamedElement(element, "velocity"), configurableEmitter.velocity);
        parseValueElement(getFirstNamedElement(element, "scaleY"), configurableEmitter.scaleY);
        final NodeList elementsByTagName = getFirstNamedElement(element, "color").getElementsByTagName("step");
        configurableEmitter.colors.clear();
        for (int i = 0; i < elementsByTagName.getLength(); ++i) {
            final Element element2 = (Element)elementsByTagName.item(i);
            configurableEmitter.addColorPoint(Float.parseFloat(element2.getAttribute("offset")), new Color(Float.parseFloat(element2.getAttribute("r")), Float.parseFloat(element2.getAttribute("g")), Float.parseFloat(element2.getAttribute("b")), 1.0f));
        }
        configurableEmitter.replay();
    }
    
    public static Element emitterToElement(final Document document, final ConfigurableEmitter configurableEmitter) {
        final Element element = document.createElement("emitter");
        element.setAttribute("name", configurableEmitter.name);
        element.setAttribute("imageName", (configurableEmitter.imageName == null) ? "" : configurableEmitter.imageName);
        element.setAttribute("useOriented", configurableEmitter.useOriented ? "true" : "false");
        element.setAttribute("useAdditive", configurableEmitter.useAdditive ? "true" : "false");
        if (configurableEmitter.usePoints == 1) {
            element.setAttribute("renderType", "inherit");
        }
        if (configurableEmitter.usePoints == 2) {
            element.setAttribute("renderType", "points");
        }
        if (configurableEmitter.usePoints == 3) {
            element.setAttribute("renderType", "quads");
        }
        element.appendChild(createRangeElement(document, "spawnInterval", configurableEmitter.spawnInterval));
        element.appendChild(createRangeElement(document, "spawnCount", configurableEmitter.spawnCount));
        element.appendChild(createRangeElement(document, "initialLife", configurableEmitter.initialLife));
        element.appendChild(createRangeElement(document, "initialSize", configurableEmitter.initialSize));
        element.appendChild(createRangeElement(document, "xOffset", configurableEmitter.xOffset));
        element.appendChild(createRangeElement(document, "yOffset", configurableEmitter.yOffset));
        element.appendChild(createRangeElement(document, "initialDistance", configurableEmitter.initialDistance));
        element.appendChild(createRangeElement(document, "speed", configurableEmitter.speed));
        element.appendChild(createRangeElement(document, "length", configurableEmitter.length));
        element.appendChild(createRangeElement(document, "emitCount", configurableEmitter.emitCount));
        element.appendChild(createValueElement(document, "spread", configurableEmitter.spread));
        element.appendChild(createValueElement(document, "angularOffset", configurableEmitter.angularOffset));
        element.appendChild(createValueElement(document, "growthFactor", configurableEmitter.growthFactor));
        element.appendChild(createValueElement(document, "gravityFactor", configurableEmitter.gravityFactor));
        element.appendChild(createValueElement(document, "windFactor", configurableEmitter.windFactor));
        element.appendChild(createValueElement(document, "startAlpha", configurableEmitter.startAlpha));
        element.appendChild(createValueElement(document, "endAlpha", configurableEmitter.endAlpha));
        element.appendChild(createValueElement(document, "alpha", configurableEmitter.alpha));
        element.appendChild(createValueElement(document, "size", configurableEmitter.size));
        element.appendChild(createValueElement(document, "velocity", configurableEmitter.velocity));
        element.appendChild(createValueElement(document, "scaleY", configurableEmitter.scaleY));
        final Element element2 = document.createElement("color");
        final ArrayList colors = configurableEmitter.colors;
        for (int i = 0; i < colors.size(); ++i) {
            final ConfigurableEmitter.ColorRecord colorRecord = colors.get(i);
            final Element element3 = document.createElement("step");
            element3.setAttribute("offset", "" + colorRecord.pos);
            element3.setAttribute("r", "" + colorRecord.col.r);
            element3.setAttribute("g", "" + colorRecord.col.g);
            element3.setAttribute("b", "" + colorRecord.col.b);
            element2.appendChild(element3);
        }
        element.appendChild(element2);
        return element;
    }
    
    public static Element createRangeElement(final Document document, final String s, final ConfigurableEmitter.Range range) {
        final Element element = document.createElement(s);
        element.setAttribute("min", "" + range.getMin());
        element.setAttribute("max", "" + range.getMax());
        element.setAttribute("enabled", "" + range.isEnabled());
        return element;
    }
    
    public static Element createValueElement(final Document document, final String s, final ConfigurableEmitter.Value value) {
        final Element element = document.createElement(s);
        if (value instanceof ConfigurableEmitter.SimpleValue) {
            element.setAttribute("type", "simple");
            element.setAttribute("value", "" + value.getValue(0.0f));
        }
        else if (value instanceof ConfigurableEmitter.RandomValue) {
            element.setAttribute("type", "random");
            element.setAttribute("value", "" + ((ConfigurableEmitter.RandomValue)value).getValue());
        }
        else if (value instanceof ConfigurableEmitter.LinearInterpolator) {
            element.setAttribute("type", "linear");
            element.setAttribute("min", "" + ((ConfigurableEmitter.LinearInterpolator)value).getMin());
            element.setAttribute("max", "" + ((ConfigurableEmitter.LinearInterpolator)value).getMax());
            element.setAttribute("active", "" + ((ConfigurableEmitter.LinearInterpolator)value).isActive());
            final ArrayList curve = ((ConfigurableEmitter.LinearInterpolator)value).getCurve();
            for (int i = 0; i < curve.size(); ++i) {
                final Vector2f vector2f = curve.get(i);
                final Element element2 = document.createElement("point");
                element2.setAttribute("x", "" + vector2f.x);
                element2.setAttribute("y", "" + vector2f.y);
                element.appendChild(element2);
            }
        }
        else {
            Log.warn("unkown value type ignored: " + value.getClass());
        }
        return element;
    }
    
    public static void parseRangeElement(final Element element, final ConfigurableEmitter.Range range) {
        if (element == null) {
            return;
        }
        range.setMin(Float.parseFloat(element.getAttribute("min")));
        range.setMax(Float.parseFloat(element.getAttribute("max")));
        range.setEnabled("true".equals(element.getAttribute("enabled")));
    }
    
    public static void parseValueElement(final Element obj, final ConfigurableEmitter.Value value) {
        if (obj == null) {
            return;
        }
        final String attribute = obj.getAttribute("type");
        final String attribute2 = obj.getAttribute("value");
        if (attribute == null || attribute.length() == 0) {
            if (value instanceof ConfigurableEmitter.SimpleValue) {
                ((ConfigurableEmitter.SimpleValue)value).setValue(Float.parseFloat(attribute2));
            }
            else if (value instanceof ConfigurableEmitter.RandomValue) {
                ((ConfigurableEmitter.RandomValue)value).setValue(Float.parseFloat(attribute2));
            }
            else {
                Log.warn("problems reading element, skipping: " + obj);
            }
        }
        else if (attribute.equals("simple")) {
            ((ConfigurableEmitter.SimpleValue)value).setValue(Float.parseFloat(attribute2));
        }
        else if (attribute.equals("random")) {
            ((ConfigurableEmitter.RandomValue)value).setValue(Float.parseFloat(attribute2));
        }
        else if (attribute.equals("linear")) {
            final String attribute3 = obj.getAttribute("min");
            final String attribute4 = obj.getAttribute("max");
            final String attribute5 = obj.getAttribute("active");
            final NodeList elementsByTagName = obj.getElementsByTagName("point");
            final ArrayList<Vector2f> curve = new ArrayList<Vector2f>();
            for (int i = 0; i < elementsByTagName.getLength(); ++i) {
                final Element element = (Element)elementsByTagName.item(i);
                curve.add(new Vector2f(Float.parseFloat(element.getAttribute("x")), Float.parseFloat(element.getAttribute("y"))));
            }
            ((ConfigurableEmitter.LinearInterpolator)value).setCurve(curve);
            ((ConfigurableEmitter.LinearInterpolator)value).setMin(Integer.parseInt(attribute3));
            ((ConfigurableEmitter.LinearInterpolator)value).setMax(Integer.parseInt(attribute4));
            ((ConfigurableEmitter.LinearInterpolator)value).setActive("true".equals(attribute5));
        }
        else {
            Log.warn("unkown type detected: " + attribute);
        }
    }
}
