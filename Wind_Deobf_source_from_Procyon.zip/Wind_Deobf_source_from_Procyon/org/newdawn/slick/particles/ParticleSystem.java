// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.particles;

import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.util.Log;
import java.util.Collection;
import java.security.AccessController;
import java.security.PrivilegedAction;
import org.newdawn.slick.opengl.TextureImpl;
import org.newdawn.slick.opengl.renderer.Renderer;
import java.util.Iterator;
import org.newdawn.slick.Color;
import org.newdawn.slick.Image;
import java.util.HashMap;
import java.util.ArrayList;
import org.newdawn.slick.opengl.renderer.SGL;

public class ParticleSystem
{
    public SGL GL;
    public static int BLEND_ADDITIVE;
    public static int BLEND_COMBINE;
    public static int DEFAULT_PARTICLES;
    public ArrayList removeMe;
    public HashMap particlesByEmitter;
    public int maxParticlesPerEmitter;
    public ArrayList emitters;
    public Particle dummy;
    public int blendingMode;
    public int pCount;
    public boolean usePoints;
    public float x;
    public float y;
    public boolean removeCompletedEmitters;
    public Image sprite;
    public boolean visible;
    public String defaultImageName;
    public Color mask;
    
    public static void setRelativePath(final String relativePath) {
        ConfigurableEmitter.setRelativePath(relativePath);
    }
    
    public ParticleSystem(final Image image) {
        this(image, 100);
    }
    
    public ParticleSystem(final String s) {
        this(s, 100);
    }
    
    public void reset() {
        final Iterator<ParticlePool> iterator = this.particlesByEmitter.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().reset(this);
        }
        for (int i = 0; i < this.emitters.size(); ++i) {
            ((ParticleEmitter)this.emitters.get(i)).resetState();
        }
    }
    
    public boolean isVisible() {
        return this.visible;
    }
    
    public void setVisible(final boolean visible) {
        this.visible = visible;
    }
    
    public void setRemoveCompletedEmitters(final boolean removeCompletedEmitters) {
        this.removeCompletedEmitters = removeCompletedEmitters;
    }
    
    public void setUsePoints(final boolean usePoints) {
        this.usePoints = usePoints;
    }
    
    public boolean usePoints() {
        return this.usePoints;
    }
    
    public ParticleSystem(final String s, final int n) {
        this(s, n, null);
    }
    
    public ParticleSystem(final String defaultImageName, final int maxParticlesPerEmitter, final Color mask) {
        this.GL = Renderer.get();
        this.removeMe = new ArrayList();
        this.particlesByEmitter = new HashMap();
        this.emitters = new ArrayList();
        this.blendingMode = 2;
        this.removeCompletedEmitters = true;
        this.visible = true;
        this.maxParticlesPerEmitter = maxParticlesPerEmitter;
        this.mask = mask;
        this.setDefaultImageName(defaultImageName);
        this.dummy = this.createParticle(this);
    }
    
    public ParticleSystem(final Image sprite, final int maxParticlesPerEmitter) {
        this.GL = Renderer.get();
        this.removeMe = new ArrayList();
        this.particlesByEmitter = new HashMap();
        this.emitters = new ArrayList();
        this.blendingMode = 2;
        this.removeCompletedEmitters = true;
        this.visible = true;
        this.maxParticlesPerEmitter = maxParticlesPerEmitter;
        this.sprite = sprite;
        this.dummy = this.createParticle(this);
    }
    
    public void setDefaultImageName(final String defaultImageName) {
        this.defaultImageName = defaultImageName;
        this.sprite = null;
    }
    
    public int getBlendingMode() {
        return this.blendingMode;
    }
    
    public Particle createParticle(final ParticleSystem particleSystem) {
        return new Particle(particleSystem);
    }
    
    public void setBlendingMode(final int blendingMode) {
        this.blendingMode = blendingMode;
    }
    
    public int getEmitterCount() {
        return this.emitters.size();
    }
    
    public ParticleEmitter getEmitter(final int index) {
        return this.emitters.get(index);
    }
    
    public void addEmitter(final ParticleEmitter particleEmitter) {
        this.emitters.add(particleEmitter);
        this.particlesByEmitter.put(particleEmitter, new ParticlePool(this, this.maxParticlesPerEmitter));
    }
    
    public void removeEmitter(final ParticleEmitter particleEmitter) {
        this.emitters.remove(particleEmitter);
        this.particlesByEmitter.remove(particleEmitter);
    }
    
    public void removeAllEmitters() {
        for (int i = 0; i < this.emitters.size(); --i, ++i) {
            this.removeEmitter((ParticleEmitter)this.emitters.get(i));
        }
    }
    
    public float getPositionX() {
        return this.x;
    }
    
    public float getPositionY() {
        return this.y;
    }
    
    public void setPosition(final float x, final float y) {
        this.x = x;
        this.y = y;
    }
    
    public void render() {
        this.render(this.x, this.y);
    }
    
    public void render(final float n, final float n2) {
        if (this.sprite == null && this.defaultImageName != null) {
            this.loadSystemParticleImage();
        }
        if (!this.visible) {
            return;
        }
        this.GL.glTranslatef(n, n2, 0.0f);
        if (this.blendingMode == 1) {
            this.GL.glBlendFunc(770, 1);
        }
        if (this.usePoints()) {
            this.GL.glEnable(2832);
            TextureImpl.bindNone();
        }
        for (int i = 0; i < this.emitters.size(); ++i) {
            final ParticleEmitter key = this.emitters.get(i);
            if (key.isEnabled()) {
                if (key.useAdditive()) {
                    this.GL.glBlendFunc(770, 1);
                }
                final ParticlePool particlePool = this.particlesByEmitter.get(key);
                Image image = key.getImage();
                if (image == null) {
                    image = this.sprite;
                }
                if (!key.isOriented() && !key.usePoints(this)) {
                    image.startUse();
                }
                for (int j = 0; j < particlePool.particles.length; ++j) {
                    if (particlePool.particles[j].inUse()) {
                        particlePool.particles[j].render();
                    }
                }
                if (!key.isOriented() && !key.usePoints(this)) {
                    image.endUse();
                }
                if (key.useAdditive()) {
                    this.GL.glBlendFunc(770, 771);
                }
            }
        }
        if (this.usePoints()) {
            this.GL.glDisable(2832);
        }
        if (this.blendingMode == 1) {
            this.GL.glBlendFunc(770, 771);
        }
        Color.white.bind();
        this.GL.glTranslatef(-n, -n2, 0.0f);
    }
    
    public void loadSystemParticleImage() {
        AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction(this) {
            public ParticleSystem this$0;
            
            @Override
            public Object run() {
                if (ParticleSystem.access$000(this.this$0) != null) {
                    ParticleSystem.access$102(this.this$0, new Image(ParticleSystem.access$200(this.this$0), ParticleSystem.access$000(this.this$0)));
                }
                else {
                    ParticleSystem.access$102(this.this$0, new Image(ParticleSystem.access$200(this.this$0)));
                }
                return null;
            }
        });
    }
    
    public void update(final int n) {
        if (this.sprite == null && this.defaultImageName != null) {
            this.loadSystemParticleImage();
        }
        this.removeMe.clear();
        final ArrayList<ParticleEmitter> list = new ArrayList<ParticleEmitter>(this.emitters);
        for (int i = 0; i < list.size(); ++i) {
            final ParticleEmitter particleEmitter = list.get(i);
            if (particleEmitter.isEnabled()) {
                particleEmitter.update(this, n);
                if (this.removeCompletedEmitters && particleEmitter.completed()) {
                    this.removeMe.add(particleEmitter);
                    this.particlesByEmitter.remove(particleEmitter);
                }
            }
        }
        this.emitters.removeAll(this.removeMe);
        this.pCount = 0;
        if (!this.particlesByEmitter.isEmpty()) {
            for (final ParticleEmitter key : this.particlesByEmitter.keySet()) {
                if (key.isEnabled()) {
                    final ParticlePool particlePool = this.particlesByEmitter.get(key);
                    for (int j = 0; j < particlePool.particles.length; ++j) {
                        if (particlePool.particles[j].life > 0.0f) {
                            particlePool.particles[j].update(n);
                            ++this.pCount;
                        }
                    }
                }
            }
        }
    }
    
    public int getParticleCount() {
        return this.pCount;
    }
    
    public Particle getNewParticle(final ParticleEmitter key, final float n) {
        final ArrayList available = this.particlesByEmitter.get(key).available;
        if (available.size() > 0) {
            final Particle particle = available.remove(available.size() - 1);
            particle.init(key, n);
            particle.setImage(this.sprite);
            return particle;
        }
        Log.warn("Ran out of particles (increase the limit)!");
        return this.dummy;
    }
    
    public void release(final Particle e) {
        if (e != this.dummy) {
            this.particlesByEmitter.get(e.getEmitter()).available.add(e);
        }
    }
    
    public void releaseAll(final ParticleEmitter particleEmitter) {
        if (!this.particlesByEmitter.isEmpty()) {
            for (final ParticlePool particlePool : this.particlesByEmitter.values()) {
                for (int i = 0; i < particlePool.particles.length; ++i) {
                    if (particlePool.particles[i].inUse() && particlePool.particles[i].getEmitter() == particleEmitter) {
                        particlePool.particles[i].setLife(-1.0f);
                        this.release(particlePool.particles[i]);
                    }
                }
            }
        }
    }
    
    public void moveAll(final ParticleEmitter key, final float n, final float n2) {
        final ParticlePool particlePool = this.particlesByEmitter.get(key);
        for (int i = 0; i < particlePool.particles.length; ++i) {
            if (particlePool.particles[i].inUse()) {
                particlePool.particles[i].move(n, n2);
            }
        }
    }
    
    public ParticleSystem duplicate() throws SlickException {
        for (int i = 0; i < this.emitters.size(); ++i) {
            if (!(this.emitters.get(i) instanceof ConfigurableEmitter)) {
                throw new SlickException("Only systems contianing configurable emitters can be duplicated");
            }
        }
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ParticleIO.saveConfiguredSystem(byteArrayOutputStream, this);
        return ParticleIO.loadConfiguredSystem(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
    }
    
    public static Color access$000(final ParticleSystem particleSystem) {
        return particleSystem.mask;
    }
    
    public static Image access$102(final ParticleSystem particleSystem, final Image sprite) {
        return particleSystem.sprite = sprite;
    }
    
    public static String access$200(final ParticleSystem particleSystem) {
        return particleSystem.defaultImageName;
    }
    
    public static String access$202(final ParticleSystem particleSystem, final String defaultImageName) {
        return particleSystem.defaultImageName = defaultImageName;
    }
    
    static {
        ParticleSystem.DEFAULT_PARTICLES = 100;
        ParticleSystem.BLEND_COMBINE = 2;
        ParticleSystem.BLEND_ADDITIVE = 1;
    }
    
    private class ParticlePool
    {
        public Particle[] particles;
        public ArrayList available;
        public ParticleSystem this$0;
        
        public ParticlePool(final ParticleSystem this$0, final ParticleSystem particleSystem, final int n) {
            this.this$0 = this$0;
            this.particles = new Particle[n];
            this.available = new ArrayList();
            for (int i = 0; i < this.particles.length; ++i) {
                this.particles[i] = this$0.createParticle(particleSystem);
            }
            this.reset(particleSystem);
        }
        
        public void reset(final ParticleSystem particleSystem) {
            this.available.clear();
            for (int i = 0; i < this.particles.length; ++i) {
                this.available.add(this.particles[i]);
            }
        }
    }
}
