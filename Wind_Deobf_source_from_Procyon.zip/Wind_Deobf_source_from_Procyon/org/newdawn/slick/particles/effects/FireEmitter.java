// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.particles.effects;

import org.newdawn.slick.Image;
import org.newdawn.slick.particles.Particle;
import org.newdawn.slick.particles.ParticleSystem;
import org.newdawn.slick.particles.ParticleEmitter;

public class FireEmitter implements ParticleEmitter
{
    public int x;
    public int y;
    public int interval;
    public int timer;
    public float size;
    
    public FireEmitter() {
        this.interval = 50;
        this.size = 40.0f;
    }
    
    public FireEmitter(final int x, final int y) {
        this.interval = 50;
        this.size = 40.0f;
        this.x = x;
        this.y = y;
    }
    
    public FireEmitter(final int x, final int y, final float size) {
        this.interval = 50;
        this.size = 40.0f;
        this.x = x;
        this.y = y;
        this.size = size;
    }
    
    @Override
    public void update(final ParticleSystem particleSystem, final int n) {
        this.timer -= n;
        if (this.timer <= 0) {
            this.timer = this.interval;
            final Particle newParticle = particleSystem.getNewParticle(this, 1000.0f);
            newParticle.setColor(1.0f, 1.0f, 1.0f, 0.0f);
            newParticle.setPosition((float)this.x, (float)this.y);
            newParticle.setSize(this.size);
            newParticle.setVelocity((float)(-0.019999999552965164 + Math.random() * 0.0), (float)(-(Math.random() * 0.0)), 1.0f);
        }
    }
    
    @Override
    public void updateParticle(final Particle particle, final int n) {
        if (particle.getLife() > 600.0f) {
            particle.adjustSize(0.0f * n);
        }
        else {
            particle.adjustSize(-0.04f * n * (this.size / 40.0f));
        }
        final float n2 = 0.0f * n;
        particle.adjustColor(0.0f, -n2 / 2.0f, -n2 * 2.0f, -n2 / 4.0f);
    }
    
    @Override
    public boolean isEnabled() {
        return true;
    }
    
    @Override
    public void setEnabled(final boolean b) {
    }
    
    @Override
    public boolean completed() {
        return false;
    }
    
    @Override
    public boolean useAdditive() {
        return false;
    }
    
    @Override
    public Image getImage() {
        return null;
    }
    
    @Override
    public boolean usePoints(final ParticleSystem particleSystem) {
        return false;
    }
    
    @Override
    public boolean isOriented() {
        return false;
    }
    
    @Override
    public void wrapUp() {
    }
    
    @Override
    public void resetState() {
    }
}
