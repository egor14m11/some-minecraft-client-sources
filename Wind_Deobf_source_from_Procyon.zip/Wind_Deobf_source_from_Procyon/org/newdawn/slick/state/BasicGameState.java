// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.state;

import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Input;

public abstract class BasicGameState implements GameState
{
    @Override
    public void inputStarted() {
    }
    
    @Override
    public boolean isAcceptingInput() {
        return true;
    }
    
    @Override
    public void setInput(final Input input) {
    }
    
    @Override
    public void inputEnded() {
    }
    
    @Override
    public abstract int getID();
    
    @Override
    public void controllerButtonPressed(final int n, final int n2) {
    }
    
    @Override
    public void controllerButtonReleased(final int n, final int n2) {
    }
    
    @Override
    public void controllerDownPressed(final int n) {
    }
    
    @Override
    public void controllerDownReleased(final int n) {
    }
    
    @Override
    public void controllerLeftPressed(final int n) {
    }
    
    @Override
    public void controllerLeftReleased(final int n) {
    }
    
    @Override
    public void controllerRightPressed(final int n) {
    }
    
    @Override
    public void controllerRightReleased(final int n) {
    }
    
    @Override
    public void controllerUpPressed(final int n) {
    }
    
    @Override
    public void controllerUpReleased(final int n) {
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
    }
    
    @Override
    public void keyReleased(final int n, final char c) {
    }
    
    @Override
    public void mouseMoved(final int n, final int n2, final int n3, final int n4) {
    }
    
    @Override
    public void mouseDragged(final int n, final int n2, final int n3, final int n4) {
    }
    
    @Override
    public void mouseClicked(final int n, final int n2, final int n3, final int n4) {
    }
    
    @Override
    public void mousePressed(final int n, final int n2, final int n3) {
    }
    
    @Override
    public void mouseReleased(final int n, final int n2, final int n3) {
    }
    
    @Override
    public void enter(final GameContainer gameContainer, final StateBasedGame stateBasedGame) throws SlickException {
    }
    
    @Override
    public void leave(final GameContainer gameContainer, final StateBasedGame stateBasedGame) throws SlickException {
    }
    
    @Override
    public void mouseWheelMoved(final int n) {
    }
}
