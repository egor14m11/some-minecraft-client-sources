// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.state;

import java.util.Iterator;
import org.newdawn.slick.state.transition.EmptyTransition;
import org.newdawn.slick.Input;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.transition.Transition;
import org.newdawn.slick.GameContainer;
import java.util.HashMap;
import org.newdawn.slick.InputListener;
import org.newdawn.slick.Game;

public abstract class StateBasedGame implements Game, InputListener
{
    public HashMap states;
    public GameState currentState;
    public GameState nextState;
    public GameContainer container;
    public String title;
    public Transition enterTransition;
    public Transition leaveTransition;
    
    public StateBasedGame(final String title) {
        this.states = new HashMap();
        this.title = title;
        this.currentState = new BasicGameState(this) {
            public StateBasedGame this$0;
            
            @Override
            public int getID() {
                return -1;
            }
            
            @Override
            public void init(final GameContainer gameContainer, final StateBasedGame stateBasedGame) throws SlickException {
            }
            
            public void render(final StateBasedGame stateBasedGame, final Graphics graphics) throws SlickException {
            }
            
            @Override
            public void update(final GameContainer gameContainer, final StateBasedGame stateBasedGame, final int n) throws SlickException {
            }
            
            @Override
            public void render(final GameContainer gameContainer, final StateBasedGame stateBasedGame, final Graphics graphics) throws SlickException {
            }
        };
    }
    
    @Override
    public void inputStarted() {
    }
    
    public int getStateCount() {
        return this.states.keySet().size();
    }
    
    public int getCurrentStateID() {
        return this.currentState.getID();
    }
    
    public GameState getCurrentState() {
        return this.currentState;
    }
    
    @Override
    public void setInput(final Input input) {
    }
    
    public void addState(final GameState gameState) {
        this.states.put(new Integer(gameState.getID()), gameState);
        if (this.currentState.getID() == -1) {
            this.currentState = gameState;
        }
    }
    
    public GameState getState(final int value) {
        return this.states.get(new Integer(value));
    }
    
    public void enterState(final int n) {
        this.enterState(n, new EmptyTransition(), new EmptyTransition());
    }
    
    public void enterState(final int i, Transition leaveTransition, Transition enterTransition) {
        if (leaveTransition == null) {
            leaveTransition = new EmptyTransition();
        }
        if (enterTransition == null) {
            enterTransition = new EmptyTransition();
        }
        this.leaveTransition = leaveTransition;
        this.enterTransition = enterTransition;
        this.nextState = this.getState(i);
        if (this.nextState == null) {
            throw new RuntimeException("No game state registered with the ID: " + i);
        }
        this.leaveTransition.init(this.currentState, this.nextState);
    }
    
    @Override
    public void init(final GameContainer container) throws SlickException {
        this.initStatesList(this.container = container);
        final Iterator<GameState> iterator = this.states.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().init(container, this);
        }
        if (this.currentState != null) {
            this.currentState.enter(container, this);
        }
    }
    
    public abstract void initStatesList(final GameContainer p0) throws SlickException;
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        this.preRenderState(gameContainer, graphics);
        if (this.leaveTransition != null) {
            this.leaveTransition.preRender(this, gameContainer, graphics);
        }
        else if (this.enterTransition != null) {
            this.enterTransition.preRender(this, gameContainer, graphics);
        }
        this.currentState.render(gameContainer, this, graphics);
        if (this.leaveTransition != null) {
            this.leaveTransition.postRender(this, gameContainer, graphics);
        }
        else if (this.enterTransition != null) {
            this.enterTransition.postRender(this, gameContainer, graphics);
        }
        this.postRenderState(gameContainer, graphics);
    }
    
    public void preRenderState(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
    }
    
    public void postRenderState(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        this.preUpdateState(gameContainer, n);
        if (this.leaveTransition != null) {
            this.leaveTransition.update(this, gameContainer, n);
            if (!this.leaveTransition.isComplete()) {
                return;
            }
            this.currentState.leave(gameContainer, this);
            final GameState currentState = this.currentState;
            this.currentState = this.nextState;
            this.nextState = null;
            this.leaveTransition = null;
            if (this.enterTransition == null) {
                this.currentState.enter(gameContainer, this);
            }
            else {
                this.enterTransition.init(this.currentState, currentState);
            }
        }
        if (this.enterTransition != null) {
            this.enterTransition.update(this, gameContainer, n);
            if (!this.enterTransition.isComplete()) {
                return;
            }
            this.currentState.enter(gameContainer, this);
            this.enterTransition = null;
        }
        this.currentState.update(gameContainer, this, n);
        this.postUpdateState(gameContainer, n);
    }
    
    public void preUpdateState(final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    public void postUpdateState(final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    public boolean transitioning() {
        return this.leaveTransition != null || this.enterTransition != null;
    }
    
    @Override
    public boolean closeRequested() {
        return true;
    }
    
    @Override
    public String getTitle() {
        return this.title;
    }
    
    public GameContainer getContainer() {
        return this.container;
    }
    
    @Override
    public void controllerButtonPressed(final int n, final int n2) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.controllerButtonPressed(n, n2);
    }
    
    @Override
    public void controllerButtonReleased(final int n, final int n2) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.controllerButtonReleased(n, n2);
    }
    
    @Override
    public void controllerDownPressed(final int n) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.controllerDownPressed(n);
    }
    
    @Override
    public void controllerDownReleased(final int n) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.controllerDownReleased(n);
    }
    
    @Override
    public void controllerLeftPressed(final int n) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.controllerLeftPressed(n);
    }
    
    @Override
    public void controllerLeftReleased(final int n) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.controllerLeftReleased(n);
    }
    
    @Override
    public void controllerRightPressed(final int n) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.controllerRightPressed(n);
    }
    
    @Override
    public void controllerRightReleased(final int n) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.controllerRightReleased(n);
    }
    
    @Override
    public void controllerUpPressed(final int n) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.controllerUpPressed(n);
    }
    
    @Override
    public void controllerUpReleased(final int n) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.controllerUpReleased(n);
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.keyPressed(n, c);
    }
    
    @Override
    public void keyReleased(final int n, final char c) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.keyReleased(n, c);
    }
    
    @Override
    public void mouseMoved(final int n, final int n2, final int n3, final int n4) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.mouseMoved(n, n2, n3, n4);
    }
    
    @Override
    public void mouseDragged(final int n, final int n2, final int n3, final int n4) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.mouseDragged(n, n2, n3, n4);
    }
    
    @Override
    public void mouseClicked(final int n, final int n2, final int n3, final int n4) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.mouseClicked(n, n2, n3, n4);
    }
    
    @Override
    public void mousePressed(final int n, final int n2, final int n3) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.mousePressed(n, n2, n3);
    }
    
    @Override
    public void mouseReleased(final int n, final int n2, final int n3) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.mouseReleased(n, n2, n3);
    }
    
    @Override
    public boolean isAcceptingInput() {
        return !this.transitioning() && this.currentState.isAcceptingInput();
    }
    
    @Override
    public void inputEnded() {
    }
    
    @Override
    public void mouseWheelMoved(final int n) {
        if (this.transitioning()) {
            return;
        }
        this.currentState.mouseWheelMoved(n);
    }
}
