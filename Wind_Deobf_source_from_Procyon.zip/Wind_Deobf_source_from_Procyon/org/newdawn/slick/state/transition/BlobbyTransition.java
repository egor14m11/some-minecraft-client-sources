// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.state.transition;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.util.MaskUtil;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.state.StateBasedGame;
import java.util.ArrayList;
import org.newdawn.slick.Color;
import org.newdawn.slick.state.GameState;
import org.newdawn.slick.opengl.renderer.SGL;

public class BlobbyTransition implements Transition
{
    public static SGL GL;
    public GameState prev;
    public boolean finish;
    public Color background;
    public ArrayList blobs;
    public int timer;
    public int blobCount;
    
    public BlobbyTransition() {
        this.blobs = new ArrayList();
        this.timer = 1000;
        this.blobCount = 10;
    }
    
    public BlobbyTransition(final Color background) {
        this.blobs = new ArrayList();
        this.timer = 1000;
        this.blobCount = 10;
        this.background = background;
    }
    
    @Override
    public void init(final GameState gameState, final GameState prev) {
        this.prev = prev;
    }
    
    @Override
    public boolean isComplete() {
        return this.finish;
    }
    
    @Override
    public void postRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        MaskUtil.resetMask();
    }
    
    @Override
    public void preRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        this.prev.render(gameContainer, stateBasedGame, graphics);
        MaskUtil.defineMask();
        for (int i = 0; i < this.blobs.size(); ++i) {
            ((Blob)this.blobs.get(i)).render(graphics);
        }
        MaskUtil.finishDefineMask();
        MaskUtil.drawOnMask();
        if (this.background != null) {
            final Color color = graphics.getColor();
            graphics.setColor(this.background);
            graphics.fillRect(0.0f, 0.0f, (float)gameContainer.getWidth(), (float)gameContainer.getHeight());
            graphics.setColor(color);
        }
    }
    
    @Override
    public void update(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final int n) throws SlickException {
        if (this.blobs.size() == 0) {
            for (int i = 0; i < this.blobCount; ++i) {
                this.blobs.add(new Blob(gameContainer));
            }
        }
        for (int j = 0; j < this.blobs.size(); ++j) {
            ((Blob)this.blobs.get(j)).update(n);
        }
        this.timer -= n;
        if (this.timer < 0) {
            this.finish = true;
        }
    }
    
    static {
        BlobbyTransition.GL = Renderer.get();
    }
    
    private class Blob
    {
        public float x;
        public float y;
        public float growSpeed;
        public float rad;
        public BlobbyTransition this$0;
        
        public Blob(final BlobbyTransition this$0, final GameContainer gameContainer) {
            this.this$0 = this$0;
            this.x = (float)(Math.random() * gameContainer.getWidth());
            this.y = (float)(Math.random() * gameContainer.getWidth());
            this.growSpeed = (float)(1.0 + Math.random() * 1.0);
        }
        
        public void update(final int n) {
            this.rad += this.growSpeed * n * 0.0f;
        }
        
        public void render(final Graphics graphics) {
            graphics.fillOval(this.x - this.rad, this.y - this.rad, this.rad * 2.0f, this.rad * 2.0f);
        }
    }
}
