// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.state.transition;

import org.newdawn.slick.state.GameState;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.state.StateBasedGame;
import java.util.ArrayList;

public class CombinedTransition implements Transition
{
    public ArrayList transitions;
    
    public CombinedTransition() {
        this.transitions = new ArrayList();
    }
    
    public void addTransition(final Transition e) {
        this.transitions.add(e);
    }
    
    @Override
    public boolean isComplete() {
        for (int i = 0; i < this.transitions.size(); ++i) {
            if (!((Transition)this.transitions.get(i)).isComplete()) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public void postRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        for (int i = this.transitions.size() - 1; i >= 0; --i) {
            ((Transition)this.transitions.get(i)).postRender(stateBasedGame, gameContainer, graphics);
        }
    }
    
    @Override
    public void preRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        for (int i = 0; i < this.transitions.size(); ++i) {
            ((Transition)this.transitions.get(i)).postRender(stateBasedGame, gameContainer, graphics);
        }
    }
    
    @Override
    public void update(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final int n) throws SlickException {
        for (int i = 0; i < this.transitions.size(); ++i) {
            final Transition transition = this.transitions.get(i);
            if (!transition.isComplete()) {
                transition.update(stateBasedGame, gameContainer, n);
            }
        }
    }
    
    @Override
    public void init(final GameState gameState, final GameState gameState2) {
        for (int i = this.transitions.size() - 1; i >= 0; --i) {
            ((Transition)this.transitions.get(i)).init(gameState, gameState2);
        }
    }
}
