// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.state.transition;

import org.newdawn.slick.SlickException;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.GameState;

public abstract class CrossStateTransition implements Transition
{
    public GameState secondState;
    
    public CrossStateTransition(final GameState secondState) {
        this.secondState = secondState;
    }
    
    @Override
    public abstract boolean isComplete();
    
    @Override
    public void postRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        this.preRenderSecondState(stateBasedGame, gameContainer, graphics);
        this.secondState.render(gameContainer, stateBasedGame, graphics);
        this.postRenderSecondState(stateBasedGame, gameContainer, graphics);
    }
    
    @Override
    public void preRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        this.preRenderFirstState(stateBasedGame, gameContainer, graphics);
    }
    
    @Override
    public void update(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    public void preRenderFirstState(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
    }
    
    public void preRenderSecondState(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
    }
    
    public void postRenderSecondState(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
    }
}
