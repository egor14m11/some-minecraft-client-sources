// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.state.transition;

import org.newdawn.slick.state.GameState;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.Color;

public class FadeOutTransition implements Transition
{
    public Color color;
    public int fadeTime;
    
    public FadeOutTransition() {
        this(Color.black, 500);
    }
    
    public FadeOutTransition(final Color color) {
        this(color, 500);
    }
    
    public FadeOutTransition(final Color color, final int fadeTime) {
        this.color = new Color(color);
        this.color.a = 0.0f;
        this.fadeTime = fadeTime;
    }
    
    @Override
    public boolean isComplete() {
        return this.color.a >= 1.0f;
    }
    
    @Override
    public void postRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) {
        final Color color = graphics.getColor();
        graphics.setColor(this.color);
        graphics.fillRect(0.0f, 0.0f, (float)(gameContainer.getWidth() * 2), (float)(gameContainer.getHeight() * 2));
        graphics.setColor(color);
    }
    
    @Override
    public void update(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final int n) {
        final Color color = this.color;
        color.a += n * (1.0f / this.fadeTime);
        if (this.color.a > 1.0f) {
            this.color.a = 1.0f;
        }
    }
    
    @Override
    public void preRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) {
    }
    
    @Override
    public void init(final GameState gameState, final GameState gameState2) {
    }
}
