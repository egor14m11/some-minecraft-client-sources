// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.state.transition;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.state.GameState;
import org.newdawn.slick.opengl.renderer.SGL;

public class HorizontalSplitTransition implements Transition
{
    public static SGL GL;
    public GameState prev;
    public float offset;
    public boolean finish;
    public Color background;
    
    public HorizontalSplitTransition() {
    }
    
    public HorizontalSplitTransition(final Color background) {
        this.background = background;
    }
    
    @Override
    public void init(final GameState gameState, final GameState prev) {
        this.prev = prev;
    }
    
    @Override
    public boolean isComplete() {
        return this.finish;
    }
    
    @Override
    public void postRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.translate(-this.offset, 0.0f);
        graphics.setClip((int)(-this.offset), 0, gameContainer.getWidth() / 2, gameContainer.getHeight());
        if (this.background != null) {
            final Color color = graphics.getColor();
            graphics.setColor(this.background);
            graphics.fillRect(0.0f, 0.0f, (float)gameContainer.getWidth(), (float)gameContainer.getHeight());
            graphics.setColor(color);
        }
        HorizontalSplitTransition.GL.glPushMatrix();
        this.prev.render(gameContainer, stateBasedGame, graphics);
        HorizontalSplitTransition.GL.glPopMatrix();
        graphics.clearClip();
        graphics.translate(this.offset * 2.0f, 0.0f);
        graphics.setClip((int)(gameContainer.getWidth() / 2 + this.offset), 0, gameContainer.getWidth() / 2, gameContainer.getHeight());
        if (this.background != null) {
            final Color color2 = graphics.getColor();
            graphics.setColor(this.background);
            graphics.fillRect(0.0f, 0.0f, (float)gameContainer.getWidth(), (float)gameContainer.getHeight());
            graphics.setColor(color2);
        }
        HorizontalSplitTransition.GL.glPushMatrix();
        this.prev.render(gameContainer, stateBasedGame, graphics);
        HorizontalSplitTransition.GL.glPopMatrix();
        graphics.clearClip();
        graphics.translate(-this.offset, 0.0f);
    }
    
    @Override
    public void preRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
    }
    
    @Override
    public void update(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final int n) throws SlickException {
        this.offset += n * 1.0f;
        if (this.offset > gameContainer.getWidth() / 2) {
            this.finish = true;
        }
    }
    
    static {
        HorizontalSplitTransition.GL = Renderer.get();
    }
}
