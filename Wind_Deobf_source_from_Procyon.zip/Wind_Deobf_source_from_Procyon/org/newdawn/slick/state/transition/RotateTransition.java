// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.state.transition;

import org.newdawn.slick.SlickException;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.state.GameState;

public class RotateTransition implements Transition
{
    public GameState prev;
    public float ang;
    public boolean finish;
    public float scale;
    public Color background;
    
    public RotateTransition() {
        this.scale = 1.0f;
    }
    
    public RotateTransition(final Color background) {
        this.scale = 1.0f;
        this.background = background;
    }
    
    @Override
    public void init(final GameState gameState, final GameState prev) {
        this.prev = prev;
    }
    
    @Override
    public boolean isComplete() {
        return this.finish;
    }
    
    @Override
    public void postRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.translate((float)(gameContainer.getWidth() / 2), (float)(gameContainer.getHeight() / 2));
        graphics.scale(this.scale, this.scale);
        graphics.rotate(0.0f, 0.0f, this.ang);
        graphics.translate((float)(-gameContainer.getWidth() / 2), (float)(-gameContainer.getHeight() / 2));
        if (this.background != null) {
            final Color color = graphics.getColor();
            graphics.setColor(this.background);
            graphics.fillRect(0.0f, 0.0f, (float)gameContainer.getWidth(), (float)gameContainer.getHeight());
            graphics.setColor(color);
        }
        this.prev.render(gameContainer, stateBasedGame, graphics);
        graphics.translate((float)(gameContainer.getWidth() / 2), (float)(gameContainer.getHeight() / 2));
        graphics.rotate(0.0f, 0.0f, -this.ang);
        graphics.scale(1.0f / this.scale, 1.0f / this.scale);
        graphics.translate((float)(-gameContainer.getWidth() / 2), (float)(-gameContainer.getHeight() / 2));
    }
    
    @Override
    public void preRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
    }
    
    @Override
    public void update(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final int n) throws SlickException {
        this.ang += n * 0.0f;
        if (this.ang > 500.0f) {
            this.finish = true;
        }
        this.scale -= n * 0.0f;
        if (this.scale < 0.0f) {
            this.scale = 0.0f;
        }
    }
}
