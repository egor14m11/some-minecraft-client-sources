// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.state.transition;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.state.GameState;
import org.newdawn.slick.opengl.renderer.SGL;

public class SelectTransition implements Transition
{
    public static SGL GL;
    public GameState prev;
    public boolean finish;
    public Color background;
    public float scale1;
    public float xp1;
    public float yp1;
    public float scale2;
    public float xp2;
    public float yp2;
    public boolean init;
    public boolean moveBackDone;
    public int pause;
    
    public SelectTransition() {
        this.scale1 = 1.0f;
        this.xp1 = 0.0f;
        this.yp1 = 0.0f;
        this.scale2 = 0.0f;
        this.xp2 = 0.0f;
        this.yp2 = 0.0f;
        this.init = false;
        this.moveBackDone = false;
        this.pause = 300;
    }
    
    public SelectTransition(final Color background) {
        this.scale1 = 1.0f;
        this.xp1 = 0.0f;
        this.yp1 = 0.0f;
        this.scale2 = 0.0f;
        this.xp2 = 0.0f;
        this.yp2 = 0.0f;
        this.init = false;
        this.moveBackDone = false;
        this.pause = 300;
        this.background = background;
    }
    
    @Override
    public void init(final GameState gameState, final GameState prev) {
        this.prev = prev;
    }
    
    @Override
    public boolean isComplete() {
        return this.finish;
    }
    
    @Override
    public void postRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.resetTransform();
        if (!this.moveBackDone) {
            graphics.translate(this.xp1, this.yp1);
            graphics.scale(this.scale1, this.scale1);
            graphics.setClip((int)this.xp1, (int)this.yp1, (int)(this.scale1 * gameContainer.getWidth()), (int)(this.scale1 * gameContainer.getHeight()));
            this.prev.render(gameContainer, stateBasedGame, graphics);
            graphics.resetTransform();
            graphics.clearClip();
        }
    }
    
    @Override
    public void preRender(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        if (this.moveBackDone) {
            graphics.translate(this.xp1, this.yp1);
            graphics.scale(this.scale1, this.scale1);
            graphics.setClip((int)this.xp1, (int)this.yp1, (int)(this.scale1 * gameContainer.getWidth()), (int)(this.scale1 * gameContainer.getHeight()));
            this.prev.render(gameContainer, stateBasedGame, graphics);
            graphics.resetTransform();
            graphics.clearClip();
        }
        graphics.translate(this.xp2, this.yp2);
        graphics.scale(this.scale2, this.scale2);
        graphics.setClip((int)this.xp2, (int)this.yp2, (int)(this.scale2 * gameContainer.getWidth()), (int)(this.scale2 * gameContainer.getHeight()));
    }
    
    @Override
    public void update(final StateBasedGame stateBasedGame, final GameContainer gameContainer, final int n) throws SlickException {
        if (!this.init) {
            this.init = true;
            this.xp2 = (float)(gameContainer.getWidth() / 2 + 50);
            this.yp2 = (float)(gameContainer.getHeight() / 4);
        }
        if (!this.moveBackDone) {
            if (this.scale1 > 0.0f) {
                this.scale1 -= n * 0.0f;
                if (this.scale1 <= 0.0f) {
                    this.scale1 = 0.0f;
                }
                this.xp1 += n * 0.0f;
                if (this.xp1 > 50.0f) {
                    this.xp1 = 50.0f;
                }
                this.yp1 += n * 0.0f;
                if (this.yp1 > gameContainer.getHeight() / 4) {
                    this.yp1 = (float)(gameContainer.getHeight() / 4);
                }
            }
            else {
                this.moveBackDone = true;
            }
        }
        else {
            this.pause -= n;
            if (this.pause > 0) {
                return;
            }
            if (this.scale2 < 1.0f) {
                this.scale2 += n * 0.0f;
                if (this.scale2 >= 1.0f) {
                    this.scale2 = 1.0f;
                }
                this.xp2 -= n * 1.0f;
                if (this.xp2 < 0.0f) {
                    this.xp2 = 0.0f;
                }
                this.yp2 -= n * 0.0f;
                if (this.yp2 < 0.0f) {
                    this.yp2 = 0.0f;
                }
            }
            else {
                this.finish = true;
            }
        }
    }
    
    static {
        SelectTransition.GL = Renderer.get();
    }
}
