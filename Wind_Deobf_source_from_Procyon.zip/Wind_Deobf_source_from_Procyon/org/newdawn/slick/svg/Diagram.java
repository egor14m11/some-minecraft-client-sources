// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg;

import java.util.HashMap;
import java.util.ArrayList;

public class Diagram
{
    public ArrayList figures;
    public HashMap patterns;
    public HashMap gradients;
    public HashMap figureMap;
    public float width;
    public float height;
    
    public Diagram(final float width, final float height) {
        this.figures = new ArrayList();
        this.patterns = new HashMap();
        this.gradients = new HashMap();
        this.figureMap = new HashMap();
        this.width = width;
        this.height = height;
    }
    
    public float getWidth() {
        return this.width;
    }
    
    public float getHeight() {
        return this.height;
    }
    
    public void addPatternDef(final String key, final String value) {
        this.patterns.put(key, value);
    }
    
    public void addGradient(final String key, final Gradient value) {
        this.gradients.put(key, value);
    }
    
    public String getPatternDef(final String key) {
        return this.patterns.get(key);
    }
    
    public Gradient getGradient(final String key) {
        return this.gradients.get(key);
    }
    
    public String[] getPatternDefNames() {
        return (String[])this.patterns.keySet().toArray(new String[0]);
    }
    
    public Figure getFigureByID(final String key) {
        return this.figureMap.get(key);
    }
    
    public void addFigure(final Figure figure) {
        this.figures.add(figure);
        this.figureMap.put(figure.getData().getAttribute("id"), figure);
        final Gradient gradient = this.getGradient(figure.getData().getAsReference("fill"));
        if (gradient != null && gradient.isRadial()) {
            for (int i = 0; i < InkscapeLoader.RADIAL_TRIANGULATION_LEVEL; ++i) {
                figure.getShape().increaseTriangulation();
            }
        }
    }
    
    public int getFigureCount() {
        return this.figures.size();
    }
    
    public Figure getFigure(final int index) {
        return this.figures.get(index);
    }
    
    public void removeFigure(final Figure o) {
        this.figures.remove(o);
        this.figureMap.remove(o.getData().getAttribute("id"));
    }
}
