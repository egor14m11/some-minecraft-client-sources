// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg;

import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.geom.Shape;

public class Figure
{
    public static int ELLIPSE;
    public static int LINE;
    public static int RECTANGLE;
    public static int PATH;
    public static int POLYGON;
    public int type;
    public Shape shape;
    public NonGeometricData data;
    public Transform transform;
    
    public Figure(final int type, final Shape shape, final NonGeometricData data, final Transform transform) {
        this.shape = shape;
        this.data = data;
        this.type = type;
        this.transform = transform;
    }
    
    public Transform getTransform() {
        return this.transform;
    }
    
    public int getType() {
        return this.type;
    }
    
    public Shape getShape() {
        return this.shape;
    }
    
    public NonGeometricData getData() {
        return this.data;
    }
    
    static {
        Figure.POLYGON = 5;
        Figure.PATH = 4;
        Figure.RECTANGLE = 3;
        Figure.LINE = 2;
        Figure.ELLIPSE = 1;
    }
}
