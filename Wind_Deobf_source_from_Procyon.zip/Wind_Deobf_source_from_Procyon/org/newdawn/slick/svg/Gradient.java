// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg;

import org.newdawn.slick.Color;
import org.newdawn.slick.ImageBuffer;
import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.Image;
import java.util.ArrayList;

public class Gradient
{
    public String name;
    public ArrayList steps;
    public float x1;
    public float x2;
    public float y1;
    public float y2;
    public float r;
    public Image image;
    public boolean radial;
    public Transform transform;
    public String ref;
    
    public Gradient(final String name, final boolean radial) {
        this.steps = new ArrayList();
        this.name = name;
        this.radial = radial;
    }
    
    public boolean isRadial() {
        return this.radial;
    }
    
    public void setTransform(final Transform transform) {
        this.transform = transform;
    }
    
    public Transform getTransform() {
        return this.transform;
    }
    
    public void reference(final String ref) {
        this.ref = ref;
    }
    
    public void resolve(final Diagram diagram) {
        if (this.ref == null) {
            return;
        }
        final Gradient gradient = diagram.getGradient(this.ref);
        for (int i = 0; i < gradient.steps.size(); ++i) {
            this.steps.add(gradient.steps.get(i));
        }
    }
    
    public void genImage() {
        if (this.image == null) {
            final ImageBuffer imageBuffer = new ImageBuffer(128, 16);
            for (int i = 0; i < 128; ++i) {
                final Color color = this.getColorAt(i / 128.0f);
                for (int j = 0; j < 16; ++j) {
                    imageBuffer.setRGBA(i, j, color.getRedByte(), color.getGreenByte(), color.getBlueByte(), color.getAlphaByte());
                }
            }
            this.image = imageBuffer.getImage();
        }
    }
    
    public Image getImage() {
        this.genImage();
        return this.image;
    }
    
    public void setR(final float r) {
        this.r = r;
    }
    
    public void setX1(final float x1) {
        this.x1 = x1;
    }
    
    public void setX2(final float x2) {
        this.x2 = x2;
    }
    
    public void setY1(final float y1) {
        this.y1 = y1;
    }
    
    public void setY2(final float y2) {
        this.y2 = y2;
    }
    
    public float getR() {
        return this.r;
    }
    
    public float getX1() {
        return this.x1;
    }
    
    public float getX2() {
        return this.x2;
    }
    
    public float getY1() {
        return this.y1;
    }
    
    public float getY2() {
        return this.y2;
    }
    
    public void addStep(final float n, final Color color) {
        this.steps.add(new Step(n, color));
    }
    
    public Color getColorAt(float n) {
        if (n <= 0.0f) {
            return this.steps.get(0).col;
        }
        if (n > 1.0f) {
            return this.steps.get(this.steps.size() - 1).col;
        }
        for (int i = 1; i < this.steps.size(); ++i) {
            final Step step = this.steps.get(i - 1);
            final Step step2 = this.steps.get(i);
            if (n <= step2.location) {
                final float n2 = step2.location - step.location;
                n -= step.location;
                final float n3 = n / n2;
                final Color color = new Color(1, 1, 1, 1);
                color.a = step.col.a * (1.0f - n3) + step2.col.a * n3;
                color.r = step.col.r * (1.0f - n3) + step2.col.r * n3;
                color.g = step.col.g * (1.0f - n3) + step2.col.g * n3;
                color.b = step.col.b * (1.0f - n3) + step2.col.b * n3;
                return color;
            }
        }
        return Color.black;
    }
    
    private class Step
    {
        public float location;
        public Color col;
        public Gradient this$0;
        
        public Step(final Gradient this$0, final float location, final Color col) {
            this.this$0 = this$0;
            this.location = location;
            this.col = col;
        }
    }
}
