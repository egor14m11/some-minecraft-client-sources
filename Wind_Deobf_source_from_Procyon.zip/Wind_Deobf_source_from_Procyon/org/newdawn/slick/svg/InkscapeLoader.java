// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg;

import org.newdawn.slick.svg.inkscape.UseProcessor;
import org.newdawn.slick.svg.inkscape.DefsProcessor;
import org.newdawn.slick.svg.inkscape.GroupProcessor;
import org.newdawn.slick.svg.inkscape.LineProcessor;
import org.newdawn.slick.svg.inkscape.PathProcessor;
import org.newdawn.slick.svg.inkscape.PolygonProcessor;
import org.newdawn.slick.svg.inkscape.EllipseProcessor;
import org.newdawn.slick.svg.inkscape.RectProcessor;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilder;
import org.newdawn.slick.geom.Transform;
import java.io.IOException;
import org.xml.sax.SAXException;
import java.io.ByteArrayInputStream;
import org.xml.sax.InputSource;
import org.xml.sax.EntityResolver;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.util.ResourceLoader;
import org.newdawn.slick.svg.inkscape.ElementProcessor;
import java.util.ArrayList;

public class InkscapeLoader implements Loader
{
    public static int RADIAL_TRIANGULATION_LEVEL;
    public static ArrayList processors;
    public Diagram diagram;
    
    public static void addElementProcessor(final ElementProcessor e) {
        InkscapeLoader.processors.add(e);
    }
    
    public static Diagram load(final String s, final boolean b) throws SlickException {
        return load(ResourceLoader.getResourceAsStream(s), b);
    }
    
    public static Diagram load(final String s) throws SlickException {
        return load(ResourceLoader.getResourceAsStream(s), false);
    }
    
    public static Diagram load(final InputStream inputStream, final boolean b) throws SlickException {
        return new InkscapeLoader().loadDiagram(inputStream, b);
    }
    
    public Diagram loadDiagram(final InputStream inputStream) throws SlickException {
        return this.loadDiagram(inputStream, false);
    }
    
    public Diagram loadDiagram(final InputStream is, final boolean b) throws SlickException {
        final DocumentBuilderFactory instance = DocumentBuilderFactory.newInstance();
        instance.setValidating(false);
        instance.setNamespaceAware(true);
        final DocumentBuilder documentBuilder = instance.newDocumentBuilder();
        documentBuilder.setEntityResolver(new EntityResolver(this) {
            public InkscapeLoader this$0;
            
            @Override
            public InputSource resolveEntity(final String s, final String s2) throws SAXException, IOException {
                return new InputSource(new ByteArrayInputStream(new byte[0]));
            }
        });
        final Element documentElement = documentBuilder.parse(is).getDocumentElement();
        String s;
        for (s = documentElement.getAttribute("width"); Character.isLetter(s.charAt(s.length() - 1)); s = s.substring(0, s.length() - 1)) {}
        String s2;
        for (s2 = documentElement.getAttribute("height"); Character.isLetter(s2.charAt(s2.length() - 1)); s2 = s2.substring(0, s2.length() - 1)) {}
        final float float1 = Float.parseFloat(s);
        float float2 = Float.parseFloat(s2);
        this.diagram = new Diagram(float1, float2);
        if (!b) {
            float2 = 0.0f;
        }
        this.loadChildren(documentElement, Transform.createTranslateTransform(0.0f, -float2));
        return this.diagram;
    }
    
    @Override
    public void loadChildren(final Element element, final Transform transform) throws ParsingException {
        final NodeList childNodes = element.getChildNodes();
        for (int i = 0; i < childNodes.getLength(); ++i) {
            if (childNodes.item(i) instanceof Element) {
                this.loadElement((Element)childNodes.item(i), transform);
            }
        }
    }
    
    public void loadElement(final Element element, final Transform transform) throws ParsingException {
        for (int i = 0; i < InkscapeLoader.processors.size(); ++i) {
            final ElementProcessor elementProcessor = InkscapeLoader.processors.get(i);
            if (elementProcessor.handles(element)) {
                elementProcessor.process(this, element, this.diagram, transform);
            }
        }
    }
    
    static {
        InkscapeLoader.RADIAL_TRIANGULATION_LEVEL = 1;
        InkscapeLoader.processors = new ArrayList();
        addElementProcessor(new RectProcessor());
        addElementProcessor(new EllipseProcessor());
        addElementProcessor(new PolygonProcessor());
        addElementProcessor(new PathProcessor());
        addElementProcessor(new LineProcessor());
        addElementProcessor(new GroupProcessor());
        addElementProcessor(new DefsProcessor());
        addElementProcessor(new UseProcessor());
    }
}
