// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg;

import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.geom.Line;
import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.geom.TexCoordGenerator;

public class LinearGradientFill implements TexCoordGenerator
{
    public Vector2f start;
    public Vector2f end;
    public Gradient gradient;
    public Line line;
    public Shape shape;
    
    public LinearGradientFill(final Shape shape, final Transform transform, final Gradient gradient) {
        this.gradient = gradient;
        final float x1 = gradient.getX1();
        final float y1 = gradient.getY1();
        final float x2 = gradient.getX2();
        final float n = gradient.getY2() - y1;
        final float n2 = x2 - x1;
        final float[] array = { x1, y1 + n / 2.0f };
        gradient.getTransform().transform(array, 0, array, 0, 1);
        transform.transform(array, 0, array, 0, 1);
        final float[] array2 = { x1 + n2, y1 + n / 2.0f };
        gradient.getTransform().transform(array2, 0, array2, 0, 1);
        transform.transform(array2, 0, array2, 0, 1);
        this.start = new Vector2f(array[0], array[1]);
        this.end = new Vector2f(array2[0], array2[1]);
        this.line = new Line(this.start, this.end);
    }
    
    @Override
    public Vector2f getCoordFor(final float n, final float n2) {
        final Vector2f vector2f = new Vector2f();
        this.line.getClosestPoint(new Vector2f(n, n2), vector2f);
        return new Vector2f(vector2f.distance(this.start) / this.line.length(), 0.0f);
    }
}
