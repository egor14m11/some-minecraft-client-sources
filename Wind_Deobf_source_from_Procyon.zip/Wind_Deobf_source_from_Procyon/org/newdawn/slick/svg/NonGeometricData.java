// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg;

import org.newdawn.slick.Color;
import java.util.Properties;

public class NonGeometricData
{
    public static String ID;
    public static String FILL;
    public static String STROKE;
    public static String OPACITY;
    public static String STROKE_WIDTH;
    public static String STROKE_MITERLIMIT;
    public static String STROKE_DASHARRAY;
    public static String STROKE_DASHOFFSET;
    public static String STROKE_OPACITY;
    public static String NONE;
    public String metaData;
    public Properties props;
    
    public NonGeometricData(final String metaData) {
        this.metaData = "";
        this.props = new Properties();
        this.metaData = metaData;
        this.addAttribute("stroke-width", "1");
    }
    
    public String morphColor(final String s) {
        if (s.equals("")) {
            return "#000000";
        }
        if (s.equals("white")) {
            return "#ffffff";
        }
        if (s.equals("black")) {
            return "#000000";
        }
        return s;
    }
    
    public void addAttribute(final String key, String value) {
        if (value == null) {
            value = "";
        }
        if (key.equals("fill")) {
            value = this.morphColor(value);
        }
        if (key.equals("stroke-opacity") && value.equals("0")) {
            this.props.setProperty("stroke", "none");
        }
        if (key.equals("stroke-width")) {
            if (value.equals("")) {
                value = "1";
            }
            if (value.endsWith("px")) {
                value = value.substring(0, value.length() - 2);
            }
        }
        if (key.equals("stroke")) {
            if ("none".equals(this.props.getProperty("stroke"))) {
                return;
            }
            if ("".equals(this.props.getProperty("stroke"))) {
                return;
            }
            value = this.morphColor(value);
        }
        this.props.setProperty(key, value);
    }
    
    public boolean isColor(final String s) {
        return this.getAttribute(s).startsWith("#");
    }
    
    public String getMetaData() {
        return this.metaData;
    }
    
    public String getAttribute(final String key) {
        return this.props.getProperty(key);
    }
    
    public Color getAsColor(final String str) {
        if (!this.isColor(str)) {
            throw new RuntimeException("Attribute " + str + " is not specified as a color:" + this.getAttribute(str));
        }
        return new Color(Integer.parseInt(this.getAttribute(str).substring(1), 16));
    }
    
    public String getAsReference(final String s) {
        final String attribute = this.getAttribute(s);
        if (attribute.length() < 7) {
            return "";
        }
        return attribute.substring(5, attribute.length() - 1);
    }
    
    public float getAsFloat(final String s) {
        final String attribute = this.getAttribute(s);
        if (attribute == null) {
            return 0.0f;
        }
        return Float.parseFloat(attribute);
    }
    
    public boolean isFilled() {
        return this.isColor("fill");
    }
    
    public boolean isStroked() {
        return this.isColor("stroke") && this.getAsFloat("stroke-width") > 0.0f;
    }
    
    static {
        NonGeometricData.NONE = "none";
        NonGeometricData.STROKE_OPACITY = "stroke-opacity";
        NonGeometricData.STROKE_DASHOFFSET = "stroke-dashoffset";
        NonGeometricData.STROKE_DASHARRAY = "stroke-dasharray";
        NonGeometricData.STROKE_MITERLIMIT = "stroke-miterlimit";
        NonGeometricData.STROKE_WIDTH = "stroke-width";
        NonGeometricData.OPACITY = "opacity";
        NonGeometricData.STROKE = "stroke";
        NonGeometricData.FILL = "fill";
        NonGeometricData.ID = "id";
    }
}
