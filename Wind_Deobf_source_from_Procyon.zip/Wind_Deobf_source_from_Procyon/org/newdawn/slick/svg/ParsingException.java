// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg;

import org.w3c.dom.Element;
import org.newdawn.slick.SlickException;

public class ParsingException extends SlickException
{
    public ParsingException(final String str, final String str2, final Throwable t) {
        super("(" + str + ") " + str2, t);
    }
    
    public ParsingException(final Element element, final String str, final Throwable t) {
        super("(" + element.getAttribute("id") + ") " + str, t);
    }
    
    public ParsingException(final String str, final String str2) {
        super("(" + str + ") " + str2);
    }
    
    public ParsingException(final Element element, final String str) {
        super("(" + element.getAttribute("id") + ") " + str);
    }
}
