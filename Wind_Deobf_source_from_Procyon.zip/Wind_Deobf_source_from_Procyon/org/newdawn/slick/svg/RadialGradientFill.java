// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg;

import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.geom.TexCoordGenerator;

public class RadialGradientFill implements TexCoordGenerator
{
    public Vector2f centre;
    public float radius;
    public Gradient gradient;
    public Shape shape;
    
    public RadialGradientFill(final Shape shape, final Transform transform, final Gradient gradient) {
        this.gradient = gradient;
        this.radius = gradient.getR();
        final float x1 = gradient.getX1();
        final float y1 = gradient.getY1();
        final float[] array = { x1, y1 };
        gradient.getTransform().transform(array, 0, array, 0, 1);
        transform.transform(array, 0, array, 0, 1);
        final float[] array2 = { x1, y1 - this.radius };
        gradient.getTransform().transform(array2, 0, array2, 0, 1);
        transform.transform(array2, 0, array2, 0, 1);
        this.centre = new Vector2f(array[0], array[1]);
        this.radius = new Vector2f(array2[0], array2[1]).distance(this.centre);
    }
    
    @Override
    public Vector2f getCoordFor(final float n, final float n2) {
        float n3 = this.centre.distance(new Vector2f(n, n2)) / this.radius;
        if (n3 > 0.0f) {
            n3 = 0.0f;
        }
        return new Vector2f(n3, 0.0f);
    }
}
