// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg;

import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.geom.MorphShape;
import java.util.ArrayList;

public class SVGMorph extends Diagram
{
    public ArrayList figures;
    
    public SVGMorph(final Diagram diagram) {
        super(diagram.getWidth(), diagram.getHeight());
        this.figures = new ArrayList();
        for (int i = 0; i < diagram.getFigureCount(); ++i) {
            final Figure figure = diagram.getFigure(i);
            this.figures.add(new Figure(figure.getType(), new MorphShape(figure.getShape()), figure.getData(), figure.getTransform()));
        }
    }
    
    public void addStep(final Diagram diagram) {
        if (diagram.getFigureCount() != this.figures.size()) {
            throw new RuntimeException("Mismatched diagrams, missing ids");
        }
        for (int i = 0; i < diagram.getFigureCount(); ++i) {
            final Figure figure = diagram.getFigure(i);
            final String metaData = figure.getData().getMetaData();
            for (int j = 0; j < this.figures.size(); ++j) {
                final Figure figure2 = this.figures.get(j);
                if (figure2.getData().getMetaData().equals(metaData)) {
                    ((MorphShape)figure2.getShape()).addShape(figure.getShape());
                    break;
                }
            }
        }
    }
    
    public void setExternalDiagram(final Diagram diagram) {
        for (int i = 0; i < this.figures.size(); ++i) {
            final Figure figure = this.figures.get(i);
            for (int j = 0; j < diagram.getFigureCount(); ++j) {
                final Figure figure2 = diagram.getFigure(j);
                if (figure2.getData().getMetaData().equals(figure.getData().getMetaData())) {
                    ((MorphShape)figure.getShape()).setExternalFrame(figure2.getShape());
                    break;
                }
            }
        }
    }
    
    public void updateMorphTime(final float n) {
        for (int i = 0; i < this.figures.size(); ++i) {
            ((MorphShape)((Figure)this.figures.get(i)).getShape()).updateMorphTime(n);
        }
    }
    
    public void setMorphTime(final float morphTime) {
        for (int i = 0; i < this.figures.size(); ++i) {
            ((MorphShape)((Figure)this.figures.get(i)).getShape()).setMorphTime(morphTime);
        }
    }
    
    @Override
    public int getFigureCount() {
        return this.figures.size();
    }
    
    @Override
    public Figure getFigure(final int index) {
        return this.figures.get(index);
    }
}
