// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg;

import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.geom.TexCoordGenerator;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.geom.ShapeRenderer;
import org.newdawn.slick.Color;
import org.newdawn.slick.opengl.TextureImpl;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.opengl.renderer.SGL;

public class SimpleDiagramRenderer
{
    public static SGL GL;
    public Diagram diagram;
    public int list;
    
    public SimpleDiagramRenderer(final Diagram diagram) {
        this.list = -1;
        this.diagram = diagram;
    }
    
    public void render(final Graphics graphics) {
        if (this.list == -1) {
            this.list = SimpleDiagramRenderer.GL.glGenLists(1);
            SimpleDiagramRenderer.GL.glNewList(this.list, 4864);
            render(graphics, this.diagram);
            SimpleDiagramRenderer.GL.glEndList();
        }
        SimpleDiagramRenderer.GL.glCallList(this.list);
        TextureImpl.bindNone();
    }
    
    public static void render(final Graphics graphics, final Diagram diagram) {
        for (int i = 0; i < diagram.getFigureCount(); ++i) {
            final Figure figure = diagram.getFigure(i);
            if (figure.getData().isFilled()) {
                if (figure.getData().isColor("fill")) {
                    graphics.setColor(figure.getData().getAsColor("fill"));
                    graphics.fill(diagram.getFigure(i).getShape());
                    graphics.setAntiAlias(true);
                    graphics.draw(diagram.getFigure(i).getShape());
                    graphics.setAntiAlias(false);
                }
                final String asReference = figure.getData().getAsReference("fill");
                if (diagram.getPatternDef(asReference) != null) {
                    System.out.println("PATTERN");
                }
                if (diagram.getGradient(asReference) != null) {
                    final Gradient gradient = diagram.getGradient(asReference);
                    final Shape shape = diagram.getFigure(i).getShape();
                    TexCoordGenerator texCoordGenerator;
                    if (gradient.isRadial()) {
                        texCoordGenerator = new RadialGradientFill(shape, diagram.getFigure(i).getTransform(), gradient);
                    }
                    else {
                        texCoordGenerator = new LinearGradientFill(shape, diagram.getFigure(i).getTransform(), gradient);
                    }
                    Color.white.bind();
                    ShapeRenderer.texture(shape, gradient.getImage(), texCoordGenerator);
                }
            }
            if (figure.getData().isStroked() && figure.getData().isColor("stroke")) {
                graphics.setColor(figure.getData().getAsColor("stroke"));
                graphics.setLineWidth(figure.getData().getAsFloat("stroke-width"));
                graphics.setAntiAlias(true);
                graphics.draw(diagram.getFigure(i).getShape());
                graphics.setAntiAlias(false);
                graphics.resetLineWidth();
            }
        }
    }
    
    static {
        SimpleDiagramRenderer.GL = Renderer.get();
    }
}
