// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg.inkscape;

import org.newdawn.slick.svg.ParsingException;
import org.w3c.dom.NodeList;
import org.newdawn.slick.Color;
import org.newdawn.slick.svg.Gradient;
import java.util.ArrayList;
import org.newdawn.slick.util.Log;
import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.svg.Diagram;
import org.newdawn.slick.svg.Loader;
import org.w3c.dom.Element;

public class DefsProcessor implements ElementProcessor
{
    @Override
    public boolean handles(final Element element) {
        return element.getNodeName().equals("defs");
    }
    
    @Override
    public void process(final Loader loader, final Element element, final Diagram diagram, final Transform transform) throws ParsingException {
        final NodeList elementsByTagName = element.getElementsByTagName("pattern");
        for (int i = 0; i < elementsByTagName.getLength(); ++i) {
            final Element element2 = (Element)elementsByTagName.item(i);
            final NodeList elementsByTagName2 = element2.getElementsByTagName("image");
            if (elementsByTagName2.getLength() == 0) {
                Log.warn("Pattern 1981 does not specify an image. Only image patterns are supported.");
            }
            else {
                diagram.addPatternDef(element2.getAttribute("id"), ((Element)elementsByTagName2.item(0)).getAttributeNS("http://www.w3.org/1999/xlink", "href"));
            }
        }
        final NodeList elementsByTagName3 = element.getElementsByTagName("linearGradient");
        final ArrayList<Gradient> list = new ArrayList<Gradient>();
        for (int j = 0; j < elementsByTagName3.getLength(); ++j) {
            final Element element3 = (Element)elementsByTagName3.item(j);
            final String attribute = element3.getAttribute("id");
            final Gradient e = new Gradient(attribute, false);
            e.setTransform(Util.getTransform(element3, "gradientTransform"));
            if (this.stringLength(element3.getAttribute("x1")) > 0) {
                e.setX1(Float.parseFloat(element3.getAttribute("x1")));
            }
            if (this.stringLength(element3.getAttribute("x2")) > 0) {
                e.setX2(Float.parseFloat(element3.getAttribute("x2")));
            }
            if (this.stringLength(element3.getAttribute("y1")) > 0) {
                e.setY1(Float.parseFloat(element3.getAttribute("y1")));
            }
            if (this.stringLength(element3.getAttribute("y2")) > 0) {
                e.setY2(Float.parseFloat(element3.getAttribute("y2")));
            }
            final String attributeNS = element3.getAttributeNS("http://www.w3.org/1999/xlink", "href");
            if (this.stringLength(attributeNS) > 0) {
                e.reference(attributeNS.substring(1));
                list.add(e);
            }
            else {
                final NodeList elementsByTagName4 = element3.getElementsByTagName("stop");
                for (int k = 0; k < elementsByTagName4.getLength(); ++k) {
                    final Element element4 = (Element)elementsByTagName4.item(k);
                    final float float1 = Float.parseFloat(element4.getAttribute("offset"));
                    final String style = Util.extractStyle(element4.getAttribute("style"), "stop-color");
                    final String style2 = Util.extractStyle(element4.getAttribute("style"), "stop-opacity");
                    final Color color = new Color(Integer.parseInt(style.substring(1), 16));
                    color.a = Float.parseFloat(style2);
                    e.addStep(float1, color);
                }
                e.getImage();
            }
            diagram.addGradient(attribute, e);
        }
        final NodeList elementsByTagName5 = element.getElementsByTagName("radialGradient");
        for (int l = 0; l < elementsByTagName5.getLength(); ++l) {
            final Element element5 = (Element)elementsByTagName5.item(l);
            final String attribute2 = element5.getAttribute("id");
            final Gradient e2 = new Gradient(attribute2, true);
            e2.setTransform(Util.getTransform(element5, "gradientTransform"));
            if (this.stringLength(element5.getAttribute("cx")) > 0) {
                e2.setX1(Float.parseFloat(element5.getAttribute("cx")));
            }
            if (this.stringLength(element5.getAttribute("cy")) > 0) {
                e2.setY1(Float.parseFloat(element5.getAttribute("cy")));
            }
            if (this.stringLength(element5.getAttribute("fx")) > 0) {
                e2.setX2(Float.parseFloat(element5.getAttribute("fx")));
            }
            if (this.stringLength(element5.getAttribute("fy")) > 0) {
                e2.setY2(Float.parseFloat(element5.getAttribute("fy")));
            }
            if (this.stringLength(element5.getAttribute("r")) > 0) {
                e2.setR(Float.parseFloat(element5.getAttribute("r")));
            }
            final String attributeNS2 = element5.getAttributeNS("http://www.w3.org/1999/xlink", "href");
            if (this.stringLength(attributeNS2) > 0) {
                e2.reference(attributeNS2.substring(1));
                list.add(e2);
            }
            else {
                final NodeList elementsByTagName6 = element5.getElementsByTagName("stop");
                for (int n = 0; n < elementsByTagName6.getLength(); ++n) {
                    final Element element6 = (Element)elementsByTagName6.item(n);
                    final float float2 = Float.parseFloat(element6.getAttribute("offset"));
                    final String style3 = Util.extractStyle(element6.getAttribute("style"), "stop-color");
                    final String style4 = Util.extractStyle(element6.getAttribute("style"), "stop-opacity");
                    final Color color2 = new Color(Integer.parseInt(style3.substring(1), 16));
                    color2.a = Float.parseFloat(style4);
                    e2.addStep(float2, color2);
                }
                e2.getImage();
            }
            diagram.addGradient(attribute2, e2);
        }
        for (int n2 = 0; n2 < list.size(); ++n2) {
            list.get(n2).resolve(diagram);
            list.get(n2).getImage();
        }
    }
    
    public int stringLength(final String s) {
        if (s == null) {
            return 0;
        }
        return s.length();
    }
}
