// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg.inkscape;

import org.newdawn.slick.svg.ParsingException;
import org.newdawn.slick.svg.NonGeometricData;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.svg.Figure;
import org.newdawn.slick.geom.Ellipse;
import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.svg.Diagram;
import org.w3c.dom.Element;
import org.newdawn.slick.svg.Loader;

public class EllipseProcessor implements ElementProcessor
{
    @Override
    public void process(final Loader loader, final Element element, final Diagram diagram, final Transform transform) throws ParsingException {
        final Transform transform2 = new Transform(transform, Util.getTransform(element));
        final float floatAttribute = Util.getFloatAttribute(element, "cx");
        final float floatAttribute2 = Util.getFloatAttribute(element, "cy");
        final float floatAttribute3 = Util.getFloatAttribute(element, "rx");
        final float floatAttribute4 = Util.getFloatAttribute(element, "ry");
        final Shape transform3 = new Ellipse(floatAttribute, floatAttribute2, floatAttribute3, floatAttribute4).transform(transform2);
        final NonGeometricData nonGeometricData = Util.getNonGeometricData(element);
        nonGeometricData.addAttribute("cx", "" + floatAttribute);
        nonGeometricData.addAttribute("cy", "" + floatAttribute2);
        nonGeometricData.addAttribute("rx", "" + floatAttribute3);
        nonGeometricData.addAttribute("ry", "" + floatAttribute4);
        diagram.addFigure(new Figure(1, transform3, nonGeometricData, transform2));
    }
    
    @Override
    public boolean handles(final Element element) {
        return element.getNodeName().equals("ellipse") || (element.getNodeName().equals("path") && "arc".equals(element.getAttributeNS("http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd", "type")));
    }
}
