// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg.inkscape;

import org.w3c.dom.Element;
import org.newdawn.slick.svg.NonGeometricData;

public class InkscapeNonGeometricData extends NonGeometricData
{
    public Element element;
    
    public InkscapeNonGeometricData(final String s, final Element element) {
        super(s);
        this.element = element;
    }
    
    @Override
    public String getAttribute(final String s) {
        String s2 = super.getAttribute(s);
        if (s2 == null) {
            s2 = this.element.getAttribute(s);
        }
        return s2;
    }
    
    public Element getElement() {
        return this.element;
    }
}
