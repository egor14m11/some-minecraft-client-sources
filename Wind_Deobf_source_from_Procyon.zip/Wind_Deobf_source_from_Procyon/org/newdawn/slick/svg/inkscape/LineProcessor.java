// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg.inkscape;

import org.newdawn.slick.svg.NonGeometricData;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.svg.Figure;
import org.newdawn.slick.geom.Line;
import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.svg.Diagram;
import org.newdawn.slick.svg.Loader;
import org.newdawn.slick.svg.ParsingException;
import java.util.StringTokenizer;
import org.w3c.dom.Element;
import org.newdawn.slick.geom.Polygon;

public class LineProcessor implements ElementProcessor
{
    public static int processPoly(final Polygon polygon, final Element element, final StringTokenizer stringTokenizer) throws ParsingException {
        int n = 0;
        while (stringTokenizer.hasMoreTokens()) {
            final String nextToken = stringTokenizer.nextToken();
            if (nextToken.equals("L")) {
                continue;
            }
            if (nextToken.equals("z")) {
                break;
            }
            if (nextToken.equals("M")) {
                continue;
            }
            if (nextToken.equals("C")) {
                return 0;
            }
            polygon.addPoint(Float.parseFloat(nextToken), Float.parseFloat(stringTokenizer.nextToken()));
            ++n;
        }
        return n;
    }
    
    @Override
    public void process(final Loader loader, final Element element, final Diagram diagram, final Transform transform) throws ParsingException {
        final Transform transform2 = new Transform(transform, Util.getTransform(element));
        float float1;
        float float2;
        float float3;
        float float4;
        if (element.getNodeName().equals("line")) {
            float1 = Float.parseFloat(element.getAttribute("x1"));
            float2 = Float.parseFloat(element.getAttribute("x2"));
            float3 = Float.parseFloat(element.getAttribute("y1"));
            float4 = Float.parseFloat(element.getAttribute("y2"));
        }
        else {
            final StringTokenizer stringTokenizer = new StringTokenizer(element.getAttribute("d"), ", ");
            final Polygon polygon = new Polygon();
            if (processPoly(polygon, element, stringTokenizer) != 2) {
                return;
            }
            float1 = polygon.getPoint(0)[0];
            float3 = polygon.getPoint(0)[1];
            float2 = polygon.getPoint(1)[0];
            float4 = polygon.getPoint(1)[1];
        }
        final float[] array = { float1, float3, float2, float4 };
        final float[] array2 = new float[4];
        transform2.transform(array, 0, array2, 0, 2);
        final Line line = new Line(array2[0], array2[1], array2[2], array2[3]);
        final NonGeometricData nonGeometricData = Util.getNonGeometricData(element);
        nonGeometricData.addAttribute("x1", "" + float1);
        nonGeometricData.addAttribute("x2", "" + float2);
        nonGeometricData.addAttribute("y1", "" + float3);
        nonGeometricData.addAttribute("y2", "" + float4);
        diagram.addFigure(new Figure(2, line, nonGeometricData, transform2));
    }
    
    @Override
    public boolean handles(final Element element) {
        return element.getNodeName().equals("line") || (element.getNodeName().equals("path") && !"arc".equals(element.getAttributeNS("http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd", "type")));
    }
}
