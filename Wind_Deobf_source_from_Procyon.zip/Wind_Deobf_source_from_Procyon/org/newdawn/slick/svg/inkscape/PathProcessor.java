// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg.inkscape;

import org.newdawn.slick.svg.NonGeometricData;
import org.newdawn.slick.svg.Figure;
import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.svg.Diagram;
import org.newdawn.slick.svg.Loader;
import org.newdawn.slick.svg.ParsingException;
import java.util.ArrayList;
import org.newdawn.slick.geom.Path;
import java.util.StringTokenizer;
import org.w3c.dom.Element;

public class PathProcessor implements ElementProcessor
{
    public static Path processPoly(final Element element, final StringTokenizer stringTokenizer) throws ParsingException {
        final ArrayList list = new ArrayList();
        int n = 0;
        boolean b = false;
        Path path = null;
        while (stringTokenizer.hasMoreTokens()) {
            final String nextToken = stringTokenizer.nextToken();
            if (nextToken.equals("L")) {
                path.lineTo(Float.parseFloat(stringTokenizer.nextToken()), Float.parseFloat(stringTokenizer.nextToken()));
            }
            else if (nextToken.equals("z")) {
                path.close();
            }
            else if (nextToken.equals("M")) {
                if (n == 0) {
                    n = 1;
                    path = new Path(Float.parseFloat(stringTokenizer.nextToken()), Float.parseFloat(stringTokenizer.nextToken()));
                }
                else {
                    b = true;
                    path.startHole(Float.parseFloat(stringTokenizer.nextToken()), Float.parseFloat(stringTokenizer.nextToken()));
                }
            }
            else {
                if (!nextToken.equals("C")) {
                    continue;
                }
                b = true;
                path.curveTo(Float.parseFloat(stringTokenizer.nextToken()), Float.parseFloat(stringTokenizer.nextToken()), Float.parseFloat(stringTokenizer.nextToken()), Float.parseFloat(stringTokenizer.nextToken()), Float.parseFloat(stringTokenizer.nextToken()), Float.parseFloat(stringTokenizer.nextToken()));
            }
        }
        if (!b) {
            return null;
        }
        return path;
    }
    
    @Override
    public void process(final Loader loader, final Element element, final Diagram diagram, final Transform transform) throws ParsingException {
        final Transform transform2 = new Transform(transform, Util.getTransform(element));
        String str = element.getAttribute("points");
        if (element.getNodeName().equals("path")) {
            str = element.getAttribute("d");
        }
        final Path processPoly = processPoly(element, new StringTokenizer(str, ", "));
        final NonGeometricData nonGeometricData = Util.getNonGeometricData(element);
        if (processPoly != null) {
            diagram.addFigure(new Figure(4, processPoly.transform(transform2), nonGeometricData, transform2));
        }
    }
    
    @Override
    public boolean handles(final Element element) {
        return element.getNodeName().equals("path") && !"arc".equals(element.getAttributeNS("http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd", "type"));
    }
}
