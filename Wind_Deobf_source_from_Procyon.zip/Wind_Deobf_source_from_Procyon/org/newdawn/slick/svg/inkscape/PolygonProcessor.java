// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg.inkscape;

import org.newdawn.slick.svg.NonGeometricData;
import org.newdawn.slick.svg.Figure;
import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.svg.Diagram;
import org.newdawn.slick.svg.Loader;
import org.newdawn.slick.svg.ParsingException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import org.w3c.dom.Element;
import org.newdawn.slick.geom.Polygon;

public class PolygonProcessor implements ElementProcessor
{
    public static int processPoly(final Polygon polygon, final Element element, final StringTokenizer stringTokenizer) throws ParsingException {
        int n = 0;
        final ArrayList list = new ArrayList();
        int n2 = 0;
        boolean closed = false;
        while (stringTokenizer.hasMoreTokens()) {
            final String nextToken = stringTokenizer.nextToken();
            if (nextToken.equals("L")) {
                continue;
            }
            if (nextToken.equals("z")) {
                closed = true;
                break;
            }
            if (nextToken.equals("M")) {
                if (n2 != 0) {
                    return 0;
                }
                n2 = 1;
            }
            else {
                if (nextToken.equals("C")) {
                    return 0;
                }
                polygon.addPoint(Float.parseFloat(nextToken), Float.parseFloat(stringTokenizer.nextToken()));
                ++n;
            }
        }
        polygon.setClosed(closed);
        return n;
    }
    
    @Override
    public void process(final Loader loader, final Element element, final Diagram diagram, final Transform transform) throws ParsingException {
        final Transform transform2 = new Transform(transform, Util.getTransform(element));
        String str = element.getAttribute("points");
        if (element.getNodeName().equals("path")) {
            str = element.getAttribute("d");
        }
        final StringTokenizer stringTokenizer = new StringTokenizer(str, ", ");
        final Polygon polygon = new Polygon();
        final int processPoly = processPoly(polygon, element, stringTokenizer);
        final NonGeometricData nonGeometricData = Util.getNonGeometricData(element);
        if (processPoly > 3) {
            diagram.addFigure(new Figure(5, polygon.transform(transform2), nonGeometricData, transform2));
        }
    }
    
    @Override
    public boolean handles(final Element element) {
        return element.getNodeName().equals("polygon") || (element.getNodeName().equals("path") && !"arc".equals(element.getAttributeNS("http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd", "type")));
    }
}
