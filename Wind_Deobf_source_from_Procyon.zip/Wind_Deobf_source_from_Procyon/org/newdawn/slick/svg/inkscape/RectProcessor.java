// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg.inkscape;

import org.newdawn.slick.svg.ParsingException;
import org.newdawn.slick.svg.NonGeometricData;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.svg.Figure;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.svg.Diagram;
import org.w3c.dom.Element;
import org.newdawn.slick.svg.Loader;

public class RectProcessor implements ElementProcessor
{
    @Override
    public void process(final Loader loader, final Element element, final Diagram diagram, final Transform transform) throws ParsingException {
        final Transform transform2 = new Transform(transform, Util.getTransform(element));
        final float float1 = Float.parseFloat(element.getAttribute("width"));
        final float float2 = Float.parseFloat(element.getAttribute("height"));
        final float float3 = Float.parseFloat(element.getAttribute("x"));
        final float float4 = Float.parseFloat(element.getAttribute("y"));
        final Shape transform3 = new Rectangle(float3, float4, float1 + 1.0f, float2 + 1.0f).transform(transform2);
        final NonGeometricData nonGeometricData = Util.getNonGeometricData(element);
        nonGeometricData.addAttribute("width", "" + float1);
        nonGeometricData.addAttribute("height", "" + float2);
        nonGeometricData.addAttribute("x", "" + float3);
        nonGeometricData.addAttribute("y", "" + float4);
        diagram.addFigure(new Figure(3, transform3, nonGeometricData, transform2));
    }
    
    @Override
    public boolean handles(final Element element) {
        return element.getNodeName().equals("rect");
    }
}
