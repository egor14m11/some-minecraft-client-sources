// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg.inkscape;

import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.svg.NonGeometricData;
import org.newdawn.slick.svg.Figure;
import org.newdawn.slick.svg.ParsingException;
import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.svg.Diagram;
import org.newdawn.slick.svg.Loader;
import org.w3c.dom.Element;

public class UseProcessor implements ElementProcessor
{
    @Override
    public boolean handles(final Element element) {
        return element.getNodeName().equals("use");
    }
    
    @Override
    public void process(final Loader loader, final Element element, final Diagram diagram, final Transform transform) throws ParsingException {
        final String asReference = Util.getAsReference(element.getAttributeNS("http://www.w3.org/1999/xlink", "href"));
        final Figure figureByID = diagram.getFigureByID(asReference);
        if (figureByID == null) {
            throw new ParsingException(element, "Unable to locate referenced element: " + asReference);
        }
        final Transform concatenate = Util.getTransform(element).concatenate(figureByID.getTransform());
        final NonGeometricData nonGeometricData = Util.getNonGeometricData(element);
        final Shape transform2 = figureByID.getShape().transform(concatenate);
        nonGeometricData.addAttribute("fill", figureByID.getData().getAttribute("fill"));
        nonGeometricData.addAttribute("stroke", figureByID.getData().getAttribute("stroke"));
        nonGeometricData.addAttribute("opacity", figureByID.getData().getAttribute("opacity"));
        nonGeometricData.addAttribute("stroke-width", figureByID.getData().getAttribute("stroke-width"));
        diagram.addFigure(new Figure(figureByID.getType(), transform2, nonGeometricData, concatenate));
    }
}
