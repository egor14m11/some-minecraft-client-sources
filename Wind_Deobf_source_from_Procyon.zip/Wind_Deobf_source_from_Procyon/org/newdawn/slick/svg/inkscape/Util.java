// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.svg.inkscape;

import org.newdawn.slick.svg.ParsingException;
import org.newdawn.slick.geom.Transform;
import java.util.StringTokenizer;
import org.newdawn.slick.svg.NonGeometricData;
import org.w3c.dom.Element;

public class Util
{
    public static String INKSCAPE;
    public static String SODIPODI;
    public static String XLINK;
    
    public static NonGeometricData getNonGeometricData(final Element element) {
        final InkscapeNonGeometricData inkscapeNonGeometricData = new InkscapeNonGeometricData(getMetaData(element), element);
        inkscapeNonGeometricData.addAttribute("id", element.getAttribute("id"));
        inkscapeNonGeometricData.addAttribute("fill", getStyle(element, "fill"));
        inkscapeNonGeometricData.addAttribute("stroke", getStyle(element, "stroke"));
        inkscapeNonGeometricData.addAttribute("opacity", getStyle(element, "opacity"));
        inkscapeNonGeometricData.addAttribute("stroke-dasharray", getStyle(element, "stroke-dasharray"));
        inkscapeNonGeometricData.addAttribute("stroke-dashoffset", getStyle(element, "stroke-dashoffset"));
        inkscapeNonGeometricData.addAttribute("stroke-miterlimit", getStyle(element, "stroke-miterlimit"));
        inkscapeNonGeometricData.addAttribute("stroke-opacity", getStyle(element, "stroke-opacity"));
        inkscapeNonGeometricData.addAttribute("stroke-width", getStyle(element, "stroke-width"));
        return inkscapeNonGeometricData;
    }
    
    public static String getMetaData(final Element element) {
        final String attributeNS = element.getAttributeNS("http://www.inkscape.org/namespaces/inkscape", "label");
        if (attributeNS != null && !attributeNS.equals("")) {
            return attributeNS;
        }
        return element.getAttribute("id");
    }
    
    public static String getStyle(final Element element, final String s) {
        final String attribute = element.getAttribute(s);
        if (attribute != null && attribute.length() > 0) {
            return attribute;
        }
        return extractStyle(element.getAttribute("style"), s);
    }
    
    public static String extractStyle(final String str, final String anObject) {
        if (str == null) {
            return "";
        }
        final StringTokenizer stringTokenizer = new StringTokenizer(str, ";");
        while (stringTokenizer.hasMoreTokens()) {
            final String nextToken = stringTokenizer.nextToken();
            if (nextToken.substring(0, nextToken.indexOf(58)).equals(anObject)) {
                return nextToken.substring(nextToken.indexOf(58) + 1);
            }
        }
        return "";
    }
    
    public static Transform getTransform(final Element element) {
        return getTransform(element, "transform");
    }
    
    public static Transform getTransform(final Element element, final String s) {
        final String attribute = element.getAttribute(s);
        if (attribute == null) {
            return new Transform();
        }
        if (attribute.equals("")) {
            return new Transform();
        }
        if (attribute.startsWith("translate")) {
            final StringTokenizer stringTokenizer = new StringTokenizer(attribute.substring(0, attribute.length() - 1).substring(10), ", ");
            return Transform.createTranslateTransform(Float.parseFloat(stringTokenizer.nextToken()), Float.parseFloat(stringTokenizer.nextToken()));
        }
        if (attribute.startsWith("matrix")) {
            final float[] array = new float[6];
            final StringTokenizer stringTokenizer2 = new StringTokenizer(attribute.substring(0, attribute.length() - 1).substring(7), ", ");
            final float[] array2 = new float[6];
            for (int i = 0; i < array2.length; ++i) {
                array2[i] = Float.parseFloat(stringTokenizer2.nextToken());
            }
            array[0] = array2[0];
            array[1] = array2[2];
            array[2] = array2[4];
            array[3] = array2[1];
            array[4] = array2[3];
            array[5] = array2[5];
            return new Transform(array);
        }
        return new Transform();
    }
    
    public static float getFloatAttribute(final Element element, final String s) throws ParsingException {
        String s2 = element.getAttribute(s);
        if (s2 == null || s2.equals("")) {
            s2 = element.getAttributeNS("http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd", s);
        }
        return Float.parseFloat(s2);
    }
    
    public static String getAsReference(String substring) {
        if (substring.length() < 2) {
            return "";
        }
        substring = substring.substring(1, substring.length());
        return substring;
    }
    
    static {
        Util.XLINK = "http://www.w3.org/1999/xlink";
        Util.SODIPODI = "http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd";
        Util.INKSCAPE = "http://www.inkscape.org/namespaces/inkscape";
    }
}
