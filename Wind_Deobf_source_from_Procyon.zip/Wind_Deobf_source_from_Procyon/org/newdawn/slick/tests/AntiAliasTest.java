// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.BasicGame;

public class AntiAliasTest extends BasicGame
{
    public AntiAliasTest() {
        super("AntiAlias Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        gameContainer.getGraphics().setBackground(Color.green);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.setAntiAlias(true);
        graphics.setColor(Color.red);
        graphics.drawOval(100.0f, 100.0f, 100.0f, 100.0f);
        graphics.fillOval(300.0f, 100.0f, 100.0f, 100.0f);
        graphics.setAntiAlias(false);
        graphics.setColor(Color.red);
        graphics.drawOval(100.0f, 300.0f, 100.0f, 100.0f);
        graphics.fillOval(300.0f, 300.0f, 100.0f, 100.0f);
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new AntiAliasTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
