// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.BigImage;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.Image;
import org.newdawn.slick.BasicGame;

public class BigImageTest extends BasicGame
{
    public Image original;
    public Image image;
    public Image imageX;
    public Image imageY;
    public Image sub;
    public Image scaledSub;
    public float x;
    public float y;
    public float ang;
    public SpriteSheet bigSheet;
    
    public BigImageTest() {
        super("Big Image Test");
        this.ang = 30.0f;
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        final BigImage bigImage = new BigImage("testdata/bigimage.tga", 2, 512);
        this.image = bigImage;
        this.original = bigImage;
        this.sub = this.image.getSubImage(210, 210, 200, 130);
        this.scaledSub = this.sub.getScaledCopy(2.0f);
        this.image = this.image.getScaledCopy(0.0f);
        this.imageX = this.image.getFlippedCopy(true, false);
        this.imageY = this.imageX.getFlippedCopy(true, true);
        this.bigSheet = new SpriteSheet(this.original, 16, 16);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        this.original.draw(0.0f, 0.0f, new Color(1.0f, 1.0f, 1.0f, 0.0f));
        this.image.draw(this.x, this.y);
        this.imageX.draw(this.x + 400.0f, this.y);
        this.imageY.draw(this.x, this.y + 300.0f);
        this.scaledSub.draw(this.x + 300.0f, this.y + 300.0f);
        this.bigSheet.getSprite(7, 5).draw(50.0f, 10.0f);
        graphics.setColor(Color.white);
        graphics.drawRect(50.0f, 10.0f, 64.0f, 64.0f);
        graphics.rotate(this.x + 400.0f, this.y + 165.0f, this.ang);
        graphics.drawImage(this.sub, this.x + 300.0f, this.y + 100.0f);
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new BigImageTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        this.ang += n * 0.0f;
        if (gameContainer.getInput().isKeyDown(203)) {
            this.x -= n * 0.0f;
        }
        if (gameContainer.getInput().isKeyDown(205)) {
            this.x += n * 0.0f;
        }
        if (gameContainer.getInput().isKeyDown(200)) {
            this.y -= n * 0.0f;
        }
        if (gameContainer.getInput().isKeyDown(208)) {
            this.y += n * 0.0f;
        }
    }
}
