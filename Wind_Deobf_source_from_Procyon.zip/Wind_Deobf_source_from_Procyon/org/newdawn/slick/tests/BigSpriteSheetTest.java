// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.BigImage;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.Image;
import org.newdawn.slick.BasicGame;

public class BigSpriteSheetTest extends BasicGame
{
    public Image original;
    public SpriteSheet bigSheet;
    public boolean oldMethod;
    
    public BigSpriteSheetTest() {
        super("Big SpriteSheet Test");
        this.oldMethod = true;
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.original = new BigImage("testdata/bigimage.tga", 2, 256);
        this.bigSheet = new SpriteSheet(this.original, 16, 16);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        if (this.oldMethod) {
            for (int i = 0; i < 43; ++i) {
                for (int j = 0; j < 27; ++j) {
                    this.bigSheet.getSprite(i, j).draw((float)(10 + i * 18), (float)(50 + j * 18));
                }
            }
        }
        else {
            this.bigSheet.startUse();
            for (int k = 0; k < 43; ++k) {
                for (int l = 0; l < 27; ++l) {
                    this.bigSheet.renderInUse(10 + k * 18, 50 + l * 18, k, l);
                }
            }
            this.bigSheet.endUse();
        }
        graphics.drawString("Press space to toggle rendering method", 10.0f, 30.0f);
        gameContainer.getDefaultFont().drawString(10.0f, 100.0f, "TEST");
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new BigSpriteSheetTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        if (gameContainer.getInput().isKeyPressed(57)) {
            this.oldMethod = !this.oldMethod;
        }
    }
}
