// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.CachedRender;
import org.newdawn.slick.BasicGame;

public class CachedRenderTest extends BasicGame
{
    public Runnable operations;
    public CachedRender cached;
    public boolean drawCached;
    
    public CachedRenderTest() {
        super("Cached Render Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.operations = new Runnable(this, gameContainer) {
            public GameContainer val$container;
            public CachedRenderTest this$0;
            
            @Override
            public void run() {
                for (int i = 0; i < 100; ++i) {
                    final int n = i + 100;
                    this.val$container.getGraphics().setColor(new Color(n, n, n, n));
                    this.val$container.getGraphics().drawOval((float)(i * 5 + 50), (float)(i * 3 + 50), 100.0f, 100.0f);
                }
            }
        };
        this.cached = new CachedRender(this.operations);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        if (gameContainer.getInput().isKeyPressed(57)) {
            this.drawCached = !this.drawCached;
        }
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.setColor(Color.white);
        graphics.drawString("Press space to toggle caching", 10.0f, 130.0f);
        if (this.drawCached) {
            graphics.drawString("Drawing from cache", 10.0f, 100.0f);
            this.cached.render();
        }
        else {
            graphics.drawString("Drawing direct", 10.0f, 100.0f);
            this.operations.run();
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new CachedRenderTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
