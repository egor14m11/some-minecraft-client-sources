// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.GridLayout;
import java.awt.Frame;
import org.newdawn.slick.Game;
import org.newdawn.slick.CanvasGameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.BasicGame;

public class CanvasSizeTest extends BasicGame
{
    public CanvasSizeTest() {
        super("Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        System.out.println(gameContainer.getWidth() + ", " + gameContainer.getHeight());
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    public static void main(final String[] array) {
        final CanvasGameContainer comp = new CanvasGameContainer(new CanvasSizeTest());
        comp.setSize(640, 480);
        final Frame frame = new Frame("Test");
        frame.setLayout(new GridLayout(1, 2));
        frame.add(comp);
        frame.pack();
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(final WindowEvent windowEvent) {
                System.exit(0);
            }
        });
        frame.setVisible(true);
        comp.start();
    }
}
