// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.geom.Polygon;
import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.geom.Curve;
import org.newdawn.slick.BasicGame;

public class CurveTest extends BasicGame
{
    public Curve curve;
    public Vector2f p1;
    public Vector2f c1;
    public Vector2f c2;
    public Vector2f p2;
    public Polygon poly;
    
    public CurveTest() {
        super("Curve Test");
        this.p1 = new Vector2f(100.0f, 300.0f);
        this.c1 = new Vector2f(100.0f, 100.0f);
        this.c2 = new Vector2f(300.0f, 100.0f);
        this.p2 = new Vector2f(300.0f, 300.0f);
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        gameContainer.getGraphics().setBackground(Color.white);
        this.curve = new Curve(this.p2, this.c2, this.c1, this.p1);
        (this.poly = new Polygon()).addPoint(500.0f, 200.0f);
        this.poly.addPoint(600.0f, 200.0f);
        this.poly.addPoint(700.0f, 300.0f);
        this.poly.addPoint(400.0f, 300.0f);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    public void drawMarker(final Graphics graphics, final Vector2f vector2f) {
        graphics.drawRect(vector2f.x - 5.0f, vector2f.y - 5.0f, 10.0f, 10.0f);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.setColor(Color.gray);
        this.drawMarker(graphics, this.p1);
        this.drawMarker(graphics, this.p2);
        graphics.setColor(Color.red);
        this.drawMarker(graphics, this.c1);
        this.drawMarker(graphics, this.c2);
        graphics.setColor(Color.black);
        graphics.draw(this.curve);
        graphics.fill(this.curve);
        graphics.draw(this.poly);
        graphics.fill(this.poly);
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new CurveTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
