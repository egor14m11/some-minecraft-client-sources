// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.BasicGame;

public class DoubleClickTest extends BasicGame
{
    public String message;
    
    public DoubleClickTest() {
        super("Double Click Test");
        this.message = "Click or Double Click";
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.drawString(this.message, 100.0f, 100.0f);
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new DoubleClickTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    @Override
    public void mouseClicked(final int n, final int n2, final int n3, final int n4) {
        if (n4 == 1) {
            this.message = "Single Click: " + n + " " + n2 + "," + n3;
        }
        if (n4 == 2) {
            this.message = "Double Click: " + n + " " + n2 + "," + n3;
        }
    }
}
