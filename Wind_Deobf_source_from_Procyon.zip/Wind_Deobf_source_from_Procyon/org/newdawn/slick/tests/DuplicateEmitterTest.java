// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.particles.ParticleEmitter;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.particles.ParticleIO;
import org.newdawn.slick.particles.ConfigurableEmitter;
import org.newdawn.slick.particles.ParticleSystem;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.BasicGame;

public class DuplicateEmitterTest extends BasicGame
{
    public GameContainer container;
    public ParticleSystem explosionSystem;
    public ConfigurableEmitter explosionEmitter;
    
    public DuplicateEmitterTest() {
        super("DuplicateEmitterTest");
    }
    
    @Override
    public void init(final GameContainer container) throws SlickException {
        this.container = container;
        this.explosionSystem = ParticleIO.loadConfiguredSystem("testdata/endlessexplosion.xml");
        (this.explosionEmitter = (ConfigurableEmitter)this.explosionSystem.getEmitter(0)).setPosition(400.0f, 100.0f);
        for (int i = 0; i < 5; ++i) {
            final ConfigurableEmitter duplicate = this.explosionEmitter.duplicate();
            if (duplicate == null) {
                throw new SlickException("Failed to duplicate explosionEmitter");
            }
            duplicate.name = duplicate.name + "_" + i;
            duplicate.setPosition((float)((i + 1) * 133), 400.0f);
            this.explosionSystem.addEmitter(duplicate);
        }
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        this.explosionSystem.update(n);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        this.explosionSystem.render();
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 1) {
            this.container.exit();
        }
        if (n == 37) {
            this.explosionEmitter.wrapUp();
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new DuplicateEmitterTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
