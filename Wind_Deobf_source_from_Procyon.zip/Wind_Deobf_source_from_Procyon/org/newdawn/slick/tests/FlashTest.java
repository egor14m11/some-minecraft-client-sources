// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Image;
import org.newdawn.slick.BasicGame;

public class FlashTest extends BasicGame
{
    public Image image;
    public boolean flash;
    public GameContainer container;
    
    public FlashTest() {
        super("Flash Test");
    }
    
    @Override
    public void init(final GameContainer container) throws SlickException {
        this.container = container;
        this.image = new Image("testdata/logo.tga");
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        graphics.drawString("Press space to toggle", 10.0f, 50.0f);
        if (this.flash) {
            this.image.draw(100.0f, 100.0f);
        }
        else {
            this.image.drawFlash(100.0f, 100.0f, (float)this.image.getWidth(), (float)this.image.getHeight(), new Color(1.0f, 0.0f, 1.0f, 1.0f));
        }
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new FlashTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 57) {
            this.flash = !this.flash;
        }
        if (n == 1) {
            this.container.exit();
        }
    }
}
