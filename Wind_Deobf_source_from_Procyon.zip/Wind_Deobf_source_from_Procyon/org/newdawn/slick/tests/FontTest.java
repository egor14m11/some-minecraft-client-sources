// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Image;
import org.newdawn.slick.AngelCodeFont;
import org.newdawn.slick.BasicGame;

public class FontTest extends BasicGame
{
    public AngelCodeFont font;
    public AngelCodeFont font2;
    public Image image;
    public static AppGameContainer container;
    
    public FontTest() {
        super("Font Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.font = new AngelCodeFont("testdata/demo2.fnt", "testdata/demo2_00.tga");
        this.font2 = new AngelCodeFont("testdata/hiero.fnt", "testdata/hiero.png");
        this.image = new Image("testdata/demo2_00.tga", false);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        this.font.drawString(80.0f, 5.0f, "A Font Example", Color.red);
        this.font.drawString(100.0f, 32.0f, "We - AV - Here is a more complete line that hopefully");
        this.font.drawString(100.0f, (float)(36 + this.font.getHeight("We Here is a more complete line that hopefully")), "will show some kerning.");
        this.font2.drawString(80.0f, 85.0f, "A Font Example", Color.red);
        this.font2.drawString(100.0f, 132.0f, "We - AV - Here is a more complete line that hopefully");
        this.font2.drawString(100.0f, (float)(136 + this.font2.getHeight("We - Here is a more complete line that hopefully")), "will show some kerning.");
        this.image.draw(100.0f, 400.0f);
        final String s = "Testing Font";
        this.font2.drawString(100.0f, 300.0f, s);
        graphics.setColor(Color.white);
        graphics.drawRect(100.0f, (float)(300 + this.font2.getYOffset(s)), (float)this.font2.getWidth(s), (float)(this.font2.getHeight(s) - this.font2.getYOffset(s)));
        this.font.drawString(500.0f, 300.0f, s);
        graphics.setColor(Color.white);
        graphics.drawRect(500.0f, (float)(300 + this.font.getYOffset(s)), (float)this.font.getWidth(s), (float)(this.font.getHeight(s) - this.font.getYOffset(s)));
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 1) {
            System.exit(0);
        }
        if (n == 57) {
            FontTest.container.setDisplayMode(640, 480, false);
        }
    }
    
    public static void main(final String[] array) {
        (FontTest.container = new AppGameContainer(new FontTest())).setDisplayMode(800, 600, false);
        FontTest.container.start();
    }
}
