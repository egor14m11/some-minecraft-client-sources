// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Color;
import org.newdawn.slick.gui.GUIContext;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.AngelCodeFont;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Font;
import org.newdawn.slick.gui.TextField;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.gui.MouseOverArea;
import org.newdawn.slick.Image;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.BasicGame;

public class GUITest extends BasicGame implements ComponentListener
{
    public Image image;
    public MouseOverArea[] areas;
    public GameContainer container;
    public String message;
    public TextField field;
    public TextField field2;
    public Image background;
    public Font font;
    public AppGameContainer app;
    
    public GUITest() {
        super("GUI Test");
        this.areas = new MouseOverArea[4];
        this.message = "Demo Menu System with stock images";
    }
    
    @Override
    public void init(final GameContainer container) throws SlickException {
        if (container instanceof AppGameContainer) {
            (this.app = (AppGameContainer)container).setIcon("testdata/icon.tga");
        }
        this.font = new AngelCodeFont("testdata/demo2.fnt", "testdata/demo2_00.tga");
        this.field = new TextField(container, this.font, 150, 20, 500, 35, new ComponentListener(this) {
            public GUITest this$0;
            
            @Override
            public void componentActivated(final AbstractComponent abstractComponent) {
                GUITest.access$002(this.this$0, "Entered1: " + GUITest.access$100(this.this$0).getText());
                GUITest.access$200(this.this$0).setFocus(true);
            }
        });
        (this.field2 = new TextField(container, this.font, 150, 70, 500, 35, new ComponentListener(this) {
            public GUITest this$0;
            
            @Override
            public void componentActivated(final AbstractComponent abstractComponent) {
                GUITest.access$002(this.this$0, "Entered2: " + GUITest.access$200(this.this$0).getText());
                GUITest.access$100(this.this$0).setFocus(true);
            }
        })).setBorderColor(Color.red);
        this.container = container;
        this.image = new Image("testdata/logo.tga");
        this.background = new Image("testdata/dungeontiles.gif");
        container.setMouseCursor("testdata/cursor.tga", 0, 0);
        for (int i = 0; i < 4; ++i) {
            (this.areas[i] = new MouseOverArea(container, this.image, 300, 100 + i * 100, 200, 90, this)).setNormalColor(new Color(1.0f, 1.0f, 1.0f, 0.0f));
            this.areas[i].setMouseOverColor(new Color(1.0f, 1.0f, 1.0f, 0.0f));
        }
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        this.background.draw(0.0f, 0.0f, 800.0f, 500.0f);
        for (int i = 0; i < 4; ++i) {
            this.areas[i].render(gameContainer, graphics);
        }
        this.field.render(gameContainer, graphics);
        this.field2.render(gameContainer, graphics);
        graphics.setFont(this.font);
        graphics.drawString(this.message, 200.0f, 550.0f);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 1) {
            System.exit(0);
        }
        if (n == 60) {
            this.app.setDefaultMouseCursor();
        }
        if (n == 59 && this.app != null) {
            this.app.setDisplayMode(640, 480, false);
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new GUITest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    @Override
    public void componentActivated(final AbstractComponent obj) {
        System.out.println("ACTIVL : " + obj);
        for (int i = 0; i < 4; ++i) {
            if (obj == this.areas[i]) {
                this.message = "Option " + (i + 1) + " pressed!";
            }
        }
        this.field2;
    }
    
    public static String access$002(final GUITest guiTest, final String message) {
        return guiTest.message = message;
    }
    
    public static TextField access$100(final GUITest guiTest) {
        return guiTest.field;
    }
    
    public static TextField access$200(final GUITest guiTest) {
        return guiTest.field2;
    }
}
