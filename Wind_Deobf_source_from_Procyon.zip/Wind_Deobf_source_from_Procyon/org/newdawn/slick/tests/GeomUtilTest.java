// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Polygon;
import org.newdawn.slick.geom.Circle;
import org.newdawn.slick.geom.GeomUtil;
import java.util.ArrayList;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.geom.GeomUtilListener;
import org.newdawn.slick.BasicGame;

public class GeomUtilTest extends BasicGame implements GeomUtilListener
{
    public Shape source;
    public Shape cut;
    public Shape[] result;
    public ArrayList points;
    public ArrayList marks;
    public ArrayList exclude;
    public boolean dynamic;
    public GeomUtil util;
    public int xp;
    public int yp;
    public Circle circle;
    public Shape rect;
    public Polygon star;
    public boolean union;
    
    public GeomUtilTest() {
        super("GeomUtilTest");
        this.points = new ArrayList();
        this.marks = new ArrayList();
        this.exclude = new ArrayList();
        this.util = new GeomUtil();
    }
    
    public void init() {
        final Polygon source = new Polygon();
        source.addPoint(100.0f, 100.0f);
        source.addPoint(150.0f, 80.0f);
        source.addPoint(210.0f, 120.0f);
        source.addPoint(340.0f, 150.0f);
        source.addPoint(150.0f, 200.0f);
        source.addPoint(120.0f, 250.0f);
        this.source = source;
        this.circle = new Circle(0.0f, 0.0f, 50.0f);
        this.rect = new Rectangle(-100.0f, -40.0f, 200.0f, 80.0f);
        this.star = new Polygon();
        float n = 40.0f;
        for (int i = 0; i < 360; i += 30) {
            n = ((n == 40.0f) ? 60.0f : 40.0f);
            this.star.addPoint((float)(Math.cos(Math.toRadians(i)) * n), (float)(Math.sin(Math.toRadians(i)) * n));
        }
        (this.cut = this.circle).setLocation(203.0f, 78.0f);
        this.xp = (int)this.cut.getCenterX();
        this.yp = (int)this.cut.getCenterY();
        this.makeBoolean();
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.util.setListener(this);
        this.init();
        gameContainer.setVSync(true);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        if (gameContainer.getInput().isKeyPressed(57)) {
            this.dynamic = !this.dynamic;
        }
        if (gameContainer.getInput().isKeyPressed(28)) {
            this.union = !this.union;
            this.makeBoolean();
        }
        if (gameContainer.getInput().isKeyPressed(2)) {
            this.cut = this.circle;
            this.circle.setCenterX((float)this.xp);
            this.circle.setCenterY((float)this.yp);
            this.makeBoolean();
        }
        if (gameContainer.getInput().isKeyPressed(3)) {
            this.cut = this.rect;
            this.rect.setCenterX((float)this.xp);
            this.rect.setCenterY((float)this.yp);
            this.makeBoolean();
        }
        if (gameContainer.getInput().isKeyPressed(4)) {
            this.cut = this.star;
            this.star.setCenterX((float)this.xp);
            this.star.setCenterY((float)this.yp);
            this.makeBoolean();
        }
        if (this.dynamic) {
            this.xp = gameContainer.getInput().getMouseX();
            this.yp = gameContainer.getInput().getMouseY();
            this.makeBoolean();
        }
    }
    
    public void makeBoolean() {
        this.marks.clear();
        this.points.clear();
        this.exclude.clear();
        this.cut.setCenterX((float)this.xp);
        this.cut.setCenterY((float)this.yp);
        if (this.union) {
            this.result = this.util.union(this.source, this.cut);
        }
        else {
            this.result = this.util.subtract(this.source, this.cut);
        }
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.drawString("Space - toggle movement of cutting shape", 530.0f, 10.0f);
        graphics.drawString("1,2,3 - select cutting shape", 530.0f, 30.0f);
        graphics.drawString("Mouse wheel - rotate shape", 530.0f, 50.0f);
        graphics.drawString("Enter - toggle union/subtract", 530.0f, 70.0f);
        graphics.drawString("MODE: " + (this.union ? "Union" : "Cut"), 530.0f, 200.0f);
        graphics.setColor(Color.green);
        graphics.draw(this.source);
        graphics.setColor(Color.red);
        graphics.draw(this.cut);
        graphics.setColor(Color.white);
        for (int i = 0; i < this.exclude.size(); ++i) {
            final Vector2f vector2f = this.exclude.get(i);
            graphics.drawOval(vector2f.x - 3.0f, vector2f.y - 3.0f, 7.0f, 7.0f);
        }
        graphics.setColor(Color.yellow);
        for (int j = 0; j < this.points.size(); ++j) {
            final Vector2f vector2f2 = this.points.get(j);
            graphics.fillOval(vector2f2.x - 1.0f, vector2f2.y - 1.0f, 3.0f, 3.0f);
        }
        graphics.setColor(Color.white);
        for (int k = 0; k < this.marks.size(); ++k) {
            final Vector2f vector2f3 = this.marks.get(k);
            graphics.fillOval(vector2f3.x - 1.0f, vector2f3.y - 1.0f, 3.0f, 3.0f);
        }
        graphics.translate(0.0f, 300.0f);
        graphics.setColor(Color.white);
        if (this.result != null) {
            for (int l = 0; l < this.result.length; ++l) {
                graphics.draw(this.result[l]);
            }
            graphics.drawString("Polys:" + this.result.length, 10.0f, 100.0f);
            graphics.drawString("X:" + this.xp, 10.0f, 120.0f);
            graphics.drawString("Y:" + this.yp, 10.0f, 130.0f);
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new GeomUtilTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    @Override
    public void pointExcluded(final float n, final float n2) {
        this.exclude.add(new Vector2f(n, n2));
    }
    
    @Override
    public void pointIntersected(final float n, final float n2) {
        this.marks.add(new Vector2f(n, n2));
    }
    
    @Override
    public void pointUsed(final float n, final float n2) {
        this.points.add(new Vector2f(n, n2));
    }
    
    @Override
    public void mouseWheelMoved(final int n) {
        if (this.dynamic) {
            if (n < 0) {
                this.cut = this.cut.transform(Transform.createRotateTransform((float)Math.toRadians(10.0), this.cut.getCenterX(), this.cut.getCenterY()));
            }
            else {
                this.cut = this.cut.transform(Transform.createRotateTransform((float)Math.toRadians(-10.0), this.cut.getCenterX(), this.cut.getCenterY()));
            }
        }
    }
}
