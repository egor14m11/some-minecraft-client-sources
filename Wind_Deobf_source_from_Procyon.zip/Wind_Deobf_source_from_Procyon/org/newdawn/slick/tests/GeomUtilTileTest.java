// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import java.util.Collection;
import java.util.HashSet;
import org.newdawn.slick.geom.Circle;
import org.newdawn.slick.geom.Polygon;
import java.util.ArrayList;
import org.newdawn.slick.geom.GeomUtil;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.geom.GeomUtilListener;
import org.newdawn.slick.BasicGame;

public class GeomUtilTileTest extends BasicGame implements GeomUtilListener
{
    public Shape source;
    public Shape cut;
    public Shape[] result;
    public GeomUtil util;
    public ArrayList original;
    public ArrayList combined;
    public ArrayList intersections;
    public ArrayList used;
    public ArrayList[][] quadSpace;
    public Shape[][] quadSpaceShapes;
    
    public GeomUtilTileTest() {
        super("GeomUtilTileTest");
        this.util = new GeomUtil();
        this.original = new ArrayList();
        this.combined = new ArrayList();
        this.intersections = new ArrayList();
        this.used = new ArrayList();
    }
    
    public void generateSpace(final ArrayList list, final float n, final float n2, final float n3, final float n4, final int n5) {
        this.quadSpace = new ArrayList[n5][n5];
        this.quadSpaceShapes = new Shape[n5][n5];
        final float n6 = (n3 - n) / n5;
        final float n7 = (n4 - n2) / n5;
        for (int i = 0; i < n5; ++i) {
            for (int j = 0; j < n5; ++j) {
                this.quadSpace[i][j] = new ArrayList();
                final Polygon polygon = new Polygon();
                polygon.addPoint(n + n6 * i, n2 + n7 * j);
                polygon.addPoint(n + n6 * i + n6, n2 + n7 * j);
                polygon.addPoint(n + n6 * i + n6, n2 + n7 * j + n7);
                polygon.addPoint(n + n6 * i, n2 + n7 * j + n7);
                for (int k = 0; k < list.size(); ++k) {
                    final Shape e = list.get(k);
                    if (this.collides(e, polygon)) {
                        this.quadSpace[i][j].add(e);
                    }
                }
                this.quadSpaceShapes[i][j] = polygon;
            }
        }
    }
    
    public void removeFromQuadSpace(final Shape o) {
        for (int length = this.quadSpace.length, i = 0; i < length; ++i) {
            for (int j = 0; j < length; ++j) {
                this.quadSpace[i][j].remove(o);
            }
        }
    }
    
    public void addToQuadSpace(final Shape e) {
        for (int length = this.quadSpace.length, i = 0; i < length; ++i) {
            for (int j = 0; j < length; ++j) {
                if (this.collides(e, this.quadSpaceShapes[i][j])) {
                    this.quadSpace[i][j].add(e);
                }
            }
        }
    }
    
    public void init() {
        final int n = 10;
        final int[][] array = { { 0, 0, 0, 0, 0, 0, 0, 3, 0, 0 }, { 0, 1, 1, 1, 0, 0, 1, 1, 1, 0 }, { 0, 1, 1, 0, 0, 0, 5, 1, 6, 0 }, { 0, 1, 2, 0, 0, 0, 4, 1, 1, 0 }, { 0, 1, 1, 0, 0, 0, 1, 1, 0, 0 }, { 0, 0, 0, 0, 3, 0, 1, 1, 0, 0 }, { 0, 0, 0, 1, 1, 0, 0, 0, 1, 0 }, { 0, 0, 0, 1, 1, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } };
        for (int i = 0; i < array[0].length; ++i) {
            for (int j = 0; j < array.length; ++j) {
                if (array[j][i] != 0) {
                    switch (array[j][i]) {
                        case 1: {
                            final Polygon e = new Polygon();
                            e.addPoint((float)(i * 32), (float)(j * 32));
                            e.addPoint((float)(i * 32 + 32), (float)(j * 32));
                            e.addPoint((float)(i * 32 + 32), (float)(j * 32 + 32));
                            e.addPoint((float)(i * 32), (float)(j * 32 + 32));
                            this.original.add(e);
                            break;
                        }
                        case 2: {
                            final Polygon e2 = new Polygon();
                            e2.addPoint((float)(i * 32), (float)(j * 32));
                            e2.addPoint((float)(i * 32 + 32), (float)(j * 32));
                            e2.addPoint((float)(i * 32), (float)(j * 32 + 32));
                            this.original.add(e2);
                            break;
                        }
                        case 3: {
                            this.original.add(new Circle((float)(i * 32 + 16), (float)(j * 32 + 32), 16.0f, 16));
                            break;
                        }
                        case 4: {
                            final Polygon e3 = new Polygon();
                            e3.addPoint((float)(i * 32 + 32), (float)(j * 32));
                            e3.addPoint((float)(i * 32 + 32), (float)(j * 32 + 32));
                            e3.addPoint((float)(i * 32), (float)(j * 32 + 32));
                            this.original.add(e3);
                            break;
                        }
                        case 5: {
                            final Polygon e4 = new Polygon();
                            e4.addPoint((float)(i * 32), (float)(j * 32));
                            e4.addPoint((float)(i * 32 + 32), (float)(j * 32));
                            e4.addPoint((float)(i * 32 + 32), (float)(j * 32 + 32));
                            this.original.add(e4);
                            break;
                        }
                        case 6: {
                            final Polygon e5 = new Polygon();
                            e5.addPoint((float)(i * 32), (float)(j * 32));
                            e5.addPoint((float)(i * 32 + 32), (float)(j * 32));
                            e5.addPoint((float)(i * 32), (float)(j * 32 + 32));
                            this.original.add(e5);
                            break;
                        }
                    }
                }
            }
        }
        final long currentTimeMillis = System.currentTimeMillis();
        this.generateSpace(this.original, 0.0f, 0.0f, (float)((n + 1) * 32), (float)((n + 1) * 32), 8);
        this.combined = this.combineQuadSpace();
        System.out.println("Combine took: " + (System.currentTimeMillis() - currentTimeMillis));
        System.out.println("Combine result: " + this.combined.size());
    }
    
    public ArrayList combineQuadSpace() {
        boolean b = true;
        while (b) {
            b = false;
            for (int i = 0; i < this.quadSpace.length; ++i) {
                for (int j = 0; j < this.quadSpace.length; ++j) {
                    final ArrayList list = this.quadSpace[i][j];
                    final int size = list.size();
                    this.combine(list);
                    b |= (size != list.size());
                }
            }
        }
        final HashSet<Object> c = new HashSet<Object>();
        for (int k = 0; k < this.quadSpace.length; ++k) {
            for (int l = 0; l < this.quadSpace.length; ++l) {
                c.addAll(this.quadSpace[k][l]);
            }
        }
        return new ArrayList((Collection<? extends E>)c);
    }
    
    public ArrayList combine(final ArrayList list) {
        ArrayList<Shape> list2 = (ArrayList<Shape>)list;
        ArrayList<Shape> combineImpl = (ArrayList<Shape>)list;
        for (int n = 1; combineImpl.size() != list2.size() || n != 0; n = 0, list2 = combineImpl, combineImpl = (ArrayList<Shape>)this.combineImpl(combineImpl)) {}
        final ArrayList<Shape> list3 = new ArrayList<Shape>();
        for (int i = 0; i < combineImpl.size(); ++i) {
            list3.add(combineImpl.get(i).prune());
        }
        return list3;
    }
    
    public ArrayList combineImpl(final ArrayList c) {
        ArrayList<Shape> list = new ArrayList<Shape>(c);
        if (this.quadSpace != null) {
            list = (ArrayList<Shape>)c;
        }
        for (int i = 0; i < c.size(); ++i) {
            final Shape o = c.get(i);
            for (int j = i + 1; j < c.size(); ++j) {
                final Shape o2 = c.get(j);
                if (o.intersects(o2)) {
                    final Shape[] union = this.util.union(o, o2);
                    if (union.length == 1) {
                        if (this.quadSpace != null) {
                            this.removeFromQuadSpace(o);
                            this.removeFromQuadSpace(o2);
                            this.addToQuadSpace(union[0]);
                        }
                        else {
                            list.remove(o);
                            list.remove(o2);
                            list.add(union[0]);
                        }
                        return list;
                    }
                }
            }
        }
        return list;
    }
    
    public boolean collides(final Shape shape, final Shape shape2) {
        if (shape.intersects(shape2)) {
            return true;
        }
        for (int i = 0; i < shape.getPointCount(); ++i) {
            final float[] point = shape.getPoint(i);
            if (shape2.contains(point[0], point[1])) {
                return true;
            }
        }
        for (int j = 0; j < shape2.getPointCount(); ++j) {
            final float[] point2 = shape2.getPoint(j);
            if (shape.contains(point2[0], point2[1])) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.util.setListener(this);
        this.init();
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.setColor(Color.green);
        for (int i = 0; i < this.original.size(); ++i) {
            graphics.draw((Shape)this.original.get(i));
        }
        graphics.setColor(Color.white);
        if (this.quadSpaceShapes != null) {
            graphics.draw(this.quadSpaceShapes[0][0]);
        }
        graphics.translate(0.0f, 320.0f);
        for (int j = 0; j < this.combined.size(); ++j) {
            graphics.setColor(Color.white);
            final Shape shape = this.combined.get(j);
            graphics.draw(shape);
            for (int k = 0; k < shape.getPointCount(); ++k) {
                graphics.setColor(Color.yellow);
                final float[] point = shape.getPoint(k);
                graphics.fillOval(point[0] - 1.0f, point[1] - 1.0f, 3.0f, 3.0f);
            }
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new GeomUtilTileTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    @Override
    public void pointExcluded(final float n, final float n2) {
    }
    
    @Override
    public void pointIntersected(final float n, final float n2) {
        this.intersections.add(new Vector2f(n, n2));
    }
    
    @Override
    public void pointUsed(final float n, final float n2) {
        this.used.add(new Vector2f(n, n2));
    }
}
