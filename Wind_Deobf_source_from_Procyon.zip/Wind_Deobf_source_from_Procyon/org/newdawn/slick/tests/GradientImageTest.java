// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.ShapeFill;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.geom.Polygon;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.fills.GradientFill;
import org.newdawn.slick.Image;
import org.newdawn.slick.BasicGame;

public class GradientImageTest extends BasicGame
{
    public Image image1;
    public Image image2;
    public GradientFill fill;
    public Shape shape;
    public Polygon poly;
    public GameContainer container;
    public float ang;
    public boolean rotating;
    
    public GradientImageTest() {
        super("Gradient Image Test");
        this.rotating = false;
    }
    
    @Override
    public void init(final GameContainer container) throws SlickException {
        this.container = container;
        this.image1 = new Image("testdata/grass.png");
        this.image2 = new Image("testdata/rocks.png");
        this.fill = new GradientFill(-64.0f, 0.0f, new Color(1.0f, 1.0f, 1.0f, 1.0f), 64.0f, 0.0f, new Color(0, 0, 0, 0));
        this.shape = new Rectangle(336.0f, 236.0f, 128.0f, 128.0f);
        (this.poly = new Polygon()).addPoint(320.0f, 220.0f);
        this.poly.addPoint(350.0f, 200.0f);
        this.poly.addPoint(450.0f, 200.0f);
        this.poly.addPoint(480.0f, 220.0f);
        this.poly.addPoint(420.0f, 400.0f);
        this.poly.addPoint(400.0f, 390.0f);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        graphics.drawString("R - Toggle Rotationg", 10.0f, 50.0f);
        graphics.drawImage(this.image1, 100.0f, 236.0f);
        graphics.drawImage(this.image2, 600.0f, 236.0f);
        graphics.translate(0.0f, -150.0f);
        graphics.rotate(400.0f, 300.0f, this.ang);
        graphics.texture(this.shape, this.image2);
        graphics.texture(this.shape, this.image1, this.fill);
        graphics.resetTransform();
        graphics.translate(0.0f, 150.0f);
        graphics.rotate(400.0f, 300.0f, this.ang);
        graphics.texture(this.poly, this.image2);
        graphics.texture(this.poly, this.image1, this.fill);
        graphics.resetTransform();
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
        if (this.rotating) {
            this.ang += n * 0.0f;
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new GradientImageTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 19) {
            this.rotating = !this.rotating;
        }
        if (n == 1) {
            this.container.exit();
        }
    }
}
