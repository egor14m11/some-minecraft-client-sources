// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.ImageBuffer;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Image;
import org.newdawn.slick.BasicGame;

public class ImageBufferTest extends BasicGame
{
    public Image image;
    
    public ImageBufferTest() {
        super("Image Buffer Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        final ImageBuffer imageBuffer = new ImageBuffer(320, 200);
        for (int i = 0; i < 320; ++i) {
            for (int j = 0; j < 200; ++j) {
                if (j == 20) {
                    imageBuffer.setRGBA(i, j, 255, 255, 255, 255);
                }
                else {
                    imageBuffer.setRGBA(i, j, i, j, 0, 255);
                }
            }
        }
        this.image = imageBuffer.getImage();
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        this.image.draw(50.0f, 50.0f);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 1) {
            System.exit(0);
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new ImageBufferTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
