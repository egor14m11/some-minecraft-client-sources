// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Image;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.BasicGame;

public class ImageMemTest extends BasicGame
{
    public ImageMemTest() {
        super("Image Memory Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        final Image image = new Image(2400, 2400);
        image.getGraphics();
        image.destroy();
        new Image(2400, 2400).getGraphics();
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new ImageMemTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
