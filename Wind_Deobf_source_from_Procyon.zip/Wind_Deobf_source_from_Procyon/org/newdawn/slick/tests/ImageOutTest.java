// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.imageout.ImageOut;
import org.newdawn.slick.particles.ParticleIO;
import org.newdawn.slick.Image;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.particles.ParticleSystem;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.BasicGame;

public class ImageOutTest extends BasicGame
{
    public GameContainer container;
    public ParticleSystem fire;
    public Graphics g;
    public Image copy;
    public String message;
    
    public ImageOutTest() {
        super("Image Out Test");
    }
    
    @Override
    public void init(final GameContainer container) throws SlickException {
        this.container = container;
        this.fire = ParticleIO.loadConfiguredSystem("testdata/system.xml");
        this.copy = new Image(400, 300);
        final String[] supportedFormats = ImageOut.getSupportedFormats();
        this.message = "Formats supported: ";
        for (int i = 0; i < supportedFormats.length; ++i) {
            this.message += supportedFormats[i];
            if (i < supportedFormats.length - 1) {
                this.message += ",";
            }
        }
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics g) {
        g.drawString("T - TGA Snapshot", 10.0f, 50.0f);
        g.drawString("J - JPG Snapshot", 10.0f, 70.0f);
        g.drawString("P - PNG Snapshot", 10.0f, 90.0f);
        g.setDrawMode(Graphics.MODE_ADD);
        g.drawImage(this.copy, 200.0f, 300.0f);
        g.setDrawMode(Graphics.MODE_NORMAL);
        g.drawString(this.message, 10.0f, 400.0f);
        g.drawRect(200.0f, 0.0f, 400.0f, 300.0f);
        g.translate(400.0f, 250.0f);
        this.fire.render();
        this.g = g;
    }
    
    public void writeTo(final String str) throws SlickException {
        this.g.copyArea(this.copy, 200, 0);
        ImageOut.write(this.copy, str);
        this.message = "Written " + str;
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        this.fire.update(n);
        if (gameContainer.getInput().isKeyPressed(25)) {
            this.writeTo("ImageOutTest.png");
        }
        if (gameContainer.getInput().isKeyPressed(36)) {
            this.writeTo("ImageOutTest.jpg");
        }
        if (gameContainer.getInput().isKeyPressed(20)) {
            this.writeTo("ImageOutTest.tga");
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new ImageOutTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 1) {
            this.container.exit();
        }
    }
}
