// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Image;
import org.newdawn.slick.BasicGame;

public class ImageTest extends BasicGame
{
    public Image tga;
    public Image scaleMe;
    public Image scaled;
    public Image gif;
    public Image image;
    public Image subImage;
    public Image rotImage;
    public float rot;
    public static boolean exitMe;
    
    public ImageTest() {
        super("Image Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        final Image image = new Image("testdata/logo.png");
        this.tga = image;
        this.image = image;
        this.rotImage = new Image("testdata/logo.png");
        this.rotImage = this.rotImage.getScaledCopy(this.rotImage.getWidth() / 2, this.rotImage.getHeight() / 2);
        this.scaleMe = new Image("testdata/logo.tga", true, 2);
        (this.gif = new Image("testdata/logo.gif")).destroy();
        this.gif = new Image("testdata/logo.gif");
        this.scaled = this.gif.getScaledCopy(120, 120);
        this.subImage = this.image.getSubImage(200, 0, 70, 260);
        this.rot = 0.0f;
        if (ImageTest.exitMe) {
            gameContainer.exit();
        }
        System.out.println(this.tga.getSubImage(50, 50, 50, 50).getColor(50, 50));
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        graphics.drawRect(0.0f, 0.0f, (float)this.image.getWidth(), (float)this.image.getHeight());
        this.image.draw(0.0f, 0.0f);
        this.image.draw(500.0f, 0.0f, 200.0f, 100.0f);
        this.scaleMe.draw(500.0f, 100.0f, 200.0f, 100.0f);
        this.scaled.draw(400.0f, 500.0f);
        final Image flippedCopy = this.scaled.getFlippedCopy(true, false);
        flippedCopy.draw(520.0f, 500.0f);
        final Image flippedCopy2 = flippedCopy.getFlippedCopy(false, true);
        flippedCopy2.draw(520.0f, 380.0f);
        flippedCopy2.getFlippedCopy(true, false).draw(400.0f, 380.0f);
        for (int i = 0; i < 3; ++i) {
            this.subImage.draw((float)(200 + i * 30), 300.0f);
        }
        graphics.translate(500.0f, 200.0f);
        graphics.rotate(50.0f, 50.0f, this.rot);
        graphics.scale(0.0f, 0.0f);
        this.image.draw();
        graphics.resetTransform();
        this.rotImage.setRotation(this.rot);
        this.rotImage.draw(100.0f, 200.0f);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
        this.rot += n * 0.0f;
        if (this.rot > 360.0f) {
            this.rot -= 360.0f;
        }
    }
    
    public static void main(final String[] array) {
        final boolean b = false;
        ImageTest.exitMe = false;
        if (b) {
            GameContainer.enableSharedContext();
            ImageTest.exitMe = true;
        }
        final AppGameContainer appGameContainer = new AppGameContainer(new ImageTest());
        appGameContainer.setForceExit(!b);
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
        if (b) {
            System.out.println("Exit first instance");
            ImageTest.exitMe = false;
            final AppGameContainer appGameContainer2 = new AppGameContainer(new ImageTest());
            appGameContainer2.setDisplayMode(800, 600, false);
            appGameContainer2.start();
        }
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 57) {
            if (this.image == this.gif) {
                this.image = this.tga;
            }
            else {
                this.image = this.gif;
            }
        }
    }
    
    static {
        ImageTest.exitMe = true;
    }
}
