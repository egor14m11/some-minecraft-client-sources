// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.svg.InkscapeLoader;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.svg.SimpleDiagramRenderer;
import org.newdawn.slick.BasicGame;

public class InkscapeTest extends BasicGame
{
    public SimpleDiagramRenderer[] renderer;
    public float zoom;
    public float x;
    public float y;
    
    public InkscapeTest() {
        super("Inkscape Test");
        this.renderer = new SimpleDiagramRenderer[5];
        this.zoom = 1.0f;
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        gameContainer.getGraphics().setBackground(Color.white);
        InkscapeLoader.RADIAL_TRIANGULATION_LEVEL = 2;
        this.renderer[3] = new SimpleDiagramRenderer(InkscapeLoader.load("testdata/svg/clonetest.svg"));
        gameContainer.getGraphics().setBackground(new Color(0.0f, 0.0f, 1.0f));
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        if (gameContainer.getInput().isKeyDown(16)) {
            this.zoom += n * 0.0f;
            if (this.zoom > 10.0f) {
                this.zoom = 10.0f;
            }
        }
        if (gameContainer.getInput().isKeyDown(30)) {
            this.zoom -= n * 0.0f;
            if (this.zoom < 0.0f) {
                this.zoom = 0.0f;
            }
        }
        if (gameContainer.getInput().isKeyDown(205)) {
            this.x += n * 0.0f;
        }
        if (gameContainer.getInput().isKeyDown(203)) {
            this.x -= n * 0.0f;
        }
        if (gameContainer.getInput().isKeyDown(208)) {
            this.y += n * 0.0f;
        }
        if (gameContainer.getInput().isKeyDown(200)) {
            this.y -= n * 0.0f;
        }
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.scale(this.zoom, this.zoom);
        graphics.translate(this.x, this.y);
        graphics.scale(0.0f, 0.0f);
        graphics.scale(3.3333333f, 3.3333333f);
        graphics.translate(400.0f, 0.0f);
        graphics.translate(100.0f, 300.0f);
        graphics.scale(0.0f, 0.0f);
        graphics.scale(1.0f, 1.0f);
        graphics.scale(0.0f, 0.0f);
        graphics.translate(-1100.0f, -380.0f);
        this.renderer[3].render(graphics);
        graphics.scale(2.0f, 2.0f);
        graphics.resetTransform();
    }
    
    public static void main(final String[] array) {
        Renderer.setRenderer(2);
        Renderer.setLineStripRenderer(4);
        final AppGameContainer appGameContainer = new AppGameContainer(new InkscapeTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
