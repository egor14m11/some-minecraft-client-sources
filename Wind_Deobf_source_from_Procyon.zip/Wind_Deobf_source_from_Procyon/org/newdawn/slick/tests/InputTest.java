// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Input;
import org.newdawn.slick.Color;
import java.util.ArrayList;
import org.newdawn.slick.BasicGame;

public class InputTest extends BasicGame
{
    public String message;
    public ArrayList lines;
    public boolean buttonDown;
    public float x;
    public float y;
    public Color[] cols;
    public int index;
    public Input input;
    public int ypos;
    public AppGameContainer app;
    public boolean space;
    public boolean lshift;
    public boolean rshift;
    
    public InputTest() {
        super("Input Test");
        this.message = "Press any key, mouse button, or drag the mouse";
        this.lines = new ArrayList();
        this.cols = new Color[] { Color.red, Color.green, Color.blue, Color.white, Color.magenta, Color.cyan };
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        if (gameContainer instanceof AppGameContainer) {
            this.app = (AppGameContainer)gameContainer;
        }
        this.input = gameContainer.getInput();
        this.x = 300.0f;
        this.y = 300.0f;
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        graphics.drawString("left shift down: " + this.lshift, 100.0f, 240.0f);
        graphics.drawString("right shift down: " + this.rshift, 100.0f, 260.0f);
        graphics.drawString("space down: " + this.space, 100.0f, 280.0f);
        graphics.setColor(Color.white);
        graphics.drawString(this.message, 10.0f, 50.0f);
        graphics.drawString("" + gameContainer.getInput().getMouseY(), 10.0f, 400.0f);
        graphics.drawString("Use the primary gamepad to control the blob, and hit a gamepad button to change the color", 10.0f, 90.0f);
        for (int i = 0; i < this.lines.size(); ++i) {
            ((Line)this.lines.get(i)).draw(graphics);
        }
        graphics.setColor(this.cols[this.index]);
        graphics.fillOval((float)(int)this.x, (float)(int)this.y, 50.0f, 50.0f);
        graphics.setColor(Color.yellow);
        graphics.fillRect(50.0f, (float)(200 + this.ypos), 40.0f, 40.0f);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
        this.lshift = gameContainer.getInput().isKeyDown(42);
        this.rshift = gameContainer.getInput().isKeyDown(54);
        this.space = gameContainer.getInput().isKeyDown(57);
        if (this.controllerLeft[0]) {
            this.x -= n * 0.0f;
        }
        if (this.controllerRight[0]) {
            this.x += n * 0.0f;
        }
        if (this.controllerUp[0]) {
            this.y -= n * 0.0f;
        }
        if (this.controllerDown[0]) {
            this.y += n * 0.0f;
        }
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 1) {
            System.exit(0);
        }
        if (n == 59 && this.app != null) {
            this.app.setDisplayMode(600, 600, false);
            this.app.reinit();
        }
    }
    
    @Override
    public void keyReleased(final int i, final char c) {
        this.message = "You pressed key code " + i + " (character = " + c + ")";
    }
    
    @Override
    public void mousePressed(final int i, final int j, final int k) {
        if (i == 0) {
            this.buttonDown = true;
        }
        this.message = "Mouse pressed " + i + " " + j + "," + k;
    }
    
    @Override
    public void mouseReleased(final int i, final int j, final int k) {
        if (i == 0) {
            this.buttonDown = false;
        }
        this.message = "Mouse released " + i + " " + j + "," + k;
    }
    
    @Override
    public void mouseClicked(final int n, final int i, final int j, final int k) {
        System.out.println("CLICKED:" + i + "," + j + " " + k);
    }
    
    @Override
    public void mouseWheelMoved(final int i) {
        this.message = "Mouse wheel moved: " + i;
        if (i < 0) {
            this.ypos -= 10;
        }
        if (i > 0) {
            this.ypos += 10;
        }
    }
    
    @Override
    public void mouseMoved(final int n, final int n2, final int n3, final int n4) {
        if (this.buttonDown) {
            this.lines.add(new Line(n, n2, n3, n4));
        }
    }
    
    @Override
    public void controllerButtonPressed(final int n, final int n2) {
        super.controllerButtonPressed(n, n2);
        ++this.index;
        this.index %= this.cols.length;
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new InputTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    private class Line
    {
        public int oldx;
        public int oldy;
        public int newx;
        public int newy;
        public InputTest this$0;
        
        public Line(final InputTest this$0, final int oldx, final int oldy, final int newx, final int newy) {
            this.this$0 = this$0;
            this.oldx = oldx;
            this.oldy = oldy;
            this.newx = newx;
            this.newy = newy;
        }
        
        public void draw(final Graphics graphics) {
            graphics.drawLine((float)this.oldx, (float)this.oldy, (float)this.newx, (float)this.newy);
        }
    }
}
