// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.geom.Path;
import org.newdawn.slick.geom.Polygon;
import org.newdawn.slick.BasicGame;

public class LineRenderTest extends BasicGame
{
    public Polygon polygon;
    public Path path;
    public float width;
    public boolean antialias;
    
    public LineRenderTest() {
        super("LineRenderTest");
        this.polygon = new Polygon();
        this.path = new Path(100.0f, 100.0f);
        this.width = 10.0f;
        this.antialias = true;
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.polygon.addPoint(100.0f, 100.0f);
        this.polygon.addPoint(200.0f, 80.0f);
        this.polygon.addPoint(320.0f, 150.0f);
        this.polygon.addPoint(230.0f, 210.0f);
        this.polygon.addPoint(170.0f, 260.0f);
        this.path.curveTo(200.0f, 200.0f, 200.0f, 100.0f, 100.0f, 200.0f);
        this.path.curveTo(400.0f, 100.0f, 400.0f, 200.0f, 200.0f, 100.0f);
        this.path.curveTo(500.0f, 500.0f, 400.0f, 200.0f, 200.0f, 100.0f);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        if (gameContainer.getInput().isKeyPressed(57)) {
            this.antialias = !this.antialias;
        }
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.setAntiAlias(this.antialias);
        graphics.setLineWidth(50.0f);
        graphics.setColor(Color.red);
        graphics.draw(this.path);
    }
    
    public static void main(final String[] array) {
        Renderer.setLineStripRenderer(4);
        Renderer.getLineStripRenderer().setLineCaps(true);
        final AppGameContainer appGameContainer = new AppGameContainer(new LineRenderTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
