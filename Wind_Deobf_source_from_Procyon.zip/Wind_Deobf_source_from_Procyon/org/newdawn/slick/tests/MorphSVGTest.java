// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.svg.SimpleDiagramRenderer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.svg.InkscapeLoader;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.svg.Diagram;
import org.newdawn.slick.svg.SVGMorph;
import org.newdawn.slick.BasicGame;

public class MorphSVGTest extends BasicGame
{
    public SVGMorph morph;
    public Diagram base;
    public float time;
    public float x;
    
    public MorphSVGTest() {
        super("MorphShapeTest");
        this.x = -300.0f;
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.base = InkscapeLoader.load("testdata/svg/walk1.svg");
        (this.morph = new SVGMorph(this.base)).addStep(InkscapeLoader.load("testdata/svg/walk2.svg"));
        this.morph.addStep(InkscapeLoader.load("testdata/svg/walk3.svg"));
        this.morph.addStep(InkscapeLoader.load("testdata/svg/walk4.svg"));
        gameContainer.setVSync(true);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        this.morph.updateMorphTime(n * 0.0f);
        this.x += n * 0.0f;
        if (this.x > 550.0f) {
            this.x = -450.0f;
        }
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.translate(this.x, 0.0f);
        SimpleDiagramRenderer.render(graphics, this.morph);
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new MorphSVGTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
