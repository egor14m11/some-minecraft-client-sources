// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.geom.Transform;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.geom.MorphShape;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.BasicGame;

public class MorphShapeTest extends BasicGame
{
    public Shape a;
    public Shape b;
    public Shape c;
    public MorphShape morph;
    public float time;
    
    public MorphShapeTest() {
        super("MorphShapeTest");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.a = new Rectangle(100.0f, 100.0f, 50.0f, 200.0f);
        this.a = this.a.transform(Transform.createRotateTransform(0.0f, 100.0f, 100.0f));
        this.b = new Rectangle(200.0f, 100.0f, 50.0f, 200.0f);
        this.b = this.b.transform(Transform.createRotateTransform(-0.6f, 100.0f, 100.0f));
        this.c = new Rectangle(300.0f, 100.0f, 50.0f, 200.0f);
        this.c = this.c.transform(Transform.createRotateTransform(-0.2f, 100.0f, 100.0f));
        (this.morph = new MorphShape(this.a)).addShape(this.b);
        this.morph.addShape(this.c);
        gameContainer.setVSync(true);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        this.time += n * 0.0f;
        this.morph.setMorphTime(this.time);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.setColor(Color.green);
        graphics.draw(this.a);
        graphics.setColor(Color.red);
        graphics.draw(this.b);
        graphics.setColor(Color.blue);
        graphics.draw(this.c);
        graphics.setColor(Color.white);
        graphics.draw(this.morph);
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new MorphShapeTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
