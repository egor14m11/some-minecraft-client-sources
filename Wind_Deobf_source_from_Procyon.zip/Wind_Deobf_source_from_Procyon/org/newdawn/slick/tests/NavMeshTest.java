// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import java.io.IOException;
import org.newdawn.slick.util.ResourceLoader;
import org.newdawn.slick.Game;
import org.newdawn.slick.util.Bootstrap;
import org.newdawn.slick.util.pathfinding.Mover;
import org.newdawn.slick.util.pathfinding.navmesh.Link;
import org.newdawn.slick.util.pathfinding.navmesh.Space;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.util.pathfinding.TileBasedMap;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.util.pathfinding.navmesh.NavPath;
import org.newdawn.slick.util.pathfinding.navmesh.NavMeshBuilder;
import org.newdawn.slick.util.pathfinding.navmesh.NavMesh;
import org.newdawn.slick.util.pathfinding.PathFindingContext;
import org.newdawn.slick.BasicGame;

public class NavMeshTest extends BasicGame implements PathFindingContext
{
    public NavMesh navMesh;
    public NavMeshBuilder builder;
    public boolean showSpaces;
    public boolean showLinks;
    public NavPath path;
    public float sx;
    public float sy;
    public float ex;
    public float ey;
    public DataMap dataMap;
    
    public NavMeshTest() {
        super("Nav-mesh Test");
        this.showSpaces = true;
        this.showLinks = true;
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        gameContainer.setShowFPS(false);
        this.dataMap = new DataMap("testdata/map.dat");
        this.builder = new NavMeshBuilder();
        this.navMesh = this.builder.build(this.dataMap);
        System.out.println("Navmesh shapes: " + this.navMesh.getSpaceCount());
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        if (gameContainer.getInput().isKeyPressed(2)) {
            this.showLinks = !this.showLinks;
        }
        if (gameContainer.getInput().isKeyPressed(3)) {
            this.showSpaces = !this.showSpaces;
        }
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.translate(50.0f, 50.0f);
        for (int i = 0; i < 50; ++i) {
            for (int j = 0; j < 50; ++j) {
                if (this.dataMap.blocked(this, i, j)) {
                    graphics.setColor(Color.gray);
                    graphics.fillRect((float)(i * 10 + 1), (float)(j * 10 + 1), 8.0f, 8.0f);
                }
            }
        }
        if (this.showSpaces) {
            for (int k = 0; k < this.navMesh.getSpaceCount(); ++k) {
                final Space space = this.navMesh.getSpace(k);
                if (this.builder.clear(this.dataMap, space)) {
                    graphics.setColor(new Color(1.0f, 1.0f, 0.0f, 0.0f));
                    graphics.fillRect(space.getX() * 10.0f, space.getY() * 10.0f, space.getWidth() * 10.0f, space.getHeight() * 10.0f);
                }
                graphics.setColor(Color.yellow);
                graphics.drawRect(space.getX() * 10.0f, space.getY() * 10.0f, space.getWidth() * 10.0f, space.getHeight() * 10.0f);
                if (this.showLinks) {
                    for (int linkCount = space.getLinkCount(), l = 0; l < linkCount; ++l) {
                        final Link link = space.getLink(l);
                        graphics.setColor(Color.red);
                        graphics.fillRect(link.getX() * 10.0f - 2.0f, link.getY() * 10.0f - 2.0f, 5.0f, 5.0f);
                    }
                }
            }
        }
        if (this.path != null) {
            graphics.setColor(Color.white);
            for (int n = 0; n < this.path.length() - 1; ++n) {
                graphics.drawLine(this.path.getX(n) * 10.0f, this.path.getY(n) * 10.0f, this.path.getX(n + 1) * 10.0f, this.path.getY(n + 1) * 10.0f);
            }
        }
    }
    
    @Override
    public Mover getMover() {
        return null;
    }
    
    @Override
    public int getSearchDistance() {
        return 0;
    }
    
    @Override
    public int getSourceX() {
        return 0;
    }
    
    @Override
    public int getSourceY() {
        return 0;
    }
    
    @Override
    public void mousePressed(final int n, final int n2, final int n3) {
        final float n4 = (n2 - 50) / 10.0f;
        final float n5 = (n3 - 50) / 10.0f;
        if (n == 0) {
            this.sx = n4;
            this.sy = n5;
        }
        else {
            this.ex = n4;
            this.ey = n5;
        }
        this.path = this.navMesh.findPath(this.sx, this.sy, this.ex, this.ey, true);
    }
    
    public static void main(final String[] array) {
        Bootstrap.runAsApplication(new NavMeshTest(), 600, 600, false);
    }
    
    private class DataMap implements TileBasedMap
    {
        public byte[] map;
        public NavMeshTest this$0;
        
        public DataMap(final NavMeshTest this$0, final String s) throws IOException {
            this.this$0 = this$0;
            this.map = new byte[2500];
            ResourceLoader.getResourceAsStream(s).read(this.map);
        }
        
        @Override
        public boolean blocked(final PathFindingContext pathFindingContext, final int n, final int n2) {
            return n >= 0 && n2 >= 0 && n < 50 && n2 < 50 && this.map[n + n2 * 50] != 0;
        }
        
        @Override
        public float getCost(final PathFindingContext pathFindingContext, final int n, final int n2) {
            return 1.0f;
        }
        
        @Override
        public int getHeightInTiles() {
            return 50;
        }
        
        @Override
        public int getWidthInTiles() {
            return 50;
        }
        
        @Override
        public void pathFinderVisited(final int n, final int n2) {
        }
    }
}
