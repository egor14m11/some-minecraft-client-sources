// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.particles.ConfigurableEmitter;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.particles.ParticleIO;
import org.newdawn.slick.particles.ParticleSystem;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Image;
import org.newdawn.slick.BasicGame;

public class PedigreeTest extends BasicGame
{
    public Image image;
    public GameContainer container;
    public ParticleSystem trail;
    public ParticleSystem fire;
    public float rx;
    public float ry;
    
    public PedigreeTest() {
        super("Pedigree Test");
        this.ry = 900.0f;
    }
    
    @Override
    public void init(final GameContainer container) throws SlickException {
        this.container = container;
        this.fire = ParticleIO.loadConfiguredSystem("testdata/system.xml");
        this.trail = ParticleIO.loadConfiguredSystem("testdata/smoketrail.xml");
        this.image = new Image("testdata/rocket.png");
        this.spawnRocket();
    }
    
    public void spawnRocket() {
        this.ry = 700.0f;
        this.rx = (float)(Math.random() * 600.0 + 100.0);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        ((ConfigurableEmitter)this.trail.getEmitter(0)).setPosition(this.rx + 14.0f, this.ry + 35.0f);
        this.trail.render();
        this.image.draw((float)(int)this.rx, (float)(int)this.ry);
        graphics.translate(400.0f, 300.0f);
        this.fire.render();
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
        this.fire.update(n);
        this.trail.update(n);
        this.ry -= n * 0.0f;
        if (this.ry < -100.0f) {
            this.spawnRocket();
        }
    }
    
    @Override
    public void mousePressed(final int n, final int n2, final int n3) {
        super.mousePressed(n, n2, n3);
        for (int i = 0; i < this.fire.getEmitterCount(); ++i) {
            ((ConfigurableEmitter)this.fire.getEmitter(i)).setPosition((float)(n2 - 400), (float)(n3 - 300), true);
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new PedigreeTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 1) {
            this.container.exit();
        }
    }
}
