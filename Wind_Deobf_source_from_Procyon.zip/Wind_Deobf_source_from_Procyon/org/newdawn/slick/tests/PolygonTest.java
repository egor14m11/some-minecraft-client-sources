// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.geom.Polygon;
import org.newdawn.slick.BasicGame;

public class PolygonTest extends BasicGame
{
    public Polygon poly;
    public boolean in;
    public float y;
    
    public PolygonTest() {
        super("Polygon Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        (this.poly = new Polygon()).addPoint(300.0f, 100.0f);
        this.poly.addPoint(320.0f, 200.0f);
        this.poly.addPoint(350.0f, 210.0f);
        this.poly.addPoint(280.0f, 250.0f);
        this.poly.addPoint(300.0f, 200.0f);
        this.poly.addPoint(240.0f, 150.0f);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        this.in = this.poly.contains((float)gameContainer.getInput().getMouseX(), (float)gameContainer.getInput().getMouseY());
        this.poly.setCenterY(0.0f);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        if (this.in) {
            graphics.setColor(Color.red);
            graphics.fill(this.poly);
        }
        graphics.setColor(Color.yellow);
        graphics.fillOval(this.poly.getCenterX() - 3.0f, this.poly.getCenterY() - 3.0f, 6.0f, 6.0f);
        graphics.setColor(Color.white);
        graphics.draw(this.poly);
    }
    
    public static void main(final String[] array) {
        new AppGameContainer(new PolygonTest(), 640, 480, false).start();
    }
}
