// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import java.nio.FloatBuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.BufferUtils;
import org.newdawn.slick.opengl.SlickCallable;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Animation;
import org.newdawn.slick.AngelCodeFont;
import org.newdawn.slick.Image;
import org.newdawn.slick.BasicGame;

public class SlickCallableTest extends BasicGame
{
    public Image image;
    public Image back;
    public float rot;
    public AngelCodeFont font;
    public Animation homer;
    
    public SlickCallableTest() {
        super("Slick Callable Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.image = new Image("testdata/rocket.png");
        this.back = new Image("testdata/sky.jpg");
        this.font = new AngelCodeFont("testdata/hiero.fnt", "testdata/hiero.png");
        this.homer = new Animation(new SpriteSheet("testdata/homeranim.png", 36, 65), 0, 0, 7, 0, true, 150, true);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.scale(2.0f, 2.0f);
        graphics.fillRect(0.0f, 0.0f, 800.0f, 600.0f, this.back, 0.0f, 0.0f);
        graphics.resetTransform();
        graphics.drawImage(this.image, 100.0f, 100.0f);
        this.image.draw(100.0f, 200.0f, 80.0f, 200.0f);
        this.font.drawString(100.0f, 200.0f, "Text Drawn before the callable");
        new SlickCallable(this) {
            public SlickCallableTest this$0;
            
            @Override
            public void performGLOperations() throws SlickException {
                this.this$0.renderGL();
            }
        }.call();
        this.homer.draw(450.0f, 250.0f, 80.0f, 200.0f);
        this.font.drawString(150.0f, 300.0f, "Text Drawn after the callable");
    }
    
    public void renderGL() {
        final FloatBuffer floatBuffer = BufferUtils.createFloatBuffer(4);
        floatBuffer.put(new float[] { 5.0f, 5.0f, 10.0f, 0.0f }).flip();
        final FloatBuffer floatBuffer2 = BufferUtils.createFloatBuffer(4);
        floatBuffer2.put(new float[] { 0.0f, 0.0f, 0.0f, 1.0f }).flip();
        GL11.glLight(16384, 4611, floatBuffer);
        GL11.glEnable(16384);
        GL11.glEnable(2884);
        GL11.glEnable(2929);
        GL11.glEnable(2896);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        final float n = 0.0f;
        GL11.glFrustum(-1.0, 1.0, (double)(-n), (double)n, 5.0, 60.0);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0f, 0.0f, -40.0f);
        GL11.glRotatef(this.rot, 0.0f, 1.0f, 1.0f);
        GL11.glMaterial(1028, 5634, floatBuffer2);
        this.gear(0.0f, 2.0f, 2.0f, 10, 0.0f);
    }
    
    public void gear(final float n, final float n2, final float n3, final int n4, final float n5) {
        final float n6 = n2 - n5 / 2.0f;
        final float n7 = n2 + n5 / 2.0f;
        final float n8 = 6.2831855f / n4 / 4.0f;
        GL11.glShadeModel(7424);
        GL11.glNormal3f(0.0f, 0.0f, 1.0f);
        GL11.glBegin(8);
        for (int i = 0; i <= n4; ++i) {
            final float n9 = i * 2.0f * 3.1415927f / n4;
            GL11.glVertex3f(n * (float)Math.cos(n9), n * (float)Math.sin(n9), n3 * 0.0f);
            GL11.glVertex3f(n6 * (float)Math.cos(n9), n6 * (float)Math.sin(n9), n3 * 0.0f);
            if (i < n4) {
                GL11.glVertex3f(n * (float)Math.cos(n9), n * (float)Math.sin(n9), n3 * 0.0f);
                GL11.glVertex3f(n6 * (float)Math.cos(n9 + 3.0f * n8), n6 * (float)Math.sin(n9 + 3.0f * n8), n3 * 0.0f);
            }
        }
        GL11.glEnd();
        GL11.glBegin(7);
        for (int j = 0; j < n4; ++j) {
            final float n10 = j * 2.0f * 3.1415927f / n4;
            GL11.glVertex3f(n6 * (float)Math.cos(n10), n6 * (float)Math.sin(n10), n3 * 0.0f);
            GL11.glVertex3f(n7 * (float)Math.cos(n10 + n8), n7 * (float)Math.sin(n10 + n8), n3 * 0.0f);
            GL11.glVertex3f(n7 * (float)Math.cos(n10 + 2.0f * n8), n7 * (float)Math.sin(n10 + 2.0f * n8), n3 * 0.0f);
            GL11.glVertex3f(n6 * (float)Math.cos(n10 + 3.0f * n8), n6 * (float)Math.sin(n10 + 3.0f * n8), n3 * 0.0f);
        }
        GL11.glEnd();
        GL11.glNormal3f(0.0f, 0.0f, -1.0f);
        GL11.glBegin(8);
        for (int k = 0; k <= n4; ++k) {
            final float n11 = k * 2.0f * 3.1415927f / n4;
            GL11.glVertex3f(n6 * (float)Math.cos(n11), n6 * (float)Math.sin(n11), -n3 * 0.0f);
            GL11.glVertex3f(n * (float)Math.cos(n11), n * (float)Math.sin(n11), -n3 * 0.0f);
            GL11.glVertex3f(n6 * (float)Math.cos(n11 + 3.0f * n8), n6 * (float)Math.sin(n11 + 3.0f * n8), -n3 * 0.0f);
            GL11.glVertex3f(n * (float)Math.cos(n11), n * (float)Math.sin(n11), -n3 * 0.0f);
        }
        GL11.glEnd();
        GL11.glBegin(7);
        for (int l = 0; l < n4; ++l) {
            final float n12 = l * 2.0f * 3.1415927f / n4;
            GL11.glVertex3f(n6 * (float)Math.cos(n12 + 3.0f * n8), n6 * (float)Math.sin(n12 + 3.0f * n8), -n3 * 0.0f);
            GL11.glVertex3f(n7 * (float)Math.cos(n12 + 2.0f * n8), n7 * (float)Math.sin(n12 + 2.0f * n8), -n3 * 0.0f);
            GL11.glVertex3f(n7 * (float)Math.cos(n12 + n8), n7 * (float)Math.sin(n12 + n8), -n3 * 0.0f);
            GL11.glVertex3f(n6 * (float)Math.cos(n12), n6 * (float)Math.sin(n12), -n3 * 0.0f);
        }
        GL11.glEnd();
        GL11.glNormal3f(0.0f, 0.0f, 1.0f);
        GL11.glBegin(8);
        for (int n13 = 0; n13 < n4; ++n13) {
            final float n14 = n13 * 2.0f * 3.1415927f / n4;
            GL11.glVertex3f(n6 * (float)Math.cos(n14), n6 * (float)Math.sin(n14), n3 * 0.0f);
            GL11.glVertex3f(n6 * (float)Math.cos(n14), n6 * (float)Math.sin(n14), -n3 * 0.0f);
            final float n15 = n7 * (float)Math.cos(n14 + n8) - n6 * (float)Math.cos(n14);
            final float n16 = n7 * (float)Math.sin(n14 + n8) - n6 * (float)Math.sin(n14);
            final float n17 = (float)Math.sqrt(n15 * n15 + n16 * n16);
            GL11.glNormal3f(n16 / n17, -(n15 / n17), 0.0f);
            GL11.glVertex3f(n7 * (float)Math.cos(n14 + n8), n7 * (float)Math.sin(n14 + n8), n3 * 0.0f);
            GL11.glVertex3f(n7 * (float)Math.cos(n14 + n8), n7 * (float)Math.sin(n14 + n8), -n3 * 0.0f);
            GL11.glNormal3f((float)Math.cos(n14), (float)Math.sin(n14), 0.0f);
            GL11.glVertex3f(n7 * (float)Math.cos(n14 + 2.0f * n8), n7 * (float)Math.sin(n14 + 2.0f * n8), n3 * 0.0f);
            GL11.glVertex3f(n7 * (float)Math.cos(n14 + 2.0f * n8), n7 * (float)Math.sin(n14 + 2.0f * n8), -n3 * 0.0f);
            GL11.glNormal3f(n6 * (float)Math.sin(n14 + 3.0f * n8) - n7 * (float)Math.sin(n14 + 2.0f * n8), -(n6 * (float)Math.cos(n14 + 3.0f * n8) - n7 * (float)Math.cos(n14 + 2.0f * n8)), 0.0f);
            GL11.glVertex3f(n6 * (float)Math.cos(n14 + 3.0f * n8), n6 * (float)Math.sin(n14 + 3.0f * n8), n3 * 0.0f);
            GL11.glVertex3f(n6 * (float)Math.cos(n14 + 3.0f * n8), n6 * (float)Math.sin(n14 + 3.0f * n8), -n3 * 0.0f);
            GL11.glNormal3f((float)Math.cos(n14), (float)Math.sin(n14), 0.0f);
        }
        GL11.glVertex3f(n6 * (float)Math.cos(0.0), n6 * (float)Math.sin(0.0), n3 * 0.0f);
        GL11.glVertex3f(n6 * (float)Math.cos(0.0), n6 * (float)Math.sin(0.0), -n3 * 0.0f);
        GL11.glEnd();
        GL11.glShadeModel(7425);
        GL11.glBegin(8);
        for (int n18 = 0; n18 <= n4; ++n18) {
            final float n19 = n18 * 2.0f * 3.1415927f / n4;
            GL11.glNormal3f(-(float)Math.cos(n19), -(float)Math.sin(n19), 0.0f);
            GL11.glVertex3f(n * (float)Math.cos(n19), n * (float)Math.sin(n19), -n3 * 0.0f);
            GL11.glVertex3f(n * (float)Math.cos(n19), n * (float)Math.sin(n19), n3 * 0.0f);
        }
        GL11.glEnd();
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
        this.rot += n * 0.0f;
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new SlickCallableTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
