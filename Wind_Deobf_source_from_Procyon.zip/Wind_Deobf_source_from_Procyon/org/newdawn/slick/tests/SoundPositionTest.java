// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.openal.SoundStore;
import org.newdawn.slick.Music;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.BasicGame;

public class SoundPositionTest extends BasicGame
{
    public GameContainer myContainer;
    public Music music;
    public int[] engines;
    
    public SoundPositionTest() {
        super("Music Position Test");
        this.engines = new int[3];
    }
    
    @Override
    public void init(final GameContainer myContainer) throws SlickException {
        SoundStore.get().setMaxSources(32);
        this.myContainer = myContainer;
        (this.music = new Music("testdata/kirby.ogg", true)).play();
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        graphics.setColor(Color.white);
        graphics.drawString("Position: " + this.music.getPosition(), 100.0f, 100.0f);
        graphics.drawString("Space - Pause/Resume", 100.0f, 130.0f);
        graphics.drawString("Right Arrow - Advance 5 seconds", 100.0f, 145.0f);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 57) {
            if (this.music.playing()) {
                this.music.pause();
            }
            else {
                this.music.resume();
            }
        }
        if (n == 205) {
            this.music.setPosition(this.music.getPosition() + 5.0f);
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new SoundPositionTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
