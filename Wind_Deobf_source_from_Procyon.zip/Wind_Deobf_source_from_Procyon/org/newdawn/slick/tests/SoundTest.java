// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.openal.AudioLoader;
import org.newdawn.slick.util.ResourceLoader;
import org.newdawn.slick.openal.SoundStore;
import org.newdawn.slick.openal.Audio;
import org.newdawn.slick.Music;
import org.newdawn.slick.Sound;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.BasicGame;

public class SoundTest extends BasicGame
{
    public GameContainer myContainer;
    public Sound sound;
    public Sound charlie;
    public Sound burp;
    public Music music;
    public Music musica;
    public Music musicb;
    public Audio engine;
    public int volume;
    public int[] engines;
    
    public SoundTest() {
        super("Sound And Music Test");
        this.volume = 10;
        this.engines = new int[3];
    }
    
    @Override
    public void init(final GameContainer myContainer) throws SlickException {
        SoundStore.get().setMaxSources(32);
        this.myContainer = myContainer;
        this.sound = new Sound("testdata/restart.ogg");
        this.charlie = new Sound("testdata/cbrown01.wav");
        this.engine = AudioLoader.getAudio("WAV", ResourceLoader.getResourceAsStream("testdata/engine.wav"));
        final Music music = new Music("testdata/SMB-X.XM");
        this.musica = music;
        this.music = music;
        this.musicb = new Music("testdata/kirby.ogg", true);
        this.burp = new Sound("testdata/burp.aif");
        this.music.play();
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        graphics.setColor(Color.white);
        graphics.drawString("The OGG loop is now streaming from the file, woot.", 100.0f, 60.0f);
        graphics.drawString("Press space for sound effect (OGG)", 100.0f, 100.0f);
        graphics.drawString("Press P to pause/resume music (XM)", 100.0f, 130.0f);
        graphics.drawString("Press E to pause/resume engine sound (WAV)", 100.0f, 190.0f);
        graphics.drawString("Press enter for charlie (WAV)", 100.0f, 160.0f);
        graphics.drawString("Press C to change music", 100.0f, 210.0f);
        graphics.drawString("Press B to burp (AIF)", 100.0f, 240.0f);
        graphics.drawString("Press + or - to change global volume of music", 100.0f, 270.0f);
        graphics.drawString("Press Y or X to change individual volume of music", 100.0f, 300.0f);
        graphics.drawString("Press N or M to change global volume of sound fx", 100.0f, 330.0f);
        graphics.setColor(Color.blue);
        graphics.drawString("Global Sound Volume Level: " + gameContainer.getSoundVolume(), 150.0f, 390.0f);
        graphics.drawString("Global Music Volume Level: " + gameContainer.getMusicVolume(), 150.0f, 420.0f);
        graphics.drawString("Current Music Volume Level: " + this.music.getVolume(), 150.0f, 450.0f);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 1) {
            System.exit(0);
        }
        if (n == 57) {
            this.sound.play();
        }
        if (n == 48) {
            this.burp.play();
        }
        if (n == 30) {
            this.sound.playAt(-1.0f, 0.0f, 0.0f);
        }
        if (n == 38) {
            this.sound.playAt(1.0f, 0.0f, 0.0f);
        }
        if (n == 28) {
            this.charlie.play(1.0f, 1.0f);
        }
        if (n == 25) {
            if (this.music.playing()) {
                this.music.pause();
            }
            else {
                this.music.resume();
            }
        }
        if (n == 46) {
            this.music.stop();
            if (this.music == this.musica) {
                this.music = this.musicb;
            }
            else {
                this.music = this.musica;
            }
            this.music.loop();
        }
        for (int i = 0; i < 3; ++i) {
            if (n == 2 + i) {
                if (this.engines[i] != 0) {
                    System.out.println("Stop " + i);
                    SoundStore.get().stopSoundEffect(this.engines[i]);
                    this.engines[i] = 0;
                }
                else {
                    System.out.println("Start " + i);
                    this.engines[i] = this.engine.playAsSoundEffect(1.0f, 1.0f, true);
                }
            }
        }
        if (c == '+') {
            ++this.volume;
            this.setVolume();
        }
        if (c == '-') {
            --this.volume;
            this.setVolume();
        }
        if (n == 21) {
            int n2 = (int)(this.music.getVolume() * 10.0f);
            if (--n2 < 0) {
                n2 = 0;
            }
            this.music.setVolume(n2 / 10.0f);
        }
        if (n == 45) {
            int n3 = (int)(this.music.getVolume() * 10.0f);
            if (++n3 > 10) {
                n3 = 10;
            }
            this.music.setVolume(n3 / 10.0f);
        }
        if (n == 49) {
            int n4 = (int)(this.myContainer.getSoundVolume() * 10.0f);
            if (--n4 < 0) {
                n4 = 0;
            }
            this.myContainer.setSoundVolume(n4 / 10.0f);
        }
        if (n == 50) {
            int n5 = (int)(this.myContainer.getSoundVolume() * 10.0f);
            if (++n5 > 10) {
                n5 = 10;
            }
            this.myContainer.setSoundVolume(n5 / 10.0f);
        }
    }
    
    public void setVolume() {
        if (this.volume > 10) {
            this.volume = 10;
        }
        else if (this.volume < 0) {
            this.volume = 0;
        }
        this.myContainer.setMusicVolume(this.volume / 10.0f);
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new SoundTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
