// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheetFont;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Font;
import org.newdawn.slick.BasicGame;

public class SpriteSheetFontTest extends BasicGame
{
    public Font font;
    public static AppGameContainer container;
    
    public SpriteSheetFontTest() {
        super("SpriteSheetFont Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.font = new SpriteSheetFont(new SpriteSheet("testdata/spriteSheetFont.png", 32, 32), ' ');
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        graphics.setBackground(Color.gray);
        this.font.drawString(80.0f, 5.0f, "A FONT EXAMPLE", Color.red);
        this.font.drawString(100.0f, 50.0f, "A MORE COMPLETE LINE");
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 1) {
            System.exit(0);
        }
        if (n == 57) {
            SpriteSheetFontTest.container.setDisplayMode(640, 480, false);
        }
    }
    
    public static void main(final String[] array) {
        (SpriteSheetFontTest.container = new AppGameContainer(new SpriteSheetFontTest())).setDisplayMode(800, 600, false);
        SpriteSheetFontTest.container.start();
    }
}
