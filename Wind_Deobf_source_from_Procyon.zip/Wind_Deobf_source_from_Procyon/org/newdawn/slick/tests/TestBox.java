// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.opengl.SlickCallable;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Color;
import org.newdawn.slick.AppGameContainer;
import java.util.ArrayList;
import org.newdawn.slick.BasicGame;

public class TestBox extends BasicGame
{
    public ArrayList games;
    public BasicGame currentGame;
    public int index;
    public AppGameContainer container;
    
    public TestBox() {
        super("Test Box");
        this.games = new ArrayList();
    }
    
    public void addGame(final Class e) {
        this.games.add(e);
    }
    
    public void nextGame() {
        if (this.index == -1) {
            return;
        }
        ++this.index;
        if (this.index >= this.games.size()) {
            this.index = 0;
        }
        this.startGame();
    }
    
    public void startGame() {
        this.currentGame = this.games.get(this.index).newInstance();
        this.container.getGraphics().setBackground(Color.black);
        this.currentGame.init(this.container);
        this.currentGame.render(this.container, this.container.getGraphics());
        this.container.setTitle(this.currentGame.getTitle());
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        if (this.games.size() == 0) {
            (this.currentGame = new BasicGame(this, "NULL") {
                public TestBox this$0;
                
                @Override
                public void init(final GameContainer gameContainer) throws SlickException {
                }
                
                @Override
                public void update(final GameContainer gameContainer, final int n) throws SlickException {
                }
                
                @Override
                public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
                }
            }).init(gameContainer);
            this.index = -1;
        }
        else {
            this.index = 0;
            this.container = (AppGameContainer)gameContainer;
            this.startGame();
        }
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        this.currentGame.update(gameContainer, n);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        SlickCallable.enterSafeBlock();
        this.currentGame.render(gameContainer, graphics);
        SlickCallable.leaveSafeBlock();
    }
    
    @Override
    public void controllerButtonPressed(final int n, final int n2) {
        this.currentGame.controllerButtonPressed(n, n2);
    }
    
    @Override
    public void controllerButtonReleased(final int n, final int n2) {
        this.currentGame.controllerButtonReleased(n, n2);
    }
    
    @Override
    public void controllerDownPressed(final int n) {
        this.currentGame.controllerDownPressed(n);
    }
    
    @Override
    public void controllerDownReleased(final int n) {
        this.currentGame.controllerDownReleased(n);
    }
    
    @Override
    public void controllerLeftPressed(final int n) {
        this.currentGame.controllerLeftPressed(n);
    }
    
    @Override
    public void controllerLeftReleased(final int n) {
        this.currentGame.controllerLeftReleased(n);
    }
    
    @Override
    public void controllerRightPressed(final int n) {
        this.currentGame.controllerRightPressed(n);
    }
    
    @Override
    public void controllerRightReleased(final int n) {
        this.currentGame.controllerRightReleased(n);
    }
    
    @Override
    public void controllerUpPressed(final int n) {
        this.currentGame.controllerUpPressed(n);
    }
    
    @Override
    public void controllerUpReleased(final int n) {
        this.currentGame.controllerUpReleased(n);
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        this.currentGame.keyPressed(n, c);
        if (n == 28) {
            this.nextGame();
        }
    }
    
    @Override
    public void keyReleased(final int n, final char c) {
        this.currentGame.keyReleased(n, c);
    }
    
    @Override
    public void mouseMoved(final int n, final int n2, final int n3, final int n4) {
        this.currentGame.mouseMoved(n, n2, n3, n4);
    }
    
    @Override
    public void mousePressed(final int n, final int n2, final int n3) {
        this.currentGame.mousePressed(n, n2, n3);
    }
    
    @Override
    public void mouseReleased(final int n, final int n2, final int n3) {
        this.currentGame.mouseReleased(n, n2, n3);
    }
    
    @Override
    public void mouseWheelMoved(final int n) {
        this.currentGame.mouseWheelMoved(n);
    }
    
    public static void main(final String[] array) {
        final TestBox testBox = new TestBox();
        testBox.addGame(AnimationTest.class);
        testBox.addGame(AntiAliasTest.class);
        testBox.addGame(BigImageTest.class);
        testBox.addGame(ClipTest.class);
        testBox.addGame(DuplicateEmitterTest.class);
        testBox.addGame(FlashTest.class);
        testBox.addGame(FontPerformanceTest.class);
        testBox.addGame(FontTest.class);
        testBox.addGame(GeomTest.class);
        testBox.addGame(GradientTest.class);
        testBox.addGame(GraphicsTest.class);
        testBox.addGame(ImageBufferTest.class);
        testBox.addGame(ImageReadTest.class);
        testBox.addGame(ImageTest.class);
        testBox.addGame(KeyRepeatTest.class);
        testBox.addGame(MusicListenerTest.class);
        testBox.addGame(PackedSheetTest.class);
        testBox.addGame(PedigreeTest.class);
        testBox.addGame(PureFontTest.class);
        testBox.addGame(ShapeTest.class);
        testBox.addGame(SoundTest.class);
        testBox.addGame(SpriteSheetFontTest.class);
        testBox.addGame(TransparentColorTest.class);
        final AppGameContainer appGameContainer = new AppGameContainer(testBox);
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
}
