// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.geom.ShapeRenderer;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.geom.TexCoordGenerator;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Polygon;
import org.newdawn.slick.BasicGame;

public class TexturePaintTest extends BasicGame
{
    public Polygon poly;
    public Image image;
    public Rectangle texRect;
    public TexCoordGenerator texPaint;
    
    public TexturePaintTest() {
        super("Texture Paint Test");
        this.poly = new Polygon();
        this.texRect = new Rectangle(50.0f, 50.0f, 100.0f, 100.0f);
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.poly.addPoint(120.0f, 120.0f);
        this.poly.addPoint(420.0f, 100.0f);
        this.poly.addPoint(620.0f, 420.0f);
        this.poly.addPoint(300.0f, 320.0f);
        this.image = new Image("testdata/rocks.png");
        this.texPaint = new TexCoordGenerator(this) {
            public TexturePaintTest this$0;
            
            @Override
            public Vector2f getCoordFor(final float n, final float n2) {
                return new Vector2f((TexturePaintTest.access$000(this.this$0).getX() - n) / TexturePaintTest.access$000(this.this$0).getWidth(), (TexturePaintTest.access$000(this.this$0).getY() - n2) / TexturePaintTest.access$000(this.this$0).getHeight());
            }
        };
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) throws SlickException {
        graphics.setColor(Color.white);
        graphics.texture(this.poly, this.image);
        ShapeRenderer.texture(this.poly, this.image, this.texPaint);
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new TexturePaintTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    public static Rectangle access$000(final TexturePaintTest texturePaintTest) {
        return texturePaintTest.texRect;
    }
}
