// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.tiled.TiledMap;
import org.newdawn.slick.BasicGame;

public class TileMapTest extends BasicGame
{
    public TiledMap map;
    public String mapName;
    public String monsterDifficulty;
    public String nonExistingMapProperty;
    public String nonExistingLayerProperty;
    public int updateCounter;
    public static int UPDATE_TIME;
    public int originalTileID;
    
    public TileMapTest() {
        super("Tile Map Test");
        this.updateCounter = 0;
        this.originalTileID = 0;
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        this.map = new TiledMap("testdata/testmap.tmx", "testdata");
        this.mapName = this.map.getMapProperty("name", "Unknown map name");
        this.monsterDifficulty = this.map.getLayerProperty(0, "monsters", "easy peasy");
        this.nonExistingMapProperty = this.map.getMapProperty("zaphod", "Undefined map property");
        this.nonExistingLayerProperty = this.map.getLayerProperty(1, "beeblebrox", "Undefined layer property");
        this.originalTileID = this.map.getTileId(10, 10, 0);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        this.map.render(10, 10, 4, 4, 15, 15);
        graphics.scale(0.0f, 0.0f);
        this.map.render(1400, 0);
        graphics.resetTransform();
        graphics.drawString("map name: " + this.mapName, 10.0f, 500.0f);
        graphics.drawString("monster difficulty: " + this.monsterDifficulty, 10.0f, 550.0f);
        graphics.drawString("non existing map property: " + this.nonExistingMapProperty, 10.0f, 525.0f);
        graphics.drawString("non existing layer property: " + this.nonExistingLayerProperty, 10.0f, 575.0f);
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) {
        this.updateCounter += n;
        if (this.updateCounter > TileMapTest.UPDATE_TIME) {
            this.updateCounter -= TileMapTest.UPDATE_TIME;
            if (this.map.getTileId(10, 10, 0) != this.originalTileID) {
                this.map.setTileId(10, 10, 0, this.originalTileID);
            }
            else {
                this.map.setTileId(10, 10, 0, 1);
            }
        }
    }
    
    @Override
    public void keyPressed(final int n, final char c) {
        if (n == 1) {
            System.exit(0);
        }
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new TileMapTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    static {
        TileMapTest.UPDATE_TIME = 1000;
    }
}
