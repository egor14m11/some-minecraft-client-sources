// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.state.transition.Transition;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.GameState;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.state.transition.SelectTransition;
import org.newdawn.slick.state.transition.BlobbyTransition;
import org.newdawn.slick.state.transition.HorizontalSplitTransition;
import org.newdawn.slick.state.transition.RotateTransition;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;
import org.newdawn.slick.state.transition.VerticalSplitTransition;
import org.newdawn.slick.state.StateBasedGame;

public class TransitionTest extends StateBasedGame
{
    public Class[][] transitions;
    public int index;
    
    public TransitionTest() {
        super("Transition Test - Hit Space To Transition");
        this.transitions = new Class[][] { { null, VerticalSplitTransition.class }, { FadeOutTransition.class, FadeInTransition.class }, { null, RotateTransition.class }, { null, HorizontalSplitTransition.class }, { null, BlobbyTransition.class }, { null, SelectTransition.class } };
    }
    
    @Override
    public void initStatesList(final GameContainer gameContainer) throws SlickException {
        this.addState(new ImageState(0, "testdata/wallpaper/paper1.png", 1));
        this.addState(new ImageState(1, "testdata/wallpaper/paper2.png", 2));
        this.addState(new ImageState(2, "testdata/bigimage.tga", 0));
    }
    
    public Transition[] getNextTransitionPair() {
        final Transition[] array = new Transition[2];
        if (this.transitions[this.index][0] != null) {
            array[0] = this.transitions[this.index][0].newInstance();
        }
        if (this.transitions[this.index][1] != null) {
            array[1] = this.transitions[this.index][1].newInstance();
        }
        ++this.index;
        if (this.index >= this.transitions.length) {
            this.index = 0;
        }
        return array;
    }
    
    public static void main(final String[] array) {
        final AppGameContainer appGameContainer = new AppGameContainer(new TransitionTest());
        appGameContainer.setDisplayMode(800, 600, false);
        appGameContainer.start();
    }
    
    private class ImageState extends BasicGameState
    {
        public int id;
        public int next;
        public String ref;
        public Image image;
        public TransitionTest this$0;
        
        public ImageState(final TransitionTest this$0, final int id, final String ref, final int next) {
            this.this$0 = this$0;
            this.ref = ref;
            this.id = id;
            this.next = next;
        }
        
        @Override
        public int getID() {
            return this.id;
        }
        
        @Override
        public void init(final GameContainer gameContainer, final StateBasedGame stateBasedGame) throws SlickException {
            this.image = new Image(this.ref);
        }
        
        @Override
        public void render(final GameContainer gameContainer, final StateBasedGame stateBasedGame, final Graphics graphics) throws SlickException {
            this.image.draw(0.0f, 0.0f, 800.0f, 600.0f);
            graphics.setColor(Color.red);
            graphics.fillRect(-50.0f, 200.0f, 50.0f, 50.0f);
        }
        
        @Override
        public void update(final GameContainer gameContainer, final StateBasedGame stateBasedGame, final int n) throws SlickException {
            if (gameContainer.getInput().isKeyPressed(57)) {
                final Transition[] nextTransitionPair = this.this$0.getNextTransitionPair();
                stateBasedGame.enterState(this.next, nextTransitionPair[0], nextTransitionPair[1]);
            }
        }
    }
}
