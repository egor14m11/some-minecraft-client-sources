// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests;

import java.io.IOException;
import org.newdawn.slick.Game;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Input;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.font.effects.ColorEffect;
import java.awt.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.UnicodeFont;
import org.newdawn.slick.BasicGame;

public class UnicodeFontTest extends BasicGame
{
    public UnicodeFont unicodeFont;
    
    public UnicodeFontTest() {
        super("Font Test");
    }
    
    @Override
    public void init(final GameContainer gameContainer) throws SlickException {
        gameContainer.setShowFPS(false);
        this.unicodeFont = new UnicodeFont("c:/windows/fonts/arial.ttf", 48, false, false);
        this.unicodeFont.getEffects().add(new ColorEffect(Color.white));
        gameContainer.getGraphics().setBackground(org.newdawn.slick.Color.darkGray);
    }
    
    @Override
    public void render(final GameContainer gameContainer, final Graphics graphics) {
        graphics.setColor(org.newdawn.slick.Color.white);
        final String s = "This is UnicodeFont!\nIt rockz. Kerning: T,";
        this.unicodeFont.drawString(10.0f, 33.0f, s);
        graphics.setColor(org.newdawn.slick.Color.red);
        graphics.drawRect(10.0f, 33.0f, (float)this.unicodeFont.getWidth(s), (float)this.unicodeFont.getLineHeight());
        graphics.setColor(org.newdawn.slick.Color.blue);
        final int yOffset = this.unicodeFont.getYOffset(s);
        graphics.drawRect(10.0f, (float)(33 + yOffset), (float)this.unicodeFont.getWidth(s), (float)(this.unicodeFont.getHeight(s) - yOffset));
        this.unicodeFont.addGlyphs("~!@!#!#$%___--");
    }
    
    @Override
    public void update(final GameContainer gameContainer, final int n) throws SlickException {
        this.unicodeFont.loadGlyphs(1);
    }
    
    public static void main(final String[] array) throws SlickException, IOException {
        Input.disableControllers();
        final AppGameContainer appGameContainer = new AppGameContainer(new UnicodeFontTest());
        appGameContainer.setDisplayMode(512, 600, false);
        appGameContainer.setTargetFrameRate(20);
        appGameContainer.start();
    }
}
