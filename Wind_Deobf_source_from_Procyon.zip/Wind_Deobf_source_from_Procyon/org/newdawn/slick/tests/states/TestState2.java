// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests.states;

import org.newdawn.slick.state.transition.Transition;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.AngelCodeFont;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.Image;
import org.newdawn.slick.Font;
import org.newdawn.slick.state.BasicGameState;

public class TestState2 extends BasicGameState
{
    public static int ID;
    public Font font;
    public Image image;
    public float ang;
    public StateBasedGame game;
    
    @Override
    public int getID() {
        return 2;
    }
    
    @Override
    public void init(final GameContainer gameContainer, final StateBasedGame game) throws SlickException {
        this.game = game;
        this.font = new AngelCodeFont("testdata/demo2.fnt", "testdata/demo2_00.tga");
        this.image = new Image("testdata/logo.tga");
    }
    
    @Override
    public void render(final GameContainer gameContainer, final StateBasedGame stateBasedGame, final Graphics graphics) {
        graphics.setFont(this.font);
        graphics.setColor(Color.green);
        graphics.drawString("This is State 2", 200.0f, 50.0f);
        graphics.rotate(400.0f, 300.0f, this.ang);
        graphics.drawImage(this.image, (float)(400 - this.image.getWidth() / 2), (float)(300 - this.image.getHeight() / 2));
    }
    
    @Override
    public void update(final GameContainer gameContainer, final StateBasedGame stateBasedGame, final int n) {
        this.ang += n * 0.0f;
    }
    
    @Override
    public void keyReleased(final int n, final char c) {
        if (n == 2) {
            this.game.enterState(1, new FadeOutTransition(Color.black), new FadeInTransition(Color.black));
        }
        if (n == 4) {
            this.game.enterState(3, new FadeOutTransition(Color.black), new FadeInTransition(Color.black));
        }
    }
    
    static {
        TestState2.ID = 2;
    }
}
