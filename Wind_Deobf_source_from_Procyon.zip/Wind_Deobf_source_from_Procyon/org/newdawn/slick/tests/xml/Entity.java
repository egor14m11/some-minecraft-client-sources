// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests.xml;

public class Entity
{
    public float x;
    public float y;
    public Inventory invent;
    public Stats stats;
    
    public void add(final Inventory invent) {
        this.invent = invent;
    }
    
    public void add(final Stats stats) {
        this.stats = stats;
    }
    
    public void dump(final String str) {
        System.out.println(str + "Entity " + this.x + "," + this.y);
        this.invent.dump(str + "\t");
        this.stats.dump(str + "\t");
    }
}
