// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests.xml;

import java.util.ArrayList;

public class GameData
{
    public ArrayList entities;
    
    public GameData() {
        this.entities = new ArrayList();
    }
    
    public void add(final Entity e) {
        this.entities.add(e);
    }
    
    public void dump(final String s) {
        System.out.println(s + "GameData");
        for (int i = 0; i < this.entities.size(); ++i) {
            ((Entity)this.entities.get(i)).dump(s + "\t");
        }
    }
}
