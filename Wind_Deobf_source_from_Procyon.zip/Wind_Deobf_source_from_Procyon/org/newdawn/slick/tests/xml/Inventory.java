// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests.xml;

import java.util.ArrayList;

public class Inventory
{
    public ArrayList items;
    
    public Inventory() {
        this.items = new ArrayList();
    }
    
    public void add(final Item e) {
        this.items.add(e);
    }
    
    public void dump(final String s) {
        System.out.println(s + "Inventory");
        for (int i = 0; i < this.items.size(); ++i) {
            ((Item)this.items.get(i)).dump(s + "\t");
        }
    }
}
