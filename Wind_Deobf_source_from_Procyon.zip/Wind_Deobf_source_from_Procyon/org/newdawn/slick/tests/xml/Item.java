// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests.xml;

public class Item
{
    public String name;
    public int condition;
    
    public void dump(final String str) {
        System.out.println(str + "Item " + this.name + "," + this.condition);
    }
}
