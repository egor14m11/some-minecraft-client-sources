// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests.xml;

import java.util.ArrayList;

public class ItemContainer extends Item
{
    public ArrayList items;
    
    public ItemContainer() {
        this.items = new ArrayList();
    }
    
    public void add(final Item e) {
        this.items.add(e);
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public void setCondition(final int condition) {
        this.condition = condition;
    }
    
    @Override
    public void dump(final String s) {
        System.out.println(s + "Item Container " + this.name + "," + this.condition);
        for (int i = 0; i < this.items.size(); ++i) {
            ((Item)this.items.get(i)).dump(s + "\t");
        }
    }
}
