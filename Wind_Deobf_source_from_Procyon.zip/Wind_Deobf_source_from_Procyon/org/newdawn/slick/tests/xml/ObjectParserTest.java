// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests.xml;

import org.newdawn.slick.util.xml.SlickXMLException;
import org.newdawn.slick.util.xml.ObjectTreeParser;

public class ObjectParserTest
{
    public static void main(final String[] array) throws SlickXMLException {
        final ObjectTreeParser objectTreeParser = new ObjectTreeParser("org.newdawn.slick.tests.xml");
        objectTreeParser.addElementMapping("Bag", ItemContainer.class);
        ((GameData)objectTreeParser.parse("testdata/objxmltest.xml")).dump("");
    }
}
