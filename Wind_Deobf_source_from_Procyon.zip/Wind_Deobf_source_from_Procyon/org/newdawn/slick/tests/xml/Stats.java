// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests.xml;

public class Stats
{
    public int hp;
    public int mp;
    public float age;
    public int exp;
    
    public void dump(final String str) {
        System.out.println(str + "Stats " + this.hp + "," + this.mp + "," + this.age + "," + this.exp);
    }
}
