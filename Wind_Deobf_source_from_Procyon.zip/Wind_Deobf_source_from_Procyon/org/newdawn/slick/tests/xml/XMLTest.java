// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tests.xml;

import org.newdawn.slick.SlickException;
import org.newdawn.slick.util.xml.XMLElement;
import org.newdawn.slick.util.xml.XMLParser;

public class XMLTest
{
    public static void fail(final String message) {
        throw new RuntimeException(message);
    }
    
    public static void assertNotNull(final Object obj) {
        if (obj == null) {
            throw new RuntimeException("TEST FAILS: " + obj + " must not be null");
        }
    }
    
    public static void assertEquals(final float f, final float f2) {
        if (f != f2) {
            throw new RuntimeException("TEST FAILS: " + f + " should be " + f2);
        }
    }
    
    public static void assertEquals(final int i, final int j) {
        if (i != j) {
            throw new RuntimeException("TEST FAILS: " + i + " should be " + j);
        }
    }
    
    public static void assertEquals(final Object obj, final Object o) {
        if (!obj.equals(o)) {
            throw new RuntimeException("TEST FAILS: " + obj + " should be " + o);
        }
    }
    
    public static void main(final String[] array) throws SlickException {
        final XMLElement parse = new XMLParser().parse("testdata/test.xml");
        assertEquals(parse.getName(), "testRoot");
        System.out.println(parse);
        assertNotNull(parse.getChildrenByName("simple").get(0).getContent());
        System.out.println(parse.getChildrenByName("simple").get(0).getContent());
        final XMLElement value = parse.getChildrenByName("parent").get(0);
        assertEquals(value.getChildrenByName("grandchild").size(), 0);
        assertEquals(value.getChildrenByName("child").size(), 2);
        assertEquals(value.getChildrenByName("child").get(0).getChildren().size(), 2);
        final XMLElement value2 = value.getChildrenByName("child").get(0).getChildren().get(0);
        final String attribute = value2.getAttribute("name");
        final String attribute2 = value2.getAttribute("nothere", "defaultValue");
        final int intAttribute = value2.getIntAttribute("age");
        assertEquals(attribute, "bob");
        assertEquals(attribute2, "defaultValue");
        assertEquals(intAttribute, 1);
        final XMLElement value3 = parse.getChildrenByName("other").get(0);
        final float n = (float)value3.getDoubleAttribute("x");
        final float n2 = (float)value3.getDoubleAttribute("y", 1.0);
        final float n3 = (float)value3.getDoubleAttribute("z", 83.0);
        assertEquals(n, 5.3f);
        assertEquals(n2, 5.4f);
        assertEquals(n3, 83.0f);
        final float n4 = (float)value3.getDoubleAttribute("z");
        fail("Attribute z as a double should fail");
    }
}
