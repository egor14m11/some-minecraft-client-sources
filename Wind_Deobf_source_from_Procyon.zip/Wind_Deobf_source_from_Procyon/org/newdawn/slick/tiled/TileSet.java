// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tiled;

import org.w3c.dom.NodeList;
import java.util.Properties;
import org.newdawn.slick.Image;
import org.newdawn.slick.Color;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.util.ResourceLoader;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Element;
import java.util.HashMap;
import org.newdawn.slick.SpriteSheet;

public class TileSet
{
    public TiledMap map;
    public int index;
    public String name;
    public int firstGID;
    public int lastGID;
    public int tileWidth;
    public int tileHeight;
    public SpriteSheet tiles;
    public int tilesAcross;
    public int tilesDown;
    public HashMap props;
    public int tileSpacing;
    public int tileMargin;
    
    public TileSet(final TiledMap map, Element documentElement, final boolean b) throws SlickException {
        this.lastGID = Integer.MAX_VALUE;
        this.props = new HashMap();
        this.tileSpacing = 0;
        this.tileMargin = 0;
        this.map = map;
        this.name = documentElement.getAttribute("name");
        this.firstGID = Integer.parseInt(documentElement.getAttribute("firstgid"));
        final String attribute = documentElement.getAttribute("source");
        if (attribute != null && !attribute.equals("")) {
            documentElement = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ResourceLoader.getResourceAsStream(map.getTilesLocation() + "/" + attribute)).getDocumentElement();
        }
        final String attribute2 = documentElement.getAttribute("tilewidth");
        final String attribute3 = documentElement.getAttribute("tileheight");
        if (attribute2.length() == 0 || attribute3.length() == 0) {
            throw new SlickException("TiledMap requires that the map be created with tilesets that use a single image.  Check the WiKi for more complete information.");
        }
        this.tileWidth = Integer.parseInt(attribute2);
        this.tileHeight = Integer.parseInt(attribute3);
        final String attribute4 = documentElement.getAttribute("spacing");
        if (attribute4 != null && !attribute4.equals("")) {
            this.tileSpacing = Integer.parseInt(attribute4);
        }
        final String attribute5 = documentElement.getAttribute("margin");
        if (attribute5 != null && !attribute5.equals("")) {
            this.tileMargin = Integer.parseInt(attribute5);
        }
        final Element element = (Element)documentElement.getElementsByTagName("image").item(0);
        final String attribute6 = element.getAttribute("source");
        Color color = null;
        final String attribute7 = element.getAttribute("trans");
        if (attribute7 != null && attribute7.length() > 0) {
            color = new Color(Integer.parseInt(attribute7, 16));
        }
        if (b) {
            this.setTileSetImage(new Image(map.getTilesLocation() + "/" + attribute6, false, 2, color));
        }
        final NodeList elementsByTagName = documentElement.getElementsByTagName("tile");
        for (int i = 0; i < elementsByTagName.getLength(); ++i) {
            final Element element2 = (Element)elementsByTagName.item(i);
            final int value = Integer.parseInt(element2.getAttribute("id")) + this.firstGID;
            final Properties value2 = new Properties();
            final NodeList elementsByTagName2 = ((Element)element2.getElementsByTagName("properties").item(0)).getElementsByTagName("property");
            for (int j = 0; j < elementsByTagName2.getLength(); ++j) {
                final Element element3 = (Element)elementsByTagName2.item(j);
                value2.setProperty(element3.getAttribute("name"), element3.getAttribute("value"));
            }
            this.props.put(new Integer(value), value2);
        }
    }
    
    public int getTileWidth() {
        return this.tileWidth;
    }
    
    public int getTileHeight() {
        return this.tileHeight;
    }
    
    public int getTileSpacing() {
        return this.tileSpacing;
    }
    
    public int getTileMargin() {
        return this.tileMargin;
    }
    
    public void setTileSetImage(final Image image) {
        this.tiles = new SpriteSheet(image, this.tileWidth, this.tileHeight, this.tileSpacing, this.tileMargin);
        this.tilesAcross = this.tiles.getHorizontalCount();
        this.tilesDown = this.tiles.getVerticalCount();
        if (this.tilesAcross <= 0) {
            this.tilesAcross = 1;
        }
        if (this.tilesDown <= 0) {
            this.tilesDown = 1;
        }
        this.lastGID = this.tilesAcross * this.tilesDown + this.firstGID - 1;
    }
    
    public Properties getProperties(final int value) {
        return this.props.get(new Integer(value));
    }
    
    public int getTileX(final int n) {
        return n % this.tilesAcross;
    }
    
    public int getTileY(final int n) {
        return n / this.tilesAcross;
    }
    
    public void setLimit(final int lastGID) {
        this.lastGID = lastGID;
    }
    
    public boolean contains(final int n) {
        return n >= this.firstGID && n <= this.lastGID;
    }
}
