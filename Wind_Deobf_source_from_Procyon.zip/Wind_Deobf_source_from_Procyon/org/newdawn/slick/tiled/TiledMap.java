// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.tiled;

import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Element;
import java.io.IOException;
import org.xml.sax.SAXException;
import java.io.ByteArrayInputStream;
import org.xml.sax.InputSource;
import org.xml.sax.EntityResolver;
import javax.xml.parsers.DocumentBuilderFactory;
import org.newdawn.slick.Image;
import java.io.InputStream;
import org.newdawn.slick.util.ResourceLoader;
import org.newdawn.slick.SlickException;
import java.util.ArrayList;
import java.util.Properties;

public class TiledMap
{
    public static boolean headless;
    public int width;
    public int height;
    public int tileWidth;
    public int tileHeight;
    public String tilesLocation;
    public Properties props;
    public ArrayList tileSets;
    public ArrayList layers;
    public ArrayList objectGroups;
    public static int ORTHOGONAL;
    public static int ISOMETRIC;
    public int orientation;
    public boolean loadTileSets;
    
    public static void setHeadless(final boolean headless) {
        TiledMap.headless = headless;
    }
    
    public TiledMap(final String s) throws SlickException {
        this(s, true);
    }
    
    public TiledMap(String replace, final boolean loadTileSets) throws SlickException {
        this.tileSets = new ArrayList();
        this.layers = new ArrayList();
        this.objectGroups = new ArrayList();
        this.loadTileSets = true;
        this.loadTileSets = loadTileSets;
        replace = replace.replace('\\', '/');
        this.load(ResourceLoader.getResourceAsStream(replace), replace.substring(0, replace.lastIndexOf("/")));
    }
    
    public TiledMap(final String s, final String s2) throws SlickException {
        this.tileSets = new ArrayList();
        this.layers = new ArrayList();
        this.objectGroups = new ArrayList();
        this.loadTileSets = true;
        this.load(ResourceLoader.getResourceAsStream(s), s2);
    }
    
    public TiledMap(final InputStream inputStream) throws SlickException {
        this.tileSets = new ArrayList();
        this.layers = new ArrayList();
        this.objectGroups = new ArrayList();
        this.loadTileSets = true;
        this.load(inputStream, "");
    }
    
    public TiledMap(final InputStream inputStream, final String s) throws SlickException {
        this.tileSets = new ArrayList();
        this.layers = new ArrayList();
        this.objectGroups = new ArrayList();
        this.loadTileSets = true;
        this.load(inputStream, s);
    }
    
    public String getTilesLocation() {
        return this.tilesLocation;
    }
    
    public int getLayerIndex(final String anObject) {
        for (int i = 0; i < this.layers.size(); ++i) {
            if (((Layer)this.layers.get(i)).name.equals(anObject)) {
                return i;
            }
        }
        return -1;
    }
    
    public Image getTileImage(final int n, final int n2, final int index) {
        final Layer layer = this.layers.get(index);
        final int index2 = layer.data[n][n2][0];
        if (index2 >= 0 && index2 < this.tileSets.size()) {
            final TileSet set = this.tileSets.get(index2);
            return set.tiles.getSprite(set.getTileX(layer.data[n][n2][1]), set.getTileY(layer.data[n][n2][1]));
        }
        return null;
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public int getTileHeight() {
        return this.tileHeight;
    }
    
    public int getTileWidth() {
        return this.tileWidth;
    }
    
    public int getTileId(final int n, final int n2, final int index) {
        return this.layers.get(index).getTileID(n, n2);
    }
    
    public void setTileId(final int n, final int n2, final int index, final int n3) {
        this.layers.get(index).setTileID(n, n2, n3);
    }
    
    public String getMapProperty(final String key, final String defaultValue) {
        if (this.props == null) {
            return defaultValue;
        }
        return this.props.getProperty(key, defaultValue);
    }
    
    public String getLayerProperty(final int index, final String key, final String defaultValue) {
        final Layer layer = this.layers.get(index);
        if (layer == null || layer.props == null) {
            return defaultValue;
        }
        return layer.props.getProperty(key, defaultValue);
    }
    
    public String getTileProperty(final int n, final String key, final String defaultValue) {
        if (n == 0) {
            return defaultValue;
        }
        final Properties properties = this.findTileSet(n).getProperties(n);
        if (properties == null) {
            return defaultValue;
        }
        return properties.getProperty(key, defaultValue);
    }
    
    public void render(final int n, final int n2) {
        this.render(n, n2, 0, 0, this.width, this.height, false);
    }
    
    public void render(final int n, final int n2, final int n3) {
        this.render(n, n2, 0, 0, this.getWidth(), this.getHeight(), n3, false);
    }
    
    public void render(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        this.render(n, n2, n3, n4, n5, n6, false);
    }
    
    public void render(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int index, final boolean b) {
        final Layer layer = this.layers.get(index);
        switch (this.orientation) {
            case 1: {
                for (int i = 0; i < n6; ++i) {
                    layer.render(n, n2, n3, n4, n5, i, b, this.tileWidth, this.tileHeight);
                }
                break;
            }
            case 2: {
                this.renderIsometricMap(n, n2, n3, n4, n5, n6, layer, b);
                break;
            }
        }
    }
    
    public void render(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final boolean b) {
        switch (this.orientation) {
            case 1: {
                for (int i = 0; i < n6; ++i) {
                    for (int j = 0; j < this.layers.size(); ++j) {
                        ((Layer)this.layers.get(j)).render(n, n2, n3, n4, n5, i, b, this.tileWidth, this.tileHeight);
                    }
                }
                break;
            }
            case 2: {
                this.renderIsometricMap(n, n2, n3, n4, n5, n6, null, b);
                break;
            }
        }
    }
    
    public void renderIsometricMap(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final Layer e, final boolean b) {
        ArrayList<Layer> layers = (ArrayList<Layer>)this.layers;
        if (e != null) {
            layers = new ArrayList<Layer>();
            layers.add(e);
        }
        final int n7 = n5 * n6;
        int n8 = 0;
        int i = 0;
        int n9 = n;
        int n10 = n2;
        int n11 = 0;
        int n12 = 0;
        while (i == 0) {
            int n13 = n11;
            int n14 = n12;
            int n15 = n9;
            int n16;
            if (n6 > n5) {
                n16 = ((n12 < n5 - 1) ? n12 : ((n5 - n13 < n6) ? (n5 - n13 - 1) : (n5 - 1)));
            }
            else {
                n16 = ((n12 < n6 - 1) ? n12 : ((n5 - n13 < n6) ? (n5 - n13 - 1) : (n6 - 1)));
            }
            for (int j = 0; j <= n16; ++j) {
                for (int k = 0; k < layers.size(); ++k) {
                    layers.get(k).render(n15, n10, n13, n14, 1, 0, b, this.tileWidth, this.tileHeight);
                }
                n15 += this.tileWidth;
                ++n8;
                ++n13;
                --n14;
            }
            if (n12 < n6 - 1) {
                ++n12;
                n9 -= this.tileWidth / 2;
                n10 += this.tileHeight / 2;
            }
            else {
                ++n11;
                n9 += this.tileWidth / 2;
                n10 += this.tileHeight / 2;
            }
            if (n8 >= n7) {
                i = 1;
            }
        }
    }
    
    public int getLayerCount() {
        return this.layers.size();
    }
    
    public int parseInt(final String s) {
        return Integer.parseInt(s);
    }
    
    public void load(final InputStream is, final String tilesLocation) throws SlickException {
        this.tilesLocation = tilesLocation;
        final DocumentBuilderFactory instance = DocumentBuilderFactory.newInstance();
        instance.setValidating(false);
        final DocumentBuilder documentBuilder = instance.newDocumentBuilder();
        documentBuilder.setEntityResolver(new EntityResolver(this) {
            public TiledMap this$0;
            
            @Override
            public InputSource resolveEntity(final String s, final String s2) throws SAXException, IOException {
                return new InputSource(new ByteArrayInputStream(new byte[0]));
            }
        });
        final Element documentElement = documentBuilder.parse(is).getDocumentElement();
        if (documentElement.getAttribute("orientation").equals("orthogonal")) {
            this.orientation = 1;
        }
        else {
            this.orientation = 2;
        }
        this.width = this.parseInt(documentElement.getAttribute("width"));
        this.height = this.parseInt(documentElement.getAttribute("height"));
        this.tileWidth = this.parseInt(documentElement.getAttribute("tilewidth"));
        this.tileHeight = this.parseInt(documentElement.getAttribute("tileheight"));
        final Element element = (Element)documentElement.getElementsByTagName("properties").item(0);
        if (element != null) {
            final NodeList elementsByTagName = element.getElementsByTagName("property");
            if (elementsByTagName != null) {
                this.props = new Properties();
                for (int i = 0; i < elementsByTagName.getLength(); ++i) {
                    final Element element2 = (Element)elementsByTagName.item(i);
                    this.props.setProperty(element2.getAttribute("name"), element2.getAttribute("value"));
                }
            }
        }
        if (this.loadTileSets) {
            TileSet set = null;
            final NodeList elementsByTagName2 = documentElement.getElementsByTagName("tileset");
            for (int j = 0; j < elementsByTagName2.getLength(); ++j) {
                final TileSet e = new TileSet(this, (Element)elementsByTagName2.item(j), !TiledMap.headless);
                e.index = j;
                if (set != null) {
                    set.setLimit(e.firstGID - 1);
                }
                set = e;
                this.tileSets.add(e);
            }
        }
        final NodeList elementsByTagName3 = documentElement.getElementsByTagName("layer");
        for (int k = 0; k < elementsByTagName3.getLength(); ++k) {
            final Layer e2 = new Layer(this, (Element)elementsByTagName3.item(k));
            e2.index = k;
            this.layers.add(e2);
        }
        final NodeList elementsByTagName4 = documentElement.getElementsByTagName("objectgroup");
        for (int l = 0; l < elementsByTagName4.getLength(); ++l) {
            final ObjectGroup e3 = new ObjectGroup((Element)elementsByTagName4.item(l));
            e3.index = l;
            this.objectGroups.add(e3);
        }
    }
    
    public int getTileSetCount() {
        return this.tileSets.size();
    }
    
    public TileSet getTileSet(final int index) {
        return this.tileSets.get(index);
    }
    
    public TileSet getTileSetByGID(final int n) {
        for (int i = 0; i < this.tileSets.size(); ++i) {
            final TileSet set = this.tileSets.get(i);
            if (set.contains(n)) {
                return set;
            }
        }
        return null;
    }
    
    public TileSet findTileSet(final int n) {
        for (int i = 0; i < this.tileSets.size(); ++i) {
            final TileSet set = this.tileSets.get(i);
            if (set.contains(n)) {
                return set;
            }
        }
        return null;
    }
    
    public void renderedLine(final int n, final int n2, final int n3) {
    }
    
    public int getObjectGroupCount() {
        return this.objectGroups.size();
    }
    
    public int getObjectCount(final int index) {
        if (index >= 0 && index < this.objectGroups.size()) {
            return this.objectGroups.get(index).objects.size();
        }
        return -1;
    }
    
    public String getObjectName(final int index, final int index2) {
        if (index >= 0 && index < this.objectGroups.size()) {
            final ObjectGroup objectGroup = this.objectGroups.get(index);
            if (index2 >= 0 && index2 < objectGroup.objects.size()) {
                return ((GroupObject)objectGroup.objects.get(index2)).name;
            }
        }
        return null;
    }
    
    public String getObjectType(final int index, final int index2) {
        if (index >= 0 && index < this.objectGroups.size()) {
            final ObjectGroup objectGroup = this.objectGroups.get(index);
            if (index2 >= 0 && index2 < objectGroup.objects.size()) {
                return ((GroupObject)objectGroup.objects.get(index2)).type;
            }
        }
        return null;
    }
    
    public int getObjectX(final int index, final int index2) {
        if (index >= 0 && index < this.objectGroups.size()) {
            final ObjectGroup objectGroup = this.objectGroups.get(index);
            if (index2 >= 0 && index2 < objectGroup.objects.size()) {
                return ((GroupObject)objectGroup.objects.get(index2)).x;
            }
        }
        return -1;
    }
    
    public int getObjectY(final int index, final int index2) {
        if (index >= 0 && index < this.objectGroups.size()) {
            final ObjectGroup objectGroup = this.objectGroups.get(index);
            if (index2 >= 0 && index2 < objectGroup.objects.size()) {
                return ((GroupObject)objectGroup.objects.get(index2)).y;
            }
        }
        return -1;
    }
    
    public int getObjectWidth(final int index, final int index2) {
        if (index >= 0 && index < this.objectGroups.size()) {
            final ObjectGroup objectGroup = this.objectGroups.get(index);
            if (index2 >= 0 && index2 < objectGroup.objects.size()) {
                return ((GroupObject)objectGroup.objects.get(index2)).width;
            }
        }
        return -1;
    }
    
    public int getObjectHeight(final int index, final int index2) {
        if (index >= 0 && index < this.objectGroups.size()) {
            final ObjectGroup objectGroup = this.objectGroups.get(index);
            if (index2 >= 0 && index2 < objectGroup.objects.size()) {
                return ((GroupObject)objectGroup.objects.get(index2)).height;
            }
        }
        return -1;
    }
    
    public String getObjectImage(final int index, final int index2) {
        if (index >= 0 && index < this.objectGroups.size()) {
            final ObjectGroup objectGroup = this.objectGroups.get(index);
            if (index2 >= 0 && index2 < objectGroup.objects.size()) {
                final GroupObject groupObject = objectGroup.objects.get(index2);
                if (groupObject == null) {
                    return null;
                }
                return GroupObject.access$000(groupObject);
            }
        }
        return null;
    }
    
    public String getObjectProperty(final int index, final int index2, final String key, final String defaultValue) {
        if (index >= 0 && index < this.objectGroups.size()) {
            final ObjectGroup objectGroup = this.objectGroups.get(index);
            if (index2 >= 0 && index2 < objectGroup.objects.size()) {
                final GroupObject groupObject = objectGroup.objects.get(index2);
                if (groupObject == null) {
                    return defaultValue;
                }
                if (groupObject.props == null) {
                    return defaultValue;
                }
                return groupObject.props.getProperty(key, defaultValue);
            }
        }
        return defaultValue;
    }
    
    static {
        TiledMap.ISOMETRIC = 2;
        TiledMap.ORTHOGONAL = 1;
    }
    
    protected class ObjectGroup
    {
        public int index;
        public String name;
        public ArrayList objects;
        public int width;
        public int height;
        public Properties props;
        public TiledMap this$0;
        
        public ObjectGroup(final TiledMap this$0, final Element element) throws SlickException {
            this.this$0 = this$0;
            this.name = element.getAttribute("name");
            this.width = Integer.parseInt(element.getAttribute("width"));
            this.height = Integer.parseInt(element.getAttribute("height"));
            this.objects = new ArrayList();
            final Element element2 = (Element)element.getElementsByTagName("properties").item(0);
            if (element2 != null) {
                final NodeList elementsByTagName = element2.getElementsByTagName("property");
                if (elementsByTagName != null) {
                    this.props = new Properties();
                    for (int i = 0; i < elementsByTagName.getLength(); ++i) {
                        final Element element3 = (Element)elementsByTagName.item(i);
                        this.props.setProperty(element3.getAttribute("name"), element3.getAttribute("value"));
                    }
                }
            }
            final NodeList elementsByTagName2 = element.getElementsByTagName("object");
            for (int j = 0; j < elementsByTagName2.getLength(); ++j) {
                final GroupObject e = this$0.new GroupObject((Element)elementsByTagName2.item(j));
                e.index = j;
                this.objects.add(e);
            }
        }
    }
    
    protected class GroupObject
    {
        public int index;
        public String name;
        public String type;
        public int x;
        public int y;
        public int width;
        public int height;
        public String image;
        public Properties props;
        public TiledMap this$0;
        
        public GroupObject(final TiledMap this$0, final Element element) throws SlickException {
            this.this$0 = this$0;
            this.name = element.getAttribute("name");
            this.type = element.getAttribute("type");
            this.x = Integer.parseInt(element.getAttribute("x"));
            this.y = Integer.parseInt(element.getAttribute("y"));
            this.width = Integer.parseInt(element.getAttribute("width"));
            this.height = Integer.parseInt(element.getAttribute("height"));
            final Element element2 = (Element)element.getElementsByTagName("image").item(0);
            if (element2 != null) {
                this.image = element2.getAttribute("source");
            }
            final Element element3 = (Element)element.getElementsByTagName("properties").item(0);
            if (element3 != null) {
                final NodeList elementsByTagName = element3.getElementsByTagName("property");
                if (elementsByTagName != null) {
                    this.props = new Properties();
                    for (int i = 0; i < elementsByTagName.getLength(); ++i) {
                        final Element element4 = (Element)elementsByTagName.item(i);
                        this.props.setProperty(element4.getAttribute("name"), element4.getAttribute("value"));
                    }
                }
            }
        }
        
        public static String access$000(final GroupObject groupObject) {
            return groupObject.image;
        }
    }
}
