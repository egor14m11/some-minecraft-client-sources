// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.Game;

public class Bootstrap
{
    public static void runAsApplication(final Game game, final int n, final int n2, final boolean b) {
        new AppGameContainer(game, n, n2, b).start();
    }
}
