// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util;

import java.awt.image.ImageObserver;
import java.awt.Image;
import java.awt.Graphics2D;
import java.nio.ByteBuffer;
import org.newdawn.slick.opengl.renderer.Renderer;
import org.newdawn.slick.opengl.TextureImpl;
import org.newdawn.slick.opengl.InternalTextureLoader;
import org.newdawn.slick.opengl.ImageIOImageData;
import java.io.IOException;
import org.newdawn.slick.opengl.Texture;
import java.awt.image.BufferedImage;

public class BufferedImageUtil
{
    public static Texture getTexture(final String s, final BufferedImage bufferedImage) throws IOException {
        return getTexture(s, bufferedImage, 3553, 6408, 9729, 9729);
    }
    
    public static Texture getTexture(final String s, final BufferedImage bufferedImage, final int n) throws IOException {
        return getTexture(s, bufferedImage, 3553, 6408, n, n);
    }
    
    public static Texture getTexture(final String s, final BufferedImage bufferedImage, final int n, final int n2, final int n3, final int n4) throws IOException {
        final ImageIOImageData imageIOImageData = new ImageIOImageData();
        final int textureID = InternalTextureLoader.createTextureID();
        final TextureImpl textureImpl = new TextureImpl(s, n, textureID);
        Renderer.get().glEnable(3553);
        Renderer.get().glBindTexture(n, textureID);
        textureImpl.setWidth(bufferedImage.getWidth());
        textureImpl.setHeight(bufferedImage.getHeight());
        int n5;
        if (bufferedImage.getColorModel().hasAlpha()) {
            n5 = 6408;
        }
        else {
            n5 = 6407;
        }
        final ByteBuffer imageToByteBuffer = imageIOImageData.imageToByteBuffer(bufferedImage, false, false, null);
        textureImpl.setTextureHeight(imageIOImageData.getTexHeight());
        textureImpl.setTextureWidth(imageIOImageData.getTexWidth());
        textureImpl.setAlpha(imageIOImageData.getDepth() == 32);
        if (n == 3553) {
            Renderer.get().glTexParameteri(n, 10241, n3);
            Renderer.get().glTexParameteri(n, 10240, n4);
            if (Renderer.get().canTextureMirrorClamp()) {
                Renderer.get().glTexParameteri(3553, 10242, 34627);
                Renderer.get().glTexParameteri(3553, 10243, 34627);
            }
            else {
                Renderer.get().glTexParameteri(3553, 10242, 10496);
                Renderer.get().glTexParameteri(3553, 10243, 10496);
            }
        }
        Renderer.get().glTexImage2D(n, 0, n2, textureImpl.getTextureWidth(), textureImpl.getTextureHeight(), 0, n5, 5121, imageToByteBuffer);
        return textureImpl;
    }
    
    public static void copyArea(final BufferedImage bufferedImage, final int x, final int y, final int w, final int h, final int n, final int n2) {
        ((Graphics2D)bufferedImage.getGraphics()).drawImage(bufferedImage.getSubimage(x, y, w, h), x + n, y + n2, null);
    }
}
