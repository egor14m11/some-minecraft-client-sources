// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util;

import java.io.InputStream;
import java.net.URL;

public class ClasspathLocation implements ResourceLocation
{
    @Override
    public URL getResource(final String s) {
        return ResourceLoader.class.getClassLoader().getResource(s.replace('\\', '/'));
    }
    
    @Override
    public InputStream getResourceAsStream(final String s) {
        return ResourceLoader.class.getClassLoader().getResourceAsStream(s.replace('\\', '/'));
    }
}
