// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util;

import java.util.Date;
import java.io.PrintStream;

public class DefaultLogSystem implements LogSystem
{
    public static PrintStream out;
    
    @Override
    public void error(final String s, final Throwable t) {
        this.error(s);
        this.error(t);
    }
    
    @Override
    public void error(final Throwable t) {
        DefaultLogSystem.out.println(new Date() + " ERROR:" + t.getMessage());
        t.printStackTrace(DefaultLogSystem.out);
    }
    
    @Override
    public void error(final String str) {
        DefaultLogSystem.out.println(new Date() + " ERROR:" + str);
    }
    
    @Override
    public void warn(final String str) {
        DefaultLogSystem.out.println(new Date() + " WARN:" + str);
    }
    
    @Override
    public void info(final String str) {
        DefaultLogSystem.out.println(new Date() + " INFO:" + str);
    }
    
    @Override
    public void debug(final String str) {
        DefaultLogSystem.out.println(new Date() + " DEBUG:" + str);
    }
    
    @Override
    public void warn(final String s, final Throwable t) {
        this.warn(s);
        t.printStackTrace(DefaultLogSystem.out);
    }
    
    static {
        DefaultLogSystem.out = System.out;
    }
}
