// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.io.File;

public class FileSystemLocation implements ResourceLocation
{
    public File root;
    
    public FileSystemLocation(final File root) {
        this.root = root;
    }
    
    @Override
    public URL getResource(final String s) {
        File file = new File(this.root, s);
        if (!file.exists()) {
            file = new File(s);
        }
        if (!file.exists()) {
            return null;
        }
        return file.toURI().toURL();
    }
    
    @Override
    public InputStream getResourceAsStream(final String s) {
        File file = new File(this.root, s);
        if (!file.exists()) {
            file = new File(s);
        }
        return new FileInputStream(file);
    }
}
