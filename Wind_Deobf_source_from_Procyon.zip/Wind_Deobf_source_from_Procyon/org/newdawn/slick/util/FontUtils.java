// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util;

import org.newdawn.slick.Color;
import org.newdawn.slick.Font;

public class FontUtils
{
    public static void drawLeft(final Font font, final String s, final int n, final int n2) {
        drawString(font, s, 1, n, n2, 0, Color.white);
    }
    
    public static void drawCenter(final Font font, final String s, final int n, final int n2, final int n3) {
        drawString(font, s, 2, n, n2, n3, Color.white);
    }
    
    public static void drawCenter(final Font font, final String s, final int n, final int n2, final int n3, final Color color) {
        drawString(font, s, 2, n, n2, n3, color);
    }
    
    public static void drawRight(final Font font, final String s, final int n, final int n2, final int n3) {
        drawString(font, s, 3, n, n2, n3, Color.white);
    }
    
    public static void drawRight(final Font font, final String s, final int n, final int n2, final int n3, final Color color) {
        drawString(font, s, 3, n, n2, n3, color);
    }
    
    public static int drawString(final Font font, final String s, final int n, final int n2, final int n3, final int n4, final Color color) {
        final int n5 = 0;
        if (n == 1) {
            font.drawString((float)n2, (float)n3, s, color);
        }
        else if (n == 2) {
            font.drawString((float)(n2 + n4 / 2 - font.getWidth(s) / 2), (float)n3, s, color);
        }
        else if (n == 3) {
            font.drawString((float)(n2 + n4 - font.getWidth(s)), (float)n3, s, color);
        }
        else if (n == 4) {
            final int n6 = n4 - font.getWidth(s);
            if (n6 <= 0) {
                font.drawString((float)n2, (float)n3, s, color);
            }
            return drawJustifiedSpaceSeparatedSubstrings(font, s, n2, n3, calculateWidthOfJustifiedSpaceInPixels(font, s, n6));
        }
        return n5;
    }
    
    public static int calculateWidthOfJustifiedSpaceInPixels(final Font font, final String s, final int n) {
        int n2 = 0;
        int i = 0;
        while (i < s.length()) {
            if (s.charAt(i++) == ' ') {
                ++n2;
            }
        }
        if (n2 > 0) {
            n2 = (n + font.getWidth(" ") * n2) / n2;
        }
        return n2;
    }
    
    public static int drawJustifiedSpaceSeparatedSubstrings(final Font font, final String s, final int n, final int n2, final int n3) {
        int i = 0;
        int n4 = n;
        while (i < s.length()) {
            int endIndex = s.indexOf(32, i);
            if (endIndex == -1) {
                endIndex = s.length();
            }
            final String substring = s.substring(i, endIndex);
            font.drawString((float)n4, (float)n2, substring);
            n4 += font.getWidth(substring) + n3;
            i = endIndex + 1;
        }
        return n4;
    }
    
    public class Alignment
    {
        public static int LEFT;
        public static int CENTER;
        public static int RIGHT;
        public static int JUSTIFY;
        public FontUtils this$0;
        
        public Alignment(final FontUtils this$0) {
            this.this$0 = this$0;
        }
        
        static {
            Alignment.JUSTIFY = 4;
            Alignment.RIGHT = 3;
            Alignment.CENTER = 2;
            Alignment.LEFT = 1;
        }
    }
}
