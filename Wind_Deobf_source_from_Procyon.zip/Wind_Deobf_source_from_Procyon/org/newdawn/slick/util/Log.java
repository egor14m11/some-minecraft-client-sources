// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util;

import java.security.AccessController;
import java.security.PrivilegedAction;

public class Log
{
    public static boolean verbose;
    public static boolean forcedVerbose;
    public static String forceVerboseProperty;
    public static String forceVerbosePropertyOnValue;
    public static LogSystem logSystem;
    
    public static void setLogSystem(final LogSystem logSystem) {
        Log.logSystem = logSystem;
    }
    
    public static void setVerbose(final boolean verbose) {
        if (Log.forcedVerbose) {
            return;
        }
        Log.verbose = verbose;
    }
    
    public static void checkVerboseLogSetting() {
        AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction() {
            @Override
            public Object run() {
                final String property = System.getProperty("org.newdawn.slick.forceVerboseLog");
                if (property != null && property.equalsIgnoreCase("true")) {
                    Log.setForcedVerboseOn();
                }
                return null;
            }
        });
    }
    
    public static void setForcedVerboseOn() {
        Log.forcedVerbose = true;
        Log.verbose = true;
    }
    
    public static void error(final String s, final Throwable t) {
        Log.logSystem.error(s, t);
    }
    
    public static void error(final Throwable t) {
        Log.logSystem.error(t);
    }
    
    public static void error(final String s) {
        Log.logSystem.error(s);
    }
    
    public static void warn(final String s) {
        Log.logSystem.warn(s);
    }
    
    public static void warn(final String s, final Throwable t) {
        Log.logSystem.warn(s, t);
    }
    
    public static void info(final String s) {
        if (Log.verbose || Log.forcedVerbose) {
            Log.logSystem.info(s);
        }
    }
    
    public static void debug(final String s) {
        if (Log.verbose || Log.forcedVerbose) {
            Log.logSystem.debug(s);
        }
    }
    
    static {
        Log.forceVerbosePropertyOnValue = "true";
        Log.forceVerboseProperty = "org.newdawn.slick.forceVerboseLog";
        Log.verbose = true;
        Log.forcedVerbose = false;
        Log.logSystem = new DefaultLogSystem();
    }
}
