// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util;

public class OperationNotSupportedException extends RuntimeException
{
    public OperationNotSupportedException(final String message) {
        super(message);
    }
}
