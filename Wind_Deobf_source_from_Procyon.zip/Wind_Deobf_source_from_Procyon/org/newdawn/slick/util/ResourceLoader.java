// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util;

import java.io.File;
import java.net.URL;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.ArrayList;

public class ResourceLoader
{
    public static ArrayList locations;
    
    public static void addResourceLocation(final ResourceLocation e) {
        ResourceLoader.locations.add(e);
    }
    
    public static void removeResourceLocation(final ResourceLocation o) {
        ResourceLoader.locations.remove(o);
    }
    
    public static void removeAllResourceLocations() {
        ResourceLoader.locations.clear();
    }
    
    public static InputStream getResourceAsStream(final String str) {
        InputStream resourceAsStream = null;
        for (int i = 0; i < ResourceLoader.locations.size(); ++i) {
            resourceAsStream = ((ResourceLocation)ResourceLoader.locations.get(i)).getResourceAsStream(str);
            if (resourceAsStream != null) {
                break;
            }
        }
        if (resourceAsStream == null) {
            throw new RuntimeException("Resource not found: " + str);
        }
        return new BufferedInputStream(resourceAsStream);
    }
    
    public static boolean resourceExists(final String s) {
        for (int i = 0; i < ResourceLoader.locations.size(); ++i) {
            if (((ResourceLocation)ResourceLoader.locations.get(i)).getResource(s) != null) {
                return true;
            }
        }
        return false;
    }
    
    public static URL getResource(final String str) {
        URL resource = null;
        for (int i = 0; i < ResourceLoader.locations.size(); ++i) {
            resource = ((ResourceLocation)ResourceLoader.locations.get(i)).getResource(str);
            if (resource != null) {
                break;
            }
        }
        if (resource == null) {
            throw new RuntimeException("Resource not found: " + str);
        }
        return resource;
    }
    
    static {
        (ResourceLoader.locations = new ArrayList()).add(new ClasspathLocation());
        ResourceLoader.locations.add(new FileSystemLocation(new File(".")));
    }
}
