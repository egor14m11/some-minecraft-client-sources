// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding;

public interface AStarHeuristic
{
    float getCost(final TileBasedMap p0, final Mover p1, final int p2, final int p3, final int p4, final int p5);
}
