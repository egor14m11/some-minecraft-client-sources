// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding;

import java.util.LinkedList;
import java.util.List;
import org.newdawn.slick.util.pathfinding.heuristics.ClosestHeuristic;
import java.util.ArrayList;

public class AStarPathFinder implements PathFinder, PathFindingContext
{
    public ArrayList closed;
    public PriorityList open;
    public TileBasedMap map;
    public int maxSearchDistance;
    public Node[][] nodes;
    public boolean allowDiagMovement;
    public AStarHeuristic heuristic;
    public Node current;
    public Mover mover;
    public int sourceX;
    public int sourceY;
    public int distance;
    
    public AStarPathFinder(final TileBasedMap tileBasedMap, final int n, final boolean b) {
        this(tileBasedMap, n, b, new ClosestHeuristic());
    }
    
    public AStarPathFinder(final TileBasedMap map, final int maxSearchDistance, final boolean allowDiagMovement, final AStarHeuristic heuristic) {
        this.closed = new ArrayList();
        this.open = new PriorityList(null);
        this.heuristic = heuristic;
        this.map = map;
        this.maxSearchDistance = maxSearchDistance;
        this.allowDiagMovement = allowDiagMovement;
        this.nodes = new Node[map.getWidthInTiles()][map.getHeightInTiles()];
        for (int i = 0; i < map.getWidthInTiles(); ++i) {
            for (int j = 0; j < map.getHeightInTiles(); ++j) {
                this.nodes[i][j] = new Node(i, j);
            }
        }
    }
    
    @Override
    public Path findPath(final Mover mover, final int n, final int n2, final int sourceX, final int sourceY) {
        this.current = null;
        this.mover = mover;
        this.sourceX = sourceX;
        this.sourceY = sourceY;
        this.distance = 0;
        if (this.map.blocked(this, sourceX, sourceY)) {
            return null;
        }
        for (int i = 0; i < this.map.getWidthInTiles(); ++i) {
            for (int j = 0; j < this.map.getHeightInTiles(); ++j) {
                this.nodes[i][j].reset();
            }
        }
        Node.access$102(this.nodes[n][n2], 0.0f);
        Node.access$202(this.nodes[n][n2], 0);
        this.closed.clear();
        this.open.clear();
        this.addToOpen(this.nodes[n][n2]);
        Node.access$302(this.nodes[sourceX][sourceY], null);
        int max = 0;
        while (max < this.maxSearchDistance && this.open.size() != 0) {
            int access$400 = n;
            int access$401 = n2;
            if (this.current != null) {
                access$400 = Node.access$400(this.current);
                access$401 = Node.access$500(this.current);
            }
            this.current = this.getFirstInOpen();
            this.distance = Node.access$200(this.current);
            if (this.current == this.nodes[sourceX][sourceY] && this.isValidLocation(mover, access$400, access$401, sourceX, sourceY)) {
                break;
            }
            this.removeFromOpen(this.current);
            this.addToClosed(this.current);
            for (int k = -1; k < 2; ++k) {
                for (int l = -1; l < 2; ++l) {
                    if (k != 0 || l != 0) {
                        if (this.allowDiagMovement || k == 0 || l == 0) {
                            final int n3 = k + Node.access$400(this.current);
                            final int n4 = l + Node.access$500(this.current);
                            if (this.isValidLocation(mover, Node.access$400(this.current), Node.access$500(this.current), n3, n4)) {
                                final float n5 = Node.access$100(this.current) + this.getMovementCost(mover, Node.access$400(this.current), Node.access$500(this.current), n3, n4);
                                final Node node = this.nodes[n3][n4];
                                this.map.pathFinderVisited(n3, n4);
                                if (n5 < Node.access$100(node)) {
                                    if (this.inOpenList(node)) {
                                        this.removeFromOpen(node);
                                    }
                                    if (this.inClosedList(node)) {
                                        this.removeFromClosed(node);
                                    }
                                }
                                if (!this.inOpenList(node) && !this.inClosedList(node)) {
                                    Node.access$102(node, n5);
                                    Node.access$602(node, this.getHeuristicCost(mover, n3, n4, sourceX, sourceY));
                                    max = Math.max(max, node.setParent(this.current));
                                    this.addToOpen(node);
                                }
                            }
                        }
                    }
                }
            }
        }
        if (Node.access$300(this.nodes[sourceX][sourceY]) == null) {
            return null;
        }
        final Path path = new Path();
        for (Node access$402 = this.nodes[sourceX][sourceY]; access$402 != this.nodes[n][n2]; access$402 = Node.access$300(access$402)) {
            path.prependStep(Node.access$400(access$402), Node.access$500(access$402));
        }
        path.prependStep(n, n2);
        return path;
    }
    
    public int getCurrentX() {
        if (this.current == null) {
            return -1;
        }
        return Node.access$400(this.current);
    }
    
    public int getCurrentY() {
        if (this.current == null) {
            return -1;
        }
        return Node.access$500(this.current);
    }
    
    public Node getFirstInOpen() {
        return (Node)this.open.first();
    }
    
    public void addToOpen(final Node node) {
        node.setOpen(true);
        this.open.add(node);
    }
    
    public boolean inOpenList(final Node node) {
        return node.isOpen();
    }
    
    public void removeFromOpen(final Node node) {
        node.setOpen(false);
        this.open.remove(node);
    }
    
    public void addToClosed(final Node e) {
        e.setClosed(true);
        this.closed.add(e);
    }
    
    public boolean inClosedList(final Node node) {
        return node.isClosed();
    }
    
    public void removeFromClosed(final Node o) {
        o.setClosed(false);
        this.closed.remove(o);
    }
    
    public boolean isValidLocation(final Mover mover, final int sourceX, final int sourceY, final int n, final int n2) {
        boolean blocked = n < 0 || n2 < 0 || n >= this.map.getWidthInTiles() || n2 >= this.map.getHeightInTiles();
        if (!blocked && (sourceX != n || sourceY != n2)) {
            this.mover = mover;
            this.sourceX = sourceX;
            this.sourceY = sourceY;
            blocked = this.map.blocked(this, n, n2);
        }
        return !blocked;
    }
    
    public float getMovementCost(final Mover mover, final int sourceX, final int sourceY, final int n, final int n2) {
        this.mover = mover;
        this.sourceX = sourceX;
        this.sourceY = sourceY;
        return this.map.getCost(this, n, n2);
    }
    
    public float getHeuristicCost(final Mover mover, final int n, final int n2, final int n3, final int n4) {
        return this.heuristic.getCost(this.map, mover, n, n2, n3, n4);
    }
    
    @Override
    public Mover getMover() {
        return this.mover;
    }
    
    @Override
    public int getSearchDistance() {
        return this.distance;
    }
    
    @Override
    public int getSourceX() {
        return this.sourceX;
    }
    
    @Override
    public int getSourceY() {
        return this.sourceY;
    }
    
    private class PriorityList
    {
        public List list;
        public AStarPathFinder this$0;
        
        public PriorityList(final AStarPathFinder this$0) {
            this.this$0 = this$0;
            this.list = new LinkedList();
        }
        
        public Object first() {
            return this.list.get(0);
        }
        
        public void clear() {
            this.list.clear();
        }
        
        public void add(final Object o) {
            for (int i = 0; i < this.list.size(); ++i) {
                if (((Comparable<Object>)this.list.get(i)).compareTo(o) > 0) {
                    this.list.add(i, o);
                    break;
                }
            }
            if (!this.list.contains(o)) {
                this.list.add(o);
            }
        }
        
        public void remove(final Object o) {
            this.list.remove(o);
        }
        
        public int size() {
            return this.list.size();
        }
        
        public boolean contains(final Object o) {
            return this.list.contains(o);
        }
        
        @Override
        public String toString() {
            String string = "{";
            for (int i = 0; i < this.size(); ++i) {
                string = string + this.list.get(i).toString() + ",";
            }
            return string + "}";
        }
        
        public PriorityList(final AStarPathFinder aStarPathFinder, final AStarPathFinder$1 object) {
            this(aStarPathFinder);
        }
    }
    
    private class Node implements Comparable
    {
        public int x;
        public int y;
        public float cost;
        public Node parent;
        public float heuristic;
        public int depth;
        public boolean open;
        public boolean closed;
        public AStarPathFinder this$0;
        
        public Node(final AStarPathFinder this$0, final int x, final int y) {
            this.this$0 = this$0;
            this.x = x;
            this.y = y;
        }
        
        public int setParent(final Node parent) {
            this.depth = parent.depth + 1;
            this.parent = parent;
            return this.depth;
        }
        
        @Override
        public int compareTo(final Object o) {
            final Node node = (Node)o;
            final float n = this.heuristic + this.cost;
            final float n2 = node.heuristic + node.cost;
            if (n < n2) {
                return -1;
            }
            if (n > n2) {
                return 1;
            }
            return 0;
        }
        
        public void setOpen(final boolean open) {
            this.open = open;
        }
        
        public boolean isOpen() {
            return this.open;
        }
        
        public void setClosed(final boolean closed) {
            this.closed = closed;
        }
        
        public boolean isClosed() {
            return this.closed;
        }
        
        public void reset() {
            this.closed = false;
            this.open = false;
            this.cost = 0.0f;
            this.depth = 0;
        }
        
        @Override
        public String toString() {
            return "[Node " + this.x + "," + this.y + "]";
        }
        
        public static float access$102(final Node node, final float cost) {
            return node.cost = cost;
        }
        
        public static int access$202(final Node node, final int depth) {
            return node.depth = depth;
        }
        
        public static Node access$302(final Node node, final Node parent) {
            return node.parent = parent;
        }
        
        public static int access$400(final Node node) {
            return node.x;
        }
        
        public static int access$500(final Node node) {
            return node.y;
        }
        
        public static int access$200(final Node node) {
            return node.depth;
        }
        
        public static float access$100(final Node node) {
            return node.cost;
        }
        
        public static float access$602(final Node node, final float heuristic) {
            return node.heuristic = heuristic;
        }
        
        public static Node access$300(final Node node) {
            return node.parent;
        }
    }
}
