// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding;

import java.util.ArrayList;
import java.io.Serializable;

public class Path implements Serializable
{
    public static long serialVersionUID;
    public ArrayList steps;
    
    public Path() {
        this.steps = new ArrayList();
    }
    
    public int getLength() {
        return this.steps.size();
    }
    
    public Step getStep(final int index) {
        return this.steps.get(index);
    }
    
    public int getX(final int n) {
        return Step.access$000(this.getStep(n));
    }
    
    public int getY(final int n) {
        return Step.access$100(this.getStep(n));
    }
    
    public void appendStep(final int n, final int n2) {
        this.steps.add(new Step(n, n2));
    }
    
    public void prependStep(final int n, final int n2) {
        this.steps.add(0, new Step(n, n2));
    }
    
    public boolean contains(final int n, final int n2) {
        return this.steps.contains(new Step(n, n2));
    }
    
    static {
        Path.serialVersionUID = ((long)951550729 ^ 0x38B78308L);
    }
    
    public class Step implements Serializable
    {
        public int x;
        public int y;
        public Path this$0;
        
        public Step(final Path this$0, final int x, final int y) {
            this.this$0 = this$0;
            this.x = x;
            this.y = y;
        }
        
        public int getX() {
            return this.x;
        }
        
        public int getY() {
            return this.y;
        }
        
        @Override
        public int hashCode() {
            return this.x * this.y;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (o instanceof Step) {
                final Step step = (Step)o;
                return step.x == this.x && step.y == this.y;
            }
            return false;
        }
        
        public static int access$000(final Step step) {
            return step.x;
        }
        
        public static int access$100(final Step step) {
            return step.y;
        }
    }
}
