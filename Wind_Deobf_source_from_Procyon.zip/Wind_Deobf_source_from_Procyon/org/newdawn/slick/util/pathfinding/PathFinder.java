// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding;

public interface PathFinder
{
    Path findPath(final Mover p0, final int p1, final int p2, final int p3, final int p4);
}
