// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding.heuristics;

import org.newdawn.slick.util.pathfinding.Mover;
import org.newdawn.slick.util.pathfinding.TileBasedMap;
import org.newdawn.slick.util.pathfinding.AStarHeuristic;

public class ClosestHeuristic implements AStarHeuristic
{
    @Override
    public float getCost(final TileBasedMap tileBasedMap, final Mover mover, final int n, final int n2, final int n3, final int n4) {
        final float n5 = (float)(n3 - n);
        final float n6 = (float)(n4 - n2);
        return (float)Math.sqrt(n5 * n5 + n6 * n6);
    }
}
