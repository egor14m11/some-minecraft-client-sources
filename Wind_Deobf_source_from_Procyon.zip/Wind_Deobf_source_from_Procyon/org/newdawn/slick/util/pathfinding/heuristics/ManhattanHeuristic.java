// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding.heuristics;

import org.newdawn.slick.util.pathfinding.Mover;
import org.newdawn.slick.util.pathfinding.TileBasedMap;
import org.newdawn.slick.util.pathfinding.AStarHeuristic;

public class ManhattanHeuristic implements AStarHeuristic
{
    public int minimumCost;
    
    public ManhattanHeuristic(final int minimumCost) {
        this.minimumCost = minimumCost;
    }
    
    @Override
    public float getCost(final TileBasedMap tileBasedMap, final Mover mover, final int n, final int n2, final int n3, final int n4) {
        return (float)(this.minimumCost * (Math.abs(n - n3) + Math.abs(n2 - n4)));
    }
}
