// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding.navmesh;

public class Link
{
    public float px;
    public float py;
    public Space target;
    
    public Link(final float px, final float py, final Space target) {
        this.px = px;
        this.py = py;
        this.target = target;
    }
    
    public float distance2(final float n, final float n2) {
        final float n3 = n - this.px;
        final float n4 = n2 - this.py;
        return n3 * n3 + n4 * n4;
    }
    
    public float getX() {
        return this.px;
    }
    
    public float getY() {
        return this.py;
    }
    
    public Space getTarget() {
        return this.target;
    }
}
