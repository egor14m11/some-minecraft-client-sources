// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding.navmesh;

import java.util.Collection;
import java.util.ArrayList;

public class NavMesh
{
    public ArrayList spaces;
    
    public NavMesh() {
        this.spaces = new ArrayList();
    }
    
    public NavMesh(final ArrayList c) {
        (this.spaces = new ArrayList()).addAll(c);
    }
    
    public int getSpaceCount() {
        return this.spaces.size();
    }
    
    public Space getSpace(final int index) {
        return this.spaces.get(index);
    }
    
    public void addSpace(final Space e) {
        this.spaces.add(e);
    }
    
    public Space findSpace(final float n, final float n2) {
        for (int i = 0; i < this.spaces.size(); ++i) {
            final Space space = this.getSpace(i);
            if (space.contains(n, n2)) {
                return space;
            }
        }
        return null;
    }
    
    public NavPath findPath(final float n, final float n2, final float n3, final float n4, final boolean b) {
        final Space space = this.findSpace(n, n2);
        final Space space2 = this.findSpace(n3, n4);
        if (space == null || space2 == null) {
            return null;
        }
        for (int i = 0; i < this.spaces.size(); ++i) {
            ((Space)this.spaces.get(i)).clearCost();
        }
        space2.fill(space, n3, n4, 0.0f);
        if (space2.getCost() == Float.MAX_VALUE) {
            return null;
        }
        if (space.getCost() == Float.MAX_VALUE) {
            return null;
        }
        final NavPath navPath = new NavPath();
        navPath.push(new Link(n, n2, null));
        if (space.pickLowestCost(space2, navPath)) {
            navPath.push(new Link(n3, n4, null));
            if (b) {
                this.optimize(navPath);
            }
            return navPath;
        }
        return null;
    }
    
    public boolean isClear(final float n, final float n2, final float n3, final float n4, final float n5) {
        final float n6 = n3 - n;
        final float n7 = n4 - n2;
        final float n8 = (float)Math.sqrt(n6 * n6 + n7 * n7);
        final float n9 = n6 * n5 / n8;
        final float n10 = n7 * n5 / n8;
        for (int n11 = (int)(n8 / n5), i = 0; i < n11; ++i) {
            if (this.findSpace(n + n9 * i, n2 + n10 * i) == null) {
                return false;
            }
        }
        return true;
    }
    
    public void optimize(final NavPath navPath) {
        int i = 0;
        while (i < navPath.length() - 2) {
            if (this.isClear(navPath.getX(i), navPath.getY(i), navPath.getX(i + 2), navPath.getY(i + 2), 0.0f)) {
                navPath.remove(i + 1);
            }
            else {
                ++i;
            }
        }
    }
}
