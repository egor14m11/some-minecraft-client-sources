// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding.navmesh;

import org.newdawn.slick.util.pathfinding.Mover;
import java.util.ArrayList;
import org.newdawn.slick.util.pathfinding.TileBasedMap;
import org.newdawn.slick.util.pathfinding.PathFindingContext;

public class NavMeshBuilder implements PathFindingContext
{
    public int sx;
    public int sy;
    public float smallestSpace;
    public boolean tileBased;
    
    public NavMeshBuilder() {
        this.smallestSpace = 0.0f;
    }
    
    public NavMesh build(final TileBasedMap tileBasedMap) {
        return this.build(tileBasedMap, true);
    }
    
    public NavMesh build(final TileBasedMap tileBasedMap, final boolean tileBased) {
        this.tileBased = tileBased;
        final ArrayList<Space> list = new ArrayList<Space>();
        if (tileBased) {
            for (int i = 0; i < tileBasedMap.getWidthInTiles(); ++i) {
                for (int j = 0; j < tileBasedMap.getHeightInTiles(); ++j) {
                    if (!tileBasedMap.blocked(this, i, j)) {
                        list.add(new Space((float)i, (float)j, 1.0f, 1.0f));
                    }
                }
            }
        }
        else {
            this.subsection(tileBasedMap, new Space(0.0f, 0.0f, (float)tileBasedMap.getWidthInTiles(), (float)tileBasedMap.getHeightInTiles()), list);
        }
        while (this.mergeSpaces(list)) {}
        this.linkSpaces(list);
        return new NavMesh(list);
    }
    
    public boolean mergeSpaces(final ArrayList list) {
        for (int i = 0; i < list.size(); ++i) {
            final Space o = list.get(i);
            for (int j = i + 1; j < list.size(); ++j) {
                final Space o2 = list.get(j);
                if (o.canMerge(o2)) {
                    list.remove(o);
                    list.remove(o2);
                    list.add(o.merge(o2));
                    return true;
                }
            }
        }
        return false;
    }
    
    public void linkSpaces(final ArrayList list) {
        for (int i = 0; i < list.size(); ++i) {
            final Space space = list.get(i);
            for (int j = i + 1; j < list.size(); ++j) {
                final Space space2 = list.get(j);
                if (space.hasJoinedEdge(space2)) {
                    space.link(space2);
                    space2.link(space);
                }
            }
        }
    }
    
    public boolean clear(final TileBasedMap tileBasedMap, final Space space) {
        if (this.tileBased) {
            return true;
        }
        float width = 0.0f;
        int n = 0;
        while (width < space.getWidth()) {
            float height = 0.0f;
            int n2 = 0;
            while (height < space.getHeight()) {
                this.sx = (int)(space.getX() + width);
                this.sy = (int)(space.getY() + height);
                if (tileBasedMap.blocked(this, this.sx, this.sy)) {
                    return false;
                }
                height += 0.0f;
                if (height <= space.getHeight() || n2 != 0) {
                    continue;
                }
                height = space.getHeight();
                n2 = 1;
            }
            width += 0.0f;
            if (width > space.getWidth() && n == 0) {
                width = space.getWidth();
                n = 1;
            }
        }
        return true;
    }
    
    public void subsection(final TileBasedMap tileBasedMap, final Space e, final ArrayList list) {
        if (!this.clear(tileBasedMap, e)) {
            final float n = e.getWidth() / 2.0f;
            final float n2 = e.getHeight() / 2.0f;
            if (n < this.smallestSpace && n2 < this.smallestSpace) {
                return;
            }
            this.subsection(tileBasedMap, new Space(e.getX(), e.getY(), n, n2), list);
            this.subsection(tileBasedMap, new Space(e.getX(), e.getY() + n2, n, n2), list);
            this.subsection(tileBasedMap, new Space(e.getX() + n, e.getY(), n, n2), list);
            this.subsection(tileBasedMap, new Space(e.getX() + n, e.getY() + n2, n, n2), list);
        }
        else {
            list.add(e);
        }
    }
    
    @Override
    public Mover getMover() {
        return null;
    }
    
    @Override
    public int getSearchDistance() {
        return 0;
    }
    
    @Override
    public int getSourceX() {
        return this.sx;
    }
    
    @Override
    public int getSourceY() {
        return this.sy;
    }
}
