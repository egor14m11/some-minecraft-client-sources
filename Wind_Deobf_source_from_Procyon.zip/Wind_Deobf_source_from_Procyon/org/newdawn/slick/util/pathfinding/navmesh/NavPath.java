// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding.navmesh;

import java.util.ArrayList;

public class NavPath
{
    public ArrayList links;
    
    public NavPath() {
        this.links = new ArrayList();
    }
    
    public void push(final Link e) {
        this.links.add(e);
    }
    
    public int length() {
        return this.links.size();
    }
    
    public float getX(final int index) {
        return this.links.get(index).getX();
    }
    
    public float getY(final int index) {
        return this.links.get(index).getY();
    }
    
    @Override
    public String toString() {
        return "[Path length=" + this.length() + "]";
    }
    
    public void remove(final int index) {
        this.links.remove(index);
    }
}
