// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.pathfinding.navmesh;

import java.util.ArrayList;
import java.util.HashMap;

public class Space
{
    public float x;
    public float y;
    public float width;
    public float height;
    public HashMap links;
    public ArrayList linksList;
    public float cost;
    
    public Space(final float x, final float y, final float width, final float height) {
        this.links = new HashMap();
        this.linksList = new ArrayList();
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    
    public float getWidth() {
        return this.width;
    }
    
    public float getHeight() {
        return this.height;
    }
    
    public float getX() {
        return this.x;
    }
    
    public float getY() {
        return this.y;
    }
    
    public void link(final Space space) {
        if (this.inTolerance(this.x, space.x + space.width) || this.inTolerance(this.x + this.width, space.x)) {
            float x = this.x;
            if (this.x + this.width == space.x) {
                x = this.x + this.width;
            }
            final float max = Math.max(this.y, space.y);
            final Link link = new Link(x, max + (Math.min(this.y + this.height, space.y + space.height) - max) / 2.0f, space);
            this.links.put(space, link);
            this.linksList.add(link);
        }
        if (this.inTolerance(this.y, space.y + space.height) || this.inTolerance(this.y + this.height, space.y)) {
            float y = this.y;
            if (this.y + this.height == space.y) {
                y = this.y + this.height;
            }
            final float max2 = Math.max(this.x, space.x);
            final Link link2 = new Link(max2 + (Math.min(this.x + this.width, space.x + space.width) - max2) / 2.0f, y, space);
            this.links.put(space, link2);
            this.linksList.add(link2);
        }
    }
    
    public boolean inTolerance(final float n, final float n2) {
        return n == n2;
    }
    
    public boolean hasJoinedEdge(final Space space) {
        if (this.inTolerance(this.x, space.x + space.width) || this.inTolerance(this.x + this.width, space.x)) {
            if (this.y >= space.y && this.y <= space.y + space.height) {
                return true;
            }
            if (this.y + this.height >= space.y && this.y + this.height <= space.y + space.height) {
                return true;
            }
            if (space.y >= this.y && space.y <= this.y + this.height) {
                return true;
            }
            if (space.y + space.height >= this.y && space.y + space.height <= this.y + this.height) {
                return true;
            }
        }
        if (this.inTolerance(this.y, space.y + space.height) || this.inTolerance(this.y + this.height, space.y)) {
            if (this.x >= space.x && this.x <= space.x + space.width) {
                return true;
            }
            if (this.x + this.width >= space.x && this.x + this.width <= space.x + space.width) {
                return true;
            }
            if (space.x >= this.x && space.x <= this.x + this.width) {
                return true;
            }
            if (space.x + space.width >= this.x && space.x + space.width <= this.x + this.width) {
                return true;
            }
        }
        return false;
    }
    
    public Space merge(final Space space) {
        final float min = Math.min(this.x, space.x);
        final float min2 = Math.min(this.y, space.y);
        float width = this.width + space.width;
        float height = this.height + space.height;
        if (this.x == space.x) {
            width = this.width;
        }
        else {
            height = this.height;
        }
        return new Space(min, min2, width, height);
    }
    
    public boolean canMerge(final Space space) {
        return this.hasJoinedEdge(space) && ((this.x == space.x && this.width == space.width) || (this.y == space.y && this.height == space.height));
    }
    
    public int getLinkCount() {
        return this.linksList.size();
    }
    
    public Link getLink(final int index) {
        return this.linksList.get(index);
    }
    
    public boolean contains(final float n, final float n2) {
        return n >= this.x && n < this.x + this.width && n2 >= this.y && n2 < this.y + this.height;
    }
    
    public void fill(final Space space, final float n, final float n2, final float cost) {
        if (cost >= this.cost) {
            return;
        }
        this.cost = cost;
        if (space == this) {
            return;
        }
        for (int i = 0; i < this.getLinkCount(); ++i) {
            final Link link = this.getLink(i);
            link.getTarget().fill(space, link.getX(), link.getY(), cost + link.distance2(n, n2));
        }
    }
    
    public void clearCost() {
        this.cost = Float.MAX_VALUE;
    }
    
    public float getCost() {
        return this.cost;
    }
    
    public boolean pickLowestCost(final Space space, final NavPath navPath) {
        if (space == this) {
            return true;
        }
        if (this.links.size() == 0) {
            return false;
        }
        Link link = null;
        for (int i = 0; i < this.getLinkCount(); ++i) {
            final Link link2 = this.getLink(i);
            if (link == null || link2.getTarget().getCost() < link.getTarget().getCost()) {
                link = link2;
            }
        }
        navPath.push(link);
        return link.getTarget().pickLowestCost(space, navPath);
    }
    
    @Override
    public String toString() {
        return "[Space " + this.x + "," + this.y + " " + this.width + "," + this.height + "]";
    }
}
