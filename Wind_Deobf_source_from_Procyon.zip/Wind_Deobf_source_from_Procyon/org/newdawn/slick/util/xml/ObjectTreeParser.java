// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.xml;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import org.newdawn.slick.util.Log;
import java.io.InputStream;
import org.newdawn.slick.util.ResourceLoader;
import java.util.ArrayList;
import java.util.HashMap;

public class ObjectTreeParser
{
    public HashMap nameToClass;
    public String defaultPackage;
    public ArrayList ignored;
    public String addMethod;
    
    public ObjectTreeParser() {
        this.nameToClass = new HashMap();
        this.ignored = new ArrayList();
        this.addMethod = "add";
    }
    
    public ObjectTreeParser(final String defaultPackage) {
        this.nameToClass = new HashMap();
        this.ignored = new ArrayList();
        this.addMethod = "add";
        this.defaultPackage = defaultPackage;
    }
    
    public void addElementMapping(final String key, final Class value) {
        this.nameToClass.put(key, value);
    }
    
    public void addIgnoredElement(final String e) {
        this.ignored.add(e);
    }
    
    public void setAddMethodName(final String addMethod) {
        this.addMethod = addMethod;
    }
    
    public void setDefaultPackage(final String defaultPackage) {
        this.defaultPackage = defaultPackage;
    }
    
    public Object parse(final String s) throws SlickXMLException {
        return this.parse(s, ResourceLoader.getResourceAsStream(s));
    }
    
    public Object parse(final String s, final InputStream inputStream) throws SlickXMLException {
        return this.traverse(new XMLParser().parse(s, inputStream));
    }
    
    public Object parseOnto(final String s, final Object o) throws SlickXMLException {
        return this.parseOnto(s, ResourceLoader.getResourceAsStream(s), o);
    }
    
    public Object parseOnto(final String s, final InputStream inputStream, final Object o) throws SlickXMLException {
        return this.traverse(new XMLParser().parse(s, inputStream), o);
    }
    
    public Class getClassForElementName(final String s) {
        final Class clazz = this.nameToClass.get(s);
        if (clazz != null) {
            return clazz;
        }
        if (this.defaultPackage != null) {
            return Class.forName(this.defaultPackage + "." + s);
        }
        return null;
    }
    
    public Object traverse(final XMLElement xmlElement) throws SlickXMLException {
        return this.traverse(xmlElement, null);
    }
    
    public Object traverse(final XMLElement xmlElement, Object instance) throws SlickXMLException {
        final String name = xmlElement.getName();
        if (this.ignored.contains(name)) {
            return null;
        }
        Class<?> clazz;
        if (instance == null) {
            clazz = (Class<?>)this.getClassForElementName(name);
        }
        else {
            clazz = instance.getClass();
        }
        if (clazz == null) {
            throw new SlickXMLException("Unable to map element " + name + " to a class, define the mapping");
        }
        if (instance == null) {
            instance = clazz.newInstance();
            final Method method = this.getMethod(clazz, "setXMLElementName", new Class[] { String.class });
            if (method != null) {
                this.invoke(method, instance, new Object[] { name });
            }
            final Method method2 = this.getMethod(clazz, "setXMLElementContent", new Class[] { String.class });
            if (method2 != null) {
                this.invoke(method2, instance, new Object[] { xmlElement.getContent() });
            }
        }
        final String[] attributeNames = xmlElement.getAttributeNames();
        for (int i = 0; i < attributeNames.length; ++i) {
            final Method method3 = this.findMethod(clazz, "set" + attributeNames[i]);
            if (method3 == null) {
                final Field field = this.findField(clazz, attributeNames[i]);
                if (field != null) {
                    this.setField(field, instance, this.typeValue(xmlElement.getAttribute(attributeNames[i]), field.getType()));
                }
                else {
                    Log.info("Unable to find property on: " + clazz + " for attribute: " + attributeNames[i]);
                }
            }
            else {
                this.invoke(method3, instance, new Object[] { this.typeValue(xmlElement.getAttribute(attributeNames[i]), method3.getParameterTypes()[0]) });
            }
        }
        final XMLElementList children = xmlElement.getChildren();
        for (int j = 0; j < children.size(); ++j) {
            final Object traverse = this.traverse(children.get(j));
            if (traverse != null) {
                final Method method4 = this.findMethod(clazz, this.addMethod, traverse.getClass());
                if (method4 == null) {
                    Log.info("Unable to find method to add: " + traverse + " to " + clazz);
                }
                else {
                    this.invoke(method4, instance, new Object[] { traverse });
                }
            }
        }
        return instance;
    }
    
    public Object typeValue(final String s, Class mapPrimitive) throws SlickXMLException {
        if (mapPrimitive == String.class) {
            return s;
        }
        mapPrimitive = this.mapPrimitive(mapPrimitive);
        return mapPrimitive.getConstructor(String.class).newInstance(s);
    }
    
    public Class mapPrimitive(final Class obj) {
        if (obj == Integer.TYPE) {
            return Integer.class;
        }
        if (obj == Double.TYPE) {
            return Double.class;
        }
        if (obj == Float.TYPE) {
            return Float.class;
        }
        if (obj == Boolean.TYPE) {
            return Boolean.class;
        }
        if (obj == Long.TYPE) {
            return Long.class;
        }
        throw new RuntimeException("Unsupported primitive: " + obj);
    }
    
    public Field findField(final Class clazz, final String anotherString) {
        final Field[] declaredFields = clazz.getDeclaredFields();
        for (int i = 0; i < declaredFields.length; ++i) {
            if (declaredFields[i].getName().equalsIgnoreCase(anotherString)) {
                if (declaredFields[i].getType().isPrimitive()) {
                    return declaredFields[i];
                }
                if (declaredFields[i].getType() == String.class) {
                    return declaredFields[i];
                }
            }
        }
        return null;
    }
    
    public Method findMethod(final Class clazz, final String anotherString) {
        final Method[] declaredMethods = clazz.getDeclaredMethods();
        for (int i = 0; i < declaredMethods.length; ++i) {
            if (declaredMethods[i].getName().equalsIgnoreCase(anotherString)) {
                final Method method = declaredMethods[i];
                if (method.getParameterTypes().length == 1) {
                    return method;
                }
            }
        }
        return null;
    }
    
    public Method findMethod(final Class clazz, final String anotherString, final Class clazz2) {
        final Method[] declaredMethods = clazz.getDeclaredMethods();
        for (int i = 0; i < declaredMethods.length; ++i) {
            if (declaredMethods[i].getName().equalsIgnoreCase(anotherString)) {
                final Method method = declaredMethods[i];
                if (method.getParameterTypes().length == 1 && method.getParameterTypes()[0].isAssignableFrom(clazz2)) {
                    return method;
                }
            }
        }
        return null;
    }
    
    public void setField(final Field field, final Object obj, final Object value) throws SlickXMLException {
        field.setAccessible(true);
        field.set(obj, value);
        field.setAccessible(false);
    }
    
    public void invoke(final Method method, final Object obj, final Object[] args) throws SlickXMLException {
        method.setAccessible(true);
        method.invoke(obj, args);
        method.setAccessible(false);
    }
    
    public Method getMethod(final Class clazz, final String name, final Class[] parameterTypes) {
        return clazz.getMethod(name, (Class[])parameterTypes);
    }
}
