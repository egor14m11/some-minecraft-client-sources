// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.xml;

import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Element;

public class XMLElement
{
    public Element dom;
    public XMLElementList children;
    public String name;
    
    public XMLElement(final Element dom) {
        this.dom = dom;
        this.name = this.dom.getTagName();
    }
    
    public String[] getAttributeNames() {
        final NamedNodeMap attributes = this.dom.getAttributes();
        final String[] array = new String[attributes.getLength()];
        for (int i = 0; i < array.length; ++i) {
            array[i] = attributes.item(i).getNodeName();
        }
        return array;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getAttribute(final String s) {
        return this.dom.getAttribute(s);
    }
    
    public String getAttribute(final String s, final String s2) {
        final String attribute = this.dom.getAttribute(s);
        if (attribute == null || attribute.length() == 0) {
            return s2;
        }
        return attribute;
    }
    
    public int getIntAttribute(final String s) throws SlickXMLException {
        return Integer.parseInt(this.getAttribute(s));
    }
    
    public int getIntAttribute(final String s, final int i) throws SlickXMLException {
        return Integer.parseInt(this.getAttribute(s, "" + i));
    }
    
    public double getDoubleAttribute(final String s) throws SlickXMLException {
        return Double.parseDouble(this.getAttribute(s));
    }
    
    public double getDoubleAttribute(final String s, final double d) throws SlickXMLException {
        return Double.parseDouble(this.getAttribute(s, "" + d));
    }
    
    public boolean getBooleanAttribute(final String s) throws SlickXMLException {
        final String attribute = this.getAttribute(s);
        if (attribute.equalsIgnoreCase("true")) {
            return true;
        }
        if (attribute.equalsIgnoreCase("false")) {
            return false;
        }
        throw new SlickXMLException("Value read: '" + this.getAttribute(s) + "' is not a boolean");
    }
    
    public boolean getBooleanAttribute(final String s, final boolean b) throws SlickXMLException {
        final String attribute = this.getAttribute(s, "" + b);
        if (attribute.equalsIgnoreCase("true")) {
            return true;
        }
        if (attribute.equalsIgnoreCase("false")) {
            return false;
        }
        throw new SlickXMLException("Value read: '" + this.getAttribute(s, "" + b) + "' is not a boolean");
    }
    
    public String getContent() {
        String string = "";
        final NodeList childNodes = this.dom.getChildNodes();
        for (int i = 0; i < childNodes.getLength(); ++i) {
            if (childNodes.item(i) instanceof Text) {
                string += childNodes.item(i).getNodeValue();
            }
        }
        return string;
    }
    
    public XMLElementList getChildren() {
        if (this.children != null) {
            return this.children;
        }
        final NodeList childNodes = this.dom.getChildNodes();
        this.children = new XMLElementList();
        for (int i = 0; i < childNodes.getLength(); ++i) {
            if (childNodes.item(i) instanceof Element) {
                this.children.add(new XMLElement((Element)childNodes.item(i)));
            }
        }
        return this.children;
    }
    
    public XMLElementList getChildrenByName(final String anObject) {
        final XMLElementList list = new XMLElementList();
        final XMLElementList children = this.getChildren();
        for (int i = 0; i < children.size(); ++i) {
            if (children.get(i).getName().equals(anObject)) {
                list.add(children.get(i));
            }
        }
        return list;
    }
    
    @Override
    public String toString() {
        String s = "[XML " + this.getName();
        final String[] attributeNames = this.getAttributeNames();
        for (int i = 0; i < attributeNames.length; ++i) {
            s = s + " " + attributeNames[i] + "=" + this.getAttribute(attributeNames[i]);
        }
        return s + "]";
    }
}
