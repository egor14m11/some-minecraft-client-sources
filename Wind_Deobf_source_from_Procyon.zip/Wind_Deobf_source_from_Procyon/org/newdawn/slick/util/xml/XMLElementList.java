// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.xml;

import java.util.Collection;
import java.util.ArrayList;

public class XMLElementList
{
    public ArrayList list;
    
    public XMLElementList() {
        this.list = new ArrayList();
    }
    
    public void add(final XMLElement e) {
        this.list.add(e);
    }
    
    public int size() {
        return this.list.size();
    }
    
    public XMLElement get(final int index) {
        return this.list.get(index);
    }
    
    public boolean contains(final XMLElement o) {
        return this.list.contains(o);
    }
    
    public void addAllTo(final Collection collection) {
        collection.addAll(this.list);
    }
}
