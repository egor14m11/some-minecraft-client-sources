// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.util.xml;

import java.io.InputStream;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.util.ResourceLoader;
import javax.xml.parsers.DocumentBuilderFactory;

public class XMLParser
{
    public static DocumentBuilderFactory factory;
    
    public XMLElement parse(final String s) throws SlickException {
        return this.parse(s, ResourceLoader.getResourceAsStream(s));
    }
    
    public XMLElement parse(final String s, final InputStream is) throws SlickXMLException {
        if (XMLParser.factory == null) {
            XMLParser.factory = DocumentBuilderFactory.newInstance();
        }
        return new XMLElement(XMLParser.factory.newDocumentBuilder().parse(is).getDocumentElement());
    }
}
