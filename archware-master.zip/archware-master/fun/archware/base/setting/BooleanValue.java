package fun.archware.base.setting;


import fun.archware.base.module.Module;

public class BooleanValue extends Setting {
    public BooleanValue(String name, String id, Module parent, boolean value) {
        super(name, id, parent, value);
    }
}
