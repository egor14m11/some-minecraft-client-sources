package fun.archware.base.setting;

import fun.archware.base.module.Module;

import java.awt.*;

public class ColorPicker extends Setting {

    public ColorPicker(String name, String id, Module parent, Color selectedColor) {
        super(name, id, parent, selectedColor);
    }
}
