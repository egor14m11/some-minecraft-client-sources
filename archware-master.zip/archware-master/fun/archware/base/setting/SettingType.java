package fun.archware.base.setting;

public enum SettingType {
    Numeric, String, Boolean, Field, MultiString, Button, ColorPicker;
}
