package fun.archware.base.setting;


import fun.archware.base.module.Module;

public class StringValue extends Setting {
    public StringValue(String name, String id, Module parent, String value, String[] values) {
        super(name, id, parent, value, values);
    }
}
