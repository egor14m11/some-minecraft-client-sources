package fun.archware.base.skeetgui;

public class GUIElement {
    public void drawScreen(final int mouseX, final int mouseY){}
    public void mouseClicked(final int mouseX, final int mouseY, final int mouseButton){}
    public void keyTyped(final char typedChar, final int keyCode){}
}
