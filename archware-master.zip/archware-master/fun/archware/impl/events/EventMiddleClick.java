/*
 * Created with :heart: by katch.
 * (c) 4.23.2021
 */

package fun.archware.impl.events;

import fun.archware.base.event.Event;

public class EventMiddleClick extends Event {
}
