package fun.archware.impl.events;

import fun.archware.base.event.Event;

/**
 * Created by 1 on 01.04.2021.
 */
public class EventUpdate extends Event {
}
