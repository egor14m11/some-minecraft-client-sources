package fun.archware.impl.modules.combat;

import fun.archware.base.module.Category;
import fun.archware.base.module.Module;

public class ShieldBreaker extends Module {
    public ShieldBreaker() {
        super("ShieldBreaker", Category.COMBAT);
    }
}
