package fun.archware.impl.modules.misc;

import fun.archware.base.module.Category;
import fun.archware.base.module.Module;

public class ModuleSound extends Module {
    public ModuleSound() {
        super("ModuleSound", Category.MISC);
    }
}
