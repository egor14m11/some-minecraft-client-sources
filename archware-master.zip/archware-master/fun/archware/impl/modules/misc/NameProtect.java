package fun.archware.impl.modules.misc;

import fun.archware.base.module.Category;
import fun.archware.base.module.Module;

public class NameProtect extends Module {
    public NameProtect() {
        super("NameProtect", Category.MISC);
    }
}
