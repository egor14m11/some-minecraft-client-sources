package fun.archware.impl.modules.render;

import fun.archware.base.module.Category;
import fun.archware.base.module.Module;

public class CustomHotbar extends Module {
    public CustomHotbar() {
        super("CustomHotbar", Category.RENDER);
    }
}
