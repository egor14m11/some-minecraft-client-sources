package fun.archware.impl.modules.render;

import fun.archware.base.module.Category;
import fun.archware.base.module.Module;

public class ItemPhysics extends Module {
    public ItemPhysics() {
        super("ItemPhysics", Category.RENDER);
    }
}
