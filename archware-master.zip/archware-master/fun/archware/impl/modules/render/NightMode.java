package fun.archware.impl.modules.render;

import fun.archware.base.event.EventTarget;
import fun.archware.base.module.Category;
import fun.archware.base.module.Module;

public class NightMode extends Module {
    public NightMode() {
        super("NightMode", Category.RENDER);
    }


}
