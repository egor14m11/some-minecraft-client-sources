/*
 * Created with :heart: by katch.
 * (c) 4.25.2021
 */

package fun.archware.impl.modules.render;

import fun.archware.base.module.Category;
import fun.archware.base.module.Module;

public class NoScoreboard extends Module {
    public NoScoreboard() {
        super("NoScoreboard", Category.RENDER);
    }
}
