package fun.archware.impl.modules.render;

import fun.archware.base.module.Category;
import fun.archware.base.module.Module;

public class SmoothCamera extends Module {
    public SmoothCamera() {
        super("SmoothCamera", Category.RENDER);
    }
}
