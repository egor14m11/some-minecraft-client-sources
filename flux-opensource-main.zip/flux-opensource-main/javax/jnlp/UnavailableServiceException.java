

package javax.jnlp;

public class UnavailableServiceException extends Exception {

  public UnavailableServiceException() {
    super();
  }

  public UnavailableServiceException(String message) {
    super(message);
  }

}

