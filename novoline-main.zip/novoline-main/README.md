# Team Khonsari & Friends present the Novoline Opensource Project
![alt text](https://cdn.discordapp.com/attachments/826624228458496010/907852691676491776/unknown.png)
![alt text](https://cdn.discordapp.com/attachments/884669714654187570/912818948007952414/Screen_Shot_2021-11-23_at_1.png)

## Credits
Aidan - Providing the base jar for the initial remap\
skidunion - Providing the old novoline jar to help create mappings for the new version\
TEAM KHONSARI - Creating the mappings used for this project

## NOTE
This branch is NOT compilable! Visit the eclipse-ready branch to compile the client yourself.


## Another Note
I think the dude who originally had this up got the gh dmca claimed and then got doxxed lol
Sounds quite "tasty" lol
