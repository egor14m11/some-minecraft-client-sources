package cc.novoline.events.events;

import cc.novoline.events.events.Event;

public class AttackEvent implements Event {
}
