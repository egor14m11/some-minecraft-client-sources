package cc.novoline.events.events;

public interface Cancellable {
   boolean isCancelled();

   void setCancelled(boolean var1);
}
