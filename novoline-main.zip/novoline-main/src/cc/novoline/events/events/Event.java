package cc.novoline.events.events;

public interface Event {
}
