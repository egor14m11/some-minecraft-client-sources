package cc.novoline.events.events;

public enum MotionUpdateEvent$State {
   PRE,
   POST;

   private static final MotionUpdateEvent$State[] $VALUES = new MotionUpdateEvent$State[]{PRE, POST};
}
