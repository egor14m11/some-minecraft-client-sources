package cc.novoline.events.events;

import net.aSv;

@aSv
public enum PacketEvent$State {
   INCOMING,
   OUTGOING;

   private static final PacketEvent$State[] $VALUES = new PacketEvent$State[]{INCOMING, OUTGOING};
}
