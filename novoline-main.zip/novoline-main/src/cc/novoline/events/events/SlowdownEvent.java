package cc.novoline.events.events;

import cc.novoline.events.events.callables.CancellableEvent;

public class SlowdownEvent extends CancellableEvent {
}
