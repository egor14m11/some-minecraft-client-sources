package cc.novoline.events.events;

import cc.novoline.events.events.Event;

public class TickUpdateEvent implements Event {
}
