package cc.novoline.events.events;

public interface Typed {
   byte getType();
}
