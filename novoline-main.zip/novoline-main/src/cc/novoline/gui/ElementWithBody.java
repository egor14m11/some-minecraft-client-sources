package cc.novoline.gui;

public interface ElementWithBody {
   boolean isHovered(int var1, int var2);

   int getWidth();

   void setWidth(int var1);

   int getHeight();

   void setHeight(int var1);
}
