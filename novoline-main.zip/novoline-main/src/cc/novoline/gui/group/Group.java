package cc.novoline.gui.group;

import cc.novoline.gui.label.Label;

public interface Group {
   Label getTitle();
}
