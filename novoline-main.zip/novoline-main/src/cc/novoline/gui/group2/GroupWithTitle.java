package cc.novoline.gui.group2;

import cc.novoline.gui.group2.Group;
import cc.novoline.gui.label.Label;

public interface GroupWithTitle extends Group {
   Label getTitle();

   void setTitle(Label var1);
}
