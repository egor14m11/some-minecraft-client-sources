package cc.novoline.gui.screen.config;

import cc.novoline.gui.screen.click.Scroll;

// $FF: synthetic class
class ConfigMenu$1 {
   static final int[] $SwitchMap$cc$novoline$gui$screen$click$Scroll = new int[Scroll.values().length];

   static {
      try {
         $SwitchMap$cc$novoline$gui$screen$click$Scroll[Scroll.DOWN.ordinal()] = 1;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$click$Scroll[Scroll.UP.ordinal()] = 2;
      } catch (NoSuchFieldError var1) {
         ;
      }

   }
}
