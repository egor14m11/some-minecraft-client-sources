package cc.novoline.gui.screen.setting;

import cc.novoline.gui.screen.setting.Setting$ColorPickerMode;
import cc.novoline.gui.screen.setting.SettingType;

// $FF: synthetic class
class Setting$1 {
   static final int[] $SwitchMap$cc$novoline$gui$screen$setting$Setting$ColorPickerMode;
   static final int[] $SwitchMap$cc$novoline$gui$screen$setting$SettingType = new int[SettingType.values().length];

   static {
      try {
         $SwitchMap$cc$novoline$gui$screen$setting$SettingType[SettingType.BINDABLE.ordinal()] = 1;
      } catch (NoSuchFieldError var10) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$SettingType[SettingType.COMBOBOX.ordinal()] = 2;
      } catch (NoSuchFieldError var9) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$SettingType[SettingType.SELECTBOX.ordinal()] = 3;
      } catch (NoSuchFieldError var8) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$SettingType[SettingType.CHECKBOX.ordinal()] = 4;
      } catch (NoSuchFieldError var7) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$SettingType[SettingType.SLIDER.ordinal()] = 5;
      } catch (NoSuchFieldError var6) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$SettingType[SettingType.TEXTBOX.ordinal()] = 6;
      } catch (NoSuchFieldError var5) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$SettingType[SettingType.COLOR_PICKER.ordinal()] = 7;
      } catch (NoSuchFieldError var4) {
         ;
      }

      $SwitchMap$cc$novoline$gui$screen$setting$Setting$ColorPickerMode = new int[Setting$ColorPickerMode.values().length];

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$Setting$ColorPickerMode[Setting$ColorPickerMode.HUE.ordinal()] = 1;
      } catch (NoSuchFieldError var3) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$Setting$ColorPickerMode[Setting$ColorPickerMode.SATURATION.ordinal()] = 2;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$gui$screen$setting$Setting$ColorPickerMode[Setting$ColorPickerMode.BRIGHTNESS.ordinal()] = 3;
      } catch (NoSuchFieldError var1) {
         ;
      }

   }
}
