package cc.novoline.gui.screen.setting;

public enum Setting$ColorPickerMode {
   HUE,
   SATURATION,
   BRIGHTNESS;

   private static final Setting$ColorPickerMode[] $VALUES = new Setting$ColorPickerMode[]{HUE, SATURATION, BRIGHTNESS};
}
