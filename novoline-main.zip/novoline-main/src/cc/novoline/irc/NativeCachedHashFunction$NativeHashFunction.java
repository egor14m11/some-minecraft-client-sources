package cc.novoline.irc;

import cc.novoline.irc.NativeCachedHashFunction$1;
import net.skidunion.p;

class NativeCachedHashFunction$NativeHashFunction {
   private NativeCachedHashFunction$NativeHashFunction() {
   }

   public String a(String var1) {
      return p.b.b(Integer.toBinaryString(var1.hashCode()));
   }

   NativeCachedHashFunction$NativeHashFunction(NativeCachedHashFunction$1 var1) {
      this();
   }
}
