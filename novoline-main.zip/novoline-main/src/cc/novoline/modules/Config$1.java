package cc.novoline.modules;

import cc.novoline.modules.Config;
import com.google.common.reflect.TypeToken;

class Config$1 extends TypeToken {
   final Config this$0;

   Config$1(Config var1) {
      this.this$0 = var1;
   }
}
