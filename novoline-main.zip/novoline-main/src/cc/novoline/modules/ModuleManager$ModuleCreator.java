package cc.novoline.modules;

import cc.novoline.modules.AbstractModule;
import cc.novoline.modules.ModuleManager;
import org.jetbrains.annotations.NotNull;

public interface ModuleManager$ModuleCreator {
   @NotNull
   AbstractModule create(@NotNull ModuleManager var1);
}
