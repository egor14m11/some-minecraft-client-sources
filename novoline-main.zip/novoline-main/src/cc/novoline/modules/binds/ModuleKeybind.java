package cc.novoline.modules.binds;

public interface ModuleKeybind {
   int getKey();
}
