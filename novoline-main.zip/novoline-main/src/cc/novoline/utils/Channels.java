package cc.novoline.utils;

public enum Channels {
   ALL,
   PARTY,
   PM,
   GUILD;
}
