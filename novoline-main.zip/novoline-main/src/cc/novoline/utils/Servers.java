package cc.novoline.utils;

public enum Servers {
   SW,
   BW,
   UHC,
   SG,
   MW,
   PRE,
   DUELS,
   PIT,
   NONE,
   LOBBY,
   MM;
}
