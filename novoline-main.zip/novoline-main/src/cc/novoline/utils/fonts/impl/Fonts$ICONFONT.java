package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontFamily;
import cc.novoline.utils.fonts.api.FontType;
import cc.novoline.utils.fonts.impl.Fonts;

public interface Fonts$ICONFONT {
   FontFamily ICONFONT = Fonts.FONT_MANAGER.fontFamily(FontType.ICONFONT);
}
