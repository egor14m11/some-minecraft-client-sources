package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import net.afb;

public final class Fonts$OXIDE$OXIDE_18 {
   public static final FontRenderer OXIDE_18 = afb.a.ofSize(18);
}
