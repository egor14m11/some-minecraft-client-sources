package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$SFBOLD;

public final class Fonts$SFBOLD$SFBOLD_12 {
   public static final FontRenderer SFBOLD_12 = Fonts$SFBOLD.SFBOLD.ofSize(12);
}
