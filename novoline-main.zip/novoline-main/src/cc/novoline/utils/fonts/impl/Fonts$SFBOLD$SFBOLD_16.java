package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$SFBOLD;

public final class Fonts$SFBOLD$SFBOLD_16 {
   public static final FontRenderer SFBOLD_16 = Fonts$SFBOLD.SFBOLD.ofSize(16);
}
