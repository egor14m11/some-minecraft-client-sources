package cc.novoline.utils.fonts.impl;

import cc.novoline.utils.fonts.api.FontRenderer;
import cc.novoline.utils.fonts.impl.Fonts$SFBOLD;

public final class Fonts$SFBOLD$SFBOLD_22 {
   public static final FontRenderer SFBOLD_22 = Fonts$SFBOLD.SFBOLD.ofSize(22);
}
