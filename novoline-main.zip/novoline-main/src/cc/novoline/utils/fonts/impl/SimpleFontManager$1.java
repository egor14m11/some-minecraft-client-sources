package cc.novoline.utils.fonts.impl;

// $FF: synthetic class
class SimpleFontManager$1 {
}
