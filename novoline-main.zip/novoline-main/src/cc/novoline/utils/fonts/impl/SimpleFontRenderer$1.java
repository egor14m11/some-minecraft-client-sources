package cc.novoline.utils.fonts.impl;

// $FF: synthetic class
class SimpleFontRenderer$1 {
}
