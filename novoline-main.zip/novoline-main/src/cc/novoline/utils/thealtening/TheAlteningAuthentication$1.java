package cc.novoline.utils.thealtening;

import cc.novoline.utils.thealtening.service.AlteningServiceType;

// $FF: synthetic class
class TheAlteningAuthentication$1 {
   static final int[] $SwitchMap$cc$novoline$utils$thealtening$service$AlteningServiceType = new int[AlteningServiceType.values().length];

   static {
      try {
         $SwitchMap$cc$novoline$utils$thealtening$service$AlteningServiceType[AlteningServiceType.MOJANG.ordinal()] = 1;
      } catch (NoSuchFieldError var2) {
         ;
      }

      try {
         $SwitchMap$cc$novoline$utils$thealtening$service$AlteningServiceType[AlteningServiceType.THEALTENING.ordinal()] = 2;
      } catch (NoSuchFieldError var1) {
         ;
      }

   }
}
