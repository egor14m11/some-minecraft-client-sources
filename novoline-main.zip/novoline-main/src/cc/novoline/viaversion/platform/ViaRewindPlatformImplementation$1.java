package cc.novoline.viaversion.platform;

import net.NO;
import net.bY;
import viaversion.viarewind.api.ViaRewindConfig;

class ViaRewindPlatformImplementation$1 implements ViaRewindConfig {
   final NO a;

   ViaRewindPlatformImplementation$1(NO var1) {
      this.a = var1;
   }

   public bY a() {
      return bY.TITLE;
   }

   public boolean isReplaceAdventureMode() {
      return true;
   }

   public boolean isReplaceParticles() {
      return true;
   }
}
