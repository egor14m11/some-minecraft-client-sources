package com.viaversion.viabackwards.api.entities.storage;

import com.viaversion.viabackwards.api.entities.storage.WrappedMetadata;

@FunctionalInterface
public interface EntityData$MetaCreator {
   void createMeta(WrappedMetadata var1);
}
